"""Independent CPU-double whole-MLP JVP check for the staged surgery endpoints."""
import itertools
import torch
from torch import nn
from mlp_primitive_factorial_224 import surgery

torch.manual_seed(224)
class Norm(nn.Module):
    def __init__(self):
        super().__init__();self.weight=nn.Parameter(torch.rand(7,dtype=torch.float64)+.4);self.variance_epsilon=1e-6
    def forward(self,s):return self.weight*s*torch.rsqrt(s.square().mean(-1,keepdim=True)+self.variance_epsilon)
class MLP(nn.Module):
    def __init__(self):
        super().__init__();self.gate_proj=nn.Linear(7,11,bias=False,dtype=torch.float64);self.up_proj=nn.Linear(7,11,bias=False,dtype=torch.float64);self.down_proj=nn.Linear(11,7,bias=False,dtype=torch.float64);self.act_fn=nn.SiLU()
    def forward(self,z):return self.down_proj(self.act_fn(self.gate_proj(z))*self.up_proj(z))
class Layer(nn.Module):
    def __init__(self):super().__init__();self.post_attention_layernorm=Norm();self.mlp=MLP()
    def forward(self,s):return self.mlp(self.post_attention_layernorm(s))

layer=Layer();start=3;s0=torch.randn(1,8,7,dtype=torch.float64);s1=s0+.7*torch.randn_like(s0)
with torch.no_grad():
    z=layer.post_attention_layernorm(s0);g=layer.mlp.gate_proj(z);u=layer.mlp.up_proj(z);phi=layer.mlp.act_fn(g)
    c={k:v[0,start:].clone() for k,v in dict(s=s0,inv=torch.rsqrt(s0.square().mean(-1,keepdim=True)+1e-6),gate=g,up=u,phi=phi,sigma=torch.sigmoid(g),normalized=z,product=phi*u,write=layer(s0)).items()}
    native=layer(s1)
primal,jvp=torch.func.jvp(layer,(s0,),(s1-s0,));errs={}
for bits in itertools.product('LF',repeat=3):
    mode=''.join(bits)
    with surgery(layer,c,start,mode):
        with torch.no_grad():actual=layer(s1)
    assert torch.equal(actual[:,:start],native[:,:start])
    if mode=='FFF':errs[mode]=float((actual-native).abs().max())
    if mode=='LLL':errs[mode]=float((actual[:,start:]-primal[:,start:]-jvp[:,start:]).abs().max())
    assert torch.isfinite(actual).all()
assert max(errs.values())<1e-12,errs
with surgery(layer,c,start,'LLL'):
    with torch.no_grad():sham=layer(s0)
assert torch.max(abs(sham-primal))<1e-12
print(dict(double_endpoint_errors=errs,all_eight_modes_finite=True,prefix_source_unchanged=True,False_sham_max=float((sham-primal).abs().max())))
