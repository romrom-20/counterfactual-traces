"""Independent saved-array crossing/range/accuracy audit218."""
import json,hashlib
from pathlib import Path
import numpy as np
R=Path(__file__).resolve().parents[1];RUN=R/'runs/silu-range-falsification-218';OUT=R/'docs/analysis/218-silu-range-falsification-audit.json'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def margin(a):return float(a[1]-a[0])
def metric(pred,actual):
 n=np.linalg.norm(actual);pn=np.linalg.norm(pred);q=float(np.linalg.norm(pred-actual)/n);cos=float(pred.ravel()@actual.ravel()/(pn*n)) if pn*n else None;return dict(relative_l2=q,cosine=cos,native_norm=float(n))
def main():
 assert not OUT.exists();design=json.loads((RUN/'design.json').read_text());p=json.loads((R/'docs/analysis/218-silu-range-falsification.json').read_text());assert all(sha(R/f)==h for f,h in design['source_hashes'].items());assert p['counts']==dict(finite_heads=1088,blocks=768,reverse_heads=64)
 for path,key in [('runs/source-receiver-partition-208/runtime.json','runtime_sha256'),('docs/analysis/215-matched-incoming-control.json','parent215_audit_sha256'),('docs/analysis/213-gate-up-arithmetic-audit.json','parent213_audit_sha256')]:assert sha(R/path)==design[key]
 rows=[];checks=[];local=[];maxclosure=0.
 for path in sorted((RUN/'pairs').glob('*.npz')):
  row=json.loads(path.with_suffix('.json').read_text());assert sha(path)==row['arrays_sha256'];assert sha(R/'runs/matched-incoming-control-215/pairs'/path.name)==row['parent215_sha256'];assert sha(R/'runs/source-receiver-partition-208/forecasts'/path.name)==row['parent208_sha256'];checks.extend(row['checks']);local.extend(row['local_checks'])
  with np.load(path) as z:
   assert all(np.isfinite(a).all() for a in z.values());actual=z['true_final'].astype(np.float64)-z['false_final'];target=margin(z['true_scores']-z['false_scores']);endpoints={}
   for branch in ['native','predicted']:
    for arm in ['LL','LF','FL','FF']:
     key=branch+'_'+arm;pred=z[key+'_state'].astype(np.float64)-z['false_final'];scores=z[key+'_scores']-z['false_scores'];m=metric(pred[-1:],actual[-1:]);error=abs(margin(scores)-target);endpoints[key]=dict(verdict=m,absolute_margin_error=error,primary_pass=bool(m['native_norm']>=.001 and m['relative_l2']<=.05 and m['cosine'] is not None and m['cosine']>=.99 and error<=.1))
   for case in row['cases']:
    b,s=case['branch'],case['silu'];pre=b+'_'+s;effect=z[b+'_'+s+'F_state'].astype(np.float64)-z[b+'_'+s+'L_state'].astype(np.float64);assert np.max(abs(effect-z[pre+'_finite_effect']))<=1e-4
    closure=float(np.max(abs(effect-z[pre+'_mixed']-z[pre+'_product_rounding']-z[pre+'_down_rounding']-z[pre+'_residual_rounding'])));assert closure<=1e-4;maxclosure=max(maxclosure,closure)
    d=effect.copy();d[0]=0;expected=(z['false_final'].astype(np.float64)+d).astype(np.float32);assert np.max(abs(expected-z[pre+'_common_state']))==0
    natural=margin(z[b+'_'+s+'F_scores'])-margin(z[b+'_'+s+'L_scores']);common=margin(z[pre+'_common_scores'])-margin(z['false_scores']);assert abs(natural-case['natural_margin_change'])<=1e-12 and abs(common-case['common_margin_change'])<=1e-12
    assert abs(float(z['closed_gradient']@d[-1])-case['initial_projection'])<=1e-10
    phi=z[b+'_'+s+'F_phi'];u=z[b+'_'+s+'F_up']
    for region,sl in [('source',slice(0,1)),('receivers',slice(1,None)),('verdict',slice(-1,None)),('causal_suffix',slice(None))]:
     a,v=phi[sl],u[sl];r=case['regimes'][region];assert int((a<design['silu_minimum']-1e-4).sum())==r['below_silu_minimum_guard'];assert int(((a<0)&(v<0)).sum())==r['negative_negative'];assert float(a.min())==r['minimum_phi']
    a,before=endpoints[b+'_'+s+'F'],endpoints[b+'_'+s+'L'];rows.append(dict(key=row['key'],group=row['group'],**case,endpoints={arm:endpoints[b+'_'+arm] for arm in ['LL','LF','FL','FF']},product_both_improve=bool(a['verdict']['relative_l2']<before['verdict']['relative_l2'] and a['absolute_margin_error']<before['absolute_margin_error'])))
 assert len(rows)==256 and len(local)==3840 and len([c for c in checks if c['kind']=='gradient_contraction'])==256 and len([c for c in checks if c['kind']=='gradient_coordinate'])==64;assert all(c['error']<=c['bound'] for c in checks) and all(c['passed'] for c in local)
 summaries=[]
 for b in ['native','predicted']:
  for s in ['L','F']:
   q=[r for r in rows if r['branch']==b and r['silu']==s];summaries.append(dict(branch=b,silu=s,count=len(q),natural_positive=sum(r['natural_margin_change']>0 for r in q),common_positive=sum(r['common_margin_change']>0 for r in q),median_natural_margin_change=float(np.median([r['natural_margin_change'] for r in q])),median_common_margin_change=float(np.median([r['common_margin_change'] for r in q])),product_both_improve=sum(r['product_both_improve'] for r in q),contexts_below_silu_minimum=sum(r['regimes']['receivers']['below_silu_minimum_guard']>0 for r in q),receiver_coordinates_below_minimum=sum(r['regimes']['receivers']['below_silu_minimum_guard'] for r in q),minimum_phi=min(r['regimes']['receivers']['minimum_phi'] for r in q),raw_mixed_failures=sum(r['errors']['finite_effect_vs_mixed']>1e-4 for r in q),endpoints={a:dict(primary_passes=sum(r['endpoints'][a]['primary_pass'] for r in q),median_verdict_relative_l2=float(np.median([r['endpoints'][a]['verdict']['relative_l2'] for r in q])),median_margin_error=float(np.median([r['endpoints'][a]['absolute_margin_error'] for r in q]))) for a in ['LL','LF','FL','FF']}))
 signs={}
 for s in ['L','F']:
  n={r['key']:r for r in rows if r['branch']=='native' and r['silu']==s};f={r['key']:r for r in rows if r['branch']=='predicted' and r['silu']==s};signs[s]={kind:sum(np.sign(n[k][kind])!=np.sign(f[k][kind]) for k in n) for kind in ['natural_margin_change','common_margin_change']}
 out=dict(qualified=True,cases=64,conditions=256,controls=len(checks),local_derivative_checks=len(local),counts=p['counts'],maximum_local_derivative_error=max(c['coordinate_error'] for c in local),maximum_gradient_coordinate_error=max(c['error'] for c in checks if c['kind']=='gradient_coordinate'),maximum_gradient_contraction_error=max(c['error'] for c in checks if c['kind']=='gradient_contraction'),maximum_saved_rounding_closure=maxclosure,silu_minimum=design['silu_minimum'],summaries=summaries,native_predicted_sign_disagreements=signs,rows=rows,auditor_sha256=sha(Path(__file__)),report_sha256=sha(R/'docs/analysis/218-silu-range-falsification.json'),original_wholeblock_jacobian_qualified=False,limits=p['limits'])
 OUT.write_text(json.dumps(out,indent=2,default=lambda x:x.item() if isinstance(x,np.generic) else str(x)));print({k:v for k,v in out.items() if k!='rows'})
if __name__=='__main__':main()
