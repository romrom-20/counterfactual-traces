"""Frozen MPS float32 primal graph; analytic CPU float64 tangent operator."""
import torch
from torch.nn import functional as F
from transformers.models.qwen2 import modeling_qwen2 as qwen


def trace(layer, x, context):
    a, m = layer.self_attn, layer.mlp
    c = {}
    with torch.no_grad():
        c['x'] = x
        c['input_rms_r'] = torch.rsqrt(x.float().square().mean(-1, keepdim=True) + layer.input_layernorm.variance_epsilon)
        n = c['input_rms'] = layer.input_layernorm(x)
        shape = (*x.shape[:-1], -1, a.head_dim)
        q,k,v = [p(n).view(shape).transpose(1,2) for p in (a.q_proj,a.k_proj,a.v_proj)]
        q,k = qwen.apply_rotary_pos_emb(q,k,*context['rope'])
        k,v = [qwen.repeat_kv(z,a.num_key_value_groups) for z in (k,v)]
        c.update(q=q,k=k,v=v)
        z = c['qk_product'] = (q@k.transpose(2,3))*a.scaling
        p = c['softmax'] = F.softmax(z+context['mask'], -1, dtype=torch.float32).to(q.dtype)
        av = c['weight_value'] = p@v
        at = c['attention'] = a.o_proj(av.transpose(1,2).contiguous().reshape(x.shape))
        mid = c['mid'] = x+at
        c['post_rms_r'] = torch.rsqrt(mid.float().square().mean(-1,keepdim=True)+layer.post_attention_layernorm.variance_epsilon)
        mn = c['post_rms'] = layer.post_attention_layernorm(mid)
        g,u = m.gate_proj(mn),m.up_proj(mn)
        phi = m.act_fn(g)
        product = phi*u
        mout = m.down_proj(product)
        c.update(gate=g,up=u,silu=phi,gate_up=product,mlp=mout,output=mid+mout, sigmoid=torch.sigmoid(g))
        c = {k:v.detach().cpu().double() for k,v in c.items()}
        c['weights']={name:p.weight.detach().cpu().double() for name,p in [('q',a.q_proj),('k',a.k_proj),('v',a.v_proj),('o',a.o_proj),('gate',m.gate_proj),('up',m.up_proj),('down',m.down_proj),('input_rms',layer.input_layernorm),('post_rms',layer.post_attention_layernorm)]}
        c['rope']=tuple(v.detach().cpu().double() for v in context['rope'])
        c.update(shape=shape,groups=a.num_key_value_groups,scaling=a.scaling)
    return c


def tangent(c, direction):
    d=direction.detach().cpu().double(); w=c['weights']; out={'input':d}
    def norm(x,dx,r,weight):
        return weight*r*(dx-x*r.square()*(x*dx).mean(-1,keepdim=True))
    dn=out['input_rms']=norm(c['x'],d,c['input_rms_r'],w['input_rms'])
    dq,dk,dv=[F.linear(dn,w[k]).view(c['shape']).transpose(1,2) for k in ['q','k','v']]
    dq,dk=qwen.apply_rotary_pos_emb(dq,dk,*c['rope'])
    dk,dv=[qwen.repeat_kv(z,c['groups']) for z in (dk,dv)]
    out.update(q=dq,k=dk,v=dv)
    dz=out['qk_product']=(dq@c['k'].transpose(2,3)+c['q']@dk.transpose(2,3))*c['scaling']
    dp=out['softmax']=c['softmax']*(dz-(c['softmax']*dz).sum(-1,keepdim=True))
    dav=out['weight_value']=dp@c['v']+c['softmax']@dv
    da=out['attention']=F.linear(dav.transpose(1,2).contiguous().reshape(c['x'].shape),w['o'])
    dm=out['mid']=d+da
    dmn=out['post_rms']=norm(c['mid'],dm,c['post_rms_r'],w['post_rms'])
    dg,du=F.linear(dmn,w['gate']),F.linear(dmn,w['up'])
    ds=out['silu']=c['sigmoid']*(1+c['gate']*(1-c['sigmoid']))*dg
    out.update(gate=dg,up=du)
    prod=out['gate_up']=ds*c['up']+c['silu']*du
    mout=out['mlp']=F.linear(prod,w['down'])
    out['output']=dm+mout
    return out['output'],out
