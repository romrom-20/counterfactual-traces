"""Actual MPS primitives and independent CPU64 product-rounding accounting."""
from contextlib import contextmanager
import torch
from torch.nn import functional as F

@contextmanager
def capture(layer):
 c={};hs=[]
 def save(name):
  def hook(module,args,out):c[name]=out.detach().cpu().double().clone()
  return hook
 def before(name):
  def hook(module,args):c[name]=args[0].detach().cpu().double().clone()
  return hook
 hs.extend([layer.mlp.act_fn.register_forward_hook(save('phi')),layer.mlp.up_proj.register_forward_hook(save('up')),layer.mlp.down_proj.register_forward_pre_hook(before('product')),layer.mlp.down_proj.register_forward_hook(save('down')),layer.post_attention_layernorm.register_forward_pre_hook(before('mid'))])
 try:yield c
 finally:
  for h in hs:h.remove()

def decompose(c,finite,affine):
 phi0,u0=c['silu'],c['up'];dp=finite['phi']-phi0;du=finite['up']-u0;w=c['weights']['down']
 gate,up,mixed=dp*u0,phi0*du,dp*du
 finite_round=finite['product']-finite['phi']*finite['up']
 false_round=c['gate_up']-phi0*u0
 affine_round=affine['product']-(c['gate_up']+gate+up)
 product_numerical=finite_round-false_round-affine_round
 project=lambda a:F.linear(a,w)
 down_round=(finite['down']-project(finite['product']))-(affine['down']-project(affine['product']))
 residual_round=(finite['output']-finite['mid']-finite['down'])-(affine['output']-affine['mid']-affine['down'])
 effect=finite['output']-affine['output'];jm=project(mixed)
 vectors={'gate_branch':project(gate),'up_branch':project(up),'mixed':jm,'product_rounding':project(product_numerical),'down_rounding':down_round,'residual_rounding':residual_round,'finite_effect':effect,'mixed_discrepancy':effect-jm}
 errors={'pure_product_identity':float((finite['phi']*finite['up']-phi0*u0-gate-up-mixed).abs().max()),'actual_product_change_identity':float((finite['product']-c['gate_up']-gate-up-mixed-finite_round+false_round).abs().max()),'matched_parent_identity':max(float((finite[k]-affine[k]).abs().max()) for k in ['phi','up','mid']),'finite_effect_vs_mixed':float((effect-jm).abs().max()),'numerical_discrepancy_closure':float((effect-jm-vectors['product_rounding']-down_round-residual_round).abs().max())}
 return vectors,errors
