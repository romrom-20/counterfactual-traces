"""FrozenFalse local analytic derivatives for arbitrary actual parent displacements."""
PARENTS={'input_rms':('x',),'qk_product':('q','k'),'softmax':('qk_product',),'weight_value':('softmax','v'),'post_rms':('mid',),'silu':('gate',),'gate_up':('silu','up')}
def local(c,name,parentdeltas):
 d=tuple(x.detach().cpu().double() for x in parentdeltas)
 if name in ['input_rms','post_rms']:
  x=c['x' if name=='input_rms' else 'mid'];r=c[name+'_r'];return c['weights'][name]*r*(d[0]-x*r.square()*(x*d[0]).mean(-1,keepdim=True))
 if name=='qk_product':return (d[0]@c['k'].transpose(2,3)+c['q']@d[1].transpose(2,3))*c['scaling']
 if name=='softmax':return c['softmax']*(d[0]-(c['softmax']*d[0]).sum(-1,keepdim=True))
 if name=='weight_value':return d[0]@c['v']+c['softmax']@d[1]
 if name=='silu':return c['sigmoid']*(1+c['gate']*(1-c['sigmoid']))*d[0]
 if name=='gate_up':return d[0]*c['up']+c['silu']*d[1]
 raise KeyError(name)
