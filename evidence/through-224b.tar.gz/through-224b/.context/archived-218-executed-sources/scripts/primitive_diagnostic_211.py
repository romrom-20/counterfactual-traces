"""Frozen-operator budget and actual public-block affine primitive surgeries."""

from contextlib import contextmanager

import torch
from local_primitive_derivative_210c import PARENTS, local
from torch.nn import functional as F
from transformers.models.qwen2 import modeling_qwen2 as qwen

GROUPS = dict(
    attention_norm_routing=("input_rms", "qk_product", "softmax"),
    value_output_interaction=("weight_value",),
    mlp_input_rms=("post_rms",),
    silu_curvature=("silu",),
    gate_up_interaction=("gate_up",),
)
LESIONS = {**GROUPS, **{name: (name,) for name in ("input_rms", "qk_product", "softmax")}}
NODES = (
    "input_rms",
    "q",
    "k",
    "v",
    "qk_product",
    "softmax",
    "weight_value",
    "attention",
    "mid",
    "post_rms",
    "gate",
    "up",
    "silu",
    "gate_up",
    "mlp",
    "output",
)


def graph(c, direction, injections=None):
    """The same frozenFalse linear graph, with optional additive node injections."""
    inj = injections or {}
    out = {"x": direction.detach().cpu().double()}
    w = c["weights"]
    pos = c.get("position", 0)

    def linear_rows(value, weight):
        if pos and torch.count_nonzero(value[:, :pos]) == 0:
            result = torch.zeros((*value.shape[:-1], weight.shape[0]), dtype=value.dtype)
            result[:, pos:] = F.linear(value[:, pos:], weight)
            return result
        return F.linear(value, weight)

    def put(name, value):
        out[name] = value + inj.get(name, 0.0)
        return out[name]

    dn = put("input_rms", local(c, "input_rms", (out["x"],)))
    dq, dk, dv = [linear_rows(dn, w[k]).view(c["shape"]).transpose(1, 2) for k in ("q", "k", "v")]
    dq, dk = qwen.apply_rotary_pos_emb(dq, dk, *c["rope"])
    dk, dv = [qwen.repeat_kv(v, c["groups"]) for v in (dk, dv)]
    for name, value in zip(("q", "k", "v"), (dq, dk, dv)):
        put(name, value)
    dz = put("qk_product", local(c, "qk_product", (out["q"], out["k"])))
    dp = put("softmax", local(c, "softmax", (dz,)))
    dav = put("weight_value", local(c, "weight_value", (dp, out["v"])))
    da = put(
        "attention", linear_rows(dav.transpose(1, 2).contiguous().reshape(c["x"].shape), w["o"])
    )
    mid = put("mid", out["x"] + da)
    mn = put("post_rms", local(c, "post_rms", (mid,)))
    dg, du = put("gate", linear_rows(mn, w["gate"])), put("up", linear_rows(mn, w["up"]))
    ds = put("silu", local(c, "silu", (dg,)))
    product = put("gate_up", local(c, "gate_up", (ds, du)))
    mlp = put("mlp", linear_rows(product, w["down"]))
    put("output", mid + mlp)
    return out


def remainder_budget(c, finite, public_jvp):
    actual = {name: finite[name] - c[name] for name in ("x", *NODES)}
    # Node outputs are computed from actual parent changes, not predicted ones.
    w = c["weights"]
    expected = {
        name: local(c, name, tuple(actual[k] for k in parents)) for name, parents in PARENTS.items()
    }
    dq, dk, dv = [
        F.linear(actual["input_rms"], w[k]).view(c["shape"]).transpose(1, 2)
        for k in ("q", "k", "v")
    ]
    dq, dk = qwen.apply_rotary_pos_emb(dq, dk, *c["rope"])
    dk, dv = [qwen.repeat_kv(z, c["groups"]) for z in (dk, dv)]
    expected.update(
        q=dq,
        k=dk,
        v=dv,
        attention=F.linear(
            actual["weight_value"].transpose(1, 2).contiguous().reshape(c["x"].shape), w["o"]
        ),
        mid=actual["x"] + actual["attention"],
        gate=F.linear(actual["post_rms"], w["gate"]),
        up=F.linear(actual["post_rms"], w["up"]),
        mlp=F.linear(actual["gate_up"], w["down"]),
        output=actual["mid"] + actual["mlp"],
    )
    remainders = {name: actual[name] - expected[name] for name in NODES}
    zero = torch.zeros_like(actual["x"])
    components = {name: graph(c, zero, {name: remainders[name]})["output"] for name in PARENTS}
    numerical = {name: value for name, value in remainders.items() if name not in PARENTS}
    components["linear_rounding"] = graph(c, zero, numerical)["output"]
    reference = graph(c, actual["x"])["output"]
    components["reference_minus_public_jvp"] = reference - public_jvp.detach().cpu().double()
    missing = actual["output"] - public_jvp.detach().cpu().double()
    closure = float((sum(components.values()) - missing).abs().max())
    return components, closure, reference


@contextmanager
def surgeries(layer, c, context, enabled=(), route=False, value=False):
    """Replace named primitives with affineFalse functions on actual finite inputs."""
    enabled = set(enabled)
    handles, values, checks = [], {}, []
    original_attention = qwen.eager_attention_forward

    def affine(name, inputs):
        deltas = tuple(x.detach().cpu().double() - c[p] for p, x in zip(PARENTS[name], inputs))
        derivative = local(c, name, deltas)
        primal_inputs = tuple(
            c[p].to(device=inputs[0].device, dtype=torch.float32) for p in PARENTS[name]
        )
        directions = tuple(x.to(device=inputs[0].device, dtype=torch.float32) for x in deltas)
        functions = {
            "input_rms": layer.input_layernorm.forward,
            "post_rms": layer.post_attention_layernorm.forward,
            "silu": layer.mlp.act_fn.forward,
            "qk_product": lambda q, k: (q @ k.transpose(2, 3)) * c["scaling"],
            "softmax": lambda z: F.softmax(z + context["mask"], -1, dtype=torch.float32),
            "weight_value": lambda p, v: p @ v,
            "gate_up": lambda p, u: p * u,
        }
        function = functions[name]
        observed = torch.func.jvp(function, primal_inputs, directions)[1].detach().cpu().double()
        error = float((derivative - observed).abs().max())
        checks.append(dict(primitive=name, coordinate_error=error, passed=error <= 1e-4))
        return (c[name] + derivative).to(device=inputs[0].device, dtype=inputs[0].dtype)

    def unary(name):
        def hook(module, args, output):
            return affine(name, (args[0],))

        return hook

    def save(name):
        def hook(module, args, output):
            values[name] = output

        return hook

    try:
        for name, module in (
            ("input_rms", layer.input_layernorm),
            ("post_rms", layer.post_attention_layernorm),
            ("silu", layer.mlp.act_fn),
        ):
            if name in enabled:
                handles.append(module.register_forward_hook(unary(name)))

        def attention(module, q, k, v, mask, scaling, dropout=0.0, **kwargs):
            assert dropout == 0 and not module.training
            k, v = [qwen.repeat_kv(z, module.num_key_value_groups) for z in (k, v)]
            z = (
                affine("qk_product", (q, k))
                if "qk_product" in enabled
                else (q @ k.transpose(2, 3)) * scaling
            )
            p = (
                affine("softmax", (z,))
                if "softmax" in enabled
                else F.softmax(z + mask, -1, dtype=torch.float32).to(q.dtype)
            )
            if route:
                p = c["softmax"].to(device=q.device, dtype=q.dtype)
            if value:
                v = c["v"].to(device=q.device, dtype=q.dtype)
            av = affine("weight_value", (p, v)) if "weight_value" in enabled else p @ v
            return av.transpose(1, 2).contiguous(), p

        qwen.eager_attention_forward = attention
        if "gate_up" in enabled:
            handles.append(layer.mlp.act_fn.register_forward_hook(save("silu")))
            handles.append(layer.mlp.up_proj.register_forward_hook(save("up")))

            def product(module, args):
                return (affine("gate_up", (values["silu"], values["up"])),)

            handles.append(layer.mlp.down_proj.register_forward_pre_hook(product))
        yield checks
    finally:
        qwen.eager_attention_forward = original_attention
        for h in handles:
            h.remove()
