"""False-state local Jacobians plus budgeted known finite block responses."""

from contextlib import contextmanager

import torch
from torch.nn import functional as F

from latent_decisions.target import block_tensor

ARMS = (
    "source_linear",
    "exact_readout",
    "residual_blocks",
    "margin_blocks",
    "union_blocks",
    "control_blocks",
)


@contextmanager
def capture(model):
    values, context, handles = [], {}, []

    def start(module, args, kwargs):
        context.update(
            input=args[0].detach().clone(),
            mask=kwargs["attention_mask"].detach().clone(),
            rope=tuple(v.detach().clone() for v in kwargs["position_embeddings"]),
        )

    def save(module, args, output):
        values.append(block_tensor(output).detach().clone())

    try:
        handles.append(model.model.layers[0].register_forward_pre_hook(start, with_kwargs=True))
        for layer in model.model.layers:
            handles.append(layer.register_forward_hook(save))
        yield values, context
    finally:
        for handle in handles:
            handle.remove()


def observe(model, ids):
    with torch.no_grad(), capture(model) as (states, context):
        result = model(
            input_ids=ids, attention_mask=torch.ones_like(ids), use_cache=False, logits_to_keep=1
        )
    return states, context, result.logits[0, -1, [895, 830]].detach().clone()


def block(layer, state, context):
    return layer(state, attention_mask=context["mask"], position_embeddings=context["rope"])


def head(model, state):
    # Full known normalization, only the two relevant linear readout rows.
    normalized = model.model.norm(state)[0, -1]
    return F.linear(normalized, model.lm_head.weight[[895, 830]])


def source(model, context, false_states, edit):
    with torch.no_grad():
        return block(model.model.layers[0], context["input"] + edit, context) - false_states[0]


def forecast(model, context, false_states, source_delta, finite_blocks, finite_head):
    """Known finite functions receive only current predicted deltas; no nativeTrue states."""
    values, primal_errors = [source_delta.detach().clone()], []
    finite_count, ad_count = 0, 0
    for index, layer in enumerate(model.model.layers[1:], 1):
        xf = false_states[index - 1]
        incoming = values[-1]
        if index + 1 in finite_blocks:
            with torch.no_grad():
                outgoing = block(layer, xf + incoming, context) - false_states[index]
            finite_count += 1
        else:
            primal, outgoing = torch.func.jvp(
                lambda x: block(layer, x, context), (xf,), (incoming,)
            )
            error = float(torch.max(abs(primal - false_states[index])))
            assert error <= 1e-4
            primal_errors.append(error)
            ad_count += 1
        values.append(outgoing.detach().clone())
    if finite_head:
        with torch.no_grad():
            scores = head(model, false_states[-1] + values[-1]) - head(model, false_states[-1])
    else:
        _, scores = torch.func.jvp(lambda x: head(model, x), (false_states[-1],), (values[-1],))
    return (
        torch.stack(values)[:, 0],
        scores.detach().clone(),
        {
            "local_block_ad_calls": ad_count,
            "local_finite_block_calls": finite_count,
            "maximum_primal_error": max(primal_errors, default=0.0),
        },
    )


def placements(selection, arm):
    blocks = {
        "source_linear": [],
        "exact_readout": [],
        "residual_blocks": selection["residual"],
        "margin_blocks": selection["margin"],
        "union_blocks": selection["union"],
        "control_blocks": selection["control"],
    }[arm]
    return set(blocks), arm != "source_linear"
