"""Bounded matched SiLU/product crossing and fixedFalse finite readout."""
import json,hashlib
from pathlib import Path
from collections import defaultdict
import numpy as np,torch
import ranked_block_response_201 as original
import primitive_diagnostic_211 as primitive
from frozen_block28_derivative_210 import trace
from gate_up_arithmetic_213 import decompose
from silu_range_falsification_218 import enabled,ARMS,captured,regimes,lower_bound
from latent_decisions.target import load_target
R=Path(__file__).resolve().parents[1];RUN=R/'runs/silu-range-falsification-218'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,o):p.write_text(json.dumps(o,indent=2))
def cpu(x):return x.detach().cpu().numpy().copy()
def main():
 assert not RUN.exists();RUN.mkdir();(RUN/'pairs').mkdir()
 files=['scripts/run_silu_range_falsification_218.py','scripts/silu_range_falsification_218.py','scripts/audit_silu_range_falsification_218.py','docs/experiments/218-silu-range-falsification.md','scripts/primitive_diagnostic_211.py','scripts/frozen_block28_derivative_210.py','scripts/local_primitive_derivative_210c.py','scripts/gate_up_arithmetic_213.py','scripts/ranked_block_response_201.py','src/latent_decisions/target.py']
 rp=R/'runs/source-receiver-partition-208/runtime.json';rt=json.loads(rp.read_text());design=dict(source_hashes={f:sha(R/f) for f in files},runtime_sha256=sha(rp),parent215_audit_sha256=sha(R/'docs/analysis/215-matched-incoming-control.json'),parent213_audit_sha256=sha(R/'docs/analysis/213-gate-up-arithmetic-audit.json'),silu_minimum=lower_bound()[1],silu_minimizer=lower_bound()[0]);write(RUN/'design.json',design);write(RUN/'runtime.json',rt)
 model,tok,device=load_target(rt['model'],'mps',offline=True);torch.set_num_threads(2)
 from latent_decisions.evidence_policy import digest
 assert digest(tok.get_vocab())==rt['tokenizer_hash'] and digest(model.config.to_dict())==rt['config_hash'];assert not model.training and model.config._attn_implementation=='eager' and next(model.parameters()).dtype==torch.float32
 counts=defaultdict(int);rows=[];layer=model.model.layers[27]
 def head(x):
  with torch.no_grad():y=original.head(model,x)
  counts['finite_heads']+=1;return cpu(y).astype(np.float64)
 def block(x,c,context,arm):
  with primitive.surgeries(layer,c,context,enabled(arm)) as checks,captured(layer) as cap,torch.no_grad():out=original.block(layer,x,context)
  counts['blocks']+=1;assert all(q['passed'] for q in checks),checks;cap['output']=out.detach().cpu().double();return out,cap,checks
 for path in sorted((R/'runs/matched-incoming-control-215/pairs').glob('*.npz')):
  parent=R/'runs/source-receiver-partition-208/forecasts'/path.name;rec=json.loads(path.with_suffix('.json').read_text());assert sha(path)==rec['record']['arrays_sha256'];assert sha(parent)==json.loads(parent.with_suffix('.json').read_text())['record']['arrays_sha256']
  arrays={};checks=[];local=[];cases=[]
  with np.load(path) as z,np.load(parent) as old:
   pos=int(z['source_position']);xf=torch.tensor(old['false_boundaries'][27][None],device=device);yf=torch.tensor(old['false_boundaries'][28][None],device=device);context=dict(mask=torch.tensor(old['mask'],device=device),rope=tuple(torch.tensor(old[k],device=device) for k in ['rope_cos','rope_sin']));c=trace(layer,xf,context);sf=head(yf);arrays.update(false_final=cpu(yf[0,pos:]),true_final=z['true_final'].copy(),false_scores=sf,true_scores=z['true_scores'].copy(),position=np.array(pos))
   def check(kind,e,b=1e-4,**kw):checks.append(dict(kind=kind,error=float(e),bound=b,**kw))
   check('false_trace',(c['output']-yf.cpu().double()).abs().max());check('false_head',np.max(abs(sf-z['false_scores'])),.005)
   for arm in ARMS:
    o,cap,lc=block(xf,c,context,arm);local.extend(dict(input='False',arm=arm,**x) for x in lc);check('false_sham',(o-yf).abs().max(),arm=arm);check('false_sham_head',np.max(abs(head(o)-sf)),.005,arm=arm)
   rx=yf.detach().clone().requires_grad_(True);yy=original.head(model,rx);grad=torch.autograd.grad(yy[1]-yy[0],rx)[0].detach().cpu().double();counts['reverse_heads']+=1
   h=yf[0,-1].detach().cpu().double();w=(model.lm_head.weight[830].detach().cpu().double()-model.lm_head.weight[895].detach().cpu().double())*model.model.norm.weight.detach().cpu().double();inv=torch.rsqrt(h.square().mean()+model.model.norm.variance_epsilon);cg=w*inv-h*inv.pow(3)*(w*h).mean();check('gradient_coordinate',(cg-grad[0,-1]).abs().max());arrays['closed_gradient']=cpu(cg);arrays['reverse_gradient']=cpu(grad[0,-1])
   for branch in ['native','predicted']:
    x=xf.clone();x[:,pos:]=torch.tensor(z[branch+'_input'][None],device=device);caps={};outputs={};scores={}
    for arm in ARMS:
     o,cap,lc=block(x,c,context,arm);local.extend(dict(input=branch,arm=arm,**r) for r in lc);caps[arm]=cap;outputs[arm]=o;scores[arm]=head(o);prefix=branch+'_'+arm;arrays[prefix+'_state']=cpu(o[0,pos:]);arrays[prefix+'_scores']=scores[arm];check('unchanged_prefix',(o-yf)[:,:pos].abs().max(),branch=branch,arm=arm)
     if arm[1]=='F':
      arrays[prefix+'_phi']=cpu(cap['phi'][0,pos:]).astype(np.float32);arrays[prefix+'_up']=cpu(cap['up'][0,pos:]).astype(np.float32)
     if arm[0]=='L':
      oldarm='FL' if arm[1]=='L' else 'FF';check('215_state_replay',np.max(abs(cpu(o[0,pos:])-z[branch+'_'+oldarm+'_state'])),branch=branch,arm=arm);check('215_score_replay',np.max(abs(scores[arm]-z[branch+'_'+oldarm+'_scores']-z['false_scores'])),.005,branch=branch,arm=arm)
    for silu in ['L','F']:
     vectors,errors=decompose(c,caps[silu+'F'],caps[silu+'L']);reg=regimes(caps[silu+'F'],pos,design['silu_minimum']);effect=vectors['finite_effect'];d=effect.clone();d[:,:pos+1]=0;changed=(yf.cpu().double()+d).to(device=device,dtype=torch.float32);common=head(changed);pre=branch+'_'+silu;arrays[pre+'_common_state']=cpu(changed[0,pos:]);arrays[pre+'_common_scores']=common
     for name,v in vectors.items():arrays[pre+'_'+name]=cpu(v[0,pos:]);check('vector_prefix',v[:,:pos].abs().max(),branch=branch,silu=silu,vector=name)
     for name in ['pure_product_identity','actual_product_change_identity','matched_parent_identity','numerical_discrepancy_closure']:check('product_'+name,errors[name],branch=branch,silu=silu)
     if silu=='F':check('finite_silu_range',sum(r['below_silu_minimum_guard'] for r in reg.values()),0.,branch=branch)
     rev=float((grad*d).sum());analytic=float((cg*d[0,-1]).sum());check('gradient_contraction',abs(rev-analytic),.001+.0001*abs(rev),branch=branch,silu=silu)
     check('common_source_prefix',(changed[:,:pos+1]-yf[:,:pos+1]).abs().max(),0.,branch=branch,silu=silu)
     natural=float((scores[silu+'F'][1]-scores[silu+'F'][0])-(scores[silu+'L'][1]-scores[silu+'L'][0]));change=float((common[1]-common[0])-(sf[1]-sf[0]));cases.append(dict(branch=branch,silu=silu,regimes=reg,errors=errors,natural_margin_change=natural,common_margin_change=change,initial_projection=analytic,reverse_projection=rev,finite_minus_initial=change-analytic))
  assert all(q['error']<=q['bound'] for q in checks),checks
  out=RUN/'pairs'/path.name;np.savez_compressed(out,**arrays);row=dict(key=path.stem,group=rec['record']['group'],parent215_sha256=sha(path),parent208_sha256=sha(parent),arrays_sha256=sha(out),checks=checks,local_checks=local,cases=cases);write(out.with_suffix('.json'),row);rows.append(row);write(RUN/'status.json',dict(status='running',completed_pairs=len(rows),counts=dict(counts)));print(path.stem,len(rows),flush=True)
 assert len(rows)==64 and all(sha(R/f)==h for f,h in design['source_hashes'].items())
 report=dict(qualified=True,cases=64,counts=dict(counts),rows=rows,original_wholeblock_jacobian_qualified=False,limits='FiniteSiLUreplacement notrangeclipping; absolutephi/uquadrants distinctfromincrementmixedterm. Retrospective, no learnedfeature/circuit/superposition/prospectiveclaim. Rawmixedfailuresretained.')
 write(R/'docs/analysis/218-silu-range-falsification.json',report);write(RUN/'status.json',dict(status='complete',**{k:v for k,v in report.items() if k!='rows'}))
if __name__=='__main__':main()
