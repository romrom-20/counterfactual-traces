"""Analytic SiLU range and actual absolute-sign regime measurements."""
import math
import torch
from contextlib import contextmanager
from gate_up_arithmetic_213 import capture
ATTENTION=('input_rms','qk_product','softmax','weight_value')
ARMS=('LL','LF','FL','FF') # SiLU then product

def enabled(arm):return (*ATTENTION,*(() if arm[0]=='F' else ('silu',)),*(() if arm[1]=='F' else ('gate_up',)))
def lower_bound():
 t=-1.3
 for _ in range(20):t-=(t+1+math.exp(t))/(1+math.exp(t))
 return t,t/(1+math.exp(-t))
@contextmanager
def captured(layer):
 with capture(layer) as c:
  def hook(module,args,out):c['gate']=out.detach().cpu().double().clone()
  h=layer.mlp.gate_proj.register_forward_hook(hook)
  try:yield c
  finally:h.remove()
def regimes(c,pos,bound):
 out={}
 for name,s in [('source',slice(pos,pos+1)),('receivers',slice(pos+1,None)),('verdict',slice(-1,None)),('causal_suffix',slice(pos,None))]:
  p,u=c['phi'][:,s],c['up'][:,s];out[name]=dict(coordinates=p.numel(),minimum_phi=float(p.min()),maximum_phi=float(p.max()),below_silu_minimum_guard=int((p<bound-1e-4).sum()),negative_phi=int((p<0).sum()),negative_up=int((u<0).sum()),negative_negative=int(((p<0)&(u<0)).sum()),positive_positive=int(((p>0)&(u>0)).sum()),negative_positive=int(((p<0)&(u>0)).sum()),positive_negative=int(((p>0)&(u<0)).sum()))
 return out
