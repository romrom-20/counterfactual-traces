AUDIT: scripts/run_oracle_reset_201.py (.context/attachments/2jQ3AP/ pasted text)
Status: PROVISIONAL — not a genuine forward-continuation experiment.

1. PROXY-RESET METHOD (line 30 of script)
   proxy_reset_err = final_err - incoming_err
   This is arithmetic on stored L2 magnitudes, NOT a model forward run with native state injected at block k and hybrid predictor resumed.

2. WHY incoming + proxy ≈ 57.8 at multiple depths
   By construction: proxy = final_err - incoming_err  =>  incoming_err + proxy = 57.8 exactly.
   At k=1: 7.3 + 50.6 = 57.9; k=11: 18.3 + 39.5 = 57.8; k=27: 48.1 + 9.7 = 57.8.
   This is an identity, not evidence of propagation structure.

3. GENUINE RESET MISSING
   Actual experiment requires: take native state at block k, feed to hybrid predictor (false JVP + selected finite blocks), compute new final delta, compare to native final. Not performed because we have no forward-model execution pipeline that takes intermediate native embeddings and resumes with the 201 hybrid hook construction.

4. FIRST-BLOCK SOURCE RECONCILIATION
   - Source matching control (201): 16/16 passed — checks boolean response scores / verdict margins at source, not displacement vector norms.
   - Source_first_delta error ~100% (relative to true_first): measures vector displacement at embedding level (170x1536) between predicted first delta and true first delta.
   - These are different metrics; both can be true simultaneously: scores can align while displacement vector diverges.

5. REPRODUCTION FROM ACTUAL RESIDUAL VECTORS (direct, not proxy)
--- appended to audit file ---
Direct reproduction completed; provisional results preserved.
