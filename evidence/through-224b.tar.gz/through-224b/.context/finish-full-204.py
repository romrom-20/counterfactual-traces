import json, os, subprocess, sys, time
from pathlib import Path
root = Path.cwd()
status_path = root / "runs/genuine-oracle-continuation-204-full/status.json"
while True:
    state = json.loads(status_path.read_text())
    if state["status"] != "running":
        break
    time.sleep(5)
assert state["status"] == "complete" and state["reset_qualified"], state
commands = [
    "audit_genuine_oracle_continuation_204.py",
    "report_genuine_oracle_continuation_204.py",
    "separate_measured_reset_errors_205.py",
    "report_layerwise_reset_norms_207.py",
    "plot_genuine_oracle_204.py",
    "build_genuine_oracle_canvas_204.py",
]
env = dict(os.environ, HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1", PYTHONPATH="src:scripts")
for name in commands:
    print("POSTPROCESS", name, flush=True)
    subprocess.run([sys.executable, str(root / "scripts" / name), "--scope", "full"], cwd=root, env=env, check=True)
(root / ".context/204-full-postprocess-complete.json").write_text(json.dumps({"complete":True,"commands":commands},indent=2))
print("FULL204POSTPROCESSCOMPLETE",flush=True)
