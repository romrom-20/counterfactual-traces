"""Descriptive comparisons of every sealed208 prediction; no fitting or model."""

import hashlib
import json
from pathlib import Path

import numpy as np

from latent_decisions.evidence_policy import write_json

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "docs/analysis/208-source-receiver-partition.json"
OUT = ROOT / "docs/analysis/208-error-comparisons.json"


def q(x):
    return x["final"]["verdict"]["relative_l2"]


def main():
    assert not OUT.exists()
    data = json.loads(SOURCE.read_text())
    assert data["qualified"]
    strata = []
    for field in (None, "block", "schema", "reverse"):
        for value in [None] if field is None else sorted({r["group"][field] for r in data["rows"]}):
            rows = [r for r in data["rows"] if field is None or r["group"][field] == value]
            comparisons = {}
            for arm in ("source_linear", "source_linear_finite_head", "source_receiver"):
                items = [r["arms"][arm] for r in rows]
                comparisons[arm] = dict(
                    median_cosine=float(
                        np.median([x["final"]["verdict"]["cosine"] for x in items])
                    ),
                    median_prediction_to_native_norm=float(
                        np.median(
                            [
                                x["final"]["verdict"]["prediction_norm"]
                                / x["final"]["verdict"]["native_norm"]
                                for x in items
                            ]
                        )
                    ),
                    residual_better_than_source_linear=sum(
                        q(r["arms"][arm]) < q(r["arms"]["source_linear"]) for r in rows
                    ),
                    margin_better_than_source_linear=sum(
                        r["arms"][arm]["absolute_margin_error"]
                        < r["arms"]["source_linear"]["absolute_margin_error"]
                        for r in rows
                    ),
                    residual_better_than_zero=sum(q(r["arms"][arm]) < 1 for r in rows),
                    margin_better_than_zero=sum(
                        r["arms"][arm]["absolute_margin_error"]
                        < r["arms"]["zero_displacement"]["absolute_margin_error"]
                        for r in rows
                    ),
                )
            curves = {
                arm: {
                    position: [
                        float(
                            np.median(
                                [r["arms"][arm]["layers"][i][position]["relative_l2"] for r in rows]
                            )
                        )
                        for i in range(28)
                    ]
                    for position in ("source", "verdict")
                }
                for arm in data["whole"]
            }
            strata.append(
                dict(
                    field=field,
                    value=value,
                    count=len(rows),
                    comparisons=comparisons,
                    median_layerwise_relative_l2=curves,
                )
            )
    report = dict(
        source_sha256=hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
        program_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        strata=strata,
        scope="Descriptive allcases/strata, no fittedrepair, no posthoc successcriterion, noindependentsamplingclaim.",
    )
    write_json(OUT, report)
    print(
        json.dumps(
            {k: v for k, v in strata[0].items() if k != "median_layerwise_relative_l2"}, indent=2
        )
    )


if __name__ == "__main__":
    main()
