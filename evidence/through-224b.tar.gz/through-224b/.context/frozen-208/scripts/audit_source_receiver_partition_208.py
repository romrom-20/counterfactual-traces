"""Reconstruct sealed208 provenance, individual outcomes and frozen panel criteria."""

import itertools
import json

import numpy as np
import run_source_receiver_partition_208 as run
from audit_two_block_factorial_209 import metrics
from transformers import AutoTokenizer

from latent_decisions.evidence_policy import digest, write_json

ROOT, RUN = run.ROOT, run.RUN
OUT = ROOT / "docs/analysis/208-source-receiver-partition.json"


def margin(x):
    return float(x[1] - x[0])


def main():
    assert not OUT.exists()
    bundle = json.loads((RUN / "design.json").read_text())
    design = bundle["design"]
    assert digest(design) == bundle["fingerprint"]
    assert all(run.sha(ROOT / p) == h for p, h in design["source_hashes"].items())
    assert (
        run.sha(ROOT / "docs/analysis/209c-two-block-factorial.json")
        == design["factorial_audit_sha256"]
    )
    status = json.loads((RUN / "status.json").read_text())
    assert status["status"] == "complete" and status["qualified"]
    assert status["forecast_pairs"] == status["observation_pairs"] == 64
    expected = dict(
        ordinary_false_models=64,
        ordinary_true_models=64,
        local_finite_block=3648,
        local_block_jvp=3456,
        head_jvp=64,
        finite_head_evaluations=448,
        skipped_zero_receiver_jvp=64,
        whole_public_false_forward_ad=24,
        whole_public_nested_finite_blocks=240,
        whole_public_nested_finite_norms=16,
        reverse_block_forward=216,
        reverse_block_backward=648,
        reverse_head_forward=216,
        reverse_head_backward=216,
    )
    assert status["counts"] == expected, status["counts"]
    mb = json.loads((RUN / "forecast-manifest.json").read_text())
    manifest = mb["manifest"]
    assert digest(manifest) == mb["sha256"] and manifest["ordinary_true_models"] == 0
    assert manifest["ordinary_false_models"] == 64 and len(manifest["entries"]) == 64
    assert manifest["design_fingerprint"] == bundle["fingerprint"]
    nb = json.loads((RUN / "false-numerical-checks.json").read_text())
    assert nb["passed"] and nb["forecast_manifest_sha256"] == run.sha(
        RUN / "forecast-manifest.json"
    )
    assert len(nb["checks"]) == 56 and len(nb["derivative_checks"]) == 1296
    assert all(c["passed"] for c in nb["checks"] + nb["derivative_checks"])
    catalog = json.loads((RUN / "historical-input-catalog.json").read_text())
    historical = set()
    for r in catalog["records"]:
        assert run.sha(ROOT / r["path"]) == r["sha256"]
        historical.update(r["input_hashes"])
    assert len(historical) == catalog["unique_inputs"]
    rt = json.loads((RUN / "runtime.json").read_text())
    tokenizer = AutoTokenizer.from_pretrained(
        **dict(
            pretrained_model_name_or_path=rt["model"]["model"],
            revision=rt["model"]["revision"],
            local_files_only=True,
        )
    )
    assert digest(tokenizer.get_vocab()) == rt["tokenizer_hash"]
    by_block = {b["id"]: b for b in run.blocks()}
    rows, checks, fresh = [], [], set()
    forecast_times, true_times = [], []
    for entry in manifest["entries"]:
        fp = RUN / "forecasts" / (entry["key"] + ".npz")
        op = RUN / "observations" / fp.name
        fobj, oobj = [json.loads(p.with_suffix(".json").read_text()) for p in (fp, op)]
        f, o = fobj["record"], oobj["record"]
        assert digest(f) == fobj["sha256"] == entry["record_sha256"]
        assert run.sha(fp) == f["arrays_sha256"] == entry["arrays_sha256"]
        assert digest(o) == oobj["sha256"] and run.sha(op) == o["arrays_sha256"]
        assert o["forecast_record_sha256"] == fobj["sha256"]
        assert o["forecast_manifest_sha256"] == run.sha(RUN / "forecast-manifest.json")
        assert f["group"] == o["group"] and digest(f["group"]) == entry["key"]
        assert f["design_fingerprint"] == bundle["fingerprint"]
        bases, pos = run.fixture.paired_bases(tokenizer, by_block[f["group"]["block"]], f["group"])
        assert bases == f["bases"] and pos == f["position"]
        ids = [digest(b["free_input_ids"]) for b in bases]
        assert ids == f["input_hashes"] and all(h not in historical and h not in fresh for h in ids)
        fresh.update(ids)
        checks.extend(f["checks"] + o["checks"])
        forecast_times.append(f["completed_utc"])
        true_times.append(o["started_utc"])
        with np.load(fp, allow_pickle=False) as raw, np.load(op, allow_pickle=False) as obs:
            assert all(np.isfinite(a).all() for table in (raw, obs) for a in table.values())
            z = {k: raw[k].astype(np.float64) for k in raw.files}
            actual = obs["true_suffix"].astype(np.float64) - z["false_boundaries"][1:, pos:]
            target = margin(obs["true_scores"].astype(np.float64) - z["false_scores"])
            assert actual.shape[0] == 28 and actual.shape[-1] == 1536
            arms = {}
            for arm in run.ARMS:
                prediction = z[f"{arm}_delta_suffix"]
                assert prediction.shape == actual.shape
                layers = []
                for i in range(28):
                    layers.append(
                        dict(
                            block=i + 1,
                            source=metrics(prediction[i, :1], actual[i, :1]),
                            verdict=metrics(prediction[i, -1:], actual[i, -1:]),
                        )
                    )
                final = {
                    name: metrics(prediction[-1, s], actual[-1, s])
                    for name, s in dict(
                        full=slice(None),
                        source=slice(0, 1),
                        receivers=slice(1, None),
                        verdict=slice(-1, None),
                    ).items()
                }
                predicted_margin = margin(z[f"{arm}_delta_scores"])
                native_norm = final["verdict"]["native_norm"]
                residual_pass = bool(
                    native_norm >= 0.001
                    and final["verdict"]["relative_l2"] <= 0.05
                    and final["verdict"]["cosine"] is not None
                    and final["verdict"]["cosine"] >= 0.99
                )
                me = abs(predicted_margin - target)
                arms[arm] = dict(
                    final=final,
                    native_margin=target,
                    predicted_margin=predicted_margin,
                    signed_margin_error=predicted_margin - target,
                    absolute_margin_error=me,
                    residual_pass=residual_pass,
                    margin_pass=me <= 0.10,
                    primary_pass=residual_pass and me <= 0.10,
                    layers=layers,
                )
            baseline = arms["source_linear"]
            for arm in run.ARMS:
                item = arms[arm]
                item["partial_progress_pass"] = bool(
                    item["final"]["verdict"]["relative_l2"]
                    <= 0.5 * baseline["final"]["verdict"]["relative_l2"]
                    and item["absolute_margin_error"] <= 0.5 * baseline["absolute_margin_error"]
                )
            rows.append(dict(key=entry["key"], group=f["group"], arms=arms))
    assert len(rows) == 64 and len(fresh) == 128 and len(checks) == 320
    assert max(forecast_times) <= manifest["sealed_utc"] < nb["completed_utc"] < min(true_times)
    assert all(c["passed"] for c in checks)
    panels = []
    for block, schema, reverse in itertools.product(by_block, ("generic", "descriptive"), range(2)):
        cells = [
            r
            for r in rows
            if r["group"]["block"] == block
            and r["group"]["schema"] == schema
            and r["group"]["reverse"] == reverse
        ]
        assert len(cells) == 4 and {
            (r["group"]["assignment"], r["group"]["target"]) for r in cells
        } == set(itertools.product(range(2), repeat=2))
        panels.append(
            dict(
                block=block,
                schema=schema,
                reverse=reverse,
                arms={
                    arm: {
                        kind: all(r["arms"][arm][kind] for r in cells)
                        for kind in ("primary_pass", "partial_progress_pass")
                    }
                    for arm in run.ARMS
                },
            )
        )
    whole = {}
    for arm in run.ARMS:
        whole[arm] = {}
        for kind in ("primary_pass", "partial_progress_pass"):
            strata = [
                dict(
                    schema=schema,
                    reverse=rev,
                    passed=sum(
                        p["arms"][arm][kind]
                        for p in panels
                        if p["schema"] == schema and p["reverse"] == rev
                    ),
                )
                for schema, rev in itertools.product(("generic", "descriptive"), range(2))
            ]
            whole[arm][kind] = dict(passed=all(s["passed"] >= 3 for s in strata), strata=strata)
    strata = []
    for field in (None, "block", "schema", "reverse"):
        for value in [None] if field is None else sorted({r["group"][field] for r in rows}):
            selected = [r for r in rows if field is None or r["group"][field] == value]
            arms = {}
            for arm in run.ARMS:
                items = [r["arms"][arm] for r in selected]
                arms[arm] = dict(
                    median_relative_l2=float(
                        np.median([x["final"]["verdict"]["relative_l2"] for x in items])
                    ),
                    median_absolute_margin_error=float(
                        np.median([x["absolute_margin_error"] for x in items])
                    ),
                    passing_individuals=sum(x["primary_pass"] for x in items),
                    partial_progress_individuals=sum(x["partial_progress_pass"] for x in items),
                )
            strata.append(dict(field=field, value=value, count=len(selected), arms=arms))
    allchecks = checks + nb["checks"]
    report = dict(
        qualified=True,
        cases=64,
        panels=16,
        design_fingerprint=bundle["fingerprint"],
        counts=expected,
        sealed_utc=manifest["sealed_utc"],
        first_true_utc=min(true_times),
        last_forecast_utc=max(forecast_times),
        numerical_controls=len(allchecks),
        derivative_projections=1296,
        maximum_coordinate_check_error=max(c["coordinate_error"] for c in allchecks),
        maximum_score_check_error=max(c["score_error"] for c in allchecks),
        maximum_reverse_projection_error=max(c["absolute_error"] for c in nb["derivative_checks"]),
        source_control_maximum=max(
            c["coordinate_error"] for c in checks if c["kind"] == "candidate_source_all28"
        ),
        fresh_input_sequences=128,
        historical_unique_sequences=len(historical),
        strata=strata,
        whole=whole,
        panel_results=panels,
        rows=rows,
        limits="Dependenttemplates; testedstatepartitiononly; nolearnedcircuit/primitiveidentification;196/204derivativefailuresunresolved. Candidate28wholefiniteblocks+27JVPnotcompactorcheap.",
    )
    write_json(OUT, report)
    print(
        json.dumps(
            {
                k: v
                for k, v in report.items()
                if k not in ("rows", "panel_results", "strata", "whole")
            },
            indent=2,
        )
    )
    print(json.dumps(strata[0], indent=2))
    print(json.dumps(whole["source_receiver"], indent=2))


if __name__ == "__main__":
    main()
