"""Seal every fresh False-only forecast, verify, then measure native True states."""

import gc
import hashlib
import itertools
import json
from collections import defaultdict
from pathlib import Path

import block_derivative_checks_209 as derivatives
import numpy as np
import oracle_continuation_203 as continuation
import public_ranked_block_response_201 as public_baseline
import ranked_block_response_201 as original
import run_natural_bit_shared_reader_181 as fixture
import source_receiver_partition_208 as partition
import torch
from run_absence_alphabet_104 import now

from latent_decisions.evidence_policy import digest, write_json
from latent_decisions.target import load_target

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / "runs/source-receiver-partition-208"
FILES = [
    "scripts/run_source_receiver_partition_208.py",
    "scripts/source_receiver_partition_208.py",
    "scripts/audit_source_receiver_partition_208.py",
    "docs/experiments/208-source-receiver-partition-registration.md",
    "scripts/block_derivative_checks_209.py",
    "scripts/oracle_continuation_203.py",
    "scripts/ranked_block_response_201.py",
    "scripts/public_ranked_block_response_201.py",
    "scripts/run_natural_bit_shared_reader_181.py",
    "scripts/audit_binding_carrier_partition_160.py",
    "scripts/audit_counterbalanced_binding_155.py",
    "scripts/audit_order_competence_151.py",
    "scripts/audit_two_block_factorial_209.py",
    "src/latent_decisions/target.py",
    "src/latent_decisions/evidence_policy.py",
]
ARMS = (
    "source_linear",
    "source_linear_finite_head",
    "source_receiver",
    "full_finite_control",
    "zero_displacement",
)
LITERALS = (
    ("marzipan", "nougat", "Monday", "Wednesday"),
    ("gimbal", "fulcrum", "Tuesday", "Saturday"),
    ("larch", "tamarack", "Thursday", "Sunday"),
    ("chalice", "goblet", "Friday", "Tuesday"),
)


def blocks():
    return [
        dict(id=a, stage="208", subjects=[a, b], days=[x, y], old_block=None)
        for a, b, x, y in LITERALS
    ]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def store(path, arrays, record):
    assert not path.exists()
    path.parent.mkdir(parents=True, exist_ok=True)
    assert all(np.isfinite(a).all() for a in arrays.values())
    np.savez_compressed(path, **arrays)
    record["arrays_sha256"] = sha(path)
    write_json(path.with_suffix(".json"), dict(record=record, sha256=digest(record)))
    return dict(key=path.stem, record_sha256=digest(record), arrays_sha256=record["arrays_sha256"])


def check(checks, kind, coordinate=0.0, score=0.0, **metadata):
    row = dict(
        kind=kind,
        coordinate_error=coordinate,
        score_error=score,
        passed=coordinate <= 1e-4 and score <= 0.005,
        **metadata,
    )
    checks.append(row)
    assert row["passed"], row


def expand(array, fb, pos):
    result = torch.zeros((28, *fb[0].shape), device=fb[0].device)
    result[:, 0, pos:] = torch.tensor(array, device=fb[0].device)
    return result


def numerical(model, device, manifest, counts):
    checks, reverse = [], []
    for entry in manifest["entries"]:
        fp = RUN / "forecasts" / (entry["key"] + ".npz")
        fr = json.loads(fp.with_suffix(".json").read_text())["record"]
        if fr["group"]["block"] != "marzipan" or fr["group"]["reverse"] != 0:
            continue
        with np.load(fp, allow_pickle=False) as z:
            fb = [torch.tensor(v[None], device=device) for v in z["false_boundaries"]]
            pos = fr["position"]
            context = dict(
                mask=torch.tensor(z["mask"], device=device),
                rope=tuple(torch.tensor(z[k], device=device) for k in ("rope_cos", "rope_sin")),
            )
            with torch.no_grad():
                edited = model.model.embed_tokens(
                    torch.tensor([fr["bases"][1]["free_input_ids"]], device=device)
                )
            for arm in ARMS[:3]:
                if arm == "source_receiver":
                    primal, tangent, sources = partition.public_response(model, fb[0], edited, pos)
                    counts["whole_public_nested_finite_blocks"] += 28
                    counts["whole_public_nested_finite_norms"] += 1
                    check(
                        checks,
                        "public_candidate_source",
                        float(
                            np.max(
                                abs(
                                    continuation.cpu(sources[:, 0])
                                    - z["source_receiver_absolute_source"]
                                )
                            )
                        ),
                        key=entry["key"],
                    )
                else:
                    primal, tangent = public_baseline.response(
                        model, fb[0], edited - fb[0], set(), arm.endswith("finite_head")
                    )
                    counts["whole_public_nested_finite_blocks"] += 1
                    if arm.endswith("finite_head"):
                        counts["whole_public_nested_finite_norms"] += 1
                counts["whole_public_false_forward_ad"] += 1
                pr = primal[0] if arm != "source_receiver" else primal[0][:, 0]
                tr = tangent[0] if arm != "source_receiver" else tangent[0][:, 0]
                check(
                    checks,
                    "public_false_primal",
                    float(torch.max(abs(pr - torch.stack(fb[1:])[:, 0]))),
                    float(np.max(abs(continuation.cpu(primal[1]) - z["false_scores"]))),
                    key=entry["key"],
                    arm=arm,
                )
                check(
                    checks,
                    "public_forecast_reconstruction",
                    float(np.max(abs(continuation.cpu(tr[:, pos:]) - z[f"{arm}_delta_suffix"]))),
                    float(np.max(abs(continuation.cpu(tangent[1]) - z[f"{arm}_delta_scores"]))),
                    key=entry["key"],
                    arm=arm,
                )
                del primal, tangent
            baseline = expand(z["source_linear_delta_suffix"], fb, pos)
            candidate = expand(z["source_receiver_delta_suffix"], fb, pos)
            receiver_j = expand(z["source_receiver_receiver_jvp_suffix"], fb, pos)
            for index in range(1, 28):
                incoming = candidate[index - 1].clone()
                incoming[:, : pos + 1] = 0
                rows = derivatives.verify(
                    model,
                    index,
                    fb[index],
                    fb[index + 1],
                    context,
                    {
                        "baseline": (baseline[index - 1], baseline[index]),
                        "candidate_receiver": (incoming, receiver_j[index]),
                    },
                    counts,
                )
                reverse.extend(dict(key=entry["key"], **r) for r in rows)
        gc.collect()
        print(f"208 False-only numerical {len(reverse)}/1296 projections", flush=True)
    assert len(checks) == 56 and len(reverse) == 1296
    report = dict(
        passed=True,
        completed_utc=now(),
        checks=checks,
        derivative_checks=reverse,
        forecast_manifest_sha256=sha(RUN / "forecast-manifest.json"),
    )
    write_json(RUN / "false-numerical-checks.json", report)


def execute(design, status, counts):
    runtime = json.loads(
        (ROOT / "runs/genuine-oracle-continuation-204-full/runtime.json").read_text()
    )
    model, tok, device = load_target(runtime["model"], "mps", offline=True)
    assert digest(tok.get_vocab()) == runtime["tokenizer_hash"]
    assert digest(model.config.to_dict()) == runtime["config_hash"]
    assert (
        len(model.model.layers) == 28
        and not model.training
        and model.config._attn_implementation == "eager"
    )
    assert next(model.parameters()).dtype == torch.float32
    write_json(RUN / "runtime.json", runtime)
    # Read only historical prompt IDs; no fresh True-state observations exist.
    historical, catalog = set(), []
    for path in sorted((ROOT / "runs").glob("**/forecasts/*.json")):
        if RUN in path.parents:
            continue
        obj = json.loads(path.read_text())
        record = obj.get("record", obj)
        bases = record.get("bases", [])
        if (
            isinstance(bases, list)
            and len(bases) == 2
            and all("free_input_ids" in b for b in bases)
        ):
            hashes = [digest(b["free_input_ids"]) for b in bases]
            historical.update(hashes)
            catalog.append(
                dict(path=str(path.relative_to(ROOT)), sha256=sha(path), input_hashes=hashes)
            )
    assert any(r["path"].startswith("runs/discovery-ranked-repair-201/") for r in catalog)
    write_json(
        RUN / "historical-input-catalog.json", dict(records=catalog, unique_inputs=len(historical))
    )
    jobs, fresh = [], set()
    for block, a, t, rev, schema in itertools.product(
        blocks(), range(2), range(2), range(2), ("generic", "descriptive")
    ):
        group = fixture.fixture.group(block, a, t, rev, schema)
        bases, pos = fixture.paired_bases(tok, block, group)
        hashes = [digest(b["free_input_ids"]) for b in bases]
        assert all(h not in historical and h not in fresh for h in hashes)
        fresh.update(hashes)
        jobs.append((digest(group), group, bases, pos))
    assert len(jobs) == 64 and len(fresh) == 128
    entries = []
    for key, group, bases, pos in jobs:
        started = now()
        ids = torch.tensor([bases[0]["free_input_ids"]], device=device)
        states, context, scores = original.observe(model, ids)
        counts["ordinary_false_models"] += 1
        fb = [context["input"], *states]
        with torch.no_grad():
            edited = model.model.embed_tokens(
                torch.tensor([bases[1]["free_input_ids"]], device=device)
            )
            own_head = original.head(model, fb[-1])
        counts["finite_head_evaluations"] += 1
        checks = []
        check(checks, "finite_false_head", score=float(torch.max(abs(own_head - scores))))
        initial = continuation.finite(model, 0, fb[0] + (edited - fb[0]), context, counts) - fb[1]
        linear, ds_linear, _ = continuation.continuation(
            model, fb, context, 1, initial, set(), False, counts
        )
        linear = torch.stack(linear)
        ds_linear_finite = continuation.readout(model, fb[-1], linear[-1], True, counts)
        candidate, receiver_j, absolute_source = partition.forecast(
            model, fb, context, edited, pos, counts
        )
        ds_candidate = continuation.readout(model, fb[-1], candidate[-1], True, counts)
        # Upper control is evaluated last and never supplies another arm's inputs.
        finite_absolute = partition.full_finite(model, context, edited, counts)
        finite_delta = finite_absolute - torch.stack(states)
        ds_finite = continuation.readout(model, fb[-1], finite_delta[-1], True, counts)
        traces = dict(
            source_linear=(linear, ds_linear),
            source_linear_finite_head=(linear, ds_linear_finite),
            source_receiver=(candidate, ds_candidate),
            full_finite_control=(finite_delta, ds_finite),
            zero_displacement=(torch.zeros_like(candidate), torch.zeros_like(ds_candidate)),
        )
        arrays = dict(
            false_boundaries=continuation.cpu(torch.stack(fb)[:, 0]),
            false_scores=continuation.cpu(scores),
            mask=continuation.cpu(context["mask"]),
            rope_cos=continuation.cpu(context["rope"][0]),
            rope_sin=continuation.cpu(context["rope"][1]),
            source_receiver_absolute_source=continuation.cpu(absolute_source[:, 0]),
            source_receiver_receiver_jvp_suffix=continuation.cpu(receiver_j[:, 0, pos:]),
            full_finite_absolute_suffix=continuation.cpu(finite_absolute[:, 0, pos:]),
        )
        for arm, (trace, ds) in traces.items():
            assert torch.count_nonzero(trace[:, :, :pos]) == 0
            arrays[f"{arm}_delta_suffix"] = continuation.cpu(trace[:, 0, pos:])
            arrays[f"{arm}_delta_scores"] = continuation.cpu(ds)
        fr = dict(
            group=group,
            bases=bases,
            position=pos,
            started_utc=started,
            completed_utc=now(),
            checks=checks,
            design_fingerprint=digest(design),
            input_hashes=[digest(b["free_input_ids"]) for b in bases],
        )
        entries.append(store(RUN / "forecasts" / (key + ".npz"), arrays, fr))
        status.update(forecast_pairs=len(entries), counts=dict(counts), updated_utc=now())
        write_json(RUN / "status.json", status)
        print(f"208 sealed False-only forecast {len(entries)}/64", flush=True)
        del (
            states,
            context,
            fb,
            edited,
            linear,
            candidate,
            receiver_j,
            finite_absolute,
            finite_delta,
            traces,
            arrays,
        )
        gc.collect()
    assert not (RUN / "observations").exists() and counts["ordinary_true_models"] == 0
    assert design["source_hashes"] == {p: sha(ROOT / p) for p in FILES}
    manifest = dict(
        entries=entries,
        sealed_utc=now(),
        design_fingerprint=digest(design),
        ordinary_false_models=counts["ordinary_false_models"],
        ordinary_true_models=counts["ordinary_true_models"],
    )
    write_json(RUN / "forecast-manifest.json", dict(manifest=manifest, sha256=digest(manifest)))
    numerical(model, device, manifest, counts)
    status.update(phase="native_true_after_global_seal", counts=dict(counts), updated_utc=now())
    write_json(RUN / "status.json", status)
    for entry in entries:
        key = entry["key"]
        fp = RUN / "forecasts" / (key + ".npz")
        fobj = json.loads(fp.with_suffix(".json").read_text())
        fr = fobj["record"]
        assert (
            digest(fr) == fobj["sha256"] == entry["record_sha256"]
            and sha(fp) == entry["arrays_sha256"]
        )
        started = now()
        assert (
            started > manifest["sealed_utc"]
            and started
            > json.loads((RUN / "false-numerical-checks.json").read_text())["completed_utc"]
        )
        states, context, scores = original.observe(
            model, torch.tensor([fr["bases"][1]["free_input_ids"]], device=device)
        )
        counts["ordinary_true_models"] += 1
        true = continuation.cpu(torch.stack(states)[:, 0])
        pos = fr["position"]
        checks = []
        with np.load(fp, allow_pickle=False) as z:
            check(
                checks,
                "native_unchanged_prefix",
                float(np.max(abs(true[:, :pos] - z["false_boundaries"][1:, :pos]))),
            )
            check(
                checks,
                "full_finite_native",
                float(np.max(abs(true[:, pos:] - z["full_finite_absolute_suffix"]))),
                float(
                    np.max(
                        abs(
                            continuation.cpu(scores)
                            - (z["false_scores"] + z["full_finite_control_delta_scores"])
                        )
                    )
                ),
            )
            check(
                checks,
                "candidate_source_all28",
                float(np.max(abs(true[:, pos] - z["source_receiver_absolute_source"]))),
            )
            native_first_delta = true[0, pos:].astype(np.float64) - z["false_boundaries"][
                1, pos:
            ].astype(np.float64)
            check(
                checks,
                "candidate_firstblock_fullsuffix",
                float(np.max(abs(native_first_delta - z["source_receiver_delta_suffix"][0]))),
            )
        store(
            RUN / "observations" / (key + ".npz"),
            dict(true_suffix=true[:, pos:], true_scores=continuation.cpu(scores)),
            dict(
                group=fr["group"],
                forecast_record_sha256=fobj["sha256"],
                forecast_manifest_sha256=sha(RUN / "forecast-manifest.json"),
                started_utc=started,
                completed_utc=now(),
                checks=checks,
            ),
        )
        status.update(
            observation_pairs=counts["ordinary_true_models"], counts=dict(counts), updated_utc=now()
        )
        write_json(RUN / "status.json", status)
        print(
            f"208 native True measurement {counts['ordinary_true_models']}/64 qualified", flush=True
        )
        del states, context, true
        gc.collect()


def main():
    assert not RUN.exists()
    assert json.loads((ROOT / "docs/analysis/209c-two-block-factorial.json").read_text())[
        "qualified"
    ]
    design = dict(
        source_hashes={p: sha(ROOT / p) for p in FILES},
        blocks=blocks(),
        arms=ARMS,
        factorial_audit_sha256=sha(ROOT / "docs/analysis/209c-two-block-factorial.json"),
        registered_utc=now(),
    )
    RUN.mkdir(parents=True)
    write_json(RUN / "design.json", dict(design=design, fingerprint=digest(design)))
    status = dict(
        status="running",
        qualified=False,
        phase="false_only_forecasts",
        forecast_pairs=0,
        observation_pairs=0,
        started_utc=now(),
    )
    counts = defaultdict(int)
    try:
        execute(design, status, counts)
        assert design["source_hashes"] == {p: sha(ROOT / p) for p in FILES}
        status.update(status="complete", qualified=True, completed_utc=now(), counts=dict(counts))
    except BaseException as exc:
        status.update(
            status="technical_failure", error=repr(exc), updated_utc=now(), counts=dict(counts)
        )
        write_json(RUN / "status.json", status)
        raise
    write_json(RUN / "status.json", status)


if __name__ == "__main__":
    main()
