"""False-only finite-source / linear-receiver update and distinct public hooks."""

import oracle_continuation_203 as continuation
import torch
from torch.autograd import forward_ad

from latent_decisions.target import block_tensor, replace_block_tensor


def forecast(model, fb, context, edited_embedding, pos, counts):
    delta = edited_embedding - fb[0]
    absolute_source = edited_embedding[:, pos].detach().clone()
    trace, receiver_trace, sources = [], [], []
    for index in range(28):
        operand = fb[index].clone()
        operand[:, pos] = absolute_source
        finite = continuation.finite(model, index, operand, context, counts)
        receiver = delta.clone()
        receiver[:, : pos + 1] = 0
        if index == 0:
            assert torch.count_nonzero(receiver) == 0
            transmitted = torch.zeros_like(delta)
            counts["skipped_zero_receiver_jvp"] += 1
        else:
            primal, transmitted = continuation.jvp(
                model, index, fb[index], receiver, context, counts
            )
            assert float(torch.max(abs(primal - fb[index + 1]))) <= 1e-4
        assert torch.count_nonzero(transmitted[:, : pos + 1]) == 0
        delta = finite - fb[index + 1] + transmitted
        absolute_source = finite[:, pos].detach().clone()
        assert torch.count_nonzero(delta[:, :pos]) == 0
        trace.append(delta)
        receiver_trace.append(transmitted)
        sources.append(absolute_source)
    return torch.stack(trace), torch.stack(receiver_trace), torch.stack(sources)


def full_finite(model, context, edited_embedding, counts):
    state, values = edited_embedding, []
    for index in range(28):
        state = continuation.finite(model, index, state, context, counts)
        values.append(state)
    return torch.stack(values)


def public_response(model, embedding, edited_embedding, pos):
    """NativeFalse whole-model primals; receiver tangents and source finite hooks."""
    values, sources, handles, operands = [], [], [], {}
    absolute_source = [edited_embedding[:, pos].detach().clone()]

    def run(lam):
        def pre_for(index):
            def pre(module, args, kwargs):
                xp, dx = forward_ad.unpack_dual(args[0])
                operand = xp.clone()
                operand[:, pos] = absolute_source[0]
                operands[index] = operand
                receiver = dx.clone()
                receiver[:, : pos + 1] = 0
                return (forward_ad.make_dual(xp, receiver), *args[1:]), kwargs

            return pre

        def out_for(index):
            def out(module, args, kwargs, output):
                yp, dy = forward_ad.unpack_dual(block_tensor(output))
                finite = block_tensor(module.forward(operands[index], **kwargs))
                delta = finite - yp + dy
                absolute_source[0] = finite[:, pos].detach().clone()
                sources.append(absolute_source[0])
                result = forward_ad.make_dual(yp, delta)
                values.append(result)
                return replace_block_tensor(output, result)

            return out

        def norm_hook(module, args, output):
            xp, dx = forward_ad.unpack_dual(args[0])
            yp, _ = forward_ad.unpack_dual(output)
            return forward_ad.make_dual(yp, module.forward(xp + dx) - yp)

        try:
            for index, layer in enumerate(model.model.layers):
                handles.append(layer.register_forward_pre_hook(pre_for(index), with_kwargs=True))
                handles.append(layer.register_forward_hook(out_for(index), with_kwargs=True))
            handles.append(model.model.norm.register_forward_hook(norm_hook))
            result = model(
                inputs_embeds=embedding + lam * (edited_embedding - embedding),
                attention_mask=torch.ones(
                    embedding.shape[:2], device=embedding.device, dtype=torch.long
                ),
                use_cache=False,
                logits_to_keep=1,
            )
            return torch.stack(values), result.logits[0, -1, [895, 830]]
        finally:
            for handle in handles:
                handle.remove()

    zero = torch.zeros((), device=embedding.device, dtype=embedding.dtype)
    primal, tangent = torch.func.jvp(run, (zero,), (torch.ones_like(zero),))
    return primal, tangent, torch.stack(sources)
