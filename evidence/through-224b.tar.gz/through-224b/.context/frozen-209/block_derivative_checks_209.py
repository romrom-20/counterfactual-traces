"""First reverse-mode projections of public-block JVPs; no double backward."""

import math

import numpy as np
import ranked_block_response_201 as original
import torch


def contract(a, b):
    x = a.detach().cpu().numpy().astype(np.float64)
    y = b.detach().cpu().numpy().astype(np.float64)
    return float(np.sum(x * y))


def verify(model, index, xf, false_out, context, directions, counts):
    """directions maps label to independently evaluated (input direction, JVP)."""
    x = xf.detach().clone().requires_grad_(True)
    y = original.block(model.model.layers[index], x, context)
    counts["reverse_block_forward"] += 1
    primal_error = float(torch.max(abs(y.detach() - false_out)))
    assert primal_error <= 1e-4, ("reverse primal", primal_error)
    n = y.numel()
    vectors = [
        (torch.sin(torch.arange(n, device=x.device, dtype=x.dtype) / 17) / math.sqrt(n)).reshape(
            y.shape
        ),
        (torch.cos(torch.arange(n, device=x.device, dtype=x.dtype) / 29) / math.sqrt(n)).reshape(
            y.shape
        ),
    ]
    head_input = false_out.detach().clone().requires_grad_(True)
    scores = original.head(model, head_input)
    vectors.append(torch.autograd.grad(scores[1] - scores[0], head_input)[0].detach())
    counts["reverse_head_forward"] += 1
    counts["reverse_head_backward"] += 1
    checks = []
    for label, vector in zip(["sin17", "cos29", "finite_margin_cotangent"], vectors):
        gradient = torch.autograd.grad((y * vector).sum(), x, retain_graph=True)[0]
        counts["reverse_block_backward"] += 1
        for name, (direction, jvp) in directions.items():
            reference = contract(gradient, direction)
            observed = contract(jvp, vector)
            error = abs(reference - observed)
            checks.append(
                dict(
                    block=index + 1,
                    direction=name,
                    projection=label,
                    reverse=reference,
                    forward=observed,
                    absolute_error=error,
                    tolerance=0.001 + 0.0001 * abs(reference),
                    passed=error <= 0.001 + 0.0001 * abs(reference),
                )
            )
    assert all(c["passed"] for c in checks), checks
    return checks
