"""Recompute all 209 endpoint metrics and signed factorial effects from arrays."""

import hashlib
import json
from pathlib import Path

import numpy as np

from latent_decisions.evidence_policy import digest, write_json

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / "runs/two-block-factorial-209b"
OUT = ROOT / "docs/analysis/209b-two-block-factorial.json"
ARMS = ("LL", "FL", "LF", "FF")


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def metrics(prediction, actual):
    p, a = prediction.ravel(), actual.ravel()
    pn, an = np.linalg.norm(p), np.linalg.norm(a)
    error = float(np.linalg.norm(p - a))
    return dict(
        error_norm=error,
        native_norm=float(an),
        prediction_norm=float(pn),
        relative_l2=error / float(an) if an else None,
        cosine=float(np.dot(p, a) / (pn * an)) if pn and an else None,
    )


def margin(scores):
    return float(scores[1] - scores[0])


def main():
    assert not OUT.exists()
    bundle = json.loads((RUN / "design.json").read_text())
    design = bundle["design"]
    assert digest(design) == bundle["fingerprint"]
    assert all(sha(ROOT / p) == h for p, h in design["source_hashes"].items())
    status = json.loads((RUN / "status.json").read_text())
    assert status["status"] == "complete" and status["qualified"]
    assert status["completed_pairs"] == 64
    expected_counts = dict(
        local_block_jvp=192,
        local_finite_block=192,
        reverse_block_forward=128,
        reverse_block_backward=384,
        reverse_head_forward=128,
        reverse_head_backward=128,
        finite_head_evaluations=704,
        whole_public_forward_ad=32,
    )
    assert status["counts"] == expected_counts, status["counts"]
    rows, checks, reverse_checks = [], [], []
    maximum_closure = maximum_margin_closure = 0.0
    for path in sorted((RUN / "pairs").glob("*.npz")):
        record = json.loads(path.with_suffix(".json").read_text())
        assert sha(path) == record["arrays_sha256"]
        assert record["parent_arrays_sha256"] == sha(
            ROOT / "runs/genuine-oracle-continuation-204-full/pairs" / path.name
        )
        checks.extend(record["checks"])
        reverse_checks.extend(record["derivative_checks"])
        with np.load(path, allow_pickle=False) as raw:
            z = {k: raw[k].astype(np.float64) for k in raw.files}
        pos = int(z["source_position"])
        native = z["native_true_suffix"][-1] - z["false_tail"][-1, pos:]
        pred = {arm: z[f"{arm}_delta_suffix"][-1] for arm in ARMS}
        m = {arm: margin(z[f"{arm}_delta_scores"]) for arm in ARMS}
        target = margin(z["true_scores"] - z["false_scores"])
        effects = dict(
            block27=pred["FL"] - pred["LL"],
            block28=pred["LF"] - pred["LL"],
            interaction=pred["FF"] - pred["FL"] - pred["LF"] + pred["LL"],
        )
        closure = float(np.max(abs(sum(effects.values()) - (pred["FF"] - pred["LL"]))))
        assert closure <= 1e-10
        maximum_closure = max(maximum_closure, closure)
        slices = dict(
            full=slice(None), source=slice(0, 1), receivers=slice(1, None), verdict=slice(-1, None)
        )
        arm_rows, effect_rows = {}, {}
        for arm in ARMS:
            item = {
                name: metrics(pred[arm][selection], native[selection])
                for name, selection in slices.items()
            }
            item.update(
                margin_prediction=m[arm],
                native_margin=target,
                signed_margin_error=m[arm] - target,
                absolute_margin_error=abs(m[arm] - target),
            )
            verdict = item["verdict"]
            item["passes_original_criteria"] = bool(
                verdict["native_norm"] >= 0.001
                and verdict["relative_l2"] <= 0.05
                and verdict["cosine"] is not None
                and verdict["cosine"] >= 0.99
                and item["absolute_margin_error"] <= 0.10
            )
            arm_rows[arm] = item
        # Project correction vectors toward the actual missing LL displacement.
        missing = native - pred["LL"]
        for effect, vector in effects.items():
            item = {}
            for name, selection in slices.items():
                v, e = vector[selection].ravel(), missing[selection].ravel()
                norm = float(np.linalg.norm(e))
                item[name] = dict(
                    norm=float(np.linalg.norm(v)),
                    signed_projection_toward_LL_missing=float(np.dot(v, e) / norm)
                    if norm
                    else None,
                )
            effect_rows[effect] = item
        additive_margin = margin(z["additive_endpoint_delta_scores"])
        me = dict(
            block27=m["FL"] - m["LL"],
            block28=m["LF"] - m["LL"],
            interaction=m["FF"] - m["FL"] - m["LF"] + m["LL"],
            residual_interaction_readout=m["FF"] - additive_margin,
            readout_combination=additive_margin - m["FL"] - m["LF"] + m["LL"],
        )
        mc = abs(me["interaction"] - me["residual_interaction_readout"] - me["readout_combination"])
        assert mc <= 1e-10
        maximum_margin_closure = max(maximum_margin_closure, mc)
        rows.append(
            dict(
                key=path.stem,
                group=record["group"],
                arms=arm_rows,
                effects=effect_rows,
                margin_effects=me,
            )
        )
    assert len(rows) == 64 and len(checks) == 544 and len(reverse_checks) == 576
    assert all(c["passed"] for c in checks + reverse_checks)
    strata = []
    for field in (None, "block", "schema", "reverse"):
        values = [None] if field is None else sorted({r["group"][field] for r in rows})
        for value in values:
            selected = [r for r in rows if field is None or r["group"][field] == value]
            arms = {}
            for arm in ARMS:
                arms[arm] = dict(
                    median_relative_l2=float(
                        np.median([r["arms"][arm]["verdict"]["relative_l2"] for r in selected])
                    ),
                    median_cosine=float(
                        np.median([r["arms"][arm]["verdict"]["cosine"] for r in selected])
                    ),
                    median_absolute_margin_error=float(
                        np.median([r["arms"][arm]["absolute_margin_error"] for r in selected])
                    ),
                    passing_individuals=sum(
                        r["arms"][arm]["passes_original_criteria"] for r in selected
                    ),
                )
            strata.append(dict(field=field, value=value, count=len(selected), arms=arms))
    report = dict(
        qualified=True,
        retrospective_only=True,
        design_fingerprint=bundle["fingerprint"],
        counts=expected_counts,
        cases=len(rows),
        checks=len(checks),
        derivative_checks=len(reverse_checks),
        maximum_check_coordinate_error=max(c["coordinate_error"] for c in checks),
        maximum_check_score_error=max(c["score_error"] for c in checks),
        maximum_derivative_projection_error=max(c["absolute_error"] for c in reverse_checks),
        maximum_vector_accounting_error=maximum_closure,
        maximum_margin_accounting_error=maximum_margin_closure,
        interpretation="Fixed native boundary26; false-state JVP versus finite blocks27/28; all headsfinite. Oracle diagnostic, nolearnedcircuit. Projected derivatives qualify onlytestedcontractions;196/204discrepanciesunresolved.",
        strata=strata,
        rows=rows,
        numerical_checks=checks,
        derivative_results=reverse_checks,
    )
    write_json(OUT, report)
    print(
        json.dumps(
            {
                k: v
                for k, v in report.items()
                if k not in ("rows", "numerical_checks", "derivative_results", "strata")
            },
            indent=2,
        )
    )
    print(json.dumps(strata[0], indent=2))


if __name__ == "__main__":
    main()
