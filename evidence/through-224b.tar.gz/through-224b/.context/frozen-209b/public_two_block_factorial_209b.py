"""Whole-model dual hooks with absolute operands for consecutive finite blocks."""

import torch
from torch.autograd import forward_ad

from latent_decisions.target import block_tensor, replace_block_tensor


def response(model, embedding, edit, reset_delta, reset_absolute, selected):
    values, handles, absolute = [], [], {}

    def run(lam):
        def hook_for(index):
            def hook(module, args, kwargs, output):
                result = block_tensor(output)
                yp, _ = forward_ad.unpack_dual(result)
                if index == 26:
                    result = forward_ad.make_dual(yp, reset_delta)
                elif index in selected:
                    xp, dx = forward_ad.unpack_dual(args[0])
                    operand = reset_absolute if index == 27 else absolute.get(27, xp + dx)
                    target = block_tensor(module.forward(operand, **kwargs))
                    absolute[index] = target
                    result = forward_ad.make_dual(yp, target - yp)
                values.append(result)
                return replace_block_tensor(output, result)

            return hook

        def norm_hook(module, args, output):
            xp, dx = forward_ad.unpack_dual(args[0])
            yp, _ = forward_ad.unpack_dual(output)
            return forward_ad.make_dual(yp, module.forward(xp + dx) - yp)

        try:
            for index, layer in enumerate(model.model.layers, 1):
                handles.append(layer.register_forward_hook(hook_for(index), with_kwargs=True))
            handles.append(model.model.norm.register_forward_hook(norm_hook))
            result = model(
                inputs_embeds=embedding + lam * edit,
                attention_mask=torch.ones(
                    embedding.shape[:2], device=embedding.device, dtype=torch.long
                ),
                use_cache=False,
                logits_to_keep=1,
            )
            return torch.stack(values), result.logits[0, -1, [895, 830]]
        finally:
            for handle in handles:
                handle.remove()

    zero = torch.zeros((), device=embedding.device, dtype=embedding.dtype)
    return torch.func.jvp(run, (zero,), (torch.ones_like(zero),))
