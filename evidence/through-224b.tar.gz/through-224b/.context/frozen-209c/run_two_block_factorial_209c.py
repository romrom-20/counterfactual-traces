"""Controlled27/28factorial with one native reset and a fixed finite readout."""

import gc
import hashlib
import json
from collections import defaultdict
from pathlib import Path

import block_derivative_checks_209 as derivatives
import numpy as np
import oracle_continuation_203 as continuation
import public_two_block_factorial_209b as public
import ranked_block_response_201 as original
import torch
from run_absence_alphabet_104 import now

from latent_decisions.evidence_policy import digest, write_json
from latent_decisions.target import load_target

ROOT = Path(__file__).resolve().parents[1]
PARENT = ROOT / "runs/genuine-oracle-continuation-204-full"
RUN = ROOT / "runs/two-block-factorial-209c"
FILES = [
    "scripts/run_two_block_factorial_209c.py",
    "scripts/block_derivative_checks_209.py",
    "scripts/audit_two_block_factorial_209c.py",
    "docs/experiments/209c-absolute-finite-factorial.md",
    "scripts/public_two_block_factorial_209b.py",
]
ARMS = {"LL": set(), "FL": {27}, "LF": {28}, "FF": {27, 28}}


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def check(checks, kind, coordinate=0.0, score=0.0, **meta):
    row = dict(
        kind=kind,
        coordinate_error=coordinate,
        score_error=score,
        passed=coordinate <= 1e-4 and score <= 0.005,
        **meta,
    )
    checks.append(row)
    assert row["passed"], row


def main():
    assert not RUN.exists()
    parent = json.loads((ROOT / "docs/analysis/204-full-oracle-vector-audit.json").read_text())
    assert parent["reset_qualified"]
    assert json.loads((PARENT / "status.json").read_text())["reset_qualified"]
    design = dict(
        source_hashes={f: sha(ROOT / f) for f in FILES},
        parent_audit_sha256=sha(ROOT / "docs/analysis/204-full-oracle-vector-audit.json"),
        arms={k: sorted(v) for k, v in ARMS.items()},
        boundary_completed_blocks=26,
        finite_readout=True,
        created_utc=now(),
    )
    RUN.mkdir(parents=True)
    write_json(RUN / "design.json", dict(design=design, fingerprint=digest(design)))
    status = dict(
        status="running", qualified=False, completed_pairs=0, counts={}, started_utc=now()
    )
    counts = defaultdict(int)
    write_json(RUN / "status.json", status)
    try:
        runtime = json.loads((PARENT / "runtime.json").read_text())
        model, tok, device = load_target(runtime["model"], "mps", offline=True)
        assert (
            digest(tok.get_vocab()) == runtime["tokenizer_hash"]
            and digest(model.config.to_dict()) == runtime["config_hash"]
        )
        assert (
            len(model.model.layers) == 28
            and model.config._attn_implementation == "eager"
            and not model.training
        )
        assert next(model.parameters()).dtype == torch.float32
        write_json(RUN / "runtime.json", runtime)
        for path in sorted((PARENT / "pairs").glob("*.npz")):
            record = json.loads(path.with_suffix(".json").read_text())
            assert sha(path) == record["arrays_sha256"]
            checks, reverse, arrays = [], [], {}
            with np.load(path, allow_pickle=False) as z:
                fb = [torch.tensor(v[None], device=device) for v in z["false_boundaries"]]
                context = dict(
                    mask=torch.tensor(z["mask"], device=device),
                    rope=tuple(torch.tensor(z[k], device=device) for k in ["rope_cos", "rope_sin"]),
                )
                pos = int(z["source_position"])
                native = torch.zeros_like(fb[26])
                native[:, pos:] = torch.tensor(z["native_delta_suffix"][26][None], device=device)
                true_tail = []
                for b in [26, 27, 28]:
                    t = fb[b].clone()
                    t[:, pos:] = torch.tensor(z["native_true_suffix"][b][None], device=device)
                    true_tail.append(t)
                check(
                    checks,
                    "native_boundary_absolute",
                    float(torch.max(abs(fb[26] + native - true_tail[0]))),
                )
                assert torch.count_nonzero(native[:, :pos]) == 0
                p27, l27 = continuation.jvp(model, 26, fb[26], native, context, counts)
                absolute27 = continuation.finite(model, 26, true_tail[0], context, counts)
                f27 = absolute27 - fb[27]
                check(checks, "false27_primal", float(torch.max(abs(p27 - fb[27]))))
                reverse.extend(
                    derivatives.verify(
                        model, 26, fb[26], fb[27], context, {"native26": (native, l27)}, counts
                    )
                )
                branches = {}
                j28directions = {}
                for first, incoming in [("L", l27), ("F", f27)]:
                    p28, l28 = continuation.jvp(model, 27, fb[27], incoming, context, counts)
                    operand28 = absolute27 if first == "F" else fb[27] + incoming
                    f28 = continuation.finite(model, 27, operand28, context, counts) - fb[28]
                    check(
                        checks,
                        "false28_primal",
                        float(torch.max(abs(p28 - fb[28]))),
                        branch27=first,
                    )
                    j28directions[first + "27"] = (incoming, l28)
                    for last, outgoing in [("L", l28), ("F", f28)]:
                        arm = first + last
                        scores = continuation.readout(model, fb[28], outgoing, True, counts)
                        branches[arm] = (incoming, outgoing, scores)
                        arrays[f"{arm}_delta_suffix"] = continuation.cpu(
                            torch.stack([incoming, outgoing])[:, 0, pos:]
                        )
                        arrays[f"{arm}_delta_scores"] = continuation.cpu(scores)
                reverse.extend(
                    derivatives.verify(model, 27, fb[27], fb[28], context, j28directions, counts)
                )
                check(
                    checks,
                    "LL_parent204_replay",
                    float(
                        np.max(
                            abs(
                                arrays["LL_delta_suffix"]
                                - z["before27_union_blocks_delta_suffix"][1:]
                            )
                        )
                    ),
                    float(
                        np.max(
                            abs(arrays["LL_delta_scores"] - z["before27_union_blocks_delta_scores"])
                        )
                    ),
                )
                ff = branches["FF"]
                check(
                    checks,
                    "FF_native_states",
                    max(
                        float(torch.max(abs(fb[b] + d - t)))
                        for b, d, t in zip([27, 28], ff[:2], true_tail[1:])
                    ),
                )
                sf = torch.tensor(z["false_scores"], device=device)
                st = torch.tensor(z["true_scores"], device=device)
                check(
                    checks, "FF_native_public_scores", score=float(torch.max(abs(sf + ff[2] - st)))
                )
                with torch.no_grad():
                    anchor = original.head(model, fb[28])
                counts["finite_head_evaluations"] += 1
                check(checks, "false_head_anchor", score=float(torch.max(abs(anchor - sf))))
                additive = branches["FL"][1] + branches["LF"][1] - branches["LL"][1]
                arrays["additive_endpoint_delta_suffix"] = continuation.cpu(additive[0, pos:])
                arrays["additive_endpoint_delta_scores"] = continuation.cpu(
                    continuation.readout(model, fb[28], additive, True, counts)
                )
                group = record["group"]
                if group["block"] == "cobalt" and group["reverse"] == 0:
                    fr = json.loads(
                        (
                            ROOT
                            / "runs/discovery-ranked-repair-201/forecasts"
                            / path.with_suffix(".json").name
                        ).read_text()
                    )["record"]
                    with torch.no_grad():
                        edit = (
                            model.model.embed_tokens(
                                torch.tensor([fr["bases"][1]["free_input_ids"]], device=device)
                            )
                            - fb[0]
                        )
                    for arm, selected in ARMS.items():
                        primal, tangent = public.response(
                            model, fb[0], edit, native, true_tail[0], selected
                        )
                        counts["whole_public_forward_ad"] += 1
                        trace = torch.stack(branches[arm][:2])
                        check(
                            checks,
                            "whole_public_hook",
                            max(
                                float(torch.max(abs(primal[0] - torch.stack(fb[1:])))),
                                float(torch.max(abs(tangent[0][26:] - trace))),
                            ),
                            float(torch.max(abs(tangent[1] - branches[arm][2]))),
                            arm=arm,
                        )
                        del primal, tangent
                arrays.update(
                    false_tail=continuation.cpu(torch.stack(fb[26:])[:, 0]),
                    native_true_suffix=continuation.cpu(torch.stack(true_tail)[:, 0, pos:]),
                    source_position=np.array(pos),
                    false_scores=z["false_scores"],
                    true_scores=z["true_scores"],
                )
                out = RUN / "pairs" / path.name
                out.parent.mkdir(parents=True, exist_ok=True)
                np.savez_compressed(out, **arrays)
                write_json(
                    out.with_suffix(".json"),
                    dict(
                        key=path.stem,
                        group=group,
                        checks=checks,
                        derivative_checks=reverse,
                        arrays_sha256=sha(out),
                        parent_arrays_sha256=sha(path),
                    ),
                )
            status.update(
                completed_pairs=status["completed_pairs"] + 1,
                counts=dict(counts),
                updated_utc=now(),
            )
            write_json(RUN / "status.json", status)
            print(f"209 factorial {status['completed_pairs']}/64 qualified", flush=True)
            del fb, native, branches, arrays, true_tail
            gc.collect()
        assert status["completed_pairs"] == 64
        assert design["source_hashes"] == {f: sha(ROOT / f) for f in FILES}
        status.update(status="complete", qualified=True, completed_utc=now())
    except BaseException as exc:
        status.update(
            status="technical_failure", error=repr(exc), counts=dict(counts), updated_utc=now()
        )
        write_json(RUN / "status.json", status)
        raise
    write_json(RUN / "status.json", status)


if __name__ == "__main__":
    main()
