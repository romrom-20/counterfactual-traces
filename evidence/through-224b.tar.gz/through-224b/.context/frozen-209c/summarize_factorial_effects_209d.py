"""Descriptive signed-effect summaries; no additional model or fitting."""

import hashlib
import json
from pathlib import Path

import numpy as np

from latent_decisions.evidence_policy import write_json

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "docs/analysis/209c-two-block-factorial.json"
OUT = ROOT / "docs/analysis/209c-factorial-effects.json"


def distribution(values):
    x = np.asarray(values, dtype=np.float64)
    return dict(
        minimum=float(x.min()),
        median=float(np.median(x)),
        maximum=float(x.max()),
        positive=int(sum(x > 0)),
        negative=int(sum(x < 0)),
        zero=int(sum(x == 0)),
    )


def main():
    assert not OUT.exists()
    source = json.loads(SOURCE.read_text())
    assert source["qualified"]
    strata = []
    for field in (None, "block", "schema", "reverse"):
        for value in (
            [None] if field is None else sorted({r["group"][field] for r in source["rows"]})
        ):
            rows = [r for r in source["rows"] if field is None or r["group"][field] == value]
            effects = {}
            for term in ("block27", "block28", "interaction"):
                effects[term] = {}
                for region in ("source", "receivers", "verdict", "full"):
                    effects[term][region] = dict(
                        norm=distribution([r["effects"][term][region]["norm"] for r in rows]),
                        signed_projection=distribution(
                            [
                                r["effects"][term][region]["signed_projection_toward_LL_missing"]
                                for r in rows
                            ]
                        ),
                        norm_relative_to_LL_error=distribution(
                            [
                                r["effects"][term][region]["norm"]
                                / r["arms"]["LL"][region]["error_norm"]
                                for r in rows
                            ]
                        ),
                    )
            margin = {
                term: distribution([r["margin_effects"][term] for r in rows])
                for term in rows[0]["margin_effects"]
            }
            single = {}
            for arm in ("FL", "LF"):
                single[arm] = dict(
                    residual_improves=sum(
                        r["arms"][arm]["verdict"]["relative_l2"]
                        < r["arms"]["LL"]["verdict"]["relative_l2"]
                        for r in rows
                    ),
                    margin_improves=sum(
                        r["arms"][arm]["absolute_margin_error"]
                        < r["arms"]["LL"]["absolute_margin_error"]
                        for r in rows
                    ),
                    residual_bound_passes=sum(
                        r["arms"][arm]["verdict"]["relative_l2"] <= 0.05 for r in rows
                    ),
                    margin_bound_passes=sum(
                        r["arms"][arm]["absolute_margin_error"] <= 0.10 for r in rows
                    ),
                )
            strata.append(
                dict(
                    field=field,
                    value=value,
                    count=len(rows),
                    effects=effects,
                    margin_effects=margin,
                    single_finite=single,
                )
            )
    output = dict(
        source_sha256=hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
        program_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        strata=strata,
        limits="Signed projections and separate norms, noL2fractions. Distributions of related cases, noindependentsampleinference. Interaction includes residual and readout components separatedalgebraically.",
    )
    write_json(OUT, output)
    print(json.dumps(strata[0], indent=2))


if __name__ == "__main__":
    main()
