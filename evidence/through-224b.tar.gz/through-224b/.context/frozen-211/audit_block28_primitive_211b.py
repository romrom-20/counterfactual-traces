"""Recompute signed211 vectors and every intervention endpoint from saved arrays."""

import json
from pathlib import Path

import numpy as np
import run_block28_primitive_211 as run
from audit_two_block_factorial_209 import metrics

from latent_decisions.evidence_policy import digest, write_json

ROOT, RUN = run.ROOT, run.RUN
OUT = ROOT / "docs/analysis/211-block28-primitives.json"


def margin(a):
    return float(a[1] - a[0])


def projected(v, missing):
    v, missing = v.ravel(), missing.ravel()
    vn, mn = float(np.linalg.norm(v)), float(np.linalg.norm(missing))
    return dict(
        norm=vn,
        signed_projection=float(np.dot(v, missing) / mn) if mn else None,
        cosine=float(np.dot(v, missing) / (vn * mn)) if vn and mn else None,
    )


def main():
    assert not OUT.exists()
    bundle = json.loads((RUN / "design.json").read_text())
    design = bundle["design"]
    assert digest(design) == bundle["fingerprint"]
    assert all(run.sha(ROOT / p) == h for p, h in design["source_hashes"].items())
    assert (
        run.sha(ROOT / "docs/analysis/209c-two-block-factorial.json")
        == design["parent_audit_sha256"]
    )
    assert (
        run.sha(ROOT / "docs/analysis/210c-actual-node-primitives.json")
        == design["local_derivative_report_sha256"]
    )
    status = json.loads((RUN / "status.json").read_text())
    assert status["status"] == "complete" and status["finite_interventions_qualified"]
    assert not status["original_wholeblock_jacobian_qualified"] and status["completed_pairs"] == 64
    expected_counts = dict(
        manual_mps_primitive_traces=192,
        finite_head_evaluations=5248,
        finite_intervention_blocks=2240,
        reference_budget_branches=128,
        whole_frozen_tangent_replay=128,
    )
    assert status["counts"] == expected_counts, status["counts"]
    rows, checks, local = [], [], []
    for path in sorted((RUN / "pairs").glob("*.npz")):
        record = json.loads(path.with_suffix(".json").read_text())
        assert run.sha(path) == record["arrays_sha256"]
        assert run.sha(run.PARENT / "pairs" / path.name) == record["parent_arrays_sha256"]
        checks.extend(record["checks"])
        local.extend(record["local_checks"])
        with np.load(path, allow_pickle=False) as raw:
            assert all(np.isfinite(v).all() for v in raw.values())
            z = {k: raw[k].astype(np.float64) for k in raw.files}
        actual = z["native_final"] - z["false_final"]
        target = margin(z["true_scores"] - z["false_scores"])
        regions = dict(
            full=slice(None), source=slice(0, 1), receivers=slice(1, None), verdict=slice(-1, None)
        )
        for branch in design["branches"]:
            endpoint_names = [
                k[len(branch) + 1 : -len("_delta")]
                for k in z
                if k.startswith(branch + "_") and k.endswith("_delta")
            ]
            assert len(endpoint_names) == 34, endpoint_names
            endpoints = {}
            baseline_missing = actual - z[f"{branch}_baseline_delta"]
            local_missing = z[f"{branch}_finite_delta"] - z[f"{branch}_baseline_delta"]
            for name in endpoint_names:
                prediction = z[f"{branch}_{name}_delta"]
                pm = margin(z[f"{branch}_{name}_scores"])
                m = {r: metrics(prediction[s], actual[s]) for r, s in regions.items()}
                v = m["verdict"]
                m.update(
                    predicted_margin=pm,
                    native_margin=target,
                    signed_margin_error=pm - target,
                    absolute_margin_error=abs(pm - target),
                    primary_pass=bool(
                        v["native_norm"] >= 0.001
                        and v["relative_l2"] <= 0.05
                        and v["cosine"] is not None
                        and v["cosine"] >= 0.99
                        and abs(pm - target) <= 0.10
                    ),
                )
                endpoints[name] = m
            baseline = endpoints["baseline"]
            for item in endpoints.values():
                item["residual_improves_baseline"] = (
                    item["verdict"]["relative_l2"] < baseline["verdict"]["relative_l2"]
                )
                item["margin_improves_baseline"] = (
                    item["absolute_margin_error"] < baseline["absolute_margin_error"]
                )
                item["both_improve_baseline"] = (
                    item["residual_improves_baseline"] and item["margin_improves_baseline"]
                )
            vectors = {}
            vector_keys = [
                k
                for k in z
                if k.startswith(f"{branch}_component_")
                or k.startswith(f"{branch}_surgery_effect_")
                or k == f"{branch}_path_interaction"
            ]
            for key in vector_keys:
                vector = z[key]
                name = key[len(branch) + 1 :]
                vectors[name] = {
                    r: dict(
                        toward_local=projected(vector[s], local_missing[s]),
                        toward_native=projected(vector[s], baseline_missing[s]),
                    )
                    for r, s in regions.items()
                }
            all_components = [z[k] for k in vector_keys if k.startswith(f"{branch}_component_")]
            closure = float(np.max(abs(sum(all_components) - local_missing)))
            assert closure <= 1e-4, closure
            # The routing/value finite factorial is measured at fullblock output.
            cross = (
                z[f"{branch}_finite_delta"]
                - z[f"{branch}_lesion_clamp_routing_delta"]
                - z[f"{branch}_lesion_clamp_value_delta"]
                + z[f"{branch}_lesion_clamp_both_delta"]
            )
            assert float(np.max(abs(cross - z[f"{branch}_path_interaction"]))) <= 1e-10
            rows.append(
                dict(
                    key=path.stem,
                    group=record["group"],
                    branch=branch,
                    endpoints=endpoints,
                    vectors=vectors,
                    maximum_budget_closure_error=closure,
                )
            )
    assert len(rows) == 128 and len(checks) == 1600 and len(local) == 1920
    assert all(c["passed"] for c in checks + local)
    strata = []
    for branch in design["branches"]:
        selected_branch = [r for r in rows if r["branch"] == branch]
        for field in (None, "block", "schema", "reverse"):
            for value in (
                [None] if field is None else sorted({r["group"][field] for r in selected_branch})
            ):
                selected = [
                    r for r in selected_branch if field is None or r["group"][field] == value
                ]
                endpoint_summary = {}
                for name in selected[0]["endpoints"]:
                    items = [r["endpoints"][name] for r in selected]
                    endpoint_summary[name] = dict(
                        median_relative_l2=float(
                            np.median([m["verdict"]["relative_l2"] for m in items])
                        ),
                        median_absolute_margin_error=float(
                            np.median([m["absolute_margin_error"] for m in items])
                        ),
                        primary_passes=sum(m["primary_pass"] for m in items),
                        both_improve_baseline=sum(m["both_improve_baseline"] for m in items),
                        residual_improves_baseline=sum(
                            m["residual_improves_baseline"] for m in items
                        ),
                        margin_improves_baseline=sum(m["margin_improves_baseline"] for m in items),
                    )
                vector_summary = {}
                for name in selected[0]["vectors"]:
                    vector_summary[name] = {}
                    for region in regions:
                        items = [r["vectors"][name][region] for r in selected]
                        vector_summary[name][region] = dict(
                            median_norm=float(
                                np.median([m["toward_native"]["norm"] for m in items])
                            ),
                            median_projection_toward_native=float(
                                np.median([m["toward_native"]["signed_projection"] for m in items])
                            ),
                            positive_native_projection=sum(
                                m["toward_native"]["signed_projection"] > 0 for m in items
                            ),
                            median_projection_toward_local=float(
                                np.median([m["toward_local"]["signed_projection"] for m in items])
                            ),
                        )
                strata.append(
                    dict(
                        branch=branch,
                        field=field,
                        value=value,
                        count=len(selected),
                        endpoints=endpoint_summary,
                        vectors=vector_summary,
                    )
                )
    report = dict(
        auditor_sha256=run.sha(Path(__file__)),
        finite_interventions_qualified=True,
        original_wholeblock_jacobian_qualified=False,
        cases=64,
        branch_cases=128,
        controls=len(checks),
        local_surgery_derivative_checks=len(local),
        counts=expected_counts,
        maximum_coordinate_control_error=max(c["coordinate_error"] for c in checks),
        maximum_score_control_error=max(c["score_error"] for c in checks),
        maximum_local_surgery_derivative_error=max(c["coordinate_error"] for c in local),
        maximum_budget_closure_error=max(r["maximum_budget_closure_error"] for r in rows),
        design_fingerprint=bundle["fingerprint"],
        strata=strata,
        rows=rows,
        limits="Retrospective finite affine surgeries qualified onlyunderdefinedinterventions. FrozenCPU64budgetretainsreference/publicdifference;NOTexactoriginalMPSJacobianattribution,learnedcircuit,208generalizationorprospectiveprediction.",
    )
    write_json(OUT, report)
    print(json.dumps({k: v for k, v in report.items() if k not in ("strata", "rows")}, indent=2))
    for s in strata:
        if s["field"] is None:
            print(json.dumps({k: v for k, v in s.items() if k != "vectors"}, indent=2))


if __name__ == "__main__":
    main()
