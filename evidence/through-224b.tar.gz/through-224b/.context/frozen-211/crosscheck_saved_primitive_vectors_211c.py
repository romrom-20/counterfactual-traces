"""Additional saved-vector agreement and incoming-state sensitivity, no model calls."""

import hashlib
import json
from pathlib import Path

import numpy as np

from latent_decisions.evidence_policy import write_json

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / "runs/block28-primitive-211"
OUT = ROOT / "docs/analysis/211c-saved-vector-crosschecks.json"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    assert not OUT.exists()
    rows, sensitivity = [], []
    for path in sorted((RUN / "pairs").glob("*.npz")):
        record = json.loads(path.with_suffix(".json").read_text())
        assert sha(path) == record["arrays_sha256"]
        with np.load(path, allow_pickle=False) as z:
            for branch in ("native", "linear27"):
                ref = z[f"{branch}_component_gate_up"][1:].ravel()
                effect = z[f"{branch}_surgery_effect_gate_up_interaction"][1:].ravel()
                error = float(np.max(abs(ref - effect)))
                rows.append(
                    dict(
                        key=path.stem,
                        group=record["group"],
                        branch=branch,
                        maximum_coordinate_disagreement=error,
                        coordinate_agreement_passed=error <= 1e-4,
                        relative_l2_disagreement=float(
                            np.linalg.norm(ref - effect) / np.linalg.norm(effect)
                        ),
                        parent_arrays_sha256=sha(path),
                    )
                )
            for stem in (
                "component_input_rms",
                "component_qk_product",
                "component_softmax",
                "component_weight_value",
                "component_post_rms",
                "component_silu",
                "component_gate_up",
                "surgery_effect_attention_norm_routing",
                "surgery_effect_value_output_interaction",
                "surgery_effect_mlp_input_rms",
                "surgery_effect_silu_curvature",
                "surgery_effect_gate_up_interaction",
            ):
                native, linear = [
                    z[f"{branch}_{stem}"][1:].ravel() for branch in ("native", "linear27")
                ]
                nn, ln = np.linalg.norm(native), np.linalg.norm(linear)
                sensitivity.append(
                    dict(
                        key=path.stem,
                        group=record["group"],
                        vector=stem,
                        incoming_state_cosine=float(np.dot(native, linear) / (nn * ln)),
                        linear_to_native_norm=float(ln / nn),
                        relative_vector_change=float(np.linalg.norm(native - linear) / nn),
                    )
                )
    assert len(rows) == 128 and len(sensitivity) == 64 * 12
    summary = []
    for vector in sorted({r["vector"] for r in sensitivity}):
        selected = [r for r in sensitivity if r["vector"] == vector]
        summary.append(
            dict(
                vector=vector,
                median_incoming_state_cosine=float(
                    np.median([r["incoming_state_cosine"] for r in selected])
                ),
                median_linear_to_native_norm=float(
                    np.median([r["linear_to_native_norm"] for r in selected])
                ),
                median_relative_vector_change=float(
                    np.median([r["relative_vector_change"] for r in selected])
                ),
            )
        )
    report = dict(
        program_sha256=sha(Path(__file__)),
        protocol_sha256=sha(ROOT / "docs/experiments/211c-saved-vector-crosschecks.md"),
        gate_up_receiving_coordinate_agreement_passed=all(
            r["coordinate_agreement_passed"] for r in rows
        ),
        failures=sum(not r["coordinate_agreement_passed"] for r in rows),
        maximum_coordinate_disagreement=max(r["maximum_coordinate_disagreement"] for r in rows),
        median_relative_l2_disagreement=float(
            np.median([r["relative_l2_disagreement"] for r in rows])
        ),
        summary=summary,
        rows=rows,
        sensitivity=sensitivity,
        limits="Savedvectorsonly, noadditionalmodelor208evaluation. Any1e-4failurepreserved; nooriginalMPSJacobianrecertification.",
    )
    write_json(OUT, report)
    print(
        json.dumps({k: v for k, v in report.items() if k not in ("rows", "sensitivity")}, indent=2)
    )


if __name__ == "__main__":
    main()
