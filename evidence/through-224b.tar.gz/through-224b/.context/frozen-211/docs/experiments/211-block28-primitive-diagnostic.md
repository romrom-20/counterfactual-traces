# Block28 primitive diagnostic from qualified209c

Register before211execution. Retain209c native full-sequence reset BEFORE27 and both block28incoming states: N=native finite27absoluteoutput; L=False27+original27linear displacement. All64old209ccontexts, no fresh208extension. Same pinnedQwen1.5B/MPSFloat32/eager/eval, fullcausalprefix/mask/RoPE, finite finalRMSNorm/Booleanreadout. No fitting, browsing, training, publication, staging/commit/push. Scientificfiles immutableafterfirstexecution; corrections separatelynamed.

## Derivative gate and distinct scopes

Sol's210 failed strict originalMPS wholeblock compatibility:4/64native and4/64linear directions exceed1e-4; original relevant additivityfails15/64. These failures persist.210b/210c independently qualify7local nonlinear derivatives,896checks each, against public primitivefirstAD andCPU64centralFD at original1e-4bound.210cusesactualfinite-node displacements. New211mustnotclaimoriginalMPSJacobian or196/204issuesresolved.

Two distinct deliverables: (a) frozen-primalCPU64 signed linear-operator accounting with an EXPLICIT Jreference−Jpublic numerical vector, and (b) finite interventions on the actualMPSblock. Only(b), subject to its owncontrols, supports intervention-specific causal statements. Reference accounting alone is not an exact attribution of the unqualified originalJacobian discrepancy. No learned circuit claim.

## Signed-vector accounting

Capture nativeFalse primitive primals and finite primals at N/Labsoluteinputs. At each graphnode compute actual finiteoutputdifference minus its frozenFalse localJacobian applied to ACTUALparentdifferences. Propagate each node remainder through the fixedCPU64False linear graph. Five reported nonlinear groups:

1. Attention normalization/routing: inputRMSNorm,QKbilinearproduct,softmax; retain allthree separately.
2. Attention weight–value product interaction. V and O projections themselves are linear and their finite rounding goes into the numerical group; also measure the finite value pathway separately below.
3. MLP-input post-attentionRMSNorm.
4. SiLU gate nonlinearity.
5. Gate–up bilinear interaction.

Keep all linear-projection/residual-addition rounding remainders separate. Add the measured Jreference−Jpublic vector explicitly. Check their signed-vector sum reconstructs finiteblock28delta−original209cJVP <=1e-4 on source/receivers/verdict/fullsequence. This is graph accounting, not an independent derivative validation. Report separate norms and signed projections toward BOTH local finite-minus-linear discrepancy and actual native final-minus-linear error, never sum norms as causal fractions. Compare N/Lcontexts, source/schema/order/cells.

## Finite surgical interventions

Starting from each fixedabsolute N/Linput, run the actualpublicMPSblock with one primitive/group replaced by its False-anchored affine function; allotheroperationsstayfinite and change their inputs normally. Affineoutput = cachedFalseoutput + qualifiedCPU64localDerivative(currentinput−cachedFalseinput), convertedtoMPSFloat32. This is an explicitly defined intervention, not a claim that originalMPSfloating tangent is exact. Replace the fivegroups above individually, plus inputRMS,QK,softmax individually. Preserve every arm. Use public modulehooks and attentioninterface replacement; no output error norms masquerading as model continuation.

For EACH affineoperationactuallyused, checkCPU64localderivative versus publicprimitivefirstAD on that surgery'scurrentparentdirection, coordinate<=1e-4. Keep failures, do notrelax. AtFalseinput every intervention mustreplay unmodifiedFalseoutput<=1e-4/score<=.005. Fullfinite N/Lmustreplay209cFF/LF states/scores<=1e-4/.005. Restorehooks aftereachrun. Readout ALWAYSfinite. Source and prefixeffects are recorded separately.

Save intervention receiving-vector effect C=fullfiniteoutput−lesionedoutput (fullsequence, plus receivingselection). Necessity test: lesionfinalresidual/margin relative to both fullfinite and actualnative target. Retrospective sufficiency test: add ONLYreceiving rows of C to original209cJacobian prediction and re-evaluate finitehead; report whether both native finalresidual and absolutemarginerror improve over that exactsameJacobianbaseline. This correction is ORACLEdiagnostic, not a false-state forecast or unique additive circuit. Apply everypredeclaredprimitive, no choose-winner-after-fit.

Also run a derivative-free attentionpath2×2: retain finite routingweights/value states, or clamp routingweights toFalse and/or values toFalse while recomputing the publicoutputprojection and downstreamMLP finitely. This identifies defined routing/valuepath interventions separately from weight–value curvature. Save actual receiving-vector contrasts and interaction; do not confuse localattentionalgebra with fullblock nonlinearMLPresponse.

All individual native success bounds remain residualrelativeL2<=.05,cosine>=.99,nativenorm>=.001,absmarginerror<=.10nats. Improvement is paired descriptive withintheseoraclecontexts; do notcallitpreregistered208success, independentreplication, or statisticalpopulationevidence. A primitive effect is state-dependent if N/Lresponses differ; no attributing that difference solely to localcurvature without accounting incomingstatechange.

Required controls before intervention-specific interpretation: immutableparent/source/runtimehashes, fullFalse/publicprimitiveprimalreplay, exactN/Lreplay, affineFalse shamreplays, allaffine localderivativechecks, finiteheadanchor, graphbudgetclosure, complete64×2branches/allarms. If these fail, stopmechanisticinterpretation, preserveartifacts and separatelynamecorrection. OriginalwholeJacobiancompatibility remainsFALSE even if these scopedfiniteinterventionchecks pass. Only a qualified repeatableoperation-specific causal effect would justify a later preregistered208generalization; that extension is outside211.

Storageclarification beforeexecution: fullsequence calculations are performed. At eachbranch, explicitly check and save maximum prefix coordinate effect over all components and all surgicaleffects (required<=1e-4), then persist the compact causal suffix plus that maximum and hash-bound fullparentFalse/native states. This is not a tokenlocal intervention. The reference/public mismatch also includes the difference between CPU64absoluteinput subtraction and the savedMPSFloat32incoming direction, not exclusively tangent arithmetic. Affine derivativerechecks cover allactuallyusedsurgicaldirections including changedroutingparents.
