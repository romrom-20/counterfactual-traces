"""Retrospective primitive budgets and finite interventions on qualified209c inputs."""

import gc
import hashlib
import json
from collections import defaultdict
from pathlib import Path

import numpy as np
import oracle_continuation_203 as continuation
import primitive_diagnostic_211 as primitive
import ranked_block_response_201 as original
import torch
from frozen_block28_derivative_210 import tangent, trace
from run_absence_alphabet_104 import now

from latent_decisions.evidence_policy import digest, write_json
from latent_decisions.target import load_target

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / "runs/block28-primitive-211"
PARENT = ROOT / "runs/two-block-factorial-209c"
FILES = [
    "scripts/run_block28_primitive_211.py",
    "scripts/primitive_diagnostic_211.py",
    "scripts/audit_block28_primitive_211.py",
    "docs/experiments/211-block28-primitive-diagnostic.md",
    "scripts/frozen_block28_derivative_210.py",
    "scripts/local_primitive_derivative_210c.py",
]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def check(checks, kind, coordinate=0.0, score=0.0, **meta):
    row = dict(
        kind=kind,
        coordinate_error=coordinate,
        score_error=score,
        passed=coordinate <= 1e-4 and score <= 0.005,
        **meta,
    )
    checks.append(row)
    assert row["passed"], row


def head(model, state, false_scores, counts):
    with torch.no_grad():
        result = original.head(model, state) - false_scores
    counts["finite_head_evaluations"] += 1
    return continuation.cpu(result)


def execute(design, status, counts):
    runtime = json.loads(
        (ROOT / "runs/genuine-oracle-continuation-204-full/runtime.json").read_text()
    )
    model, tok, device = load_target(runtime["model"], "mps", offline=True)
    torch.set_num_threads(2)
    assert (
        digest(tok.get_vocab()) == runtime["tokenizer_hash"]
        and digest(model.config.to_dict()) == runtime["config_hash"]
    )
    assert (
        not model.training
        and model.config._attn_implementation == "eager"
        and next(model.parameters()).dtype == torch.float32
    )
    write_json(RUN / "runtime.json", dict(**runtime, cpu_threads=2))
    layer = model.model.layers[27]
    for path in sorted((PARENT / "pairs").glob("*.npz")):
        metadata = json.loads(path.with_suffix(".json").read_text())
        assert sha(path) == metadata["arrays_sha256"]
        original_path = ROOT / "runs/genuine-oracle-continuation-204-full/pairs" / path.name
        assert sha(original_path) == metadata["parent_arrays_sha256"]
        checks, local_checks, arrays = [], [], {}
        with (
            np.load(path, allow_pickle=False) as z,
            np.load(original_path, allow_pickle=False) as oz,
        ):
            pos = int(z["source_position"])
            false_input = torch.tensor(z["false_tail"][1][None], device=device)
            false_final = torch.tensor(z["false_tail"][2][None], device=device)
            context = dict(
                mask=torch.tensor(oz["mask"], device=device),
                rope=tuple(torch.tensor(oz[k], device=device) for k in ("rope_cos", "rope_sin")),
            )
            c = trace(layer, false_input, context)
            c["position"] = pos
            counts["manual_mps_primitive_traces"] += 1
            check(
                checks,
                "false_primitive_trace",
                float((c["output"] - false_final.cpu().double()).abs().max()),
            )
            with torch.no_grad():
                sf = original.head(model, false_final)
            counts["finite_head_evaluations"] += 1
            check(
                checks,
                "false_finite_head",
                score=float(np.max(abs(continuation.cpu(sf) - z["false_scores"]))),
            )
            native_final = false_final.clone()
            native_final[:, pos:] = torch.tensor(z["native_true_suffix"][2][None], device=device)
            for name, enabled in {
                **primitive.LESIONS,
                "clamp_routing": (),
                "clamp_value": (),
                "clamp_both": (),
            }.items():
                with (
                    primitive.surgeries(
                        layer,
                        c,
                        context,
                        enabled,
                        name in ("clamp_routing", "clamp_both"),
                        name in ("clamp_value", "clamp_both"),
                    ) as lc,
                    torch.no_grad(),
                ):
                    sham = original.block(layer, false_input, context)
                counts["finite_intervention_blocks"] += 1
                local_checks.extend(dict(branch="False_sham", arm=name, **r) for r in lc)
                check(
                    checks,
                    "false_surgery_sham",
                    float(torch.max(abs(sham - false_final))),
                    float(np.max(abs(head(model, sham, sf, counts)))),
                    arm=name,
                )
            arrays.update(
                false_final=continuation.cpu(false_final[0, pos:]),
                native_final=continuation.cpu(native_final[0, pos:]),
                false_scores=z["false_scores"],
                true_scores=z["true_scores"],
                position=np.array(pos),
            )
            for branch, first, last in (("native", "FL", "FF"), ("linear27", "LL", "LF")):
                if branch == "native":
                    absolute = false_input.clone()
                    absolute[:, pos:] = torch.tensor(
                        z["native_true_suffix"][1][None], device=device
                    )
                else:
                    incoming = torch.zeros_like(false_input)
                    incoming[:, pos:] = torch.tensor(z["LL_delta_suffix"][0][None], device=device)
                    absolute = false_input + incoming
                public_j = torch.zeros_like(false_final)
                public_j[:, pos:] = torch.tensor(
                    z[f"{first}_delta_suffix"][-1][None], device=device
                )
                finite_cache = trace(layer, absolute, context)
                counts["manual_mps_primitive_traces"] += 1
                with primitive.surgeries(layer, c, context) as lc, torch.no_grad():
                    full = original.block(layer, absolute, context)
                counts["finite_intervention_blocks"] += 1
                check(
                    checks,
                    "finite_public_primitive_reconstruction",
                    float((full.cpu().double() - finite_cache["output"]).abs().max()),
                    branch=branch,
                )
                expected = z["false_tail"][2, pos:].astype(np.float64) + z[f"{last}_delta_suffix"][
                    -1
                ].astype(np.float64)
                check(
                    checks,
                    "finite_209c_replay",
                    float(
                        np.max(abs(continuation.cpu(full[0, pos:]).astype(np.float64) - expected))
                    ),
                    float(np.max(abs(head(model, full, sf, counts) - z[f"{last}_delta_scores"]))),
                    branch=branch,
                )
                components, closure, reference = primitive.remainder_budget(
                    c, finite_cache, public_j
                )
                prefix_errors = [float(v[:, :pos].abs().max()) for v in components.values()]
                prefix_errors.append(float((full - false_final)[:, :pos].abs().max()))
                counts["reference_budget_branches"] += 1
                check(checks, "signed_reference_budget", closure, branch=branch)
                ref, _ = tangent(c, finite_cache["x"] - c["x"])
                counts["whole_frozen_tangent_replay"] += 1
                check(
                    checks,
                    "suffix_optimized_reference_replay",
                    float((ref - reference).abs().max()),
                    branch=branch,
                )
                for label, vector in components.items():
                    arrays[f"{branch}_component_{label}"] = continuation.cpu(vector[0, pos:])
                # Keep the explicitly grouped routing correction and all seven primitives.
                correction_vectors = {
                    **components,
                    "attention_norm_routing": sum(
                        components[k] for k in primitive.GROUPS["attention_norm_routing"]
                    ),
                }
                baseline = false_final + public_j
                arrays[f"{branch}_baseline_delta"] = continuation.cpu(public_j[0, pos:])
                arrays[f"{branch}_baseline_scores"] = head(model, baseline, sf, counts)
                check(
                    checks,
                    "original_jvp_finite_readout_replay",
                    score=float(
                        np.max(
                            abs(arrays[f"{branch}_baseline_scores"] - z[f"{first}_delta_scores"])
                        )
                    ),
                    branch=branch,
                )
                arrays[f"{branch}_finite_delta"] = continuation.cpu(full[0, pos:]).astype(
                    np.float64
                ) - z["false_tail"][2, pos:].astype(np.float64)
                arrays[f"{branch}_finite_scores"] = head(model, full, sf, counts)
                for name, vector in correction_vectors.items():
                    patched = baseline.detach().cpu().double()
                    patched[:, pos + 1 :] += vector[:, pos + 1 :]
                    patched = patched.to(device=device, dtype=torch.float32)
                    arrays[f"{branch}_budget_repair_{name}_delta"] = continuation.cpu(
                        patched[0, pos:]
                    ).astype(np.float64) - z["false_tail"][2, pos:].astype(np.float64)
                    arrays[f"{branch}_budget_repair_{name}_scores"] = head(
                        model, patched, sf, counts
                    )
                for name, enabled in {
                    **primitive.LESIONS,
                    "clamp_routing": (),
                    "clamp_value": (),
                    "clamp_both": (),
                }.items():
                    with (
                        primitive.surgeries(
                            layer,
                            c,
                            context,
                            enabled,
                            name in ("clamp_routing", "clamp_both"),
                            name in ("clamp_value", "clamp_both"),
                        ) as lc,
                        torch.no_grad(),
                    ):
                        lesioned = original.block(layer, absolute, context)
                    counts["finite_intervention_blocks"] += 1
                    local_checks.extend(dict(branch=branch, arm=name, **r) for r in lc)
                    assert all(r["passed"] for r in lc), lc
                    effect = full.cpu().double() - lesioned.cpu().double()
                    prefix_errors.append(float(effect[:, :pos].abs().max()))
                    arrays[f"{branch}_lesion_{name}_delta"] = continuation.cpu(
                        lesioned[0, pos:]
                    ).astype(np.float64) - z["false_tail"][2, pos:].astype(np.float64)
                    arrays[f"{branch}_lesion_{name}_scores"] = head(model, lesioned, sf, counts)
                    arrays[f"{branch}_surgery_effect_{name}"] = continuation.cpu(effect[0, pos:])
                    patched = baseline.cpu().double()
                    patched[:, pos + 1 :] += effect[:, pos + 1 :]
                    patched = patched.to(device=device, dtype=torch.float32)
                    arrays[f"{branch}_surgery_repair_{name}_delta"] = continuation.cpu(
                        patched[0, pos:]
                    ).astype(np.float64) - z["false_tail"][2, pos:].astype(np.float64)
                    arrays[f"{branch}_surgery_repair_{name}_scores"] = head(
                        model, patched, sf, counts
                    )
                # Derivative-free routing/value factorial: native routing/value, or False clamps.
                arrays[f"{branch}_path_interaction"] = (
                    arrays[f"{branch}_finite_delta"]
                    - arrays[f"{branch}_lesion_clamp_routing_delta"]
                    - arrays[f"{branch}_lesion_clamp_value_delta"]
                    + arrays[f"{branch}_lesion_clamp_both_delta"]
                )
                arrays[f"{branch}_prefix_maximum"] = np.array(max(prefix_errors))
                check(checks, "zero_prefix_support", max(prefix_errors), branch=branch)
            assert all(r["passed"] for r in local_checks)
        out = RUN / "pairs" / path.name
        out.parent.mkdir(parents=True, exist_ok=True)
        assert not out.exists() and all(np.isfinite(a).all() for a in arrays.values())
        np.savez_compressed(out, **arrays)
        write_json(
            out.with_suffix(".json"),
            dict(
                key=path.stem,
                group=metadata["group"],
                arrays_sha256=sha(out),
                parent_arrays_sha256=sha(path),
                checks=checks,
                local_checks=local_checks,
            ),
        )
        status.update(
            completed_pairs=status["completed_pairs"] + 1, counts=dict(counts), updated_utc=now()
        )
        write_json(RUN / "status.json", status)
        print(
            f"211 primitive diagnostic {status['completed_pairs']}/64 finite controls qualified",
            flush=True,
        )
        del c, finite_cache, components, correction_vectors, arrays
        gc.collect()


def main():
    assert not RUN.exists()
    assert json.loads((ROOT / "docs/analysis/209c-two-block-factorial.json").read_text())[
        "qualified"
    ]
    assert json.loads((ROOT / "runs/block28-derivative-210c/status.json").read_text())["passed"]
    design = dict(
        source_hashes={p: sha(ROOT / p) for p in FILES},
        registration_utc=now(),
        parent_audit_sha256=sha(ROOT / "docs/analysis/209c-two-block-factorial.json"),
        local_derivative_report_sha256=sha(ROOT / "docs/analysis/210c-actual-node-primitives.json"),
        original_wholeblock_jacobian_qualified=False,
        groups=primitive.GROUPS,
        lesions=primitive.LESIONS,
        branches=["native", "linear27"],
    )
    RUN.mkdir(parents=True)
    write_json(RUN / "design.json", dict(design=design, fingerprint=digest(design)))
    status = dict(
        status="running",
        finite_interventions_qualified=False,
        original_wholeblock_jacobian_qualified=False,
        completed_pairs=0,
        started_utc=now(),
    )
    counts = defaultdict(int)
    try:
        execute(design, status, counts)
        assert status["completed_pairs"] == 64 and design["source_hashes"] == {
            p: sha(ROOT / p) for p in FILES
        }
        status.update(
            status="complete",
            finite_interventions_qualified=True,
            completed_utc=now(),
            counts=dict(counts),
        )
    except BaseException as exc:
        status.update(
            status="technical_failure", error=repr(exc), counts=dict(counts), updated_utc=now()
        )
        write_json(RUN / "status.json", status)
        raise
    write_json(RUN / "status.json", status)


if __name__ == "__main__":
    main()
