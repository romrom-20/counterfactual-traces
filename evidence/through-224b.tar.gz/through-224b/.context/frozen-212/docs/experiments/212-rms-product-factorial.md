# Controlled MLP-input RMSNorm × gate–up product factorial

Registered before execution. Use all64 qualified209c contexts and two block28 incoming states from the native FULLsequence reset before block27: native finite27absoluteoutput and originalFalse27+linear27displacement. No new208run, broad28blocksweep, fit, browser, training, staging/commit/push or publication. All prior failures remain. Scientific files immutable after first execution; separately name corrections and preserve original thresholds.

Use phi=SiLU(gatepreactivation), not preactivationg in the product identity. Sol's independent213 decomposes actual finite product change into DeltaPhi*uFalse,phiFalse*DeltaU,DeltaPhi*DeltaU, with explicit product/cast/downprojection/residual rounding terms. The strict unadjusted reference-versus-finite coordinate failures remain failures even if measured rounding terms close the accounting.

## Four conditions, two fixed backgrounds

At each incoming state, cross MLP-input post-attentionRMSNorm (R) and gate–up product (G): LL,FL,LF,FF, letters orderedRthenG. L means cachedFalse-output plus the qualified localFalse derivative at actual changed inputs, computedCPU64 then convertedMPSFloat32. F means actualfinitepublicprimitive. False anchors stay fixed across arms; no native-state coefficient calibration.

PRIMARY finite background: attention and SiLU remain FINITE in allfourarms. Thus FF is the ordinaryfinite28block; native FFmatching is a CONTROL, not a newprediction or mechanism discovery. FL mustreplay211gate-up lesion; LF mustreplay211MLP-RMS lesion; FF mustreplay211finite branch. This tests whether the product effect changes when normalization is repaired while holding the other computations fixed.

SEPARATE affine background: attentioninputRMS,QKproduct,softmax,weight–valueproduct andSiLU remain False-AFFINE in allfourarms; only R/G vary. This tests a prospective-relevant local surrogate, but the incomingnative/linear27states remain oracle-derived diagnosticinputs. Its LL is a defined finite affine computation, not automatically the exact originalMPSJacobian. Compare to original209cJVP at1e-4 and preserve any failures as NONrequired originalcompatibility checks; originalwholeJacobianqualification remainsFALSE. Alllocal derivatives and actualsurgery checks remain required. Do not combine backgrounds or select favorable outcomes.

For each background save actualfullsequence endpoints. Also add only RECEIVINGrows of each measured D_arm−D_LL contrast to the ORIGINAL209cJVP prediction, using finitehead. This anchored contrast is an explicitly defined oracle repair, not retrospective recertification of the originalJacobian or a false-state forecast. No nativeTrue output enters contrast construction. Native output is used only as the retrospective evaluation target.

## Signed interaction and endpoints

Save cR=D_FL−D_LL,cG=D_LF−D_LL,I=D_FF−D_FL−D_LF+D_LL. Check the vector identity at1e-4 onreceivers/source/verdict/fullsequence. Record norms and signed projections toward BOTH localFF−LL and actualnative-minus-LL errors. Preserve gateconditional effects D_LF−D_LL versus D_FF−D_FL and normconditional effects analogously. No subtraction of error norms or causal fractions.

Every head is FINITE normalization plus fixedtrue830/false895logits. Marginfactorial contrast includes readout geometry. Evaluate syntheticadditive D_add=D_FL+D_LF−D_LL and separate G(FF)−G(add) from G(add)−G(FL)−G(LF)+G(LL). This is an algebraic measurement of one nonlinearreadout, not competing learned mechanisms. Report everycase/background/incoming/schema/order/source, alloriginal residualrelativeL2<=.05,cosine>=.99,nativenorm>=.001 andmarginerror<=.10nats, plus allfour-cell panels/whole>=3of4sourceblocks in EVERYschema/order. Improvement alone is not accuracy.

## Readout direction test

Using the independently measured211finite SiLU and gate–up effect vectors, apply each RECEIVINGvector at threeexplicitbases: original209cJVP forecast; finite-backgroundRMSfinite/productaffine FL; and the original211lesioned endpoint (so additionreconstructs its finite endpoint). The firsttwo are fixed-vector state interventions, not claims that the sameprimitive has the sameeffect there. Record exact finite margin change, signed native marginerror before/after, initial finite-readoutgradient projection, and remainder(exactchange−initialprojection). Do not infer readoutalignment from L2error alone.

Independently check the known closed-form RMSreadout gradient against public standardfirstreverse, original .001+.0001abs(reference) scalarbound, on all768segments(64×2incoming×2vectors×3bases). Finalhead staysfinite for allendpointmetrics. Gradientprojection is diagnostic, not replacementforfiniteG. Any geometric cancellation is expected readout geometry unless separately established as an operation mechanism.

## Required and separate controls

Require qualified209c/211finiteintervention/local210cparents; fullhashbindings; pinnedoriginalMPSFloat32/eager/eval; False primitive trace/publichead bounds; all8Falsefactorial sham arms <=1e-4/.005; native/linear finite-background three211arm replays <=1e-4/.005; local affine derivativechecks in EVERYactualdirection <=1e-4; allprefixsupports<=1e-4; finite algebraicvector/marginclosure; readoutgradientchecks and lesioned-to-finite readoutreconstruction. The affine-backgroundLL original-JVP comparison is explicitly measured but cannotqualify originalderivatives if itfails. No relaxed threshold or stale failure status converted tosuccess.

This is a bounded joint primitive diagnostic. It may motivate a later registered208retrospective or fresh-context test, but a favorable native-input FF is insufficient because it already runs the finite block. Broader208and freshprospective tests require a frozen nontrivial predictor and a separate preregistered evaluation when that predictor is ready; no generalization is claimed here.

Beforeexecution captureclarification: in everyfour-arm factorial capture actualpostSiLUphi,up,downprojectioninput/output,postnorminput andblockoutput. Check matchedphi/up/mid across the twoGconditions at eachR (gate-up intervention cannot alter its parents). Independently decompose puregate/up/mixedterms using sealed213helper, retainallroundingvectors, require productexpansion/parentmatch/numericalclosure<=1e-4, and explicitly record rawmixed-versus-finite failures without relabeling them. SignedfactorialI mustequal the normalization-dependent change in the projectedpuremixedterm PLUS the separatelymeasured change in numericalterms, within1e-4. Save branchterms andinteraction vectors onsource/receivers/verdict/causalprefix. This is an arithmetic explanation of definedfiniteinterventions, not certificationofwholeJacobian orlearnedfeature. No208candidate is selected fromtheseoracleoutcomes inthisrun.

Storageclarification beforeexecution: fullsequence inputs/computations/interventions are used; persist compact causalsuffix endpoints/vectors after explicitprefix-zero checks, with hash-bound fullparentstates. All768readoutsegments and allrawmixed/optionalJacobianfailures mustremain separate fromrequiredfactorialqualification.
