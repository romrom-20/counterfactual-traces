"""Fixed factorial definitions and finite-RMS readout geometry."""

import numpy as np
import ranked_block_response_201 as original
import torch

ARMS = ("LL", "FL", "LF", "FF")
BACKGROUNDS = ("finite", "affine")
FIXED_AFFINE = ("input_rms", "qk_product", "softmax", "weight_value", "silu")


def enabled(background, arm):
    fixed = list(FIXED_AFFINE) if background == "affine" else []
    if arm[0] == "L":
        fixed.append("post_rms")
    if arm[1] == "L":
        fixed.append("gate_up")
    return tuple(fixed)


def head_scores(model, state, counts):
    with torch.no_grad():
        result = original.head(model, state)
    counts["finite_head_evaluations"] += 1
    return result.detach().cpu().numpy().astype(np.float64)


def readout_segment(model, base, correction, false_scores, target_scores, counts):
    """FiniteG and independently computed initial differential, no linearhead forecast."""
    scores0 = head_scores(model, base, counts)
    changed = (base.detach().cpu().double() + correction.detach().cpu().double()).to(
        device=base.device, dtype=torch.float32
    )
    scores1 = head_scores(model, changed, counts)
    x = base.detach().clone().requires_grad_(True)
    logits = original.head(model, x)
    gradient = torch.autograd.grad(logits[1] - logits[0], x)[0]
    counts["readout_reverse_forward"] += 1
    counts["readout_reverse_backward"] += 1
    reverse = float(
        np.sum(
            gradient.detach().cpu().numpy().astype(np.float64)
            * correction.detach().cpu().numpy().astype(np.float64)
        )
    )
    h = base[0, -1].detach().cpu().double()
    direction = correction[0, -1].detach().cpu().double()
    norm = model.model.norm
    weight = (
        model.lm_head.weight[830] - model.lm_head.weight[895]
    ).detach().cpu().double() * norm.weight.detach().cpu().double()
    inv = torch.rsqrt(h.square().mean() + norm.variance_epsilon)
    closed_gradient = weight * inv - h * inv.pow(3) * (weight * h).mean()
    analytic = float((closed_gradient * direction).sum())
    error = abs(reverse - analytic)
    check = dict(
        reverse_projection=reverse,
        analytic_projection=analytic,
        absolute_error=error,
        tolerance=0.001 + 0.0001 * abs(reverse),
        passed=error <= 0.001 + 0.0001 * abs(reverse),
    )
    delta0 = scores0 - false_scores
    delta1 = scores1 - false_scores
    native = float((target_scores - false_scores)[1] - (target_scores - false_scores)[0])
    margin0, margin1 = float(delta0[1] - delta0[0]), float(delta1[1] - delta1[0])
    change = margin1 - margin0
    return dict(
        margin_before=margin0,
        margin_after=margin1,
        finite_margin_change=change,
        initial_gradient_projection=analytic,
        finite_minus_initial_projection=change - analytic,
        native_margin=native,
        signed_error_before=margin0 - native,
        signed_error_after=margin1 - native,
        absolute_error_improves=abs(margin1 - native) < abs(margin0 - native),
        derivative_check=check,
    ), changed
