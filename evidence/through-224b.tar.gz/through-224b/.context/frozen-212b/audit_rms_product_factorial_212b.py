"""Array audit of signed RMS/product interactions and finite readout changes."""

import itertools
import json
from pathlib import Path

import numpy as np
import run_rms_product_factorial_212b as run
from audit_block28_primitive_211b import projected
from audit_two_block_factorial_209 import metrics

from latent_decisions.evidence_policy import digest, write_json

ROOT, RUN = run.ROOT, run.RUN
OUT = ROOT / "docs/analysis/212-rms-product-factorial.json"


def margin(scores):
    return float(scores[1] - scores[0])


def main():
    assert not OUT.exists()
    bundle = json.loads((RUN / "design.json").read_text())
    design = bundle["design"]
    assert digest(design) == bundle["fingerprint"]
    assert all(run.sha(ROOT / p) == h for p, h in design["source_hashes"].items())
    status = json.loads((RUN / "status.json").read_text())
    assert (
        status["status"] == "complete"
        and status["finite_factorial_qualified"]
        and status["completed_pairs"] == 64
    )
    assert not status["original_wholeblock_jacobian_qualified"]
    expected_counts = dict(
        manual_false_primitive_traces=64,
        finite_factorial_blocks=1536,
        finite_head_evaluations=4544,
        readout_reverse_forward=768,
        readout_reverse_backward=768,
    )
    assert status["counts"] == expected_counts, status["counts"]
    rows, controls, local, optional, geometry, arithmetic = [], [], [], [], [], []
    for path in sorted((RUN / "pairs").glob("*.npz")):
        record = json.loads(path.with_suffix(".json").read_text())
        assert run.sha(path) == record["arrays_sha256"]
        assert run.sha(run.PARENT / path.name) == record["parent_arrays_sha256"]
        assert (
            run.sha(ROOT / "runs/block28-primitive-211/pairs" / path.name)
            == record["parent211_arrays_sha256"]
        )
        controls.extend(record["controls"])
        local.extend(record["local_checks"])
        optional.extend(record["optional_checks"])
        geometry.extend(
            dict(key=path.stem, group=record["group"], **r) for r in record["readout_geometry"]
        )
        arithmetic.extend(
            dict(key=path.stem, group=record["group"], **r) for r in record["arithmetic"]
        )
        with np.load(path, allow_pickle=False) as raw:
            assert all(np.isfinite(a).all() for a in raw.values())
            z = {k: raw[k].astype(np.float64) for k in raw.files}
        actual = z["native_final"] - z["false_final"]
        target_margin = margin(z["true_scores"] - z["false_scores"])
        regions = dict(
            full=slice(None), source=slice(0, 1), receivers=slice(1, None), verdict=slice(-1, None)
        )
        for branch, background in itertools.product(design["branches"], design["backgrounds"]):
            prefix = f"{branch}_{background}"
            states = {a: z[f"{prefix}_{a}_state"] for a in design["arms"]}
            endpoint_keys = {a: f"{prefix}_{a}" for a in design["arms"]}
            endpoint_keys.update({a + "_anchor": f"{prefix}_{a}_anchor" for a in design["arms"]})
            endpoint_keys["original_jvp"] = f"{branch}_original_jvp"
            endpoints = {}
            for label, key in endpoint_keys.items():
                prediction = z[key + "_state"] - z["false_final"]
                pm = margin(z[key + "_scores"])
                m = {name: metrics(prediction[s], actual[s]) for name, s in regions.items()}
                v = m["verdict"]
                m.update(
                    predicted_margin=pm,
                    native_margin=target_margin,
                    signed_margin_error=pm - target_margin,
                    absolute_margin_error=abs(pm - target_margin),
                    primary_pass=bool(
                        v["native_norm"] >= 0.001
                        and v["relative_l2"] <= 0.05
                        and v["cosine"] is not None
                        and v["cosine"] >= 0.99
                        and abs(pm - target_margin) <= 0.10
                    ),
                )
                endpoints[label] = m
            for m in endpoints.values():
                b = endpoints["original_jvp"]
                m["both_improve_original"] = bool(
                    m["verdict"]["relative_l2"] < b["verdict"]["relative_l2"]
                    and m["absolute_margin_error"] < b["absolute_margin_error"]
                )
            ll, fl, lf, ff = [states[a] for a in design["arms"]]
            vec = dict(
                rms=fl - ll, gate=lf - ll, interaction=ff - fl - lf + ll, gate_after_rms=ff - fl
            )
            local_missing = ff - ll
            native_missing = z["native_final"] - ll
            effects = {}
            for name, vector in vec.items():
                assert float(np.max(abs(vector - z[f"{prefix}_effect_{name}"]))) <= 1e-4
                effects[name] = {
                    region: dict(
                        toward_local=projected(vector[s], local_missing[s]),
                        toward_native=projected(vector[s], native_missing[s]),
                    )
                    for region, s in regions.items()
                }
            norm_change = {}
            for region, s in regions.items():
                before, after = vec["gate"][s].ravel(), vec["gate_after_rms"][s].ravel()
                bn, an = np.linalg.norm(before), np.linalg.norm(after)
                norm_change[region] = dict(
                    before_norm=float(bn),
                    after_norm=float(an),
                    norm_ratio=float(an / bn) if bn else None,
                    cosine=float(np.dot(before, after) / (bn * an)) if bn and an else None,
                )
            m = {a: margin(z[f"{prefix}_{a}_scores"]) for a in design["arms"]}
            add = margin(z[f"{prefix}_additive_scores"])
            margin_effects = dict(
                rms=m["FL"] - m["LL"],
                gate=m["LF"] - m["LL"],
                gate_after_rms=m["FF"] - m["FL"],
                interaction=m["FF"] - m["FL"] - m["LF"] + m["LL"],
                residual_interaction_readout=m["FF"] - add,
                readout_combination=add - m["FL"] - m["LF"] + m["LL"],
            )
            assert (
                abs(
                    margin_effects["interaction"]
                    - margin_effects["residual_interaction_readout"]
                    - margin_effects["readout_combination"]
                )
                <= 1e-10
            )
            conditional = {}
            for label, start, end in (
                ("gate_before_rms", "LL", "LF"),
                ("gate_after_rms", "FL", "FF"),
            ):
                a, b = endpoints[start], endpoints[end]
                conditional[label] = dict(
                    residual_improves=b["verdict"]["relative_l2"] < a["verdict"]["relative_l2"],
                    margin_improves=b["absolute_margin_error"] < a["absolute_margin_error"],
                    both_improve=b["verdict"]["relative_l2"] < a["verdict"]["relative_l2"]
                    and b["absolute_margin_error"] < a["absolute_margin_error"],
                )
            pure_interaction = z[f"{prefix}_F_product_mixed"] - z[f"{prefix}_L_product_mixed"]
            numerical_interaction = sum(
                z[f"{prefix}_F_product_{k}"] - z[f"{prefix}_L_product_{k}"]
                for k in ("product_rounding", "down_rounding", "residual_rounding")
            )
            closure = float(
                np.max(abs(vec["interaction"] - pure_interaction - numerical_interaction))
            )
            assert closure <= 1e-4
            rows.append(
                dict(
                    key=path.stem,
                    group=record["group"],
                    branch=branch,
                    background=background,
                    endpoints=endpoints,
                    effects=effects,
                    margin_effects=margin_effects,
                    gate_change_with_rms=norm_change,
                    conditional=conditional,
                    maximum_mixed_interaction_closure=closure,
                )
            )
    assert (
        len(rows) == 256
        and len(controls) == 9216
        and len(local) == 5376
        and len(optional) == 128
        and len(geometry) == 768
        and len(arithmetic) == 512
    )
    assert all(r["passed"] for r in controls + local) and all(
        r["derivative_check"]["passed"] for r in geometry
    )
    strata = []
    for branch, background in itertools.product(design["branches"], design["backgrounds"]):
        selected_context = [
            r for r in rows if r["branch"] == branch and r["background"] == background
        ]
        for field in (None, "block", "schema", "reverse"):
            for value in (
                [None] if field is None else sorted({r["group"][field] for r in selected_context})
            ):
                selected = [
                    r for r in selected_context if field is None or r["group"][field] == value
                ]
                endpoints = {}
                for name in selected[0]["endpoints"]:
                    items = [r["endpoints"][name] for r in selected]
                    endpoints[name] = dict(
                        median_verdict_relative_l2=float(
                            np.median([r["verdict"]["relative_l2"] for r in items])
                        ),
                        median_receiving_relative_l2=float(
                            np.median([r["receivers"]["relative_l2"] for r in items])
                        ),
                        median_absolute_margin_error=float(
                            np.median([r["absolute_margin_error"] for r in items])
                        ),
                        primary_passes=sum(r["primary_pass"] for r in items),
                        both_improve_original=sum(r["both_improve_original"] for r in items),
                    )
                margins = {
                    k: float(np.median([r["margin_effects"][k] for r in selected]))
                    for k in selected[0]["margin_effects"]
                }
                gate = dict(
                    median_receiving_norm_before=float(
                        np.median(
                            [
                                r["gate_change_with_rms"]["receivers"]["before_norm"]
                                for r in selected
                            ]
                        )
                    ),
                    median_receiving_norm_after=float(
                        np.median(
                            [r["gate_change_with_rms"]["receivers"]["after_norm"] for r in selected]
                        )
                    ),
                    median_receiving_norm_ratio=float(
                        np.median(
                            [r["gate_change_with_rms"]["receivers"]["norm_ratio"] for r in selected]
                        )
                    ),
                )
                conditional = {
                    label: {
                        k: sum(r["conditional"][label][k] for r in selected)
                        for k in ("residual_improves", "margin_improves", "both_improve")
                    }
                    for label in ("gate_before_rms", "gate_after_rms")
                }
                strata.append(
                    dict(
                        branch=branch,
                        background=background,
                        field=field,
                        value=value,
                        count=len(selected),
                        endpoints=endpoints,
                        median_margin_effects=margins,
                        gate=gate,
                        conditional=conditional,
                    )
                )
    geometry_summary = []
    for branch, vector, base in itertools.product(
        design["branches"],
        ("silu", "gate_up"),
        ("original_jvp", "norm_repaired", "lesion_to_finite"),
    ):
        items = [
            r
            for r in geometry
            if r["branch"] == branch and r["vector"] == vector and r["base"] == base
        ]
        assert len(items) == 64
        geometry_summary.append(
            dict(
                branch=branch,
                vector=vector,
                base=base,
                count=64,
                median_finite_margin_change=float(
                    np.median([r["finite_margin_change"] for r in items])
                ),
                median_initial_gradient_projection=float(
                    np.median([r["initial_gradient_projection"] for r in items])
                ),
                median_finite_minus_initial_projection=float(
                    np.median([r["finite_minus_initial_projection"] for r in items])
                ),
                positive_finite_change=sum(r["finite_margin_change"] > 0 for r in items),
                error_improves=sum(r["absolute_error_improves"] for r in items),
            )
        )
    panels = []
    for branch, background, schema, reverse in itertools.product(
        design["branches"], design["backgrounds"], ("generic", "descriptive"), range(2)
    ):
        cells = [
            r
            for r in rows
            if r["branch"] == branch
            and r["background"] == background
            and r["group"]["schema"] == schema
            and r["group"]["reverse"] == reverse
        ]
        for name in cells[0]["endpoints"]:
            passed = 0
            for block in sorted({r["group"]["block"] for r in cells}):
                block_cells = [r for r in cells if r["group"]["block"] == block]
                assert len(block_cells) == 4
                passed += all(r["endpoints"][name]["primary_pass"] for r in block_cells)
            panels.append(
                dict(
                    branch=branch,
                    background=background,
                    schema=schema,
                    reverse=reverse,
                    arm=name,
                    passing_panels=passed,
                    whole_stratum_pass=passed >= 3,
                )
            )
    report = dict(
        finite_factorial_qualified=True,
        original_wholeblock_jacobian_qualified=False,
        cases=64,
        context_rows=256,
        design_fingerprint=bundle["fingerprint"],
        auditor_sha256=run.sha(Path(__file__)),
        counts=expected_counts,
        controls=len(controls),
        local_derivative_checks=len(local),
        readout_gradient_checks=len(geometry),
        maximum_coordinate_control_error=max(r["coordinate_error"] for r in controls),
        maximum_score_control_error=max(r["score_error"] for r in controls),
        maximum_local_derivative_error=max(r["coordinate_error"] for r in local),
        maximum_readout_gradient_error=max(
            r["derivative_check"]["absolute_error"] for r in geometry
        ),
        maximum_mixed_interaction_closure=max(r["maximum_mixed_interaction_closure"] for r in rows),
        affine_LL_original_JVP_failures=sum(not r["passed"] for r in optional),
        maximum_affine_LL_original_JVP_error=max(r["coordinate_error"] for r in optional),
        raw_mixed_agreement_failures=sum(not r["raw_passed"] for r in arithmetic),
        maximum_raw_mixed_agreement_error=max(r["raw_coordinate_error"] for r in arithmetic),
        strata=strata,
        rows=rows,
        geometry_summary=geometry_summary,
        readout_geometry=geometry,
        panel_results=panels,
        limits="Controlledoracleincomingstates; finite-backgroundFFtrivialcontrol; affinebackgrounddefinedsurrogate. NeitheroriginalJacobiancertificationnor208generalizationorprospectiveprediction.",
    )
    write_json(OUT, report)
    print(
        json.dumps(
            {
                k: v
                for k, v in report.items()
                if k
                not in ("strata", "rows", "geometry_summary", "readout_geometry", "panel_results")
            },
            indent=2,
        )
    )
    for r in strata:
        if r["field"] is None:
            print(json.dumps(r, indent=2))


if __name__ == "__main__":
    main()
