"""Controlled four-arm factorial, pure-product accounting and finite readout geometry."""

import gc
import json
from collections import defaultdict
from pathlib import Path

import numpy as np
import primitive_diagnostic_211 as primitive
import ranked_block_response_201 as original
import rms_product_factorial_212 as method
import torch
from frozen_block28_derivative_210 import trace
from gate_up_arithmetic_213 import capture, decompose
from run_absence_alphabet_104 import now
from run_block28_primitive_211 import check as original_check
from run_block28_primitive_211 import sha

from latent_decisions.evidence_policy import digest, write_json
from latent_decisions.target import load_target

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / "runs/rms-product-factorial-212b"
PARENT = ROOT / "runs/two-block-factorial-209c/pairs"
FILES = [
    "scripts/run_rms_product_factorial_212b.py",
    "scripts/rms_product_factorial_212.py",
    "scripts/audit_rms_product_factorial_212b.py",
    "docs/experiments/212-rms-product-factorial.md",
    "docs/experiments/212b-numpy-scalar-serialization.md",
    "scripts/primitive_diagnostic_211.py",
    "scripts/frozen_block28_derivative_210.py",
    "scripts/local_primitive_derivative_210c.py",
    "scripts/gate_up_arithmetic_213.py",
]


def check(checks, kind, coordinate=0.0, score=0.0, **meta):
    # Explicit Python scalars preserve mathematics/bounds and serialize metadata.
    return original_check(checks, kind, float(coordinate), float(score), **meta)


def array(value):
    return value.detach().cpu().numpy().copy()


def execute(design, status, counts):
    runtime = json.loads(
        (ROOT / "runs/genuine-oracle-continuation-204-full/runtime.json").read_text()
    )
    model, tok, device = load_target(runtime["model"], "mps", offline=True)
    torch.set_num_threads(2)
    assert (
        digest(tok.get_vocab()) == runtime["tokenizer_hash"]
        and digest(model.config.to_dict()) == runtime["config_hash"]
    )
    assert (
        not model.training
        and model.config._attn_implementation == "eager"
        and next(model.parameters()).dtype == torch.float32
    )
    write_json(RUN / "runtime.json", dict(**runtime, cpu_threads=2))
    layer = model.model.layers[27]
    for path in sorted(PARENT.glob("*.npz")):
        meta = json.loads(path.with_suffix(".json").read_text())
        op = ROOT / "runs/genuine-oracle-continuation-204-full/pairs" / path.name
        pp = ROOT / "runs/block28-primitive-211/pairs" / path.name
        assert sha(path) == meta["arrays_sha256"] and sha(op) == meta["parent_arrays_sha256"]
        assert sha(pp) == json.loads(pp.with_suffix(".json").read_text())["arrays_sha256"]
        controls, local_checks, optional, geometry, arithmetic, arrays = [], [], [], [], [], {}
        with (
            np.load(path, allow_pickle=False) as z,
            np.load(op, allow_pickle=False) as oz,
            np.load(pp, allow_pickle=False) as pz,
        ):
            pos = int(z["source_position"])
            xf = torch.tensor(z["false_tail"][1][None], device=device)
            yf = torch.tensor(z["false_tail"][2][None], device=device)
            context = dict(
                mask=torch.tensor(oz["mask"], device=device),
                rope=tuple(torch.tensor(oz[k], device=device) for k in ("rope_cos", "rope_sin")),
            )
            c = trace(layer, xf, context)
            counts["manual_false_primitive_traces"] += 1
            check(
                controls,
                "false_primitive_trace",
                float((c["output"] - yf.cpu().double()).abs().max()),
            )
            sf = method.head_scores(model, yf, counts)
            check(controls, "false_head", score=float(np.max(abs(sf - z["false_scores"]))))
            for background in method.BACKGROUNDS:
                for arm in method.ARMS:
                    with (
                        primitive.surgeries(
                            layer, c, context, method.enabled(background, arm)
                        ) as checks,
                        torch.no_grad(),
                    ):
                        result = original.block(layer, xf, context)
                    counts["finite_factorial_blocks"] += 1
                    local_checks.extend(
                        dict(branch="False", background=background, arm=arm, **r) for r in checks
                    )
                    check(
                        controls,
                        "false_factorial_sham",
                        float((result - yf).abs().max()),
                        float(np.max(abs(method.head_scores(model, result, counts) - sf))),
                        background=background,
                        arm=arm,
                    )
            arrays.update(
                false_final=z["false_tail"][2, pos:],
                native_final=z["native_true_suffix"][2],
                false_scores=z["false_scores"],
                true_scores=z["true_scores"],
                position=np.array(pos),
            )
            for branch, baseline_arm in (("native", "FL"), ("linear27", "LL")):
                if branch == "native":
                    incoming = xf.clone()
                    incoming[:, pos:] = torch.tensor(
                        z["native_true_suffix"][1][None], device=device
                    )
                else:
                    dx = torch.zeros_like(xf)
                    dx[:, pos:] = torch.tensor(z["LL_delta_suffix"][0][None], device=device)
                    incoming = xf + dx
                original_j = torch.zeros_like(yf)
                original_j[:, pos:] = torch.tensor(
                    z[f"{baseline_arm}_delta_suffix"][-1][None], device=device
                )
                baseline = yf + original_j
                arrays[f"{branch}_original_jvp_state"] = array(baseline[0, pos:])
                arrays[f"{branch}_original_jvp_scores"] = (
                    method.head_scores(model, baseline, counts) - sf
                )
                check(
                    controls,
                    "original_jvp_finite_head",
                    score=float(
                        np.max(
                            abs(
                                arrays[f"{branch}_original_jvp_scores"]
                                - z[f"{baseline_arm}_delta_scores"]
                            )
                        )
                    ),
                    branch=branch,
                )
                outputs = {}
                for background in method.BACKGROUNDS:
                    captures = {}
                    for arm in method.ARMS:
                        with (
                            primitive.surgeries(
                                layer, c, context, method.enabled(background, arm)
                            ) as checks,
                            capture(layer) as cap,
                            torch.no_grad(),
                        ):
                            result = original.block(layer, incoming, context)
                        counts["finite_factorial_blocks"] += 1
                        assert all(r["passed"] for r in checks), checks
                        local_checks.extend(
                            dict(branch=branch, background=background, arm=arm, **r) for r in checks
                        )
                        cap["output"] = result.detach().cpu().double()
                        captures[arm] = cap
                        outputs[(background, arm)] = result
                        key = f"{branch}_{background}_{arm}"
                        arrays[key + "_state"] = array(result[0, pos:])
                        arrays[key + "_scores"] = method.head_scores(model, result, counts) - sf
                        check(
                            controls,
                            "zero_prefix",
                            float((result - yf)[:, :pos].abs().max()),
                            branch=branch,
                            background=background,
                            arm=arm,
                        )
                        if background == "finite" and arm in ("FL", "LF", "FF"):
                            old_name = {
                                "FL": "lesion_gate_up_interaction",
                                "LF": "lesion_mlp_input_rms",
                                "FF": "finite",
                            }[arm]
                            expected = (
                                pz["false_final"].astype(np.float64)
                                + pz[f"{branch}_{old_name}_delta"]
                            )
                            check(
                                controls,
                                "211_finite_arm_replay",
                                float(
                                    np.max(
                                        abs(array(result[0, pos:]).astype(np.float64) - expected)
                                    )
                                ),
                                float(
                                    np.max(
                                        abs(
                                            arrays[key + "_scores"]
                                            - pz[f"{branch}_{old_name}_scores"]
                                        )
                                    )
                                ),
                                branch=branch,
                                arm=arm,
                            )
                    for rflag in ("L", "F"):
                        vectors, errors = decompose(c, captures[rflag + "F"], captures[rflag + "L"])
                        for name in (
                            "pure_product_identity",
                            "actual_product_change_identity",
                            "matched_parent_identity",
                            "numerical_discrepancy_closure",
                        ):
                            check(
                                controls,
                                "product_" + name,
                                errors[name],
                                branch=branch,
                                background=background,
                                rms=rflag,
                            )
                        arithmetic.append(
                            dict(
                                branch=branch,
                                background=background,
                                rms=rflag,
                                raw_coordinate_error=errors["finite_effect_vs_mixed"],
                                raw_passed=errors["finite_effect_vs_mixed"] <= 1e-4,
                            )
                        )
                        for name, vector in vectors.items():
                            check(
                                controls,
                                "product_vector_prefix",
                                float(vector[:, :pos].abs().max()),
                                branch=branch,
                                background=background,
                                rms=rflag,
                                vector=name,
                            )
                            arrays[f"{branch}_{background}_{rflag}_product_{name}"] = array(
                                vector[0, pos:]
                            )
                    ll, fl, lf, ff = [outputs[(background, a)].cpu().double() for a in method.ARMS]
                    effect_r, effect_g, interaction = fl - ll, lf - ll, ff - fl - lf + ll
                    check(
                        controls,
                        "factorial_vector_identity",
                        float((effect_r + effect_g + interaction - (ff - ll)).abs().max()),
                        branch=branch,
                        background=background,
                    )
                    pure_change = (
                        arrays[f"{branch}_{background}_F_product_mixed"]
                        - arrays[f"{branch}_{background}_L_product_mixed"]
                    )
                    numerical_change = sum(
                        arrays[f"{branch}_{background}_F_product_{k}"]
                        - arrays[f"{branch}_{background}_L_product_{k}"]
                        for k in ("product_rounding", "down_rounding", "residual_rounding")
                    )
                    check(
                        controls,
                        "interaction_puremixed_plus_rounding",
                        float(
                            np.max(
                                abs(array(interaction[0, pos:]) - pure_change - numerical_change)
                            )
                        ),
                        branch=branch,
                        background=background,
                    )
                    for name, value in dict(
                        rms=effect_r, gate=effect_g, interaction=interaction, gate_after_rms=ff - fl
                    ).items():
                        arrays[f"{branch}_{background}_effect_{name}"] = array(value[0, pos:])
                    for arm in method.ARMS:
                        contrast = outputs[(background, arm)].cpu().double() - ll
                        patched = baseline.cpu().double()
                        patched[:, pos + 1 :] += contrast[:, pos + 1 :]
                        patched = patched.to(device=device, dtype=torch.float32)
                        key = f"{branch}_{background}_{arm}_anchor"
                        arrays[key + "_state"] = array(patched[0, pos:])
                        arrays[key + "_scores"] = method.head_scores(model, patched, counts) - sf
                    additive = (fl + lf - ll).to(device=device, dtype=torch.float32)
                    arrays[f"{branch}_{background}_additive_state"] = array(additive[0, pos:])
                    arrays[f"{branch}_{background}_additive_scores"] = (
                        method.head_scores(model, additive, counts) - sf
                    )
                    if background == "affine":
                        error = float((ll - baseline.cpu().double()).abs().max())
                        optional.append(
                            dict(
                                kind="affine_LL_vs_original_JVP",
                                branch=branch,
                                coordinate_error=error,
                                passed=error <= 1e-4,
                                required=False,
                            )
                        )
                for vector_name, lesion_name in (
                    ("silu", "silu_curvature"),
                    ("gate_up", "gate_up_interaction"),
                ):
                    correction = torch.zeros_like(yf, device="cpu", dtype=torch.float64)
                    correction[:, pos + 1 :] = torch.tensor(
                        pz[f"{branch}_surgery_effect_{lesion_name}"][1:][None], dtype=torch.float64
                    )
                    lesion = yf.cpu().double()
                    lesion[:, pos:] += torch.tensor(
                        pz[f"{branch}_lesion_{lesion_name}_delta"][None], dtype=torch.float64
                    )
                    bases = dict(
                        original_jvp=baseline,
                        norm_repaired=outputs[("finite", "FL")],
                        lesion_to_finite=lesion.to(device=device, dtype=torch.float32),
                    )
                    for base_name, base in bases.items():
                        item, changed = method.readout_segment(
                            model, base, correction, sf, z["true_scores"].astype(np.float64), counts
                        )
                        assert item["derivative_check"]["passed"], item
                        geometry.append(
                            dict(branch=branch, vector=vector_name, base=base_name, **item)
                        )
                        if base_name == "lesion_to_finite" or (
                            base_name == "norm_repaired" and vector_name == "gate_up"
                        ):
                            expected = outputs[("finite", "FF")]
                            check(
                                controls,
                                "readout_receiving_reconstruction",
                                float((changed - expected)[:, pos + 1 :].abs().max()),
                                abs(
                                    item["margin_after"]
                                    - (
                                        arrays[f"{branch}_finite_FF_scores"][1]
                                        - arrays[f"{branch}_finite_FF_scores"][0]
                                    )
                                ),
                                branch=branch,
                                vector=vector_name,
                                base=base_name,
                            )
            assert all(r["passed"] for r in local_checks)
        out = RUN / "pairs" / path.name
        out.parent.mkdir(parents=True, exist_ok=True)
        assert not out.exists() and all(np.isfinite(a).all() for a in arrays.values())
        np.savez_compressed(out, **arrays)
        write_json(
            out.with_suffix(".json"),
            dict(
                key=path.stem,
                group=meta["group"],
                arrays_sha256=sha(out),
                parent_arrays_sha256=sha(path),
                parent211_arrays_sha256=sha(pp),
                controls=controls,
                local_checks=local_checks,
                optional_checks=optional,
                readout_geometry=geometry,
                arithmetic=arithmetic,
            ),
        )
        status.update(
            completed_pairs=status["completed_pairs"] + 1, counts=dict(counts), updated_utc=now()
        )
        write_json(RUN / "status.json", status)
        print(f"212 RMS/product factorial {status['completed_pairs']}/64", flush=True)
        del c, captures, outputs, arrays
        gc.collect()


def main():
    assert not RUN.exists()
    assert json.loads((ROOT / "docs/analysis/211-block28-primitives.json").read_text())[
        "finite_interventions_qualified"
    ]
    assert json.loads((ROOT / "runs/gate-up-arithmetic-213/status.json").read_text())[
        "arithmetic_qualified"
    ]
    design = dict(
        source_hashes={p: sha(ROOT / p) for p in FILES},
        registered_utc=now(),
        branches=["native", "linear27"],
        backgrounds=method.BACKGROUNDS,
        arms=method.ARMS,
        parent211_audit_sha256=sha(ROOT / "docs/analysis/211-block28-primitives.json"),
        original_wholeblock_jacobian_qualified=False,
    )
    RUN.mkdir(parents=True)
    write_json(RUN / "design.json", dict(design=design, fingerprint=digest(design)))
    status = dict(
        status="running",
        finite_factorial_qualified=False,
        original_wholeblock_jacobian_qualified=False,
        completed_pairs=0,
        started_utc=now(),
    )
    counts = defaultdict(int)
    try:
        execute(design, status, counts)
        assert status["completed_pairs"] == 64 and design["source_hashes"] == {
            p: sha(ROOT / p) for p in FILES
        }
        status.update(
            status="complete",
            finite_factorial_qualified=True,
            completed_utc=now(),
            counts=dict(counts),
        )
    except BaseException as exc:
        status.update(
            status="technical_failure", error=repr(exc), counts=dict(counts), updated_utc=now()
        )
        write_json(RUN / "status.json", status)
        raise
    write_json(RUN / "status.json", status)


if __name__ == "__main__":
    main()
