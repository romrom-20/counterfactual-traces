"""Independently rebuild saved214 contrasts and all fixed retrospective outcomes."""

import itertools
import json
from pathlib import Path

import numpy as np
import run_last_block_transfer_214 as run
from audit_two_block_factorial_209 import metrics

from latent_decisions.evidence_policy import digest, write_json

ROOT, RUN = run.ROOT, run.RUN
OUT = ROOT/"docs/analysis/214-last-block-transfer.json"


def margin(x):
    return float(x[1]-x[0])


def outcome(prediction, actual, scores, target, baseline=None):
    regions = dict(full=slice(None),source=slice(0,1),receivers=slice(1,None),verdict=slice(-1,None))
    result = dict(final={k:metrics(prediction[s],actual[s]) for k,s in regions.items()},
                  predicted_margin=margin(scores),native_margin=target)
    v = result["final"]["verdict"]
    error = abs(result["predicted_margin"]-target)
    result.update(absolute_margin_error=error,signed_margin_error=result["predicted_margin"]-target,
        primary_pass=bool(v["native_norm"]>=.001 and v["relative_l2"]<=.05
                          and v["cosine"] is not None and v["cosine"]>=.99 and error<=.10))
    if baseline is not None:
        result.update(both_improve=bool(v["relative_l2"]<baseline["final"]["verdict"]["relative_l2"]
                                       and error<baseline["absolute_margin_error"]),
            partial_progress_pass=bool(v["relative_l2"]<=.5*baseline["final"]["verdict"]["relative_l2"]
                                      and error<=.5*baseline["absolute_margin_error"]))
    return result


def main():
    assert not OUT.exists()
    bundle=json.loads((RUN/"design.json").read_text());design=bundle["design"]
    assert digest(design)==bundle["fingerprint"]
    assert all(run.sha(ROOT/p)==h for p,h in (design["source_hashes"]|design["result_hashes"]).items())
    status=json.loads((RUN/"status.json").read_text())
    assert status["status"]=="complete" and status["qualified"]
    assert status["candidate_pairs"]==status["evaluation_pairs"]==64
    assert not status["original_wholeblock_jacobian_qualified"]
    counts=dict(manual_false_primitive_traces=64,surrogate_block_evaluations=1024,
                source_finite_replays=64,finite_head_evaluations=704,
                reverse_block_forward=64,reverse_block_backward=192,
                reverse_head_forward=64,reverse_head_backward=64)
    assert counts==status["counts"],status["counts"]
    mb=json.loads((RUN/"candidate-manifest.json").read_text());manifest=mb["manifest"]
    assert digest(manifest)==mb["sha256"] and manifest["native_observations_opened"]==0
    assert manifest["retrospective"] and manifest["design_fingerprint"]==bundle["fingerprint"]
    controls=[];local=[];reverse=[];optional=[];rows=[];times=[];ctimes=[]
    for entry in manifest["entries"]:
        fp=RUN/"candidates"/(entry["key"]+".npz")
        ep=RUN/"evaluations"/fp.name
        fobj,eobj=[json.loads(p.with_suffix(".json").read_text()) for p in (fp,ep)]
        f,e=fobj["record"],eobj["record"]
        assert digest(f)==fobj["sha256"]==entry["record_sha256"]
        assert run.sha(fp)==f["arrays_sha256"]==entry["arrays_sha256"]
        assert digest(e)==eobj["sha256"] and run.sha(ep)==e["arrays_sha256"]
        assert e["candidate_manifest_sha256"]==run.sha(RUN/"candidate-manifest.json")
        assert f["design_fingerprint"]==e["design_fingerprint"]==bundle["fingerprint"]
        parent=run.PARENT/"forecasts"/fp.name
        native=run.PARENT/"observations"/fp.name
        assert run.sha(parent)==f["parent_arrays_sha256"] and run.sha(native)==e["parent_arrays_sha256"]
        assert json.loads(parent.with_suffix(".json").read_text())["sha256"]==f["parent_record_sha256"]
        assert not f["old_forecast_native_arrays_read"] and not f["native_observations_opened"]
        controls.extend(f["controls"]);local.extend(f["local_checks"])
        reverse.extend(f["reverse_checks"]);optional.extend(f["optional_checks"])
        times.append(e["started_utc"]);ctimes.append(f["completed_utc"])
        with np.load(fp,allow_pickle=False) as raw, np.load(ep,allow_pickle=False) as obs, np.load(parent,allow_pickle=False) as old:
            assert all(np.isfinite(a).all() for z in (raw,obs) for a in z.values())
            z={k:raw[k].astype(np.float64) for k in raw.files}
            actual=obs["true_final"].astype(np.float64)-z["false_final"]
            target=margin(obs["true_scores"].astype(np.float64)-z["false_scores"])
            baseline=outcome(z["original_state"]-z["false_final"],actual,z["original_scores"],target)
            arms={}
            for arm in design["arms"]:
                cf=z[f"full_{arm}_state"]-z["full_LL_state"]
                cs=z[f"source_{arm}_state"]-z["source_LL_state"]
                correction=cf-cs;correction[:1]=0
                assert np.max(abs(correction-z[f"{arm}_correction"]))<=1e-4
                expected=(z["original_state"]+correction).astype(np.float32).astype(np.float64)
                assert np.max(abs(expected-z[f"{arm}_state"]))<=1e-4
                arms[arm]=outcome(z[f"{arm}_state"]-z["false_final"],actual,z[f"{arm}_scores"],target,baseline)
            gap=z["full_LL_state"]-z["source_LL_state"]-z["receiver_jvp"]
            assert np.max(abs(gap-z["affine_LL_original_receiver_gap"]))<=1e-4
            assert np.max(abs(z["LL_state"]-z["original_state"]))==0
            for arm in ("source_linear_finite_head","zero_displacement"):
                arms[arm]=outcome(old[f"{arm}_delta_suffix"][-1].astype(np.float64),actual,
                                 old[f"{arm}_delta_scores"].astype(np.float64),target,baseline)
        rows.append(dict(key=fp.stem,group=f["group"],arms=arms,
                         maximum_LL_original_receiver_gap=float(np.max(abs(gap)))))
    assert len(rows)==64 and len(controls)==1600 and len(local)==6144 and len(reverse)==192 and len(optional)==64
    assert all(r["passed"] for r in controls+local+reverse)
    assert max(ctimes)<=manifest["sealed_utc"]<min(times)
    panels=[]
    for block,schema,rev in itertools.product(sorted({r["group"]["block"] for r in rows}),
                                             ("generic","descriptive"),range(2)):
        cells=[r for r in rows if r["group"]["block"]==block and r["group"]["schema"]==schema and r["group"]["reverse"]==rev]
        assert len(cells)==4 and {(r["group"]["assignment"],r["group"]["target"]) for r in cells}==set(itertools.product(range(2),repeat=2))
        panels.append(dict(block=block,schema=schema,reverse=rev,arms={
            a:{k:all(r["arms"][a][k] for r in cells) for k in ("primary_pass","partial_progress_pass")}
            for a in rows[0]["arms"]}))
    whole={}
    for arm in rows[0]["arms"]:
        whole[arm]={}
        for kind in ("primary_pass","partial_progress_pass"):
            strata=[dict(schema=schema,reverse=rev,passing_panels=sum(p["arms"][arm][kind] for p in panels if p["schema"]==schema and p["reverse"]==rev))
                    for schema,rev in itertools.product(("generic","descriptive"),range(2))]
            whole[arm][kind]=dict(passed=all(s["passing_panels"]>=3 for s in strata),strata=strata)
    strata=[]
    for field in (None,"block","schema","reverse"):
        for value in ([None] if field is None else sorted({r["group"][field] for r in rows})):
            selected=[r for r in rows if field is None or r["group"][field]==value]
            arms={}
            for arm in selected[0]["arms"]:
                items=[r["arms"][arm] for r in selected]
                arms[arm]=dict(median_verdict_relative_l2=float(np.median([r["final"]["verdict"]["relative_l2"] for r in items])),
                    median_receiving_relative_l2=float(np.median([r["final"]["receivers"]["relative_l2"] for r in items])),
                    median_absolute_margin_error=float(np.median([r["absolute_margin_error"] for r in items])),
                    both_improve=sum(r["both_improve"] for r in items),primary_passes=sum(r["primary_pass"] for r in items),
                    partial_progress_passes=sum(r["partial_progress_pass"] for r in items))
            strata.append(dict(field=field,value=value,count=len(selected),arms=arms))
    report=dict(qualified=True,original_wholeblock_jacobian_qualified=False,retrospective=True,cases=64,
        source_design_fingerprint=bundle["fingerprint"],auditor_sha256=run.sha(Path(__file__)),counts=counts,
        controls=len(controls),local_derivative_checks=len(local),reverse_projections=len(reverse),
        maximum_coordinate_control_error=max(r["coordinate_error"] for r in controls),
        maximum_score_control_error=max(r["score_error"] for r in controls),
        maximum_local_derivative_error=max(r["coordinate_error"] for r in local),
        maximum_reverse_projection_error=max(r["absolute_error"] for r in reverse),
        optional_LL_original_JVP_failures=sum(not r["passed"] for r in optional),
        maximum_LL_original_JVP_error=max(r["coordinate_error"] for r in optional),
        candidate_sealed_utc=manifest["sealed_utc"],first_native_opened_utc=min(times),
        rows=rows,strata=strata,panel_results=panels,whole=whole,
        limits="Already-observed208, lastblockonly; definedconditionalcontrast, noexactoriginal-Jreplacement, nolearnedcircuitorprospectiveclaim.")
    write_json(OUT,report)
    print(json.dumps({k:v for k,v in report.items() if k not in ("rows","strata","panel_results","whole")},indent=2))
    print(json.dumps(strata[0],indent=2))
    print(json.dumps(whole,indent=2))


if __name__=="__main__":
    main()
