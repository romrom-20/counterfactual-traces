"""Fixed retrospective receiver-conditional correction, sealed before scoring."""

import gc
import json
from collections import defaultdict
from pathlib import Path

import block_derivative_checks_209 as derivatives
import numpy as np
import primitive_diagnostic_211 as primitive
import ranked_block_response_201 as original
import rms_product_factorial_212 as method
import torch
from frozen_block28_derivative_210 import trace
from run_absence_alphabet_104 import now
from run_rms_product_factorial_212b import check, sha

from latent_decisions.evidence_policy import digest, write_json
from latent_decisions.target import load_target

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / "runs/last-block-transfer-214"
PARENT = ROOT / "runs/source-receiver-partition-208"
FILES = [
    "scripts/run_last_block_transfer_214.py",
    "scripts/audit_last_block_transfer_214.py",
    "docs/experiments/214-last-block-retrospective-transfer.md",
    "scripts/rms_product_factorial_212.py",
    "scripts/primitive_diagnostic_211.py",
    "scripts/frozen_block28_derivative_210.py",
    "scripts/local_primitive_derivative_210c.py",
    "scripts/block_derivative_checks_209.py",
    "scripts/ranked_block_response_201.py",
    "scripts/run_rms_product_factorial_212b.py",
    "scripts/run_block28_primitive_211.py",
    "src/latent_decisions/target.py",
    "src/latent_decisions/evidence_policy.py",
]


def cpu(x):
    return x.detach().cpu().numpy().copy()


def save(path, arrays, record):
    assert not path.exists() and all(np.isfinite(a).all() for a in arrays.values())
    path.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(path, **arrays)
    record = dict(record, arrays_sha256=sha(path), completed_utc=now())
    write_json(path.with_suffix(".json"), dict(record=record, sha256=digest(record)))
    return dict(key=path.stem, arrays_sha256=sha(path), record_sha256=digest(record))


def execute(design, status, counts):
    runtime = json.loads((PARENT / "runtime.json").read_text())
    model, tok, device = load_target(runtime["model"], "mps", offline=True)
    torch.set_num_threads(2)
    assert digest(tok.get_vocab()) == runtime["tokenizer_hash"]
    assert digest(model.config.to_dict()) == runtime["config_hash"]
    assert not model.training and model.config._attn_implementation == "eager"
    assert next(model.parameters()).dtype == torch.float32
    write_json(RUN / "runtime.json", dict(**runtime, cpu_threads=2))
    layer = model.model.layers[27]
    entries = []
    for path in sorted((PARENT / "forecasts").glob("*.npz")):
        obj = json.loads(path.with_suffix(".json").read_text())
        record = obj["record"]
        assert sha(path) == record["arrays_sha256"] and digest(record) == obj["sha256"]
        controls, local, optional = [], [], []
        pos = record["position"]
        # Deliberately read only False/known predicted operands from this old archive.
        with np.load(path, allow_pickle=False) as z:
            xf = torch.tensor(z["false_boundaries"][27][None], device=device)
            yf = torch.tensor(z["false_boundaries"][28][None], device=device)
            sf_saved = z["false_scores"].astype(np.float64)
            d = torch.zeros_like(xf)
            d[:, pos:] = torch.tensor(z["source_receiver_delta_suffix"][26][None], device=device)
            incoming = xf + d
            incoming[:, pos] = torch.tensor(z["source_receiver_absolute_source"][26], device=device)
            source_only = xf.clone()
            source_only[:, pos] = incoming[:, pos]
            old_delta = torch.zeros_like(yf)
            old_delta[:, pos:] = torch.tensor(z["source_receiver_delta_suffix"][27][None], device=device)
            old = yf + old_delta
            old_scores_saved = z["source_receiver_delta_scores"].astype(np.float64)
            receiver_jvp = torch.zeros_like(yf)
            receiver_jvp[:, pos:] = torch.tensor(
                z["source_receiver_receiver_jvp_suffix"][27][None], device=device
            )
            context = dict(
                mask=torch.tensor(z["mask"], device=device),
                rope=tuple(torch.tensor(z[k], device=device) for k in ("rope_cos", "rope_sin")),
            )
        c = trace(layer, xf, context)
        counts["manual_false_primitive_traces"] += 1
        check(controls, "false_trace", float((c["output"]-yf.cpu().double()).abs().max()))
        sf = method.head_scores(model, yf, counts)
        check(controls, "false_head", score=float(np.max(abs(sf-sf_saved))))
        old_scores = method.head_scores(model, old, counts) - sf
        check(controls, "old_finite_head", score=float(np.max(abs(old_scores-old_scores_saved))))
        outputs = {}
        for arm in method.ARMS:
            with primitive.surgeries(layer, c, context, method.enabled("affine", arm)) as checks, torch.no_grad():
                out = original.block(layer, xf, context)
            counts["surrogate_block_evaluations"] += 1
            local.extend(dict(input="False", arm=arm, **r) for r in checks)
            check(controls, "false_surrogate_sham", float((out-yf).abs().max()),
                  float(np.max(abs(method.head_scores(model,out,counts)-sf))), arm=arm)
        for name, operand in (("full", incoming), ("source", source_only), ("zero_receiver", source_only.clone())):
            for arm in method.ARMS:
                with primitive.surgeries(layer,c,context,method.enabled("affine",arm)) as checks, torch.no_grad():
                    out = original.block(layer,operand,context)
                counts["surrogate_block_evaluations"] += 1
                local.extend(dict(input=name,arm=arm,**r) for r in checks)
                assert all(r["passed"] for r in checks), checks
                check(controls,"unchanged_prefix",float((out-yf)[:,:pos].abs().max()), input=name,arm=arm)
                outputs[name,arm] = out.detach()
        with torch.no_grad():
            source_finite = original.block(layer,source_only,context)
        counts["source_finite_replays"] += 1
        replay_delta = source_finite-yf+receiver_jvp
        replay = yf+replay_delta
        check(controls,"208_source_update_replay",float((replay-old).abs().max()),
              float(np.max(abs(method.head_scores(model,replay,counts)-sf-old_scores_saved))))
        rd = incoming-xf
        rd[:,:pos+1] = 0
        reverse = derivatives.verify(model,27,xf,yf,context,{"old_receiver":(rd,receiver_jvp)},counts)
        arrays = dict(false_final=cpu(yf[0,pos:]), original_state=cpu(old[0,pos:]),
                      original_scores=old_scores, false_scores=sf, source_position=np.array(pos),
                      incoming_prediction=cpu(incoming[0,pos:]),
                      source_only_input=cpu(source_only[0,pos:]), receiver_jvp=cpu(receiver_jvp[0,pos:]))
        llgap = outputs["full","LL"].cpu().double()-outputs["source","LL"].cpu().double()-receiver_jvp.cpu().double()
        gap = float(llgap.abs().max())
        optional.append(dict(kind="affine_LL_receiver_original_JVP",coordinate_error=gap,passed=gap<=1e-4))
        arrays["affine_LL_original_receiver_gap"] = cpu(llgap[0,pos:])
        for arm in method.ARMS:
            contrast_full = outputs["full",arm].cpu().double()-outputs["full","LL"].cpu().double()
            contrast_source = outputs["source",arm].cpu().double()-outputs["source","LL"].cpu().double()
            difference = contrast_full-contrast_source
            check(controls,"contrast_prefix_source_zero",float(difference[:,:pos+1].abs().max()),arm=arm)
            zero_contrast = outputs["zero_receiver",arm].cpu().double()-outputs["zero_receiver","LL"].cpu().double()
            check(controls,"zero_receiver_actual_replay",float((zero_contrast-contrast_source).abs().max()),arm=arm)
            # This is a defined contrast. It is not identified with original J.
            correction = torch.zeros_like(difference)
            correction[:,pos+1:] = difference[:,pos+1:]
            candidate = (old.cpu().double()+correction).to(device=device,dtype=torch.float32)
            scores = method.head_scores(model,candidate,counts)-sf
            if arm=="LL":
                check(controls,"LL_replays_old",float((candidate-old).abs().max()),
                      float(np.max(abs(scores-old_scores))))
            for name in ("full","source"):
                arrays[f"{name}_{arm}_state"] = cpu(outputs[name,arm][0,pos:])
            arrays[f"{arm}_correction"] = cpu(correction[0,pos:])
            arrays[f"{arm}_state"] = cpu(candidate[0,pos:])
            arrays[f"{arm}_scores"] = scores
        assert all(r["passed"] for r in local + controls)
        entry = save(RUN/"candidates"/path.name,arrays,dict(
            group=record["group"],position=pos,parent_arrays_sha256=sha(path),
            parent_record_sha256=obj["sha256"],design_fingerprint=design["fingerprint"],
            controls=controls,local_checks=local,optional_checks=optional,reverse_checks=reverse,
            old_forecast_native_arrays_read=False,native_observations_opened=False))
        entries.append(entry)
        status.update(candidate_pairs=len(entries),counts=dict(counts),updated_utc=now())
        write_json(RUN/"status.json",status)
        gc.collect()
        print(f"214 candidates {len(entries)}/64",flush=True)
    assert len(entries)==64
    manifest = dict(design_fingerprint=design["fingerprint"],entries=entries,sealed_utc=now(),
                    native_observations_opened=0,retrospective=True)
    write_json(RUN/"candidate-manifest.json",dict(manifest=manifest,sha256=digest(manifest)))
    del model, c, outputs, incoming, source_only
    gc.collect()
    # No native observation file is opened until the global seal is durable.
    for entry in entries:
        path = PARENT/"observations"/(entry["key"]+".npz")
        started = now()
        record = json.loads(path.with_suffix(".json").read_text())["record"]
        assert sha(path)==record["arrays_sha256"]
        with np.load(path,allow_pickle=False) as z:
            arrays = dict(true_final=z["true_suffix"][-1].copy(),true_scores=z["true_scores"].copy())
        save(RUN/"evaluations"/path.name,arrays,dict(started_utc=started,
            parent_arrays_sha256=sha(path),candidate_manifest_sha256=sha(RUN/"candidate-manifest.json"),
            design_fingerprint=design["fingerprint"]))
        status["evaluation_pairs"] += 1
    status.update(status="complete",qualified=True,counts=dict(counts),completed_utc=now(),
                  original_wholeblock_jacobian_qualified=False)
    write_json(RUN/"status.json",status)


def main():
    assert not RUN.exists()
    assert json.loads((ROOT/"docs/analysis/208-source-receiver-partition.json").read_text())["qualified"]
    assert json.loads((ROOT/"docs/analysis/212-rms-product-factorial.json").read_text())["finite_factorial_qualified"]
    assert json.loads((ROOT/"docs/analysis/213-gate-up-arithmetic-audit.json").read_text())["arithmetic_qualified"]
    RUN.mkdir(parents=True)
    design = dict(experiment=214,arms=list(method.ARMS),cases=64,retrospective=True,
        source_hashes={p:sha(ROOT/p) for p in FILES},
        result_hashes={p:sha(ROOT/p) for p in (
            "docs/analysis/212-rms-product-factorial.json",
            "docs/analysis/213-gate-up-arithmetic-audit.json",
            "docs/analysis/208-source-receiver-partition.json")},
        primary=dict(relative_l2=.05,cosine=.99,minimum_native_norm=.001,margin_error=.10),
        partial_progress_factor=.5,partial_baseline="source_receiver",whole_panels_per_stratum=3,
        registered_utc=now())
    bundle = dict(design=design,fingerprint=digest(design))
    write_json(RUN/"design.json",bundle)
    status = dict(status="running",started_utc=now(),candidate_pairs=0,evaluation_pairs=0,qualified=False)
    write_json(RUN/"status.json",status)
    try:
        execute(bundle,status,defaultdict(int))
    except Exception as error:
        status.update(status="technical_failure",error=repr(error),failed_utc=now())
        write_json(RUN/"status.json",status)
        raise


if __name__=="__main__":
    main()
