"""Independent array audit of matched incoming-state controls; all endpoints retained."""

import itertools
import json
from pathlib import Path

import numpy as np
import run_matched_incoming_control_215 as run
from audit_block28_primitive_211b import projected
from audit_last_block_transfer_214b import margin, outcome
from audit_two_block_factorial_209 import metrics

from latent_decisions.evidence_policy import digest, write_json

ROOT,RUN=run.ROOT,run.RUN
OUT=ROOT/"docs/analysis/215-matched-incoming-control.json"


def main():
    assert not OUT.exists()
    bundle=json.loads((RUN/"design.json").read_text());design=bundle["design"]
    assert digest(design)==bundle["fingerprint"]
    assert all(run.sha(ROOT/p)==h for p,h in design["source_hashes"].items())
    assert run.sha(ROOT/"docs/analysis/214-last-block-transfer.json")==design["transfer_result_sha256"]
    status=json.loads((RUN/"status.json").read_text())
    counts=dict(manual_false_primitive_traces=64,surrogate_block_evaluations=768,finite_block_evaluations=128,finite_head_evaluations=960)
    assert status["status"]=="complete" and status["qualified"] and status["completed_pairs"]==64
    assert not status["original_wholeblock_jacobian_qualified"] and status["counts"]==counts,status
    controls=[];local=[];rows=[]
    for path in sorted((RUN/"pairs").glob("*.npz")):
        obj=json.loads(path.with_suffix(".json").read_text());record=obj["record"]
        assert digest(record)==obj["sha256"] and run.sha(path)==record["arrays_sha256"]
        assert record["design_fingerprint"]==bundle["fingerprint"]
        for p,h in ((run.PARENT/"forecasts"/path.name,record["parent_forecast_sha256"]),
                    (run.PARENT/"observations"/path.name,record["parent_observation_sha256"]),
                    (ROOT/"runs/last-block-transfer-214/candidates"/path.name,record["parent214_sha256"])):
            assert run.sha(p)==h
        controls.extend(record["controls"]);local.extend(record["local_checks"])
        with np.load(path,allow_pickle=False) as raw:
            assert all(np.isfinite(a).all() for a in raw.values())
            z={k:raw[k].astype(np.float64) for k in raw.files}
        actual=z["true_final"]-z["false_final"]
        actual_input=z["native_input"]-z["false_input"]
        target=margin(z["true_scores"]-z["false_scores"])
        for branch in design["branches"]:
            baseline=outcome(z[f"{branch}_LL_state"]-z["false_final"],actual,z[f"{branch}_LL_scores"],target)
            arms={a:outcome(z[f"{branch}_{a}_state"]-z["false_final"],actual,z[f"{branch}_{a}_scores"],target,baseline) for a in [*design["arms"],"finite"]}
            states={a:z[f"{branch}_{a}_state"] for a in design["arms"]}
            effects=dict(rms=states["FL"]-states["LL"],gate=states["LF"]-states["LL"],
                         gate_after_rms=states["FF"]-states["FL"],interaction=states["FF"]-states["FL"]-states["LF"]+states["LL"])
            signed={}
            for name,v in effects.items():
                assert np.max(abs(v-z[f"{branch}_effect_{name}"]))<=1e-4
                signed[name]=dict(receivers=projected(v[1:],(z["true_final"]-states["LL"])[1:]),
                                  verdict=projected(v[-1:],(z["true_final"]-states["LL"])[-1:]))
            conditional={}
            for label,a,b in (("gate_before_rms","LL","LF"),("gate_after_rms","FL","FF")):
                conditional[label]=dict(residual_improves=arms[b]["final"]["verdict"]["relative_l2"]<arms[a]["final"]["verdict"]["relative_l2"],
                    margin_improves=arms[b]["absolute_margin_error"]<arms[a]["absolute_margin_error"],
                    both_improve=arms[b]["final"]["verdict"]["relative_l2"]<arms[a]["final"]["verdict"]["relative_l2"] and arms[b]["absolute_margin_error"]<arms[a]["absolute_margin_error"],
                    finite_margin_change=margin(z[f"{branch}_{b}_scores"]-z[f"{branch}_{a}_scores"]))
            inp=z[f"{branch}_input"]-z["false_input"]
            rows.append(dict(key=path.stem,group=record["group"],branch=branch,arms=arms,conditional=conditional,effects=signed,
                             incoming={k:metrics(inp[s],actual_input[s]) for k,s in dict(source=slice(0,1),receivers=slice(1,None),verdict=slice(-1,None)).items()}))
    assert len(rows)==128 and len(controls)==1408 and len(local)==4608
    assert all(r["passed"] for r in controls+local)
    strata=[];panels=[]
    for branch in design["branches"]:
        cases=[r for r in rows if r["branch"]==branch]
        for field in (None,"block","schema","reverse"):
            for value in ([None] if field is None else sorted({r["group"][field] for r in cases})):
                selected=[r for r in cases if field is None or r["group"][field]==value]
                arms={a:dict(median_verdict_relative_l2=float(np.median([r["arms"][a]["final"]["verdict"]["relative_l2"] for r in selected])),
                    median_receiving_relative_l2=float(np.median([r["arms"][a]["final"]["receivers"]["relative_l2"] for r in selected])),
                    median_absolute_margin_error=float(np.median([r["arms"][a]["absolute_margin_error"] for r in selected])),
                    both_improve_LL=sum(r["arms"][a]["both_improve"] for r in selected),primary_passes=sum(r["arms"][a]["primary_pass"] for r in selected)) for a in cases[0]["arms"]}
                conditional={label:dict(**{k:sum(r["conditional"][label][k] for r in selected) for k in ("residual_improves","margin_improves","both_improve")},
                    median_finite_margin_change=float(np.median([r["conditional"][label]["finite_margin_change"] for r in selected]))) for label in cases[0]["conditional"]}
                strata.append(dict(branch=branch,field=field,value=value,count=len(selected),arms=arms,conditional=conditional,
                    median_incoming_receiving_relative_l2=float(np.median([r["incoming"]["receivers"]["relative_l2"] for r in selected])),
                    median_incoming_verdict_relative_l2=float(np.median([r["incoming"]["verdict"]["relative_l2"] for r in selected]))))
        for schema,rev,a in itertools.product(("generic","descriptive"),range(2),cases[0]["arms"]):
            passed=0
            for block in sorted({r["group"]["block"] for r in cases}):
                cells=[r for r in cases if r["group"]["schema"]==schema and r["group"]["reverse"]==rev and r["group"]["block"]==block]
                assert len(cells)==4 and {(r["group"]["assignment"],r["group"]["target"]) for r in cells}==set(itertools.product(range(2),repeat=2))
                passed+=all(r["arms"][a]["primary_pass"] for r in cells)
            panels.append(dict(branch=branch,schema=schema,reverse=rev,arm=a,passing_panels=passed,whole_stratum_pass=passed>=3))
    report=dict(qualified=True,retrospective_oracle=True,cases=64,context_rows=128,original_wholeblock_jacobian_qualified=False,
        design_fingerprint=bundle["fingerprint"],auditor_sha256=run.sha(Path(__file__)),counts=counts,controls=len(controls),local_derivative_checks=len(local),
        maximum_coordinate_control_error=max(r["coordinate_error"] for r in controls),maximum_score_control_error=max(r["score_error"] for r in controls),
        maximum_local_derivative_error=max(r["coordinate_error"] for r in local),rows=rows,strata=strata,panel_results=panels,
        limits="Matched208oracle/predictedincomingstates; sourcefixed; localdefinedsurrogate, notoriginalJacobiancertificate, learnedcircuitorprospectiveprediction.")
    write_json(OUT,report)
    print(json.dumps({k:v for k,v in report.items() if k not in ("rows","strata","panel_results")},indent=2))
    for s in strata:
        if s["field"] is None:print(json.dumps(s,indent=2))


if __name__=="__main__":main()
