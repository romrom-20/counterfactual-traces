"""Oracle matched-context check of local mechanism versus inaccurate incoming state."""

import gc
import json
from collections import defaultdict
from pathlib import Path

import numpy as np
import primitive_diagnostic_211 as primitive
import ranked_block_response_201 as original
import rms_product_factorial_212 as method
import torch
from frozen_block28_derivative_210 import trace
from run_absence_alphabet_104 import now
from run_last_block_transfer_214 import PARENT, cpu, save
from run_rms_product_factorial_212b import check, sha

from latent_decisions.evidence_policy import digest, write_json
from latent_decisions.target import load_target

ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/"runs/matched-incoming-control-215"
FILES=["scripts/run_matched_incoming_control_215.py","scripts/audit_matched_incoming_control_215.py",
       "docs/experiments/215-matched-incoming-state-control.md","scripts/run_last_block_transfer_214.py",
       "scripts/audit_last_block_transfer_214b.py","scripts/rms_product_factorial_212.py",
       "scripts/primitive_diagnostic_211.py","scripts/frozen_block28_derivative_210.py",
       "scripts/local_primitive_derivative_210c.py","scripts/run_rms_product_factorial_212b.py"]


def execute(bundle,status,counts):
    rt=json.loads((PARENT/"runtime.json").read_text())
    model,tok,device=load_target(rt["model"],"mps",offline=True)
    torch.set_num_threads(2)
    assert digest(tok.get_vocab())==rt["tokenizer_hash"] and digest(model.config.to_dict())==rt["config_hash"]
    assert not model.training and model.config._attn_implementation=="eager" and next(model.parameters()).dtype==torch.float32
    write_json(RUN/"runtime.json",dict(**rt,cpu_threads=2))
    layer=model.model.layers[27]
    for path in sorted((PARENT/"forecasts").glob("*.npz")):
        meta=json.loads(path.with_suffix(".json").read_text())["record"]
        op=PARENT/"observations"/path.name
        pp=ROOT/"runs/last-block-transfer-214/candidates"/path.name
        assert sha(path)==meta["arrays_sha256"]
        assert sha(op)==json.loads(op.with_suffix(".json").read_text())["record"]["arrays_sha256"]
        assert sha(pp)==json.loads(pp.with_suffix(".json").read_text())["record"]["arrays_sha256"]
        controls=[];local=[];pos=meta["position"]
        with np.load(path,allow_pickle=False) as z,np.load(op,allow_pickle=False) as oz,np.load(pp,allow_pickle=False) as pz:
            xf=torch.tensor(z["false_boundaries"][27][None],device=device)
            yf=torch.tensor(z["false_boundaries"][28][None],device=device)
            native=xf.clone();native[:,pos:]=torch.tensor(oz["true_suffix"][26][None],device=device)
            predicted=xf.clone();predicted[:,pos:]=torch.tensor(pz["incoming_prediction"][None],device=device)
            context=dict(mask=torch.tensor(z["mask"],device=device),rope=tuple(torch.tensor(z[k],device=device) for k in ("rope_cos","rope_sin")))
            target=oz["true_suffix"][-1].copy();true_scores=oz["true_scores"].astype(np.float64)
            sf_saved=z["false_scores"].astype(np.float64)
            old_outputs={arm:pz[f"full_{arm}_state"].copy() for arm in method.ARMS}
        c=trace(layer,xf,context);counts["manual_false_primitive_traces"]+=1
        check(controls,"false_trace",float((c["output"]-yf.cpu().double()).abs().max()))
        sf=method.head_scores(model,yf,counts)
        check(controls,"false_head",score=float(np.max(abs(sf-sf_saved))))
        check(controls,"matched_native_predicted_source",float((native[:,pos]-predicted[:,pos]).abs().max()))
        arrays=dict(false_final=cpu(yf[0,pos:]),true_final=target,false_scores=sf,true_scores=true_scores,
                    false_input=cpu(xf[0,pos:]),native_input=cpu(native[0,pos:]),predicted_input=cpu(predicted[0,pos:]),source_position=np.array(pos))
        for arm in method.ARMS:
            with primitive.surgeries(layer,c,context,method.enabled("affine",arm)) as checks,torch.no_grad():
                out=original.block(layer,xf,context)
            counts["surrogate_block_evaluations"]+=1
            local.extend(dict(input="False",arm=arm,**r) for r in checks)
            check(controls,"false_surrogate_sham",float((out-yf).abs().max()),
                  float(np.max(abs(method.head_scores(model,out,counts)-sf))),arm=arm)
        for branch,incoming in (("native",native),("predicted",predicted)):
            outputs={}
            for arm in method.ARMS:
                with primitive.surgeries(layer,c,context,method.enabled("affine",arm)) as checks,torch.no_grad():
                    out=original.block(layer,incoming,context)
                counts["surrogate_block_evaluations"]+=1
                local.extend(dict(input=branch,arm=arm,**r) for r in checks)
                check(controls,"surrogate_unchanged_prefix",float((out-yf)[:,:pos].abs().max()),input=branch,arm=arm)
                if branch=="predicted":check(controls,"214_full_surrogate_replay",float(np.max(abs(cpu(out[0,pos:])-old_outputs[arm]))),arm=arm)
                arrays[f"{branch}_{arm}_state"]=cpu(out[0,pos:])
                arrays[f"{branch}_{arm}_scores"]=method.head_scores(model,out,counts)-sf
                outputs[arm]=out.detach().cpu().double()
            for label,vector in dict(rms=outputs["FL"]-outputs["LL"],gate=outputs["LF"]-outputs["LL"],
                                     gate_after_rms=outputs["FF"]-outputs["FL"],interaction=outputs["FF"]-outputs["FL"]-outputs["LF"]+outputs["LL"]).items():
                arrays[f"{branch}_effect_{label}"]=cpu(vector[0,pos:])
            with torch.no_grad():out=original.block(layer,incoming,context)
            counts["finite_block_evaluations"]+=1
            scores=method.head_scores(model,out,counts)-sf
            check(controls,"finite_unchanged_prefix",float((out-yf)[:,:pos].abs().max()),input=branch)
            if branch=="native":check(controls,"native_finite_replay",float(np.max(abs(cpu(out[0,pos:])-target))),float(np.max(abs(scores-(true_scores-sf)))))
            arrays[f"{branch}_finite_state"]=cpu(out[0,pos:]);arrays[f"{branch}_finite_scores"]=scores
        assert len(controls)==22 and len(local)==72 and all(r["passed"] for r in controls+local)
        save(RUN/"pairs"/path.name,arrays,dict(group=meta["group"],position=pos,design_fingerprint=bundle["fingerprint"],
             parent_forecast_sha256=sha(path),parent_observation_sha256=sha(op),parent214_sha256=sha(pp),controls=controls,local_checks=local))
        status.update(completed_pairs=status["completed_pairs"]+1,counts=dict(counts),updated_utc=now())
        write_json(RUN/"status.json",status);gc.collect();print(f"215 {status['completed_pairs']}/64",flush=True)
    assert status["completed_pairs"]==64
    status.update(status="complete",qualified=True,original_wholeblock_jacobian_qualified=False,completed_utc=now())
    write_json(RUN/"status.json",status)


def main():
    assert not RUN.exists()
    result=ROOT/"docs/analysis/214-last-block-transfer.json"
    assert json.loads(result.read_text())["qualified"]
    RUN.mkdir(parents=True)
    design=dict(experiment=215,retrospective_oracle=True,arms=list(method.ARMS),branches=["native","predicted"],cases=64,
                source_hashes={p:sha(ROOT/p) for p in FILES},transfer_result_sha256=sha(result),registered_utc=now())
    bundle=dict(design=design,fingerprint=digest(design));write_json(RUN/"design.json",bundle)
    status=dict(status="running",qualified=False,completed_pairs=0,started_utc=now());write_json(RUN/"status.json",status)
    try:execute(bundle,status,defaultdict(int))
    except Exception as e:
        status.update(status="technical_failure",error=repr(e),failed_utc=now());write_json(RUN/"status.json",status);raise


if __name__=="__main__":main()
