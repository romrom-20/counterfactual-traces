"""Cross actual215 receiving corrections with fixed finite readout bases."""
import json,hashlib
from pathlib import Path
from collections import defaultdict
import torch,numpy as np
import ranked_block_response_201 as original
from latent_decisions.target import load_target
R=Path(__file__).resolve().parents[1];RUN=R/'runs/vector-readout-cross-216'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,o):p.write_text(json.dumps(o,indent=2))
def cpu(x):return x.detach().cpu().numpy().copy()
def main():
 assert not RUN.exists();RUN.mkdir();(RUN/'pairs').mkdir()
 files=['scripts/run_vector_readout_cross_216.py','scripts/audit_vector_readout_cross_216.py','docs/experiments/216-vector-readout-cross.md','scripts/ranked_block_response_201.py','src/latent_decisions/target.py']
 rp=R/'runs/source-receiver-partition-208/runtime.json';runtime=json.loads(rp.read_text());design=dict(source_hashes={f:sha(R/f) for f in files},runtime_sha256=sha(rp),parent215_audit_sha256=sha(R/'docs/analysis/215-matched-incoming-control.json'),bases=['native','predicted','false'],vectors=['native','predicted'],cases=64)
 write(RUN/'design.json',design);write(RUN/'runtime.json',runtime)
 model,tok,device=load_target(runtime['model'],'mps',offline=True);torch.set_num_threads(2);counts=defaultdict(int);rows=[]
 from latent_decisions.evidence_policy import digest
 assert digest(tok.get_vocab())==runtime['tokenizer_hash'] and digest(model.config.to_dict())==runtime['config_hash']
 assert not model.training and next(model.parameters()).dtype==torch.float32 and model.config._attn_implementation=='eager'
 def head(x):
  with torch.no_grad():y=original.head(model,x)
  counts['finite_head_evaluations']+=1;return cpu(y).astype(np.float64)
 for path in sorted((R/'runs/matched-incoming-control-215/pairs').glob('*.npz')):
  pp=R/'runs/source-receiver-partition-208/forecasts'/path.name;rec=json.loads(path.with_suffix('.json').read_text());assert sha(path)==rec['record']['arrays_sha256'];assert sha(pp)==json.loads(pp.with_suffix('.json').read_text())['record']['arrays_sha256']
  arrays={};checks=[];segments=[]
  with np.load(path) as z,np.load(pp) as old:
   pos=int(z['source_position']);xf=torch.tensor(old['false_boundaries'][28][None],device=device);assert pos<xf.shape[1]-1
   assert np.max(abs(cpu(xf[0,pos:])-z['false_final']))<=1e-4
   bases={'false':xf};vectors={}
   for name in ['native','predicted']:
    b=xf.clone();b[:,pos:]=torch.tensor(z[name+'_FL_state'][None],device=device);bases[name]=b
    d=torch.zeros_like(xf,device='cpu',dtype=torch.float64);d[:,pos+1:]=torch.tensor(z[name+'_effect_gate_after_rms'][1:][None],dtype=torch.float64);vectors[name]=d
    arrays[name+'_vector']=cpu(d[0,pos:])
   for name,b in bases.items():
    scores0=head(b);arrays[name+'_base_state']=cpu(b[0,pos:]);arrays[name+'_base_scores']=scores0
    expected=z['false_scores'].astype(np.float64) if name=='false' else z[name+'_FL_scores'].astype(np.float64)+z['false_scores'].astype(np.float64)
    checks.append(dict(kind='base_score_replay',base=name,error=float(np.max(abs(scores0-expected))),bound=.005))
    rx=b.detach().clone().requires_grad_(True);y=original.head(model,rx);grad=torch.autograd.grad(y[1]-y[0],rx)[0].detach().cpu().double();counts['reverse_head_forward']+=1;counts['reverse_head_backward']+=1
    h=b[0,-1].detach().cpu().double();w=(model.lm_head.weight[830].detach().cpu().double()-model.lm_head.weight[895].detach().cpu().double())*model.model.norm.weight.detach().cpu().double();inv=torch.rsqrt(h.square().mean()+model.model.norm.variance_epsilon);cg=w*inv-h*inv.pow(3)*(w*h).mean()
    checks.append(dict(kind='gradient_coordinate',base=name,error=float((cg-grad[0,-1]).abs().max()),bound=1e-4))
    arrays[name+'_reverse_gradient']=cpu(grad[0,-1]);arrays[name+'_closed_gradient']=cpu(cg)
    for vn,d in vectors.items():
     changed=(b.detach().cpu().double()+d).to(device=device,dtype=torch.float32);scores1=head(changed);pre=name+'_'+vn
     arrays[pre+'_state']=cpu(changed[0,pos:]);arrays[pre+'_scores']=scores1
     support=float((changed[:,:pos+1]-b[:,:pos+1]).abs().max());checks.append(dict(kind='prefix_source_preserved',base=name,vector=vn,error=support,bound=0.))
     rev=float((grad*d).sum());analytic=float((cg*d[0,-1]).sum());tol=.001+.0001*abs(rev);checks.append(dict(kind='gradient_contraction',base=name,vector=vn,error=abs(rev-analytic),bound=tol))
     if name==vn:
      er=float(np.max(abs(cpu(changed[0,pos+1:])-z[vn+'_FF_state'][1:])));es=float(np.max(abs(scores1-z[vn+'_FF_scores'].astype(np.float64)-z['false_scores'].astype(np.float64))));checks.extend([dict(kind='natural_receiving_replay',base=name,error=er,bound=1e-4),dict(kind='natural_score_replay',base=name,error=es,bound=.005)])
     change=float((scores1[1]-scores1[0])-(scores0[1]-scores0[0]));segments.append(dict(base=name,vector=vn,natural=name==vn,finite_margin_change=change,initial_projection=analytic,reverse_projection=rev,finite_minus_initial=change-analytic))
   arrays.update(false_scores=z['false_scores'].copy(),position=np.array(pos))
  assert all(c['error']<=c['bound'] for c in checks),checks
  out=RUN/'pairs'/path.name;np.savez_compressed(out,**arrays);row=dict(key=path.stem,group=rec['record']['group'],parent215_sha256=sha(path),parent208_sha256=sha(pp),arrays_sha256=sha(out),checks=checks,segments=segments);write(out.with_suffix('.json'),row);rows.append(row);write(RUN/'status.json',dict(status='running',completed_pairs=len(rows),counts=dict(counts)));print(path.stem,len(rows),flush=True)
 assert len(rows)==64 and all(sha(R/f)==h for f,h in design['source_hashes'].items())
 report=dict(qualified=True,cases=64,rows=rows,counts=dict(counts),original_wholeblock_jacobian_qualified=False,limits='Retrospectivefiniteheadcross; naturaldiagonalversussynthetictransplantation. No learnedcircuit,priority,forecastorprospectiveclaim.')
 write(R/'docs/analysis/216-vector-readout-cross.json',report);write(RUN/'status.json',dict(status='complete',**{k:v for k,v in report.items() if k!='rows'}))
if __name__=='__main__':main()
