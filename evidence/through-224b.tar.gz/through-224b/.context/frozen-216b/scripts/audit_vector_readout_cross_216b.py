"""Independent saved-array audit and crossed finite-margin summaries216."""
import json,hashlib
from pathlib import Path
import numpy as np
R=Path(__file__).resolve().parents[1];RUN=R/'runs/vector-readout-cross-216';OUT=R/'docs/analysis/216-vector-readout-cross-audit.json'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def margin(s):return float(s[1]-s[0])
def main():
 assert not OUT.exists();d=json.loads((RUN/'design.json').read_text());p=json.loads((R/'docs/analysis/216-vector-readout-cross.json').read_text());assert all(sha(R/f)==h for f,h in d['source_hashes'].items());assert p['cases']==64 and p['counts']==dict(finite_head_evaluations=576,reverse_head_forward=192,reverse_head_backward=192)
 assert sha(R/'runs/source-receiver-partition-208/runtime.json')==d['runtime_sha256'];assert sha(R/'docs/analysis/215-matched-incoming-control.json')==d['parent215_audit_sha256']
 rows=[];checks=[];segments=[]
 for path in sorted((RUN/'pairs').glob('*.npz')):
  row=json.loads(path.with_suffix('.json').read_text());assert sha(path)==row['arrays_sha256'];parent=R/'runs/matched-incoming-control-215/pairs'/path.name;old=R/'runs/source-receiver-partition-208/forecasts'/path.name;assert sha(parent)==row['parent215_sha256'] and sha(old)==row['parent208_sha256'];checks.extend(row['checks']);f={}
  with np.load(path) as z,np.load(parent) as pz:
   assert all(np.isfinite(a).all() for a in z.values())
   for name in ['native','predicted']:
    assert np.max(abs(z[name+'_vector'][0]))==0
    assert np.max(abs(z[name+'_vector'][1:]-pz[name+'_effect_gate_after_rms'][1:]))==0
   for s in row['segments']:
    b,v=s['base'],s['vector'];expected=(z[b+'_base_state'].astype(np.float64)+z[v+'_vector']).astype(np.float32);assert np.max(abs(expected-z[b+'_'+v+'_state']))==0
    change=margin(z[b+'_'+v+'_scores'])-margin(z[b+'_base_scores']);analytic=float(z[b+'_closed_gradient']@z[v+'_vector'][-1]);reverse=float(z[b+'_reverse_gradient']@z[v+'_vector'][-1]);assert abs(change-s['finite_margin_change'])<=1e-12 and abs(analytic-s['initial_projection'])<=1e-10 and abs(reverse-s['reverse_projection'])<=1e-10
    f[b,v]=change;segments.append(dict(key=row['key'],group=row['group'],**s))
   total=f['native','native']-f['predicted','predicted'];vector=.5*((f['native','native']-f['native','predicted'])+(f['predicted','native']-f['predicted','predicted']));geometry=.5*((f['native','native']-f['predicted','native'])+(f['native','predicted']-f['predicted','predicted']));assert abs(total-vector-geometry)<=1e-12
   rows.append(dict(key=row['key'],group=row['group'],natural_effect_difference=total,symmetric_vector_contrast=vector,symmetric_base_contrast=geometry,sign_disagreement_at_base={b:bool(np.sign(f[b,'native'])!=np.sign(f[b,'predicted'])) for b in d['bases']},same_vector_sign_disagreement_between_natural_bases={v:bool(np.sign(f['native',v])!=np.sign(f['predicted',v])) for v in d['vectors']}))
 assert len(rows)==64 and len(segments)==384 and len(checks)==1408 and all(c['error']<=c['bound'] for c in checks)
 summaries=[]
 for b in d['bases']:
  for v in d['vectors']:
   q=[s for s in segments if s['base']==b and s['vector']==v];summaries.append(dict(base=b,vector=v,count=len(q),positive_finite=sum(s['finite_margin_change']>0 for s in q),negative_finite=sum(s['finite_margin_change']<0 for s in q),median_finite_margin_change=float(np.median([s['finite_margin_change'] for s in q])),median_initial_projection=float(np.median([s['initial_projection'] for s in q])),maximum_finite_minus_initial= max(abs(s['finite_minus_initial']) for s in q),finite_initial_sign_disagreements=sum(np.sign(s['finite_margin_change'])!=np.sign(s['initial_projection']) for s in q)))
 out=dict(qualified=True,cases=64,finite_segments=384,controls=len(checks),counts=p['counts'],maximum_gradient_coordinate_error=max(c['error'] for c in checks if c['kind']=='gradient_coordinate'),maximum_gradient_contraction_error=max(c['error'] for c in checks if c['kind']=='gradient_contraction'),maximum_natural_receiving_replay_error=max(c['error'] for c in checks if c['kind']=='natural_receiving_replay'),maximum_natural_score_replay_error=max(c['error'] for c in checks if c['kind']=='natural_score_replay'),vector_sign_disagreements_at_fixed_base={b:sum(r['sign_disagreement_at_base'][b] for r in rows) for b in d['bases']},same_vector_sign_disagreements_between_natural_bases={v:sum(r['same_vector_sign_disagreement_between_natural_bases'][v] for r in rows) for v in d['vectors']},summaries=summaries,rows=rows,segments=segments,auditor_sha256=sha(Path(__file__)),report_sha256=sha(R/'docs/analysis/216-vector-readout-cross.json'),original_wholeblock_jacobian_qualified=False,limits='Naturaldiagonal and synthetictransplants; symmetriccontrasts are algebraicaccounting not uniquecausalallocation. Retrospective,dependentcontexts; no circuit,priorityorprospectiveclaim.')
 OUT.write_text(json.dumps(out,indent=2,default=lambda x:x.item() if isinstance(x,np.generic) else str(x)));print({k:v for k,v in out.items() if k not in ['rows','segments']})
if __name__=='__main__':main()
