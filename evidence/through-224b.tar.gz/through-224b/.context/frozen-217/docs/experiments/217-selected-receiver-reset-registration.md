# Selected-depth receiver resets of the original 208 update

Registered after 216's common-readout experiment and before 217 model execution. All 64 old208 contexts, retrospective/oracle only. No fresh-context or prospective claim, fitted coefficient, layer search, browser, training, publication or git operations. Preserve all earlier scientific and technical failures and 204's qualified reset scope. Scientific code/protocol/auditor immutable after first execution; corrections separately named without relaxing executed thresholds.

## Reset and continuation

Boundary k means k completed blocks. Predeclare k in {0,8,16,24,27}. At boundary k, replace ALL RECEIVING rows after the Boolean source with native True receiving states from the saved208 observation. Keep False prefix and the independently verified exact known Boolean-source trajectory from the original208 False-only forecast. At k=0 the receiver reset is zero and the known edited Boolean embedding supplies the source; this is an original-predictor replay control. At k=27 the incoming state is the native input used by215; this is the native-input replay control. No claim to an exact earliest layer between these coarse tested depths.

Resume exactly the original208 finite-source/False-first-AD-receiver update, not a full-finite continuation:

    delta[l+1] = finite_source[l+1] - false[l+1] + J_false[l](R delta[l]).

Compute each finite_source block from a full nativeFalse anchor with only its absolute source row replaced by the known source state. Cache these 28 actual block evaluations independently and replay against original208 saved updates. R zeros prefix and source. Every receiver JVP is actually executed; no norm subtraction, copied native future trajectory or synthetic transport identity. Native receiver values enter only at the ONE declared reset. Save every subsequent predicted suffix. Check exact source support, unchanged prefix and False primals. The original MPS first-AD operation is retained; original whole-block coordinate certification remains false.

## Two final-block diagnostics and actual final endpoints

At each resulting boundary27 state, evaluate the same215 affine-background FL and FF arms (MLP-input RMSNorm finite; gate-up product affine vs finite; other nonlinear primitives False-affine). Record signed receiving C_k=FF−FL, natural finite margin effect and whether product repair improves BOTH verdict residual and margin errors. Also transplant C_k into the SAME fixed native-FL final readout base for that context, exactly as216, and measure finite margin change there. A positive fixed-base effect beyond .02 nats is a predeclared diagnostic of native-like sign, NOT an accuracy pass. Report raw signs too. Crossed216 already demonstrated that vector-source changes, rather than readout alone, carry the prominent sign reversals; 217 is not a new unique-feature attribution.

Also execute the original208 final source/receiver update and the entire finite block28 at each resulting input. Every final head stays finite. Evaluate all endpoints with original joint bounds: native verdict displacement norm>=.001, relativeL2<=.05, cosine>=.99, absolute margin-response error<=.10 nats. Native-input whole-finite28 is a trivial control, not a predictor. No improvement threshold substitutes for accuracy.

## Numerical qualification

Require original1e-4 coordinates/.005 logitscore bounds for: all28 known sources vs native observations; Boolean embedding support; cached source-block prefix/source/replay; False trace/head and two local sham arms; reset prefix/source/native receivers; every local JVP primal; each propagated prefix/source; fixed reference head; all actual local primitive derivatives; all final prefix supports; and k0/k27 input, trajectory and215 endpoint/head replays. Use exact saved absolute source operands, including at boundary27, to avoid source subtraction/readdition.

Independently check EVERY used JVP direction with three standard first-reverse projections (.001+.0001*abs(reference)), grouping directions at the same block so shared reverse gradients are computed once. These scalar checks do not certify all coordinates. In a second structurally distinct whole-model forward-AD hook implementation, actually replay all five reset continuations for the preregistered marzipan block (16 contexts covering all schema/order/assignment/target cells). Require full False primal and post-reset trajectory/source/head agreement at original bounds. No model calls for different agents run concurrently.

Expected local JVPs: 64 per context (27+20+12+4+1), total4096; 27 reverse block evaluations per context, 3 reverse projections per JVP=12288 scalar comparisons. Cache28 source-finite blocks and evaluate5 final finite controls per context=2112 finite blocks. Two False shams plus2arms*5resets=768 surrogate blocks, 4224 local primitive checks. One False head, two sham heads, one fixed-base head, and5heads*5resets=1856 finite heads. Whole-model subset:80 forward-AD replays,2240 nested source-finite blocks and80 finite norm hooks. Model counters and each required check kind must be independently audited.

## Aggregation and interpretation

Retain every reset, source block, schema, order and four assignment/target cells. For sign restoration and beneficial natural correction separately, require all four cells per panel and >=3/4 panels in EVERY schema/order stratum for a whole-test diagnostic pass. Apply the same panel aggregation to original accuracy endpoints. Report nonmonotonic results; do not interpolate or binary-search untested depths. The earliest successful tested boundary is only the earliest in this five-point grid. A reset can show reintroduced downstream error without identifying the primitive or learned feature producing it.

Freeze and evaluate a new mechanism-based predictor on unseen contexts only if these diagnostics support a concrete False-state-only rule. An oracle reset is not such a rule, and an accurate head at a native endpoint cannot justify a prospective success claim.

Before-execution audit clarification: independently reconstruct each boundary27 input from the preceding saved trajectory with the known source row overwritten; depth27 must equal the saved reset itself. Report receiving/verdict error at every subsequently computed block, using the saved native observations only for evaluation. Layerwise error regrowth does not by itself separate generation from amplification or identify a primitive cause.
