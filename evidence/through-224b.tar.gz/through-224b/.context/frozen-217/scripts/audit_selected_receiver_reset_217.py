"""Saved-array reconstruction and fixed panel outcomes for actual receiver resets."""

import itertools
import json
from collections import Counter
from pathlib import Path

import numpy as np
import run_selected_receiver_reset_217 as run
from audit_block28_primitive_211b import projected
from audit_last_block_transfer_214b import margin,outcome
from audit_two_block_factorial_209 import metrics

from latent_decisions.evidence_policy import digest,write_json

ROOT,RUN=run.ROOT,run.RUN
OUT=ROOT/"docs/analysis/217-selected-receiver-reset.json"


def main():
    assert not OUT.exists()
    bundle=json.loads((RUN/"design.json").read_text());design=bundle["design"]
    assert digest(design)==bundle["fingerprint"]
    assert all(run.sha(ROOT/p)==h for p,h in design["source_hashes"].items())
    assert run.sha(ROOT/"docs/analysis/215-matched-incoming-control.json")==design["parent215_result_sha256"]
    assert run.sha(ROOT/"docs/analysis/216-vector-readout-cross-audit.json")==design["parent216_audit_sha256"]
    status=json.loads((RUN/"status.json").read_text())
    expected=dict(local_finite_block=2112,local_block_jvp=4096,manual_false_primitive_traces=64,
        surrogate_block_evaluations=768,finite_head_evaluations=1856,skipped_zero_receiver_jvp=64,
        reverse_block_forward=1728,reverse_block_backward=5184,reverse_head_forward=1728,reverse_head_backward=1728,
        whole_public_forward_ad=80,whole_public_nested_source_blocks=2240,whole_public_finite_norms=80)
    assert status["status"]=="complete" and status["qualified"] and status["completed_pairs"]==64
    assert not status["original_wholeblock_jacobian_qualified"] and status["counts"]==expected,status
    controls=[];local=[];reverse=[];rows=[];maximum_formula=0.;keys=[]
    for path in sorted((RUN/"pairs").glob("*.npz")):
        obj=json.loads(path.with_suffix(".json").read_text());record=obj["record"]
        assert digest(record)==obj["sha256"] and run.sha(path)==record["arrays_sha256"]
        assert record["design_fingerprint"]==bundle["fingerprint"]
        fp=run.PARENT/"forecasts"/path.name;op=run.PARENT/"observations"/path.name
        pp=ROOT/"runs/matched-incoming-control-215/pairs"/path.name
        assert run.sha(fp)==record["parent_forecast_sha256"] and run.sha(op)==record["parent_observation_sha256"] and run.sha(pp)==record["parent215_sha256"]
        controls.extend(record["controls"]);local.extend(record["local_checks"]);reverse.extend(record["reverse_checks"]);keys.append(path.stem)
        kinds=Counter(r["kind"] for r in record["controls"])
        required=dict(known_source_native_all28=1,embedding_support=1,source_cache_prefix=28,source_cache_source=28,
            source_cache_original208=28,false_trace=1,false_head=1,false_surrogate_sham=2,fixed_native_FL_head=1,
            reset_prefix=5,reset_source=5,reset_receivers=5,local_jvp_false_primal=64,continued_prefix=65,continued_source=65,
            surrogate_prefix=10,finite_control_prefix=5,**{"215_input_replay":2,"215_endpoint_replay":6},original208_full_replay=1)
        if record["group"]["block"]=="marzipan":
            required.update(whole_public_false_primal=5,whole_public_reset_trajectory=5,whole_public_exact_source=5)
        assert kinds==Counter(required),(path,kinds,required)
        assert len(record["local_checks"])==66 and len(record["reverse_checks"])==192
        with np.load(path,allow_pickle=False) as raw,np.load(fp,allow_pickle=False) as old,np.load(op,allow_pickle=False) as native:
            assert all(np.isfinite(a).all() for a in raw.values())
            z={k:raw[k].astype(np.float64) for k in raw.files}
            actual=z["native_final"]-z["false_final"]
            target=margin(z["true_scores"]-z["false_scores"])
            pos=record["position"]
            for depth in design["depths"]:
                prefix=f"reset_{depth}"
                initial=z[prefix+"_initial_state"]
                if depth:
                    assert np.max(abs(initial[1:]-native["true_suffix"][depth-1,1:]))<=1e-4
                    assert np.max(abs(initial[0]-z["known_source"][depth-1]))<=1e-4
                else:
                    assert np.max(abs(initial[1:]-old["false_boundaries"][0,pos+1:]))==0
                trajectory=z[prefix+"_trajectory"];j=z[prefix+"_receiver_jvp"]
                assert trajectory.shape[0]==28-depth and np.max(abs(j[:,0]))==0
                if depth==27:input27=initial.copy()
                else:
                    input27=(z["false_input27"]+trajectory[26-depth]).astype(np.float32).astype(np.float64)
                    input27[0]=z["known_source"][26]
                assert np.max(abs(input27-z[prefix+"_input27"]))<=1e-4
                assert np.max(abs(z["native_input27"]-native["true_suffix"][26]))==0
                gap=float(np.max(abs(trajectory-z["source_cache_delta"][depth:]-j)))
                maximum_formula=max(maximum_formula,gap);assert gap<=1e-4
                assert np.max(abs(z[prefix+"_original_state"]-z["false_final"]-trajectory[-1]))<=1e-4
                correction=z[prefix+"_FF_state"]-z[prefix+"_FL_state"];correction[:1]=0
                assert np.max(abs(correction-z[prefix+"_correction"]))<=1e-4
                common=(z["fixed_base"]+correction).astype(np.float32).astype(np.float64)
                assert np.max(abs(common-z[prefix+"_common_state"]))<=1e-4
                baseline=outcome(z[prefix+"_FL_state"]-z["false_final"],actual,z[prefix+"_FL_scores"],target)
                arms={a:outcome(z[prefix+"_"+a+"_state"]-z["false_final"],actual,z[prefix+"_"+a+"_scores"],target,baseline)
                      for a in ("original","FL","FF","finite")}
                natural_change=margin(z[prefix+"_FF_scores"]-z[prefix+"_FL_scores"])
                common_change=margin(z[prefix+"_common_scores"])
                q0=arms["FL"]["final"]["verdict"]["relative_l2"];q1=arms["FF"]["final"]["verdict"]["relative_l2"]
                m0=arms["FL"]["absolute_margin_error"];m1=arms["FF"]["absolute_margin_error"]
                diagnostics=dict(natural_product_both_improve=bool(q1<q0 and m1<m0),natural_margin_positive=natural_change>0,
                    common_margin_positive=common_change>0,common_sign_restored_guard=common_change>.02)
                incoming=z[prefix+"_input27"]-z["false_input27"]
                native_in=z["native_input27"]-z["false_input27"]
                incoming_metrics={k:metrics(incoming[s],native_in[s]) for k,s in dict(source=slice(0,1),receivers=slice(1,None),verdict=slice(-1,None)).items()}
                layerwise=[]
                for offset,prediction in enumerate(trajectory):
                    block=depth+offset+1
                    actual_layer=native["true_suffix"][block-1].astype(np.float64)-old["false_boundaries"][block,pos:].astype(np.float64)
                    layerwise.append(dict(after_block=block,receivers=metrics(prediction[1:],actual_layer[1:]),verdict=metrics(prediction[-1:],actual_layer[-1:])))
                rows.append(dict(key=path.stem,group=record["group"],boundary=depth,arms=arms,diagnostics=diagnostics,
                    natural_product_margin_change=natural_change,common_product_margin_change=common_change,incoming=incoming_metrics,
                    receiver_correction=projected(correction[1:],(z["native_final"]-z[prefix+"_FL_state"])[1:]),layerwise=layerwise))
    assert len(keys)==64 and len(set(keys))==64 and len(rows)==320 and len(local)==4224 and len(reverse)==12288
    assert all(r["passed"] for r in controls+local+reverse)
    strata=[];panels=[]
    for depth in design["depths"]:
        contexts=[r for r in rows if r["boundary"]==depth]
        for field in (None,"block","schema","reverse"):
            for value in ([None] if field is None else sorted({r["group"][field] for r in contexts})):
                selected=[r for r in contexts if field is None or r["group"][field]==value]
                arms={a:dict(median_verdict_relative_l2=float(np.median([r["arms"][a]["final"]["verdict"]["relative_l2"] for r in selected])),
                    median_absolute_margin_error=float(np.median([r["arms"][a]["absolute_margin_error"] for r in selected])),
                    primary_passes=sum(bool(r["arms"][a]["primary_pass"]) for r in selected)) for a in contexts[0]["arms"]}
                strata.append(dict(boundary=depth,field=field,value=value,count=len(selected),arms=arms,
                    median_incoming_receiving_relative_l2=float(np.median([r["incoming"]["receivers"]["relative_l2"] for r in selected])),
                    median_natural_product_margin_change=float(np.median([r["natural_product_margin_change"] for r in selected])),
                    median_common_product_margin_change=float(np.median([r["common_product_margin_change"] for r in selected])),
                    diagnostics={k:sum(bool(r["diagnostics"][k]) for r in selected) for k in contexts[0]["diagnostics"]}))
        for schema,rev,block in itertools.product(("generic","descriptive"),range(2),sorted({r["group"]["block"] for r in contexts})):
            cells=[r for r in contexts if r["group"]["schema"]==schema and r["group"]["reverse"]==rev and r["group"]["block"]==block]
            assert len(cells)==4 and {(r["group"]["assignment"],r["group"]["target"]) for r in cells}==set(itertools.product(range(2),repeat=2))
            panels.append(dict(boundary=depth,schema=schema,reverse=rev,block=block,
                diagnostics={k:all(r["diagnostics"][k] for r in cells) for k in cells[0]["diagnostics"]},
                accuracy={a:all(r["arms"][a]["primary_pass"] for r in cells) for a in cells[0]["arms"]}))
    whole=[]
    for depth in design["depths"]:
        for category,names in (("diagnostics",rows[0]["diagnostics"]),("accuracy",rows[0]["arms"])):
            for name in names:
                by_stratum=[dict(schema=schema,reverse=rev,passing_panels=sum(p[category][name] for p in panels if p["boundary"]==depth and p["schema"]==schema and p["reverse"]==rev))
                            for schema,rev in itertools.product(("generic","descriptive"),range(2))]
                whole.append(dict(boundary=depth,category=category,metric=name,passed=all(s["passing_panels"]>=3 for s in by_stratum),strata=by_stratum))
    report=dict(qualified=True,retrospective_oracle=True,original_wholeblock_jacobian_qualified=False,cases=64,context_rows=320,
        depths=design["depths"],counts=expected,controls=len(controls),local_derivative_checks=len(local),reverse_projections=len(reverse),
        maximum_coordinate_control_error=max(r["coordinate_error"] for r in controls),maximum_score_control_error=max(r["score_error"] for r in controls),
        maximum_local_derivative_error=max(r["coordinate_error"] for r in local),maximum_reverse_projection_error=max(r["absolute_error"] for r in reverse),
        maximum_saved_update_formula_error=maximum_formula,design_fingerprint=bundle["fingerprint"],auditor_sha256=run.sha(Path(__file__)),
        rows=rows,strata=strata,panel_results=panels,whole=whole,
        limits="Selectedfiveoracledepths; actualoriginal208firstADcontinuations, noexactearliestlayer, uniqueerrorfeature,circuitorprospectiveprediction. OriginalcoordinateJacobianunqualified.")
    write_json(OUT,report)
    print(json.dumps({k:v for k,v in report.items() if k not in ("rows","strata","panel_results","whole")},indent=2))
    for s in strata:
        if s["field"] is None:print(json.dumps(s,indent=2))
    print(json.dumps(whole,indent=2))


if __name__=="__main__":main()
