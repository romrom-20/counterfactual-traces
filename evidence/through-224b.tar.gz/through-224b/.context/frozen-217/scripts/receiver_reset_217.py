"""Structurally separate whole-model source/receiver reset replay."""

import torch
from torch.autograd import forward_ad

from latent_decisions.target import block_tensor, replace_block_tensor


def public_reset(model, embedding, edited, position, boundary, receiver_reset):
    values, sources, handles, operands = [], [], [], {}
    absolute_source = [edited[:, position].detach().clone()]

    def run(lam):
        def pre_for(index):
            def pre(module, args, kwargs):
                primal, direction = forward_ad.unpack_dual(args[0])
                operand = primal.clone()
                operand[:, position] = absolute_source[0]
                operands[index] = operand
                receiver = (receiver_reset if index == boundary else direction).clone()
                receiver[:, :position+1] = 0
                return (forward_ad.make_dual(primal, receiver), *args[1:]), kwargs
            return pre

        def out_for(index):
            def out(module, args, kwargs, output):
                primal, direction = forward_ad.unpack_dual(block_tensor(output))
                finite = block_tensor(module.forward(operands[index], **kwargs))
                delta = finite-primal+direction
                absolute_source[0] = finite[:, position].detach().clone()
                sources.append(absolute_source[0])
                result = forward_ad.make_dual(primal, delta)
                values.append(result)
                return replace_block_tensor(output, result)
            return out

        def norm_hook(module, args, output):
            primal, direction = forward_ad.unpack_dual(args[0])
            value, _ = forward_ad.unpack_dual(output)
            return forward_ad.make_dual(value, module.forward(primal+direction)-value)

        try:
            for index, layer in enumerate(model.model.layers):
                handles.append(layer.register_forward_pre_hook(pre_for(index), with_kwargs=True))
                handles.append(layer.register_forward_hook(out_for(index), with_kwargs=True))
            handles.append(model.model.norm.register_forward_hook(norm_hook))
            result = model(inputs_embeds=embedding+lam*(edited-embedding),
                attention_mask=torch.ones(embedding.shape[:2],device=embedding.device,dtype=torch.long),
                use_cache=False,logits_to_keep=1)
            return torch.stack(values), result.logits[0,-1,[895,830]]
        finally:
            for h in handles:h.remove()
    zero = torch.zeros((),device=embedding.device,dtype=embedding.dtype)
    primal,tangent = torch.func.jvp(run,(zero,),(torch.ones_like(zero),))
    return primal,tangent,torch.stack(sources)
