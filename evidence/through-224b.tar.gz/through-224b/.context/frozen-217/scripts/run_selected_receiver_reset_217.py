"""Actual finite-source/JVP-receiver continuations from selected native resets."""

import gc
import json
from collections import defaultdict
from pathlib import Path

import block_derivative_checks_209 as derivatives
import numpy as np
import oracle_continuation_203 as continuation
import primitive_diagnostic_211 as primitive
import ranked_block_response_201 as original
import receiver_reset_217 as independent
import rms_product_factorial_212 as method
import torch
from frozen_block28_derivative_210 import trace
from run_absence_alphabet_104 import now
from run_last_block_transfer_214 import PARENT, cpu, save
from run_rms_product_factorial_212b import check, sha

from latent_decisions.evidence_policy import digest,write_json
from latent_decisions.target import load_target

ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/"runs/selected-receiver-reset-217"
DEPTHS=(0,8,16,24,27)
FILES=["scripts/run_selected_receiver_reset_217.py","scripts/receiver_reset_217.py",
       "scripts/audit_selected_receiver_reset_217.py","docs/experiments/217-selected-receiver-reset-registration.md",
       "scripts/oracle_continuation_203.py","scripts/block_derivative_checks_209.py",
       "scripts/ranked_block_response_201.py","scripts/rms_product_factorial_212.py",
       "scripts/primitive_diagnostic_211.py","scripts/frozen_block28_derivative_210.py",
       "scripts/local_primitive_derivative_210c.py","scripts/run_rms_product_factorial_212b.py",
       "scripts/run_last_block_transfer_214.py","src/latent_decisions/target.py","src/latent_decisions/evidence_policy.py"]


def execute(bundle,status,counts):
    rt=json.loads((PARENT/"runtime.json").read_text())
    model,tok,device=load_target(rt["model"],"mps",offline=True)
    torch.set_num_threads(2)
    assert digest(tok.get_vocab())==rt["tokenizer_hash"] and digest(model.config.to_dict())==rt["config_hash"]
    assert not model.training and model.config._attn_implementation=="eager" and next(model.parameters()).dtype==torch.float32
    write_json(RUN/"runtime.json",dict(**rt,cpu_threads=2))
    for path in sorted((PARENT/"forecasts").glob("*.npz")):
        meta=json.loads(path.with_suffix(".json").read_text())["record"]
        op=PARENT/"observations"/path.name
        pp=ROOT/"runs/matched-incoming-control-215/pairs"/path.name
        assert sha(path)==meta["arrays_sha256"]
        assert sha(op)==json.loads(op.with_suffix(".json").read_text())["record"]["arrays_sha256"]
        assert sha(pp)==json.loads(pp.with_suffix(".json").read_text())["record"]["arrays_sha256"]
        with np.load(path,allow_pickle=False) as z,np.load(op,allow_pickle=False) as oz,np.load(pp,allow_pickle=False) as pz:
            fb=[torch.tensor(a[None],device=device) for a in z["false_boundaries"]]
            native=torch.tensor(oz["true_suffix"],device=device)
            known=torch.tensor(z["source_receiver_absolute_source"],device=device)
            old_delta=torch.tensor(z["source_receiver_delta_suffix"],device=device)
            old_j=torch.tensor(z["source_receiver_receiver_jvp_suffix"],device=device)
            sf_saved=z["false_scores"].astype(np.float64);true_scores=oz["true_scores"].astype(np.float64)
            context=dict(mask=torch.tensor(z["mask"],device=device),rope=tuple(torch.tensor(z[k],device=device) for k in ("rope_cos","rope_sin")))
            old215={k:pz[k].copy() for k in pz.files if k.startswith(("native_","predicted_"))}
        pos=meta["position"]
        controls=[];local=[];reverse=[];cache=[];directions=defaultdict(dict)
        with torch.no_grad():edited=model.model.embed_tokens(torch.tensor([meta["bases"][1]["free_input_ids"]],device=device))
        edit=edited-fb[0]
        check(controls,"known_source_native_all28",float((known-native[:,0]).abs().max()))
        check(controls,"embedding_support",float(torch.cat((edit[:,:pos],edit[:,pos+1:]),dim=1).abs().max()))
        for index in range(28):
            operand=fb[index].clone()
            operand[:,pos]=edited[:,pos] if index==0 else known[index-1]
            finite=continuation.finite(model,index,operand,context,counts)
            delta=finite-fb[index+1]
            cache.append(delta.detach())
            check(controls,"source_cache_prefix",float(delta[:,:pos].abs().max()),block=index+1)
            check(controls,"source_cache_source",float((finite[:,pos]-known[index]).abs().max()),block=index+1)
            check(controls,"source_cache_original208",float((delta[0,pos:]+old_j[index]-old_delta[index]).abs().max()),block=index+1)
        layer=model.model.layers[27];c=trace(layer,fb[27],context);counts["manual_false_primitive_traces"]+=1
        check(controls,"false_trace",float((c["output"]-fb[28].cpu().double()).abs().max()))
        sf=method.head_scores(model,fb[28],counts)
        check(controls,"false_head",score=float(np.max(abs(sf-sf_saved))))
        for arm in ("FL","FF"):
            with primitive.surgeries(layer,c,context,method.enabled("affine",arm)) as checks,torch.no_grad():out=original.block(layer,fb[27],context)
            counts["surrogate_block_evaluations"]+=1
            local.extend(dict(boundary="False",arm=arm,**r) for r in checks)
            check(controls,"false_surrogate_sham",float((out-fb[28]).abs().max()),float(np.max(abs(method.head_scores(model,out,counts)-sf))),arm=arm)
        fixed=fb[28].clone();fixed[:,pos:]=torch.tensor(old215["native_FL_state"][None],device=device)
        fixed_scores=method.head_scores(model,fixed,counts)
        check(controls,"fixed_native_FL_head",score=float(np.max(abs(fixed_scores-sf-old215["native_FL_scores"]))))
        arrays=dict(false_input27=cpu(fb[27][0,pos:]),native_input27=cpu(native[26]),false_final=cpu(fb[28][0,pos:]),
            native_final=cpu(native[27]),false_scores=sf,true_scores=true_scores,position=np.array(pos),
            fixed_base=cpu(fixed[0,pos:]),fixed_scores=fixed_scores,source_cache_delta=cpu(torch.stack(cache)[:,0,pos:]),known_source=cpu(known))
        outputs={};reset_directions={}
        for depth in DEPTHS:
            incoming=fb[depth].clone()
            incoming[:,pos]=edited[:,pos] if depth==0 else known[depth-1]
            if depth:incoming[:,pos+1:]=native[depth-1,1:]
            check(controls,"reset_prefix",float((incoming-fb[depth])[:,:pos].abs().max()),boundary=depth)
            source=edited[:,pos] if depth==0 else known[depth-1]
            check(controls,"reset_source",float((incoming[:,pos]-source).abs().max()),boundary=depth)
            receivers=fb[0][:,pos+1:] if depth==0 else native[depth-1,1:][None]
            check(controls,"reset_receivers",float((incoming[:,pos+1:]-receivers).abs().max()),boundary=depth)
            delta=incoming-fb[depth]
            reset_directions[depth]=delta.detach().clone()
            arrays[f"reset_{depth}_initial_state"]=cpu(incoming[0,pos:])
            states=[];jvps=[];input27=incoming.clone() if depth==27 else None
            for index in range(depth,28):
                if index==27 and input27 is None:
                    input27=fb[27]+delta;input27[:,pos]=known[26]
                receiver=delta.clone();receiver[:,:pos+1]=0
                if index==0:
                    assert torch.count_nonzero(receiver)==0
                    transmitted=torch.zeros_like(delta);counts["skipped_zero_receiver_jvp"]+=1
                else:
                    primal,transmitted=continuation.jvp(model,index,fb[index],receiver,context,counts)
                    check(controls,"local_jvp_false_primal",float((primal-fb[index+1]).abs().max()),boundary=depth,block=index+1)
                    directions[index][f"reset_{depth}"]=(receiver.detach(),transmitted.detach())
                assert torch.count_nonzero(transmitted[:,:pos+1])==0
                delta=cache[index]+transmitted
                jvps.append(transmitted.detach())
                check(controls,"continued_prefix",float(delta[:,:pos].abs().max()),boundary=depth,block=index+1)
                check(controls,"continued_source",float((fb[index+1][:,pos]+delta[:,pos]-known[index]).abs().max()),boundary=depth,block=index+1)
                states.append(delta.detach())
            states=torch.stack(states);outputs[depth]=(states,delta)
            arrays[f"reset_{depth}_trajectory"]=cpu(states[:,0,pos:])
            arrays[f"reset_{depth}_receiver_jvp"]=cpu(torch.stack(jvps)[:,0,pos:])
            arrays[f"reset_{depth}_input27"]=cpu(input27[0,pos:])
            final=fb[28]+delta
            arrays[f"reset_{depth}_original_state"]=cpu(final[0,pos:])
            arrays[f"reset_{depth}_original_scores"]=method.head_scores(model,final,counts)-sf
            arms={}
            for arm in ("FL","FF"):
                with primitive.surgeries(layer,c,context,method.enabled("affine",arm)) as checks,torch.no_grad():out=original.block(layer,input27,context)
                counts["surrogate_block_evaluations"]+=1
                local.extend(dict(boundary=depth,arm=arm,**r) for r in checks)
                check(controls,"surrogate_prefix",float((out-fb[28])[:,:pos].abs().max()),boundary=depth,arm=arm)
                arms[arm]=out.detach()
                arrays[f"reset_{depth}_{arm}_state"]=cpu(out[0,pos:])
                arrays[f"reset_{depth}_{arm}_scores"]=method.head_scores(model,out,counts)-sf
            correction=arms["FF"].cpu().double()-arms["FL"].cpu().double()
            correction[:,:pos+1]=0
            common=(fixed.cpu().double()+correction).to(device=device,dtype=torch.float32)
            arrays[f"reset_{depth}_correction"]=cpu(correction[0,pos:])
            arrays[f"reset_{depth}_common_state"]=cpu(common[0,pos:])
            arrays[f"reset_{depth}_common_scores"]=method.head_scores(model,common,counts)-fixed_scores
            finite=continuation.finite(model,27,input27,context,counts)
            check(controls,"finite_control_prefix",float((finite-fb[28])[:,:pos].abs().max()),boundary=depth)
            arrays[f"reset_{depth}_finite_state"]=cpu(finite[0,pos:])
            arrays[f"reset_{depth}_finite_scores"]=method.head_scores(model,finite,counts)-sf
            if depth in (0,27):
                branch="predicted" if depth==0 else "native"
                check(controls,"215_input_replay",float(np.max(abs(cpu(input27[0,pos:])-old215[branch+"_input"]))),boundary=depth)
                for arm in ("FL","FF","finite"):
                    check(controls,"215_endpoint_replay",float(np.max(abs(arrays[f"reset_{depth}_{arm}_state"]-old215[f"{branch}_{arm}_state"]))),
                        float(np.max(abs(arrays[f"reset_{depth}_{arm}_scores"]-old215[f"{branch}_{arm}_scores"]))),boundary=depth,arm=arm)
            if depth==0:check(controls,"original208_full_replay",float((states[:,0,pos:]-old_delta).abs().max()))
        for index,items in directions.items():
            reverse.extend(derivatives.verify(model,index,fb[index],fb[index+1],context,items,counts))
        if meta["group"]["block"]=="marzipan":
            for depth in DEPTHS:
                primal,tangent,sources=independent.public_reset(model,fb[0],edited,pos,depth,reset_directions[depth])
                counts["whole_public_forward_ad"]+=1;counts["whole_public_nested_source_blocks"]+=28;counts["whole_public_finite_norms"]+=1
                check(controls,"whole_public_false_primal",float((primal[0][:,0]-torch.stack(fb[1:])[:,0]).abs().max()),float(np.max(abs(cpu(primal[1])-sf))),boundary=depth)
                check(controls,"whole_public_reset_trajectory",float((tangent[0][depth:,0,pos:]-outputs[depth][0][:,0,pos:]).abs().max()),
                    float(np.max(abs(cpu(tangent[1])-arrays[f"reset_{depth}_original_scores"]))),boundary=depth)
                check(controls,"whole_public_exact_source",float((sources[:,0]-known).abs().max()),boundary=depth)
                del primal,tangent,sources
        assert len(local)==66 and len(reverse)==192 and all(r["passed"] for r in controls+local+reverse)
        save(RUN/"pairs"/path.name,arrays,dict(group=meta["group"],position=pos,design_fingerprint=bundle["fingerprint"],
            parent_forecast_sha256=sha(path),parent_observation_sha256=sha(op),parent215_sha256=sha(pp),
            controls=controls,local_checks=local,reverse_checks=reverse))
        status.update(completed_pairs=status["completed_pairs"]+1,counts=dict(counts),updated_utc=now())
        write_json(RUN/"status.json",status);gc.collect();print(f"217 resets {status['completed_pairs']}/64",flush=True)
    status.update(status="complete",qualified=True,original_wholeblock_jacobian_qualified=False,completed_utc=now())
    write_json(RUN/"status.json",status)


def main():
    assert not RUN.exists()
    assert json.loads((ROOT/"docs/analysis/215-matched-incoming-control.json").read_text())["qualified"]
    RUN.mkdir(parents=True)
    design=dict(experiment=217,depths=list(DEPTHS),cases=64,retrospective_oracle=True,
        source_hashes={p:sha(ROOT/p) for p in FILES},parent215_result_sha256=sha(ROOT/"docs/analysis/215-matched-incoming-control.json"),
        parent216_audit_sha256=sha(ROOT/"docs/analysis/216-vector-readout-cross-audit.json"),
        fixed_sign_guard=.02,whole_minimum_panels=3,registered_utc=now())
    bundle=dict(design=design,fingerprint=digest(design));write_json(RUN/"design.json",bundle)
    status=dict(status="running",qualified=False,completed_pairs=0,started_utc=now());write_json(RUN/"status.json",status)
    try:execute(bundle,status,defaultdict(int))
    except Exception as error:
        status.update(status="technical_failure",error=repr(error),failed_utc=now());write_json(RUN/"status.json",status);raise


if __name__=="__main__":main()
