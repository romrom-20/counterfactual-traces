# 219: signed neuron mixed terms and direct product interventions

Registered before any 219 model execution or neuron-level numerical analysis. Preserve 218 and the complete 2,089-file closure unchanged. No browser, literature search, training, end-to-end correction sweep, publication or Git mutation.

## Question and scope

Does a compact, stable set of block-28 neuron products carry the native/forecast mixed-correction contrast, or is the contrast distributed and cancellation dependent? Which gate/up changes contribute to its sign? All 64 existing 208/215/218 contexts remain retrospective. The primary setting is 218 finite SiLU, finite MLP-input RMSNorm and four False-affine attention primitives. It is not a fully native-attention computation. Absolute activation sign regimes are not learned features.

For each context at the verdict position, define the fixed False-final readout gradient g, downstream projection weights v_i=(W_down[:,i] dot g), and actual finite-SiLU parent increments dPhi_N,dU_N,dPhi_P,dU_P relative to the same False anchors. Save every signed contribution a_ab,i=v_i*dPhi_a,i*dU_b,i for a,b in {N,P}. Receiving-position vector effects also retain every receiving row; only the verdict row enters the final token's head.

The native-minus-forecast contrast t_i=a_NN,i-a_PP,i has the exact symmetric decomposition

    gate_i=.5*v_i*(dPhi_N-dPhi_P)*(dU_N+dU_P)
    up_i  =.5*v_i*(dPhi_N+dPhi_P)*(dU_N-dU_P).

This is conditional algebraic accounting, not a unique causal fraction. Report positive/negative/absolute totals, net totals, cancellation, per-case top-|t| concentration and fixed-mask concentration. Never infer concentration from a large fraction of a nearly cancelled signed net.

## Frozen selection and matched controls

Use chalice and gimbal (32 old contexts) for selection. Rank neurons by mean absolute t_i across those contexts, ties by neuron index. Freeze one ordering and nested k={8,32,128,512} masks. The other two old families, larch and marzipan, are excluded from mask selection, then analyzed with the frozen masks. This is retrospective family separation, not fresh unseen-context validation or independent replication.

Random controls use a single deterministic permutation (seed 219) from the complement of the selected top-512 neurons, with matched cardinality for each k. Also apply the same random control scaled to match the selected edit's L2 norm in RECEIVING PRODUCT COORDINATES, separately for each context. Save scale and both norms; do not claim residual/readout norm matching. Freeze selection.json before any product-intervention evaluation. Native observations used for selection are explicitly oracle inputs.

## Direct causal intervention

Recompute False/native/forecast full-sequence block-28 computations and replay every used 218 finite-SiLU product-affine and finite-product endpoint/operand. Capture actual product, mid-residual and down-projection outputs. Every affine primitive JVP used in these reconstructions is checked against its actual local first AD derivative with the unchanged 1e-4 bound. Independently recompute each False readout gradient using public first reverse; verify against both saved 218 gradient and closed-form gradient. Original whole-block Jacobian coordinate qualification remains false.

At each incoming background B in {N,P}, start from its actual finite-product input p_B to the public down projection. For every gate/up cross ab, directly replace receiving product coordinates by

    p_B + [dPhi_a*dU_b - dPhi_B*dU_B],

with source/prefix edits exactly zero. This holds B's other terms fixed; cross products are synthetic primitive interventions, not native counterfactual trajectories. For each selected/random/norm-matched-random mask, replace only its coordinates of the opposite-minus-own mixed product. Execute the public down projection and final residual addition, and evaluate the actual finite head. Cross BB is the sham, and cross opposite-opposite is the all-neuron benchmark. Save actual product operands and final suffix states/scores, not just scalar projections.

For fixed-readout comparisons, subtract B's product-affine output, keep receiving rows only, and transplant that correction into the SAME False-final state before executing the finite head. Natural head outcomes are also retained. Projection scores are diagnostics; actual finite changes remain primary behavioral measurements.

Independently replay the direct product edits inside the full public block using down-input hooks for each B: sham, opposite-opposite all-neuron cross, and selected k=128 (six full-block replays per context). Inputs, all earlier primitives and donor edits must match; coordinates <=1e-4, scores <=.005. Zero source/prefix edits and unchanged prefix/source output controls are required. CPU64 accounting separates ideal mixed displacement, product-cast rounding, down-projection rounding and residual-addition rounding. Raw mixed-vector equality failures remain recorded rather than being relabeled as passes.

## Counts and numerical gates

Per context: five reconstruction blocks (False FF, N/P FL and FF), six full-block intervention replays, 32 actual public down-projection interventions (four cross combinations and 12 masked edits for each background), 64 direct finite heads plus five reconstruction heads, six replay heads and one False head = 76 finite heads, one first-reverse head gradient. Expected all-context totals: 704 blocks, 2,048 down-only interventions, 4,864 finite heads, 64 reverse head gradients, and 2,944 local derivative checks. Counts exclude model loading and CPU64 algebra. All nonfinite values fail. Original coordinate and score bounds remain 1e-4 and .005; gradient contractions retain .001+.0001*abs(reverse). CPU64 algebra tolerances are 1e-9 for scalar accounting and 1e-9 for measured arithmetic closure. No accuracy tolerance is changed.

## Predefined compact-account gate, not an inferential significance test

Only k<=128 can trigger a compact-account follow-up. Require, on the 32 mask-excluded old contexts: (1) median selected |t| mass >=50% of total |t|; (2) in BOTH swap directions, at least80% of originally opposite-sign cases with both all-neuron/sham common effects exceeding .02 nats attain the all-neuron donor-effect sign, and (3) selected edits approach the all-neuron finite common effect more closely than BOTH cardinality- and product-norm-matched random controls in at least75% of cases in EACH schema/order stratum. Report denominators, every k, failures and all individual cases. No eligible sign cases means that part of the gate fails, rather than vacuously passes. This gate is a conservative action rule, not a publication/novelty criterion or probability estimate.

A passing account permits formulating a separately registered False-state-only upstream hypothesis. It does not itself predict unknown native gate/up increments. No fresh run or end-to-end repair is launched by 219. If the gate fails, report the distributed/unstable result and identify what remains unexplained before proposing a new predictor.

Sources, auditor and protocol are copied and hash-sealed before execution. Scientific files become immutable once executed. Any necessary correction is separately named, registered and preserves the failure. Saved-array audit independently reconstructs neuron accounting, selection, edit operands, arithmetic closure and finite-head scores from preserved arrays/weights.
