"""Independent saved-array accounting, product-edit checks and compact-account gate."""

import hashlib
import json
from collections import Counter
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / "runs/neuron-mixed-interventions-219"
OUT = ROOT / "docs/analysis/219-neuron-mixed-interventions.json"
KS = (8, 32, 128, 512)


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def margin(s):
    return float(s[1] - s[0])


def head(x, weights):
    h = x[-1].astype(np.float64)
    return (h / np.sqrt(np.mean(h*h) + float(weights["eps"])) * weights["norm"]) @ weights["head"].T


def main():
    assert not OUT.exists()
    design = json.loads((RUN / "design.json").read_text())
    assert all(sha(ROOT/p) == h for p,h in design["source_hashes"].items())
    status = json.loads((RUN / "status.json").read_text())
    assert status["status"] == "complete" and status["qualified"] and status["counts"] == design["expected"]
    masks = json.loads((RUN / "selection.json").read_text()); seal = json.loads((RUN / "selection-seal.json").read_text())
    assert sha(RUN / "selection.json") == seal["sha256"] and seal["excluded_contexts"] == 32
    controls=[]; local=[]; rows=[]; neurons=[]; contrasts=[]; discovery=[]; maxclosure=0.; maxhead=0.; maxscalar=0.
    weights = dict(np.load(RUN / "weights.npz")); down=weights["down"].astype(np.float64)
    for path in sorted((RUN / "captures").glob("*.npz")):
        record=json.loads(path.with_suffix(".json").read_text()); assert sha(path)==record["arrays_sha256"]
        for folder,key in (("silu-range-falsification-218/pairs","parent218_sha256"),("matched-incoming-control-215/pairs","parent215_sha256"),("source-receiver-partition-208/forecasts","parent208_sha256")):
            assert sha(ROOT/"runs"/folder/path.name)==record[key]
        controls.extend(record["checks"]);local.extend(record["local_checks"])
        z=dict(np.load(path)); assert all(np.isfinite(v).all() for v in z.values())
        with np.load(ROOT/"runs/silu-range-falsification-218/pairs"/path.name) as old:
            for b,branch in (("N","native"),("P","predicted")):
                for arm in ("FL","FF"):
                    assert np.max(abs(z[b+"_"+arm+"_state"]-old[branch+"_"+arm+"_state"]))<=1e-4
                    assert np.max(abs(z[b+"_"+arm+"_scores"]-old[branch+"_"+arm+"_scores"]))<=.005
                for operand in ("phi","up"):
                    assert np.max(abs(z[b+"_"+operand]-old[branch+"_FF_"+operand]))<=1e-4
        v=down.T@z["gradient"]
        assert np.max(abs(v-z["projection_weights"]))<=1e-9
        dp={b:z[b+"_phi"]-z["phi0"] for b in ("N","P")};du={b:z[b+"_up"]-z["up0"] for b in ("N","P")}
        mixed={ab:dp[ab[0]]*du[ab[1]] for ab in ("NN","NP","PN","PP")}
        a={ab:v*m[-1] for ab,m in mixed.items()}
        assert all(np.max(abs(a[ab]-z["a_"+ab]))<=1e-9 for ab in a)
        t=a["NN"]-a["PP"];g=.5*v*(dp["N"][-1]-dp["P"][-1])*(du["N"][-1]+du["P"][-1]);u=.5*v*(dp["N"][-1]+dp["P"][-1])*(du["N"][-1]-du["P"][-1])
        assert np.max(abs(t-g-u))<=1e-9 and np.max(abs(g-z["gate_contrast"]))<=1e-9 and np.max(abs(u-z["up_contrast"]))<=1e-9
        contrasts.append(t)
        if record["group"]["block"] in ("chalice","gimbal"):discovery.append(t)
        order=np.lexsort((np.arange(len(t)),-np.abs(t)));absolute=float(np.abs(t).sum())
        con=dict(net=float(t.sum()),positive=float(t[t>0].sum()),negative=float(t[t<0].sum()),absolute=absolute,
            cancellation_ratio=abs(float(t.sum()))/absolute,neurons_for_90pct_absolute=int(np.searchsorted(np.cumsum(abs(t[order])),.9*absolute)+1),
            fixed={str(k):dict(absolute_fraction=float(abs(t[np.array(masks["ranking"][:k])]).sum()/absolute),signed_sum=float(t[np.array(masks["ranking"][:k])].sum()),
                oracle_absolute_fraction=float(abs(t[order[:k]]).sum()/absolute)) for k in KS})
        ip=RUN/"interventions"/path.name;ir=json.loads(ip.with_suffix(".json").read_text())
        assert sha(ip)==ir["arrays_sha256"] and ir["capture_sha256"]==record["arrays_sha256"] and ir["selection_sha256"]==seal["sha256"]
        controls.extend(ir["checks"]);local.extend(ir["local_checks"])
        iz=dict(np.load(ip)); assert all(np.isfinite(v).all() for v in iz.values()) and len(ir["rows"])==32
        for r in ir["rows"]:
            b,label=r["background"],r["label"];own=b*2;other=("P" if b=="N" else "N")*2
            if r["kind"]=="cross":delta=(mixed[r["cross"]]-mixed[own]).copy()
            else:
                difference=mixed[other]-mixed[own];delta=np.zeros_like(difference)
                ids=masks["ranking"][:r["k"]] if r["kind"]=="selected" else masks["random_ranking"][:r["k"]]
                delta[:,ids]=difference[:,ids];delta*=r["scale"]
            delta[0]=0;key=b+"_"+label
            product=iz[key+"_product"].astype(np.float64);out=iz[key+"_state"].astype(np.float64);dout=iz[key+"_down"].astype(np.float64)
            expected=(z[b+"_product"]+delta).astype(np.float32)
            assert np.max(abs(expected-product))<=1e-4
            if r["kind"]=="norm_random":assert abs(np.linalg.norm(delta)-r["target_product_l2"])<=1e-9
            assert np.max(abs(product[0]-z[b+"_product"][0]))==0
            actual=out-z[b+"_FF_state"]
            ideal=delta@down.T
            product_round=(product-z[b+"_product"]-delta)@down.T
            down_round=(dout-product@down.T)-(z[b+"_down"]-z[b+"_product"]@down.T)
            residual_round=(out-z[b+"_mid"]-dout)-(z[b+"_FF_state"]-z[b+"_mid"]-z[b+"_down"])
            closure=float(np.max(abs(actual-ideal-product_round-down_round-residual_round)));maxclosure=max(maxclosure,closure);assert closure<=1e-9
            correction=out-z[b+"_FL_state"];correction[0]=0
            common=(z["false_final"].astype(np.float64)+correction).astype(np.float32)
            assert np.max(abs(common-iz[key+"_common_state"]))==0
            scalar=float(correction[-1]@z["gradient"]);maxscalar=max(maxscalar,abs(scalar-r["projection"]));assert abs(scalar-r["projection"])<=1e-9
            natural=margin(iz[key+"_scores"]);effect=margin(iz[key+"_common_scores"])-margin(z["false_scores"])
            assert abs(natural-r["natural_margin"])<=1e-12 and abs(effect-r["common_margin_change"])<=1e-12
            for state,scores in ((out,iz[key+"_scores"]),(common,iz[key+"_common_scores"])):
                error=float(np.max(abs(head(state,weights)-scores)));maxhead=max(maxhead,error);assert error<=.005
            if r["replay"]:
                assert np.max(abs(out-iz[key+"_replay_state"]))<=1e-4 and np.max(abs(iz[key+"_scores"]-iz[key+"_replay_scores"]))<=.005
            if label=="cross_"+own:
                assert np.max(abs(out-z[b+"_FF_state"]))<=1e-4
            r.update(key=record["key"],group=record["group"],held_out_of_selection=record["group"]["block"] in ("larch","marzipan"))
            rows.append(r)
        neurons.append(dict(key=record["key"],group=record["group"],held_out_of_selection=record["group"]["block"] in ("larch","marzipan"),
            concentration=con,cross_projections={ab:float(a[ab].sum()) for ab in a},gate_contrast=float(g.sum()),up_contrast=float(u.sum())))
    assert len(neurons)==64 and len(rows)==2048 and len(local)==2944 and sum(r["replay"] for r in rows)==384
    assert all(c["error"]<=c["bound"] for c in controls) and all(c["passed"] for c in local)
    expected_scores=np.mean(abs(np.array(discovery)),axis=0);expected_order=np.lexsort((np.arange(len(expected_scores)),-expected_scores))
    assert np.max(abs(expected_scores-masks["scores"]))<=1e-9 and expected_order.tolist()==masks["ranking"]
    pool=np.setdiff1d(np.arange(len(expected_order)),expected_order[:512]);assert np.random.default_rng(219).permutation(pool).tolist()==masks["random_ranking"]
    gates=[];summary=[]
    for subset in ("all","selection","excluded"):
        ns=[r for r in neurons if subset=="all" or r["held_out_of_selection"]==(subset=="excluded")]
        for k in KS:
            summary.append(dict(subset=subset,k=k,count=len(ns),median_fixed_absolute_fraction=float(np.median([n["concentration"]["fixed"][str(k)]["absolute_fraction"] for n in ns])),
                median_oracle_absolute_fraction=float(np.median([n["concentration"]["fixed"][str(k)]["oracle_absolute_fraction"] for n in ns])),
                median_neurons_for_90pct_absolute=float(np.median([n["concentration"]["neurons_for_90pct_absolute"] for n in ns])),
                median_gate_contrast=float(np.median([n["gate_contrast"] for n in ns])),median_up_contrast=float(np.median([n["up_contrast"] for n in ns])),
                median_net_contrast=float(np.median([n["concentration"]["net"] for n in ns])),median_net_over_absolute=float(np.median([n["concentration"]["cancellation_ratio"] for n in ns]))))
    for k in KS:
        held=[r for r in rows if r["held_out_of_selection"]];directions=[];strata=[]
        for b in ("N","P"):
            allcases=sorted({r["key"] for r in held});eligible=0;signs=0
            for key in allcases:
                rr={r["label"]:r for r in held if r["background"]==b and r["key"]==key}
                own=rr["cross_"+b*2]["common_margin_change"];other=rr["cross_"+("P" if b=="N" else "N")*2]["common_margin_change"]
                if abs(own)>.02 and abs(other)>.02 and np.sign(own)!=np.sign(other):
                    eligible+=1;signs+=np.sign(rr[f"selected_{k}"]["common_margin_change"])==np.sign(other)
            directions.append(dict(background=b,eligible=eligible,donor_sign_attained=int(signs),passed=bool(eligible and signs/eligible>=.8)))
            for schema in ("generic","descriptive"):
                for order in (0,1):
                    cases=[key for key in allcases if next(r for r in held if r["key"]==key)["group"]["schema"]==schema and next(r for r in held if r["key"]==key)["group"]["reverse"]==order]
                    wins=0
                    for key in cases:
                        rr={r["label"]:r for r in held if r["background"]==b and r["key"]==key}
                        target=rr["cross_"+("P" if b=="N" else "N")*2]["common_margin_change"]
                        selected_error=abs(rr[f"selected_{k}"]["common_margin_change"]-target)
                        wins+=all(selected_error<abs(rr[f"{control}_{k}"]["common_margin_change"]-target) for control in ("random","norm_random"))
                    strata.append(dict(background=b,schema=schema,order=order,count=len(cases),wins=int(wins),passed=bool(cases and wins/len(cases)>=.75)))
        mass=next(r["median_fixed_absolute_fraction"] for r in summary if r["subset"]=="excluded" and r["k"]==k)
        gates.append(dict(k=k,compact_eligible=k<=128,median_excluded_absolute_mass=mass,mass_pass=mass>=.5,directions=directions,strata=strata,
            passed=bool(k<=128 and mass>=.5 and all(r["passed"] for r in directions+strata))))
    neuron_summary=[];ts=np.array(contrasts)
    for i in masks["ranking"][:32]:
        neuron_summary.append(dict(index=i,mean_absolute_contrast=float(np.mean(abs(ts[:,i]))),positive_contexts=int((ts[:,i]>0).sum()),negative_contexts=int((ts[:,i]<0).sum())))
    result=dict(qualified=True,contexts=64,interventions=2048,counts=status["counts"],controls=len(controls),local_derivative_checks=len(local),
        maximum_local_derivative_error=max(c["coordinate_error"] for c in local),maximum_saved_rounding_closure=maxclosure,
        maximum_cpu64_finite_head_error=maxhead,maximum_saved_scalar_error=maxscalar,
        raw_ideal_vector_failures=sum(r["raw_ideal_vector_error"]>1e-4 for r in rows),
        maximum_raw_ideal_vector_error=max(r["raw_ideal_vector_error"] for r in rows),
        selection_sha256=seal["sha256"],summaries=summary,compact_gates=gates,top_neurons=neuron_summary,neurons=neurons,rows=rows,
        original_wholeblock_jacobian_qualified=False,prospective=False,
        scope="Retrospective fixed-readout neuron products and direct product edits in an attention-affine finite-SiLU finite-RMS surrogate. Masks selected using native observations in two old families; not learned features or fresh predictions.",
        auditor_sha256=sha(Path(__file__)),weights_sha256=sha(RUN/"weights.npz"))
    OUT.write_text(json.dumps(result,indent=2,default=lambda x:x.item() if isinstance(x,np.generic) else str(x))+"\n")
    print(json.dumps({k:v for k,v in result.items() if k not in ("neurons","rows")},indent=2))


if __name__=="__main__":
    main()
