"""Frozen algebra and masks for retrospective neuron-product interventions."""

import numpy as np

KS = (8, 32, 128, 512)
DISCOVERY = ("chalice", "gimbal")
CROSSES = ("NN", "NP", "PN", "PP")


def accounting(phi, up, phi0, up0, weight):
    dp = {b: phi[b].astype(np.float64) - phi0 for b in ("N", "P")}
    du = {b: up[b].astype(np.float64) - up0 for b in ("N", "P")}
    mixed = {ab: dp[ab[0]] * du[ab[1]] for ab in CROSSES}
    signed = {ab: weight * mixed[ab][-1] for ab in CROSSES}
    gate = .5 * weight * (dp["N"][-1] - dp["P"][-1]) * (du["N"][-1] + du["P"][-1])
    up_effect = .5 * weight * (dp["N"][-1] + dp["P"][-1]) * (du["N"][-1] - du["P"][-1])
    return mixed, signed, gate, up_effect


def ranked(values):
    return np.lexsort((np.arange(len(values)), -np.abs(values)))


def selection(records, arrays):
    chosen = [arrays[r["key"]]["contrast"] for r in records if r["group"]["block"] in DISCOVERY]
    assert len(chosen) == 32
    scores = np.mean(np.abs(chosen), axis=0)
    order = ranked(scores)
    pool = np.setdiff1d(np.arange(len(order)), order[:512])
    random = np.random.default_rng(219).permutation(pool)
    return dict(discovery_families=list(DISCOVERY), excluded_families=["larch", "marzipan"],
                ranking=order.tolist(), scores=scores.tolist(), random_ranking=random.tolist(), ks=list(KS))


def edits(mixed, background, masks):
    own, other = background * 2, ("P" if background == "N" else "N") * 2
    result = []
    for ab in CROSSES:
        delta = (mixed[ab] - mixed[own]).copy()
        delta[0] = 0
        result.append(("cross_" + ab, delta, dict(kind="cross", cross=ab, scale=1.)))
    difference = mixed[other] - mixed[own]
    difference = difference.copy(); difference[0] = 0
    for k in KS:
        selected = np.zeros_like(difference); selected[:, masks["ranking"][:k]] = difference[:, masks["ranking"][:k]]
        random = np.zeros_like(difference); random[:, masks["random_ranking"][:k]] = difference[:, masks["random_ranking"][:k]]
        target_norm, random_norm = float(np.linalg.norm(selected)), float(np.linalg.norm(random))
        assert random_norm > 0
        scale = target_norm / random_norm
        for kind, delta, alpha in (("selected", selected, 1.), ("random", random, 1.), ("norm_random", random * scale, scale)):
            result.append((f"{kind}_{k}", delta, dict(kind=kind, k=k, scale=alpha,
                target_product_l2=target_norm, random_product_l2=random_norm, actual_product_l2=float(np.linalg.norm(delta)))))
    assert len(result) == 16 and all(np.count_nonzero(d[0]) == 0 for _, d, _ in result)
    return result


def concentration(t, mask):
    mass = float(np.abs(t).sum())
    order = ranked(t)
    return dict(net=float(t.sum()), positive=float(t[t > 0].sum()), negative=float(t[t < 0].sum()),
        absolute=mass, cancellation_ratio=abs(float(t.sum())) / mass if mass else None,
        neurons_for_90pct_absolute=int(np.searchsorted(np.cumsum(np.abs(t[order])), .9 * mass) + 1) if mass else 0,
        fixed={str(k): dict(absolute_fraction=float(np.abs(t[mask[:k]]).sum()) / mass if mass else 0.,
                           signed_sum=float(t[mask[:k]].sum()),
                           oracle_absolute_fraction=float(np.abs(t[order[:k]]).sum()) / mass if mass else 0.) for k in KS})
