"""Registered retrospective capture, frozen neuron masks and direct product edits."""

import hashlib
import json
from collections import Counter
from pathlib import Path

import numpy as np
import torch
from torch.nn import functional as F

import ranked_block_response_201 as public
import primitive_diagnostic_211 as primitive
from frozen_block28_derivative_210 import trace
from gate_up_arithmetic_213 import capture
from neuron_mixed_219 import accounting, selection, edits
from latent_decisions.target import load_target
from latent_decisions.evidence_policy import digest

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / "runs/neuron-mixed-interventions-219"
P218 = ROOT / "runs/silu-range-falsification-218/pairs"
ATTENTION = ("input_rms", "qk_product", "softmax", "weight_value")


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def write(p, obj):
    p.write_text(json.dumps(obj, indent=2, default=lambda x: x.item() if isinstance(x, np.generic) else str(x)) + "\n")


def cpu(t):
    return t.detach().cpu().numpy().copy()


def main():
    assert not RUN.exists()
    previous = ROOT / "results/silu-range-falsification-218/manifest.json"
    closure = json.loads(previous.read_text())
    assert len(closure["files"]) == 2089 and all(sha(ROOT / p) == h for p, h in closure["files"].items())
    sources = ["scripts/run_neuron_mixed_219.py", "scripts/neuron_mixed_219.py", "scripts/audit_neuron_mixed_219.py",
        "docs/experiments/219-neuron-mixed-interventions.md", "scripts/primitive_diagnostic_211.py",
        "scripts/frozen_block28_derivative_210.py", "scripts/local_primitive_derivative_210c.py",
        "scripts/gate_up_arithmetic_213.py", "scripts/ranked_block_response_201.py", "src/latent_decisions/target.py"]
    rtpath = ROOT / "runs/source-receiver-partition-208/runtime.json"
    design = dict(source_hashes={p: sha(ROOT / p) for p in sources}, previous_manifest_sha256=sha(previous),
        runtime_sha256=sha(rtpath), parent218_audit_sha256=sha(ROOT / "docs/analysis/218-silu-range-falsification-audit.json"),
        expected=dict(blocks=704, direct_down=2048, finite_heads=4864, reverse_heads=64, local_checks=2944))
    RUN.mkdir(); (RUN / "captures").mkdir(); (RUN / "interventions").mkdir()
    write(RUN / "design.json", design)
    rt = json.loads(rtpath.read_text()); write(RUN / "runtime.json", rt)
    model, tokenizer, device = load_target(rt["model"], "mps", offline=True)
    torch.set_num_threads(2)
    assert digest(tokenizer.get_vocab()) == rt["tokenizer_hash"] and digest(model.config.to_dict()) == rt["config_hash"]
    assert not model.training and model.config._attn_implementation == "eager" and next(model.parameters()).dtype == torch.float32
    layer = model.model.layers[27]
    down = layer.mlp.down_proj.weight.detach().cpu().double()
    np.savez_compressed(RUN / "weights.npz", down=cpu(down),
        norm=cpu(model.model.norm.weight), head=cpu(model.lm_head.weight[[895, 830]]), eps=np.array(model.model.norm.variance_epsilon))
    counts = Counter(); records = []; neuron_arrays = {}

    def head(x):
        with torch.no_grad():
            out = public.head(model, x)
        counts["finite_heads"] += 1
        return cpu(out).astype(np.float64)

    def block(x, c, context, enabled):
        with primitive.surgeries(layer, c, context, enabled) as local, capture(layer) as cap, torch.no_grad():
            y = public.block(layer, x, context)
        assert all(r["passed"] for r in local)
        cap["output"] = y.detach().cpu().double()
        counts["blocks"] += 1; counts["local_checks"] += len(local)
        return y, cap, local

    # Capture phase: no mask-based intervention is measured before selection.json exists.
    for path in sorted(P218.glob("*.npz")):
        parent = json.loads(path.with_suffix(".json").read_text()); assert sha(path) == parent["arrays_sha256"]
        p215 = ROOT / "runs/matched-incoming-control-215/pairs" / path.name
        p208 = ROOT / "runs/source-receiver-partition-208/forecasts" / path.name
        assert sha(p215) == parent["parent215_sha256"] and sha(p208) == parent["parent208_sha256"]
        checks = []; local_checks = []
        def check(kind, error, bound=1e-4):
            checks.append(dict(kind=kind, error=float(error), bound=bound)); assert error <= bound, checks[-1]
        with np.load(path) as old, np.load(p215) as inputs, np.load(p208) as original:
            pos = int(old["position"])
            xf = torch.tensor(original["false_boundaries"][27][None], device=device)
            yf = torch.tensor(original["false_boundaries"][28][None], device=device)
            context = dict(mask=torch.tensor(original["mask"], device=device),
                rope=tuple(torch.tensor(original[k], device=device) for k in ("rope_cos", "rope_sin")))
            c = trace(layer, xf, context)
            check("false_trace", (c["output"] - yf.cpu().double()).abs().max())
            sf = head(yf); check("false_head", np.max(abs(sf - old["false_scores"])), .005)
            sham, _, local = block(xf, c, context, ATTENTION)
            local_checks.extend(local); check("false_block", (sham - yf).abs().max())
            check("false_block_head", np.max(abs(head(sham) - sf)), .005)
            rx = yf.detach().clone().requires_grad_(True)
            scores = public.head(model, rx)
            gradient = torch.autograd.grad(scores[1] - scores[0], rx)[0][0, -1].detach().cpu().double()
            counts["reverse_heads"] += 1
            check("gradient_saved218", np.max(abs(cpu(gradient) - old["closed_gradient"])))
            h = yf[0, -1].detach().cpu().double()
            w = (model.lm_head.weight[830].detach().cpu().double() - model.lm_head.weight[895].detach().cpu().double()) * model.model.norm.weight.detach().cpu().double()
            inv = torch.rsqrt(h.square().mean() + model.model.norm.variance_epsilon)
            closed = w * inv - h * inv.pow(3) * (w * h).mean()
            check("gradient_closed", (gradient - closed).abs().max())
            weights = down.T @ closed
            arrays = dict(position=np.array(pos), phi0=cpu(c["silu"][0, pos:]), up0=cpu(c["up"][0, pos:]),
                projection_weights=cpu(weights), gradient=cpu(closed), reverse_gradient=cpu(gradient),
                false_final=old["false_final"].copy(), true_final=old["true_final"].copy(),
                false_scores=sf, true_scores=old["true_scores"].copy())
            phi = {}; up = {}
            for b, branch in (("N", "native"), ("P", "predicted")):
                x = xf.clone(); x[:, pos:] = torch.tensor(inputs[branch + "_input"][None], device=device)
                for arm in ("FL", "FF"):
                    y, cap, lc = block(x, c, context, (*ATTENTION, *(("gate_up",) if arm == "FL" else ())))
                    local_checks.extend(lc); ss = head(y)
                    check("218_endpoint", np.max(abs(cpu(y[0, pos:]) - old[branch + "_" + arm + "_state"])))
                    check("218_score", np.max(abs(ss - old[branch + "_" + arm + "_scores"])), .005)
                    arrays[b + "_" + arm + "_state"] = cpu(y[0, pos:])
                    arrays[b + "_" + arm + "_scores"] = ss
                    if arm == "FF":
                        for name in ("product", "mid", "down", "phi", "up"):
                            arrays[b + "_" + name] = cpu(cap[name][0, pos:])
                        for name in ("phi", "up"):
                            check("218_operand", np.max(abs(arrays[b + "_" + name] - old[branch + "_FF_" + name])))
                        phi[b], up[b] = arrays[b + "_phi"], arrays[b + "_up"]
            mixed, signed, gate, up_effect = accounting(phi, up, arrays["phi0"], arrays["up0"], arrays["projection_weights"])
            arrays.update({"a_" + ab: v for ab, v in signed.items()})
            arrays.update(gate_contrast=gate, up_contrast=up_effect, contrast=signed["NN"] - signed["PP"])
            check("symmetric_contrast", np.max(abs(arrays["contrast"] - gate - up_effect)), 1e-9)
            for ab in signed:
                vector = F.linear(torch.tensor(mixed[ab][-1]), down)
                check("signed_sum_projection", abs(float(vector @ closed) - signed[ab].sum()), 1e-9)
            out = RUN / "captures" / path.name
            np.savez_compressed(out, **arrays)
            record = dict(key=path.stem, group=parent["group"], parent218_sha256=sha(path), parent215_sha256=sha(p215), parent208_sha256=sha(p208),
                arrays_sha256=sha(out), checks=checks, local_checks=local_checks)
            write(out.with_suffix(".json"), record); records.append(record); neuron_arrays[path.stem] = dict(contrast=arrays["contrast"])
        write(RUN / "status.json", dict(status="capturing", completed=len(records), counts=dict(counts)))
        print("capture", len(records), path.stem, flush=True)
    assert len(records) == 64
    masks = selection(records, neuron_arrays); write(RUN / "selection.json", masks)
    selection_hash = sha(RUN / "selection.json")
    write(RUN / "selection-seal.json", dict(sha256=selection_hash, phase="Before any direct neuron-product intervention", excluded_contexts=32))
    # Interventions: each edit enters the actual public down projection on the full sequence.
    for record in records:
        name = record["key"] + ".npz"
        with np.load(RUN / "captures" / name) as saved, np.load(ROOT / "runs/matched-incoming-control-215/pairs" / name) as inputs, np.load(ROOT / "runs/source-receiver-partition-208/forecasts" / name) as original:
            z = {k: saved[k].copy() for k in saved.files}; pos = int(z["position"])
            xf = torch.tensor(original["false_boundaries"][27][None], device=device)
            yf = torch.tensor(original["false_boundaries"][28][None], device=device)
            context = dict(mask=torch.tensor(original["mask"], device=device), rope=tuple(torch.tensor(original[k], device=device) for k in ("rope_cos", "rope_sin")))
            c = trace(layer, xf, context)
            mixed, _, _, _ = accounting({b:z[b+"_phi"] for b in ("N", "P")}, {b:z[b+"_up"] for b in ("N", "P")}, z["phi0"], z["up0"], z["projection_weights"])
            output_arrays = {}; rows = []; checks = []; local_checks = []
            def check(kind, error, bound=1e-4):
                checks.append(dict(kind=kind, error=float(error), bound=bound)); assert error <= bound, checks[-1]
            for b, branch in (("N", "native"), ("P", "predicted")):
                x = xf.clone(); x[:, pos:] = torch.tensor(inputs[branch + "_input"][None], device=device)
                # False prefix is unchanged, so construct the captured full product/mid from False and saved suffix.
                base_product = c["gate_up"].clone(); base_product[:, pos:] = torch.tensor(z[b + "_product"])
                mid = c["mid"].clone(); mid[:, pos:] = torch.tensor(z[b + "_mid"])
                mid_gpu = mid.to(device=device, dtype=torch.float32)
                baseline_output = z[b + "_FF_state"].astype(np.float64)
                baseline_down = z[b + "_down"].astype(np.float64)
                baseline_product = z[b + "_product"].astype(np.float64)
                base_projected = F.linear(torch.tensor(baseline_product), down).numpy()
                for label, delta, meta in edits(mixed, b, masks):
                    key = b + "_" + label
                    actual_product = base_product.clone(); actual_product[:, pos:] += torch.tensor(delta)
                    actual_product = actual_product.to(device=device, dtype=torch.float32)
                    with torch.no_grad():
                        actual_down = layer.mlp.down_proj(actual_product)
                        out = mid_gpu + actual_down
                    counts["direct_down"] += 1
                    ss = head(out)
                    suffix = cpu(out[0, pos:]); product_cpu = cpu(actual_product[0, pos:]); down_cpu = cpu(actual_down[0, pos:])
                    d = suffix.astype(np.float64) - z[b + "_FL_state"].astype(np.float64); d[0] = 0
                    common = yf.clone(); common[:, pos:] = torch.tensor(z["false_final"].astype(np.float64) + d, device=device, dtype=torch.float32)
                    cs = head(common)
                    check("unchanged_prefix_source", (out[:, :pos+1] - torch.tensor(np.concatenate((cpu(c["output"])[0, :pos], baseline_output[:1]), axis=0)[None], device=device, dtype=torch.float32)).abs().max())
                    check("edit_source_zero", np.max(abs(delta[0])), 0.)
                    actual_delta = product_cpu.astype(np.float64) - baseline_product
                    ideal = F.linear(torch.tensor(delta), down).numpy()
                    product_round = F.linear(torch.tensor(actual_delta - delta), down).numpy()
                    down_round = F.linear(torch.tensor(product_cpu.astype(np.float64)), down).numpy()
                    down_round = (down_cpu.astype(np.float64) - down_round) - (baseline_down - base_projected)
                    residual_round = (suffix.astype(np.float64) - z[b+"_mid"] - down_cpu) - (baseline_output - z[b+"_mid"] - baseline_down)
                    raw_error = float(np.max(abs(suffix - baseline_output - ideal)))
                    closure = float(np.max(abs(suffix - baseline_output - ideal - product_round - down_round - residual_round)))
                    check("measured_rounding_closure", closure, 1e-9)
                    check("norm_matching", abs(meta["actual_product_l2"] - meta["target_product_l2"]), 1e-9) if meta["kind"] == "norm_random" else None
                    contraction = float(d[-1] @ z["reverse_gradient"])
                    projection = float(d[-1] @ z["gradient"])
                    check("gradient_contraction", abs(contraction - projection), .001 + .0001 * abs(contraction))
                    if label == "cross_" + b * 2:
                        check("own_cross_sham", np.max(abs(suffix - z[b+"_FF_state"])))
                        check("own_cross_score", np.max(abs(ss - z[b+"_FF_scores"])), .005)
                    replay = label in ("cross_" + b * 2, "cross_" + ("P" if b == "N" else "N") * 2, "selected_128")
                    if replay:
                        def replace(module, args):
                            check("public_original_product", (args[0] - base_product.to(device=device, dtype=torch.float32)).abs().max())
                            return (actual_product,)
                        with primitive.surgeries(layer, c, context, ATTENTION) as lc, torch.no_grad():
                            hook = layer.mlp.down_proj.register_forward_pre_hook(replace)
                            try: actual = public.block(layer, x, context)
                            finally: hook.remove()
                        assert all(r["passed"] for r in lc)
                        local_checks.extend(lc); counts["local_checks"] += len(lc); counts["blocks"] += 1
                        hs = head(actual)
                        check("whole_block_replay", (actual - out).abs().max())
                        check("whole_head_replay", np.max(abs(hs - ss)), .005)
                        output_arrays[key+"_replay_state"] = cpu(actual[0, pos:]); output_arrays[key+"_replay_scores"] = hs
                    for field, value in (("state", suffix), ("scores", ss), ("product", product_cpu), ("down", down_cpu), ("common_state", cpu(common[0,pos:])), ("common_scores", cs)):
                        output_arrays[key+"_"+field] = value
                    rows.append(dict(background=b, label=label, **meta,
                        natural_margin=float(ss[1]-ss[0]), common_margin_change=float(cs[1]-cs[0]-z["false_scores"][1]+z["false_scores"][0]),
                        projection=projection, raw_ideal_vector_error=raw_error, rounding_closure=closure, replay=replay))
            dest = RUN / "interventions" / name; np.savez_compressed(dest, **output_arrays)
            write(dest.with_suffix(".json"), dict(key=record["key"], group=record["group"], capture_sha256=record["arrays_sha256"], selection_sha256=selection_hash,
                arrays_sha256=sha(dest), rows=rows, checks=checks, local_checks=local_checks))
        write(RUN / "status.json", dict(status="intervening", completed=records.index(record)+1, counts=dict(counts)))
        print("intervene", records.index(record)+1, record["key"], flush=True)
    assert dict(counts) == design["expected"], (dict(counts), design["expected"])
    assert all(sha(ROOT / p) == h for p, h in design["source_hashes"].items()) and sha(RUN / "selection.json") == selection_hash
    write(RUN / "status.json", dict(status="complete", qualified=True, counts=dict(counts), original_wholeblock_jacobian_qualified=False))


if __name__ == "__main__":
    main()
