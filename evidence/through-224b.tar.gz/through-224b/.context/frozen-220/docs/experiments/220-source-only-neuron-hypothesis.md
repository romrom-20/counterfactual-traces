# 220: prospective source-only hypothesis for the selected neuron response

Freeze this hypothesis, the original 219 top-32 neuron mask, all sources and the auditor before model execution. Preserve the qualified 219/218 evidence and original whole-block derivative caveat. No correction sweep, learning, browser, literature search, publication or Git mutation.

## Hypothesis

219/219b found a stable causal mixed-product group and a strongly reduced positive contribution at neuron 6411 under the executed receiver forecast. The new hypothesis is that the receiver forecast suppresses a direct Boolean-source response along those gate/up projections. A source-only receiving-state prediction should therefore recover the native selected-group response and the 6411 parent changes more accurately than the old predictor, with small absolute error. This is a risky quantitative claim, not an assertion established by 219.

## Fresh inputs and ordering

Use one new literal family: subjects belfry/thimble, days Wednesday/Friday, stage220. All assignment/target/order/schema combinations give 16 pairs. Before computation, compare both full token-sequence hashes against a hash-bound catalog of historical paired inputs from every existing `runs/**/forecasts/*.json`. Require all32 unique hashes to be absent. If any collide, stop and separately register a new design; do not choose after measuring outcomes. These remain dependent synthetic templates and one checkpoint, not a broad distribution test.

Run ALL 16 False observations and S/P forecasts, all False-only numerical checks, and save a hash-bound forecast manifest **before any new ordinary True model forward**. No full-finite True upper control is permitted during prediction. Only then measure all16 native True trajectories. Input treatment tokens and model weights are known; native True internal measurements are not available to the prediction phase.

## Two frozen predictions, no fitted constants

P is the executed original208 finite-source/False-first-AD-receiver rule, unchanged. Its source trajectory is computed from the changed known source token while every local finite-source call keeps receivers at False. Save every P displacement and actual receiver JVP. Verify each False primal and all27 used nonzero receiver directions with three standard first-reverse scalar projections at the original `.001+.0001*abs(reference)` bound. This does not resolve the original whole-coordinate Jacobian disagreement.

S uses the same exact known source at boundary27 but sets receiving rows to their False states. It is a False-state-only prediction, not a native receiver reset. At block28, both S and P run the SAME 219 finite-SiLU/MLP-RMS, False-affine-attention computation. Capture the selected gate/up operands and their mixed terms relative to the same False anchors.

For each prediction, add only the frozen top32 mixed terms to its actual product-affine down-input, preserving source/prefix. Execute the public down projection and residual addition. Subtract that incoming background's product-affine output, keep receiving rows, and measure the correction at the SAME False-final state through the actual finite head. This selected-group finite common-readout effect is the primary predicted response. Also save neuron6411's signed initial mixed projection and the two-dimensional vector (DeltaPhi,DeltaU). No native target is used to rescale or select a forecast.

After sealing all forecasts, construct N from native True boundary27 and evaluate exactly the same local quantities. N is a native-INCOMING, attention-affine surrogate target. It is not the complete network's native behavioral response. Genuine native final residuals/margins are saved for context only; this test cannot establish overall Question B accuracy.

## Numerical qualification

Require False reconstruction, equal prefixes, known-source/native-source agreement after measurement, sham and actual public-block product-hook replays at coordinates<=1e-4 and scores<=.005. Check each actual affine primitive with its local first AD derivative. Check False-final head gradients against public first reverse. Retain raw ideal-vector discrepancies and account separately for product-cast, down-projection and residual-addition rounding, CPU64 closure<=1e-9. An independent saved-array auditor reconstructs operands, selected products, scores, actual P update identities and all sealed hashes. Preserve all failures with separately named corrections; never alter thresholds after execution.

Expected work:16 ordinary False and16 ordinary True models;448 finite-source blocks and432 receiver JVPs for the original P;432 reverse-block forwards/1296 backwards plus432 reverse-head forwards/backwards for scalar checks;160 local surrogate/replay blocks;48 direct down interventions;272 finite heads;16 additional first-reverse group-head gradients;688 local primitive checks;1296 upstream scalar checks. Model loading and CPU64 algebra are excluded. No finite approximation is substituted for the actual final readout.

## Frozen success gate

On each of the four schema/order strata (four assignment/target cells), require >=3/4 individual passes for EACH condition below, and >=12/16 overall. Native target norms below .001 fail relative criteria rather than passing vacuously.

1. S selected-group finite common-readout prediction has absolute error <=.10 nats AND is strictly closer to N than P.
2. S neuron6411 initial signed mixed projection has absolute error <=.10 nats AND is strictly closer to N than P.
3. S neuron6411 (DeltaPhi,DeltaU) has relative L2 error <=.25 AND is strictly closer to N than P in that two-dimensional norm.

All three must pass for the source-only hypothesis to count as a successful local predictive account. Separately report whether S's positive6411 contribution exceeds P in all8 descriptive cases, all signed/magnitude errors, every case, and exact four-cell panels. A small improvement with large remaining error fails. These are new mechanism-test thresholds, not revisions of any earlier full residual/verdict accuracy bound. If rejected, do not call the native mechanism explained or start an end-to-end repair sweep.
