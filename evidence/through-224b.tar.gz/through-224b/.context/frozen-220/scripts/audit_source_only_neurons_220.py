"""Sealed-forecast, independent product arithmetic and frozen prospective gates."""

import hashlib,json
from pathlib import Path
import numpy as np

R=Path(__file__).resolve().parents[1];RUN=R/"runs/source-only-neurons-220";OUT=R/"docs/analysis/220-source-only-neuron-hypothesis.json"
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def margin(s):return float(s[1]-s[0])
def finite_head(x,w):
    h=x[-1].astype(np.float64);return h/np.sqrt(np.mean(h*h)+float(w["eps"]))*w["norm"]@w["head"].T
def main():
    assert not OUT.exists();design=json.loads((RUN/"design.json").read_text());status=json.loads((RUN/"status.json").read_text())
    assert all(sha(R/p)==h for p,h in design["source_hashes"].items())
    assert status["status"]=="complete" and status["qualified"] and status["counts"]==design["expected"]
    manifest=json.loads((RUN/"forecast-manifest.json").read_text());seal=sha(RUN/"forecast-manifest.json");start=json.loads((RUN/"observation-start.json").read_text())
    assert manifest["native_true_models_before_seal"]==0 and start["forecast_manifest_sha256"]==seal and start["started_monotonic_ns"]>manifest["sealed_monotonic_ns"]
    assert manifest["design_sha256"]==sha(RUN/"design.json")
    catalog=json.loads((RUN/"historical-catalog.json").read_text());historical={h for r in catalog["records"] for h in r["input_hashes"]}
    assert all(sha(R/r["path"])==r["sha256"] for r in catalog["records"])
    jobs=json.loads((RUN/"fresh-inputs.json").read_text());assert jobs["historical_catalog_sha256"]==sha(RUN/"historical-catalog.json")
    fresh=[];rows=[];controls=[];local=[];reverse=[];rawfail=0;maxraw=0.;maxclosure=0.;maxhead=0.;maxupdate=0.
    mask=design["mask"];weights=dict(np.load(RUN/"weights.npz"));down=weights["down"].astype(np.float64)
    for job in jobs["jobs"]:
        key=job["key"];fp=RUN/"forecasts"/(key+".npz");op=RUN/"observations"/(key+".npz");fr=json.loads(fp.with_suffix(".json").read_text());obs=json.loads(op.with_suffix(".json").read_text())
        entry=next(e for e in manifest["entries"] if e["key"]==key)
        assert sha(fp)==fr["arrays_sha256"]==entry["arrays_sha256"]==obs["forecast_sha256"] and sha(fp.with_suffix(".json"))==entry["record_sha256"]
        assert sha(op)==obs["arrays_sha256"] and obs["forecast_manifest_sha256"]==seal
        assert fr["sealed_utc"]<=manifest["sealed_utc"]<=start["started_utc"]<=obs["observed_utc"]
        controls.extend(fr["checks"]+obs["checks"]);local.extend(fr["local_checks"]+obs["local_checks"]);reverse.extend(fr["reverse_checks"])
        from latent_decisions.evidence_policy import digest
        for b in fr["bases"]:fresh.append(digest(b["free_input_ids"]))
        a,b=[z["free_input_ids"] for z in fr["bases"]];assert len(a)==len(b) and [i for i,(x,y) in enumerate(zip(a,b)) if x!=y]==[fr["position"]]
        z=dict(np.load(fp));n=dict(np.load(op));assert all(np.isfinite(v).all() for v in [*z.values(),*n.values()])
        pos=fr["position"];fb=z["false_boundaries"].astype(np.float64)
        update=z["source_finite_suffix"].astype(np.float64)-fb[1:,pos:]+z["P_receiver_jvp"].astype(np.float64)
        gap=float(np.max(abs(update-z["P_delta"])));maxupdate=max(maxupdate,gap);assert gap<=1e-4
        assert np.max(abs(z["P_receiver_jvp"][:,0]))==0 and np.max(abs(z["source_finite_suffix"][:,0]-z["known_source"]))==0
        assert np.max(abs(n["true_suffix"][:,0]-z["known_source"]))<=1e-4
        sx=fb[27,pos:].copy();sx[0]=z["known_source"][26];px=(fb[27,pos:]+z["P_delta"][26]).astype(np.float32);px[0]=z["known_source"][26]
        assert np.max(abs(sx-z["S_input"]))==0 and np.max(abs(px-z["P_input"]))==0 and np.max(abs(n["true_suffix"][26]-n["N_input"]))==0
        quantities={}
        for label,d in (("S",z),("P",z),("N",n)):
            dp=d[label+"_phi"]-z["phi0"];du=d[label+"_up"]-z["up0"]
            mixed=np.zeros_like(dp);mixed[:,mask]=dp[:,mask]*du[:,mask];mixed[0]=0
            contributions=z["projection_weights"]*dp[-1]*du[-1]
            assert np.max(abs(contributions-d[label+"_contributions"]))<=1e-9
            parents=np.array([dp[-1,6411],du[-1,6411]]);assert np.max(abs(parents-d[label+"_parents6411"]))==0
            product=d[label+"_group_product"].astype(np.float64);p0=d[label+"_product"].astype(np.float64)
            assert np.max(abs(product-(p0+mixed).astype(np.float32)))<=1e-4
            actual=d[label+"_group_state"].astype(np.float64)-d[label+"_FL_state"]
            ideal=mixed@down.T;pr=(product-p0-mixed)@down.T
            dr=(d[label+"_group_down"]-product@down.T)-(d[label+"_down"]-p0@down.T)
            rr=(d[label+"_group_state"]-d[label+"_mid"]-d[label+"_group_down"])-(d[label+"_FL_state"]-d[label+"_mid"]-d[label+"_down"])
            closure=float(np.max(abs(actual-ideal-pr-dr-rr)));maxclosure=max(maxclosure,closure);assert closure<=1e-9
            raw=float(np.max(abs(actual-ideal)));rawfail+=raw>1e-4;maxraw=max(maxraw,raw)
            assert np.max(abs(actual[0]))==0
            common=(z["false_final"].astype(np.float64)+actual).astype(np.float32)
            assert np.max(abs(common-d[label+"_common_state"]))==0
            assert np.max(abs(d[label+"_group_state"]-d[label+"_replay_state"]))<=1e-4 and np.max(abs(d[label+"_group_scores"]-d[label+"_replay_scores"]))<=.005
            for state,scores in ((common,d[label+"_common_scores"]),(d[label+"_group_state"],d[label+"_group_scores"]),(d[label+"_FL_state"],d[label+"_FL_scores"]),(d[label+"_FF_state"],d[label+"_FF_scores"])):
                e=float(np.max(abs(finite_head(state,weights)-scores)));maxhead=max(maxhead,e);assert e<=.005
            quantities[label]=dict(group_finite_effect=margin(d[label+"_common_scores"])-margin(z["false_scores"]),
                neuron6411_projection=float(contributions[6411]),parents6411=parents.tolist(),group_initial_projection=float(contributions[mask].sum()))
        errors={}
        for pred in ("S","P"):
            q=quantities[pred];target=quantities["N"];parent=np.array(q["parents6411"])-target["parents6411"];target_norm=np.linalg.norm(target["parents6411"])
            errors[pred]=dict(group_absolute=abs(q["group_finite_effect"]-target["group_finite_effect"]),neuron_absolute=abs(q["neuron6411_projection"]-target["neuron6411_projection"]),
                parents_l2=float(np.linalg.norm(parent)),parents_relative=float(np.linalg.norm(parent)/target_norm) if target_norm>=.001 else None)
        s,p=errors["S"],errors["P"]
        passes=dict(group=bool(s["group_absolute"]<=.1 and s["group_absolute"]<p["group_absolute"]),neuron=bool(s["neuron_absolute"]<=.1 and s["neuron_absolute"]<p["neuron_absolute"]),
            parents=bool(s["parents_relative"] is not None and s["parents_relative"]<=.25 and s["parents_l2"]<p["parents_l2"]))
        rows.append(dict(key=key,group=fr["group"],quantities=quantities,errors=errors,passes=passes,source_greater_than_P6411=quantities["S"]["neuron6411_projection"]>quantities["P"]["neuron6411_projection"]))
    assert len(rows)==16 and len(fresh)==32 and len(set(fresh))==32 and not set(fresh)&historical
    assert len(local)==688 and len(reverse)==1296 and all(c["error"]<=c["bound"] for c in controls) and all(c["passed"] for c in local+reverse)
    panels=[]
    for schema in ("generic","descriptive"):
        for order in (0,1):
            rr=[r for r in rows if r["group"]["schema"]==schema and r["group"]["reverse"]==order]
            assert len(rr)==4 and {(r["group"]["assignment"],r["group"]["target"]) for r in rr}==set(itertools.product(range(2),repeat=2))
            panels.append(dict(schema=schema,order=order,passes={k:sum(r["passes"][k] for r in rr) for k in ("group","neuron","parents")}))
    overall={k:sum(r["passes"][k] for r in rows) for k in ("group","neuron","parents")}
    accepted=all(overall[k]>=12 and all(p["passes"][k]>=3 for p in panels) for k in overall)
    summaries=[]
    for schema in (None,"generic","descriptive"):
        rr=[r for r in rows if schema is None or r["group"]["schema"]==schema]
        summaries.append(dict(schema=schema,count=len(rr),quantities={label:{metric:float(np.median([r["quantities"][label][metric] for r in rr])) for metric in ("group_finite_effect","neuron6411_projection")} for label in ("S","P","N")},
            errors={label:{metric:float(np.median([r["errors"][label][metric] for r in rr if r["errors"][label][metric] is not None])) for metric in ("group_absolute","neuron_absolute","parents_relative")} for label in ("S","P")}))
    result=dict(qualified=True,hypothesis_accepted=accepted,prospective=True,contexts=16,counts=status["counts"],controls=len(controls),local_derivative_checks=len(local),upstream_reverse_checks=len(reverse),
        maximum_local_derivative_error=max(c["coordinate_error"] for c in local),maximum_upstream_reverse_error=max(c["absolute_error"] for c in reverse),
        maximum_saved_update_error=maxupdate,maximum_cpu64_head_error=maxhead,maximum_rounding_closure=maxclosure,raw_ideal_failures=int(rawfail),maximum_raw_ideal_error=maxraw,
        forecast_manifest_sha256=seal,all_forecasts_sealed_before_native=True,passes=overall,panels=panels,summaries=summaries,rows=rows,
        descriptive_source_greater_than_P6411=sum(r["source_greater_than_P6411"] for r in rows if r["group"]["schema"]=="descriptive"),
        original_wholeblock_jacobian_qualified=False,full_question_B_solved=False,
        scope="Fresh test of a fixed source-only hypothesis for a selected group's response in a native-incoming attention-affine surrogate. Not full native behavioral prediction or a learned circuit.",auditor_sha256=sha(Path(__file__)))
    OUT.write_text(json.dumps(result,indent=2,default=lambda x:x.item() if isinstance(x,np.generic) else str(x))+"\n");print(json.dumps({k:v for k,v in result.items() if k!="rows"},indent=2))
if __name__=="__main__":
    import itertools
    main()
