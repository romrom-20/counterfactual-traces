"""Seal False-only source/receiver neuron forecasts before any fresh True forward."""

import hashlib,itertools,json,time,gc
from collections import Counter
from datetime import datetime,timezone
from pathlib import Path
import numpy as np
import torch
from torch.nn import functional as F
import ranked_block_response_201 as public
import source_receiver_partition_208 as partition
import block_derivative_checks_209 as derivatives
import primitive_diagnostic_211 as primitive
import run_natural_bit_shared_reader_181 as fixture
from frozen_block28_derivative_210 import trace
from gate_up_arithmetic_213 import capture
from latent_decisions.target import load_target
from latent_decisions.evidence_policy import digest

ROOT=Path(__file__).resolve().parents[1];RUN=ROOT/"runs/source-only-neurons-220"
ATTENTION=("input_rms","qk_product","softmax","weight_value")
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def cpu(t):return t.detach().cpu().numpy().copy()
def write(p,obj):p.write_text(json.dumps(obj,indent=2,default=lambda x:x.item() if isinstance(x,np.generic) else str(x))+"\n")
def stamp():return datetime.now(timezone.utc).isoformat()

def main():
    assert not RUN.exists();RUN.mkdir();(RUN/"forecasts").mkdir();(RUN/"observations").mkdir()
    files=["scripts/run_source_only_neurons_220.py","scripts/audit_source_only_neurons_220.py","docs/experiments/220-source-only-neuron-hypothesis.md",
        "scripts/source_receiver_partition_208.py","scripts/oracle_continuation_203.py","scripts/block_derivative_checks_209.py",
        "scripts/primitive_diagnostic_211.py","scripts/frozen_block28_derivative_210.py","scripts/local_primitive_derivative_210c.py",
        "scripts/gate_up_arithmetic_213.py","scripts/ranked_block_response_201.py","scripts/run_natural_bit_shared_reader_181.py",
        "scripts/audit_binding_carrier_partition_160.py","scripts/audit_counterbalanced_binding_155.py","scripts/audit_order_competence_151.py",
        "src/latent_decisions/target.py","src/latent_decisions/evidence_policy.py"]
    prior=ROOT/"results/neuron-mixed-interventions-219/manifest.json";bundle=json.loads(prior.read_text());assert all(sha(ROOT/p)==h for p,h in bundle["files"].items())
    maskpath=ROOT/"runs/neuron-mixed-interventions-219/selection.json";mask=json.loads(maskpath.read_text())["ranking"][:32]
    rtpath=ROOT/"runs/source-receiver-partition-208/runtime.json";rt=json.loads(rtpath.read_text())
    design=dict(source_hashes={p:sha(ROOT/p) for p in files},prior_manifest_sha256=sha(prior),mask_sha256=sha(maskpath),mask=mask,dominant_neuron=6411,
        runtime_sha256=sha(rtpath),created_utc=stamp(),expected=dict(ordinary_false=16,ordinary_true=16,local_finite_block=448,local_block_jvp=432,
        skipped_zero_receiver_jvp=16,reverse_block_forward=432,reverse_block_backward=1296,reverse_head_forward=432,reverse_head_backward=432,
        surrogate_blocks=160,direct_down=48,finite_heads=272,group_head_gradients=16,local_primitive_checks=688))
    write(RUN/"design.json",design);write(RUN/"runtime.json",rt)
    model,tok,device=load_target(rt["model"],"mps",offline=True);torch.set_num_threads(2)
    assert digest(tok.get_vocab())==rt["tokenizer_hash"] and digest(model.config.to_dict())==rt["config_hash"]
    assert not model.training and next(model.parameters()).dtype==torch.float32 and model.config._attn_implementation=="eager"
    layer=model.model.layers[27];down=layer.mlp.down_proj.weight.detach().cpu().double()
    np.savez_compressed(RUN/"weights.npz",down=cpu(down),norm=cpu(model.model.norm.weight),head=cpu(model.lm_head.weight[[895,830]]),eps=np.array(model.model.norm.variance_epsilon))
    historical=set();catalog=[]
    for p in sorted((ROOT/"runs").glob("**/forecasts/*.json")):
        if RUN in p.parents:continue
        obj=json.loads(p.read_text());r=obj.get("record",obj);bases=r.get("bases",[])
        if isinstance(bases,list) and len(bases)==2 and all("free_input_ids" in b for b in bases):
            hs=[digest(b["free_input_ids"]) for b in bases];historical.update(hs);catalog.append(dict(path=str(p.relative_to(ROOT)),sha256=sha(p),input_hashes=hs))
    assert any(c["path"].startswith("runs/source-receiver-partition-208/") for c in catalog)
    write(RUN/"historical-catalog.json",dict(records=catalog,unique_inputs=len(historical)))
    block=dict(id="belfry",stage="220",subjects=["belfry","thimble"],days=["Wednesday","Friday"],old_block=None)
    jobs=[];fresh=set()
    for a,t,rev,schema in itertools.product(range(2),range(2),range(2),("generic","descriptive")):
        group=fixture.fixture.group(block,a,t,rev,schema);bases,pos=fixture.paired_bases(tok,block,group);hs=[digest(b["free_input_ids"]) for b in bases]
        assert all(h not in historical and h not in fresh for h in hs);fresh.update(hs);jobs.append((digest(group),group,bases,pos))
    assert len(jobs)==16 and len(fresh)==32
    write(RUN/"fresh-inputs.json",dict(jobs=[dict(key=k,group=g,bases=b,position=p) for k,g,b,p in jobs],historical_catalog_sha256=sha(RUN/"historical-catalog.json")))
    counts=Counter();entries=[]
    def head(x):
        with torch.no_grad():s=public.head(model,x)
        counts["finite_heads"]+=1;return cpu(s).astype(np.float64)
    def block_eval(x,c,context,enabled,local):
        with primitive.surgeries(layer,c,context,enabled) as lc,capture(layer) as cap,torch.no_grad():y=public.block(layer,x,context)
        assert all(q["passed"] for q in lc);local.extend(lc);counts["local_primitive_checks"]+=len(lc);counts["surrogate_blocks"]+=1
        cap["output"]=y.detach().cpu().double();return y,cap
    def measure(b,x,c,context,yf,gradient,pos,checks,local):
        def check(kind,error,bound=1e-4):checks.append(dict(kind=kind,error=float(error),bound=bound));assert error<=bound,checks[-1]
        y0,c0=block_eval(x,c,context,(*ATTENTION,"gate_up"),local);y1,c1=block_eval(x,c,context,ATTENTION,local)
        arrays={b+"_FL_state":cpu(y0[0,pos:]),b+"_FF_state":cpu(y1[0,pos:]),b+"_FL_scores":head(y0),b+"_FF_scores":head(y1)}
        for name in ("phi","up","mid","product","down"):arrays[b+"_"+name]=cpu(c0[name][0,pos:])
        check("matched_parents",max(float((c0[n]-c1[n]).abs().max()) for n in ("phi","up","mid")))
        dp=c1["phi"]-c["silu"];du=c1["up"]-c["up"];edit=torch.zeros_like(dp);edit[:,:,mask]=dp[:,:,mask]*du[:,:,mask];edit[:,:pos+1]=0
        product=(c0["product"]+edit).to(device=device,dtype=torch.float32)
        with torch.no_grad():d=layer.mlp.down_proj(product);out=c0["mid"].to(device=device,dtype=torch.float32)+d
        counts["direct_down"]+=1
        effect=out.detach().cpu().double()-c0["output"];check("group_prefix_source",effect[:,:pos+1].abs().max(),0.)
        common=(yf.cpu().double()+effect).to(device=device,dtype=torch.float32)
        arrays.update({b+"_group_state":cpu(out[0,pos:]),b+"_group_product":cpu(product[0,pos:]),b+"_group_down":cpu(d[0,pos:]),
            b+"_group_scores":head(out),b+"_common_state":cpu(common[0,pos:]),b+"_common_scores":head(common),b+"_input":cpu(x[0,pos:])})
        def replace(module,args):
            check("public_original_product",(args[0]-c1["product"].to(device=device,dtype=torch.float32)).abs().max());return (product,)
        with primitive.surgeries(layer,c,context,ATTENTION) as lc,torch.no_grad():
            hook=layer.mlp.down_proj.register_forward_pre_hook(replace)
            try:replay=public.block(layer,x,context)
            finally:hook.remove()
        assert all(q["passed"] for q in lc);local.extend(lc);counts["local_primitive_checks"]+=len(lc);counts["surrogate_blocks"]+=1
        rs=head(replay);check("group_public_replay",(replay-out).abs().max());check("group_public_head",np.max(abs(rs-arrays[b+"_group_scores"])),.005)
        arrays[b+"_replay_state"]=cpu(replay[0,pos:]);arrays[b+"_replay_scores"]=rs
        effect=effect[0,pos:];ideal=F.linear(edit[0,pos:],down)
        p0=c0["product"][0,pos:];p1=product[0,pos:].cpu().double();d0=c0["down"][0,pos:];d1=d[0,pos:].cpu().double()
        pr=F.linear(p1-p0-edit[0,pos:],down);dr=(d1-F.linear(p1,down))-(d0-F.linear(p0,down));mid=c0["mid"][0,pos:]
        rr=(out[0,pos:].cpu().double()-mid-d1)-(c0["output"][0,pos:]-mid-d0)
        check("rounding_closure",(effect-ideal-pr-dr-rr).abs().max(),1e-9)
        weights=down.T@gradient;contributions=weights*(dp[0,-1]*du[0,-1])
        arrays[b+"_contributions"]=cpu(contributions);arrays[b+"_parents6411"]=np.array([float(dp[0,-1,6411]),float(du[0,-1,6411])])
        check("group_initial_projection",abs(float(ideal[-1]@gradient)-float(contributions[mask].sum())),1e-9)
        return arrays
    for number,(key,group,bases,pos) in enumerate(jobs,1):
        assert not any((RUN/"observations").iterdir())
        states,context,scores=public.observe(model,torch.tensor([bases[0]["free_input_ids"]],device=device));counts["ordinary_false"]+=1
        fb=[context["input"],*states];checks=[];local=[]
        def check(kind,error,bound=1e-4):checks.append(dict(kind=kind,error=float(error),bound=bound));assert error<=bound,checks[-1]
        with torch.no_grad():edited=model.model.embed_tokens(torch.tensor([bases[1]["free_input_ids"]],device=device))
        check("embedding_support_prefix",(edited-fb[0])[:,:pos].abs().max(),0.)
        check("embedding_support_suffix",(edited-fb[0])[:,pos+1:].abs().max(),0.)
        finite_cache=[];original_finite=partition.continuation.finite
        def retain_finite(*args,**kwargs):
            result=original_finite(*args,**kwargs);finite_cache.append(cpu(result[0,pos:]));return result
        partition.continuation.finite=retain_finite
        try:delta,receiver,sources=partition.forecast(model,fb,context,edited,pos,counts)
        finally:partition.continuation.finite=original_finite
        assert len(finite_cache)==28
        reverse=[]
        for index in range(1,28):
            incoming=delta[index-1].clone();incoming[:,:pos+1]=0
            reverse.extend(derivatives.verify(model,index,fb[index],fb[index+1],context,{"P_receiver":(incoming,receiver[index])},counts))
        xf,yf=fb[27],fb[28];c=trace(layer,xf,context);check("false_trace",(c["output"]-yf.cpu().double()).abs().max())
        sf=head(yf);check("false_head",np.max(abs(sf-cpu(scores))),.005)
        sham,_=block_eval(xf,c,context,ATTENTION,local);check("false_sham",(sham-yf).abs().max());check("false_sham_head",np.max(abs(head(sham)-sf)),.005)
        rx=yf.detach().clone().requires_grad_(True);ys=public.head(model,rx);grad=torch.autograd.grad(ys[1]-ys[0],rx)[0][0,-1].detach().cpu().double();counts["group_head_gradients"]+=1
        h=yf[0,-1].detach().cpu().double();w=(model.lm_head.weight[830].detach().cpu().double()-model.lm_head.weight[895].detach().cpu().double())*model.model.norm.weight.detach().cpu().double();inv=torch.rsqrt(h.square().mean()+model.model.norm.variance_epsilon);closed=w*inv-h*inv.pow(3)*(w*h).mean();check("closed_gradient",(closed-grad).abs().max())
        arrays=dict(false_boundaries=cpu(torch.stack(fb)[:,0]),false_final=cpu(yf[0,pos:]),false_scores=sf,mask=cpu(context["mask"]),rope_cos=cpu(context["rope"][0]),rope_sin=cpu(context["rope"][1]),
            P_delta=cpu(delta[:,0,pos:]),P_receiver_jvp=cpu(receiver[:,0,pos:]),source_finite_suffix=np.stack(finite_cache),known_source=cpu(sources[:,0]),phi0=cpu(c["silu"][0,pos:]),up0=cpu(c["up"][0,pos:]),gradient=cpu(closed),projection_weights=cpu(down.T@closed))
        sx=xf.clone();sx[:,pos]=sources[26];px=xf+delta[26];px[:,pos]=sources[26]
        arrays.update(measure("S",sx,c,context,yf,closed,pos,checks,local));arrays.update(measure("P",px,c,context,yf,closed,pos,checks,local))
        dest=RUN/"forecasts"/(key+".npz");np.savez_compressed(dest,**arrays)
        rec=dict(key=key,group=group,bases=bases,position=pos,arrays_sha256=sha(dest),checks=checks,local_checks=local,reverse_checks=reverse,sealed_utc=stamp())
        write(dest.with_suffix(".json"),rec);entries.append(dict(key=key,arrays_sha256=sha(dest),record_sha256=sha(dest.with_suffix(".json"))))
        write(RUN/"status.json",dict(status="forecasting",completed=number,counts=dict(counts)));print("forecast",number,key,flush=True);gc.collect()
    assert not any((RUN/"observations").iterdir()) and len(entries)==16
    write(RUN/"forecast-manifest.json",dict(entries=entries,sealed_utc=stamp(),sealed_monotonic_ns=time.monotonic_ns(),native_true_models_before_seal=0,design_sha256=sha(RUN/"design.json"),selection_sha256=sha(maskpath),fresh_inputs_sha256=sha(RUN/"fresh-inputs.json")))
    sealed=sha(RUN/"forecast-manifest.json")
    write(RUN/"observation-start.json",dict(forecast_manifest_sha256=sealed,started_utc=stamp(),started_monotonic_ns=time.monotonic_ns()))
    for number,(key,group,bases,pos) in enumerate(jobs,1):
        assert sha(RUN/"forecast-manifest.json")==sealed
        entry=next(e for e in entries if e["key"]==key);fp=RUN/"forecasts"/(key+".npz");assert sha(fp)==entry["arrays_sha256"]
        with np.load(fp) as z:
            fb=[torch.tensor(a[None],device=device) for a in z["false_boundaries"]];yf=fb[28]
            context=dict(mask=torch.tensor(z["mask"],device=device),rope=tuple(torch.tensor(z[k],device=device) for k in ("rope_cos","rope_sin")))
            states,_,scores=public.observe(model,torch.tensor([bases[1]["free_input_ids"]],device=device));counts["ordinary_true"]+=1
            checks=[];local=[]
            def check(kind,error,bound=1e-4):checks.append(dict(kind=kind,error=float(error),bound=bound));assert error<=bound,checks[-1]
            check("known_source_native",np.max(abs(cpu(torch.stack(states)[:,0,pos])-z["known_source"])))
            check("native_prefix",max(float((a[:,:pos]-b[:,:pos]).abs().max()) for a,b in zip(states,fb[1:])))
            c=trace(layer,fb[27],context);arrays=measure("N",states[26],c,context,yf,torch.tensor(z["gradient"]),pos,checks,local)
            arrays.update(true_suffix=cpu(torch.stack(states)[:,0,pos:]),true_scores=cpu(scores))
            dest=RUN/"observations"/(key+".npz");np.savez_compressed(dest,**arrays)
            write(dest.with_suffix(".json"),dict(key=key,group=group,arrays_sha256=sha(dest),forecast_sha256=entry["arrays_sha256"],forecast_manifest_sha256=sealed,
                observed_utc=stamp(),checks=checks,local_checks=local))
        write(RUN/"status.json",dict(status="observing",completed=number,counts=dict(counts)));print("observe",number,key,flush=True);gc.collect()
    assert dict(counts)==design["expected"],(dict(counts),design["expected"])
    assert all(sha(ROOT/p)==h for p,h in design["source_hashes"].items())
    write(RUN/"status.json",dict(status="complete",qualified=True,counts=dict(counts),forecast_manifest_sha256=sealed,original_wholeblock_jacobian_qualified=False))

if __name__=="__main__":main()
