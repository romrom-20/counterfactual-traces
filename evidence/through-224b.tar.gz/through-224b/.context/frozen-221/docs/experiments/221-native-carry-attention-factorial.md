# 221: native attention bridge and the origin of the final-block parent response

Registered before 221 numerical analysis or model execution. Preserve all 2,312 files in the 220 closure, the rejected source-only hypothesis, and every earlier numerical caveat. All64 old208 contexts; frozen219 top32 and random-control masks. No fitting, new neuron selection, browser, training, correction sweep, publication or Git mutation. Scientific sources/protocol/auditor immutable after execution; any correction is separately named without relaxing bounds.

## The causal picture to test

```mermaid
flowchart LR
  R[Receiving residual carried into block 28] --> ADD[Residual addition]
  A[Attention write computed in block 28] --> ADD
  ADD --> N[Finite MLP-input RMSNorm]
  N --> G[Gate projection and finite SiLU]
  N --> U[Up projection]
  G --> P[Gate × up product]
  U --> P
  P --> D[Public down projection]
  D --> H[Actual finite head at a common False state]
```

Two gaps are explicit. 219's causal group was established with attention False-affine; test whether it carries the native/forecast contrast with fully native attention. Then distinguish a receiving residual already carried into the last block from a new attention write made inside it. This is not yet attribution to earlier blocks or a separation of every upstream Taylor remainder from error amplification.

## Inputs and factorial

At boundary27 reconstruct full-sequence N and P inputs from the verified215 native/forecast suffix and False prefix. S has the same known exact Boolean source but False receivers. All comparisons are retrospective. Evaluate fully native attention (A=F) and the old four-False-affine attention primitives (A=L), with finite SiLU and MLP-input RMSNorm initially. Capture actual public attention output a_B and actual mid-residual x_B+a_B for B=S,N,P; validate A=L N/P endpoints against218 finite-SiLU FF and A=F N against the actual native final output.

For each attention background and B=N/P construct the two-by-two mid-residual intervention on ACTUAL Float32 operands:

    mid00 = x_S + a_S
    mid10 = x_B + a_S           receiving carry only
    mid01 = x_S + a_B           receiving attention write only
    mid11 = x_B + a_B           both; captured incoming-state replay

The x and a operands are source-matched. Prefix/source rows remain matched within an attention background. The same mid00 is shared by N and P; seven distinct mids per background. The crossed attention writes are explicit synthetic interventions, not native trajectories. Record the small Float32 addition interaction separately.

Cross each mid with (R=F) ordinary finite RMSNorm and (R=S) the RMS inverse scale measured at that background's source-only mid00, held fixed while applying the same learned RMS weight. SiLU stays finite. This gives28 mids/normalization conditions per context. R=S is a causal normalization intervention; making pre-SiLU maps linear under a fixed denominator is expected algebra, not a novel mechanism.

## Product outcomes and fixed reference

At each mid actually execute the public norm/gate/up/SiLU modules and three down-inputs: product-affine around False (L), actual finite product (F), and the affine product plus only the frozen32 mixed terms on receiving rows (G). Save actual phi/up, normalized inputs, gate preactivations for6411/3902, products, down outputs, final receiving displacements and finite scores. Source/prefix edits of G−L are exactly zero.

For F−L and G−L keep receiving rows and transplant the measured correction into the SAME False-final state. All behavioral effects use the finite head. Initial projections retain the saved/rechecked False readout gradient and all signed neuron contributions. They do not substitute for finite effects. Save natural endpoint residual/margin errors for context without calling a small improvement an accuracy pass.

Independently replay G through the full public block for EVERY mid/normalization condition: choose the actual carry input x_S/x_B, override attention output with a_S/a_B, optionally freeze the post-attention norm scale, and override the actual down-input with the measured G product. Require exact semantic correspondence, original coordinate/head bounds and unchanged sources/prefix. At N11/P11 finite normalization, native and affine attention endpoints must replay captured public blocks. Mid00 fixed-scale and ordinary norm must replay each other.

## Native-attention neuron interventions

Under fully native attention and finite RMS at N11/P11, swap opposite-minus-own mixed terms on all neurons (benchmark), the fixed32 units, cardinality-matched random32 outside the original top512, and the same random edit scaled to match selected receiving-product L2. Execute actual public down projections/residual additions and finite natural/common heads. Replay both selected swaps in the whole public block. Report every sign and finite distance; do not select a new mask. These test transfer of the 219 causal account to actual native attention, not learned features.

## Questions and reporting rules

1. Native bridge: does the fixed group retain the native/forecast sign contrast, and do selected swaps approach the all-neuron donor effect more closely than both controls in every schema/order stratum? Report original fixed-mask evidence and all native results even if transfer fails.
2. Carry versus write: compare6411 gate/up increments, 3902 controls and the finite32 effect at00/10/01/11. A carry-only or write-only sufficiency diagnostic needs parent relative error<=.25 and group-effect error<=.10 nats against the actual11 endpoint. Apply four-cell panels and >=3/4 panels in EVERY schema/order stratum, as previously. No norm-ratio allocation is called a causal fraction.
3. Normalization: report actual changes in parents and finite32 effect when replacing finite RMS scale by source-only scale. Record the four-cell interaction for pre-gate, up, post-SiLU gate, initial projection and finite effects, including measured arithmetic. Parent-map interaction vanishing with a fixed denominator alone is expected geometry; its causal effect on the native response determines relevance. This factorial does not identify a learned circuit or the earlier operation creating a carried residual.

## Numerical qualification

Pinned offline Qwen/MPS Float32/eager/eval runtime. Preserve original coordinates<=1e-4, scores<=.005. Qualify every attention-affine primitive at its actual direction and every product-affine first derivative against public first AD. Recompute all64 False head gradients by standard first reverse and compare closed form. Do not use or recertify the unresolved original whole-block Jacobian.

Retain raw ideal mixed-vector failures. Independently measure product-cast, down-projection and residual-addition rounding, CPU64 reconstruction<=1e-9. Include native/218 endpoint/operand replays, False primals, Boolean-source matching, source/prefix support, actual mid constructions, fixed-norm sham, every full-block replay and finite-head score replay. An independent saved-array auditor reconstructs inputs, neuron/product accounting, factorials, controls and all numerical gates from actual saved operands and weights.

Expected all64 work:2,432 public blocks (8 captures/shams+28 mid replays+2 selected-swap replays per context),5,888 explicit down projections (3×28 mid arms+8 swaps per context),12,480 explicit finite heads,64 first-reverse head gradients;2,816 local derivative checks (16 attention+28 product per context). CPU64 algebra/model loading excluded. Failures remain visible; no fresh prospective claim is made.
