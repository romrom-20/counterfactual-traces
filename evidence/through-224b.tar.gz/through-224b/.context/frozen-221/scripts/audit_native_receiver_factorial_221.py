"""Independent actual-operand audit of the native carry/write/RMS factorial."""

import hashlib,json,itertools
from pathlib import Path
import numpy as np

R=Path(__file__).resolve().parents[1];RUN=R/"runs/native-receiver-factorial-221";OUT=R/"docs/analysis/221-native-receiver-factorial.json"
UNITS=[6411,3902]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def margin(s):return float(s[1]-s[0])
def head(x,w):
    h=x[-1].astype(np.float64);return (h/np.sqrt(np.mean(h*h)+float(w["eps"]))*w["norm"])@w["head"].T
def outcome(state,scores,z):
    pred=state[-1].astype(np.float64)-z["false_final"][-1];actual=z["true_final"][-1]-z["false_final"][-1]
    return dict(verdict_relative_l2=float(np.linalg.norm(pred-actual)/np.linalg.norm(actual)),margin_error=abs(margin(scores-z["false_scores"])-margin(z["true_scores"]-z["false_scores"])))

def main():
    assert not OUT.exists();design=json.loads((RUN/"design.json").read_text());status=json.loads((RUN/"status.json").read_text())
    assert all(sha(R/p)==h for p,h in design["source_hashes"].items())
    assert status["status"]=="complete" and status["qualified"] and status["counts"]==design["expected"]
    w=dict(np.load(RUN/"weights.npz"));down=w["down"].astype(np.float64);mask=design["mask"];rand=design["random"]
    controls=[];local=[];rows=[];swaps=[];interactions=[];rawfail=0;rawtotal=0;maxraw=0.;maxclosure=0.;maxhead=0.;maxparent=0.;maxnorm=0.;maxinteractionclosure=0.
    for path in sorted((RUN/"pairs").glob("*.npz")):
        rec=json.loads(path.with_suffix(".json").read_text());assert sha(path)==rec["arrays_sha256"]
        for folder,key in (("matched-incoming-control-215/pairs","parent215_sha256"),("source-receiver-partition-208/forecasts","parent208_sha256"),("silu-range-falsification-218/pairs","parent218_sha256"),("neuron-mixed-interventions-219/captures","parent219_sha256")):
            assert sha(R/"runs"/folder/path.name)==rec[key]
        controls.extend(rec["checks"]);local.extend(rec["local_checks"]);z=dict(np.load(path));assert all(np.isfinite(v).all() for v in z.values())
        bykey={};assert len(rec["mids"])==28 and len(rec["swaps"])==8
        for meta in rec["mids"]:
            key=meta["key"];a,norm,b=meta["attention"],meta["norm"],meta["background"]
            x=z["x_"+(b if meta["carry"] else "S")].astype(np.float64)
            attention=z[f"capture_{a}_{b if meta['write'] else 'S'}_attention"].astype(np.float64)
            mid=(x+attention).astype(np.float32).astype(np.float64);assert np.max(abs(mid-z[key+"_mid"]))==0
            gain=z[key+"_gain"].astype(np.float64)
            if norm=="S":assert np.max(abs(gain-z["source_gain_"+a]))==0
            else:
                expected=1/np.sqrt(np.mean(mid*mid,axis=-1,keepdims=True)+float(w["post_eps"]))
                assert np.max(abs(gain-expected))<=1e-4
            normalized=z[key+"_normalized"].astype(np.float64);ne=float(np.max(abs(normalized-w["post_norm"]*(mid*gain))));maxnorm=max(maxnorm,ne);assert ne<=1e-4
            gp=normalized@w["gate_units"].T;up=normalized@w["up_units"].T
            ge=float(np.max(abs(gp-z[key+"_gate_units"])));ue=float(np.max(abs(up-z[key+"_up"][:,UNITS])));maxparent=max(maxparent,ge,ue);assert max(ge,ue)<=1e-4
            phi=z[key+"_phi"].astype(np.float64);u=z[key+"_up"].astype(np.float64)
            assert np.max(abs(z[key+"_gate_units"]/(1+np.exp(-z[key+"_gate_units"]))-phi[:,UNITS]))<=1e-4
            dp=phi-z["phi0"];du=u-z["up0"];mix=dp*du;selected=np.zeros_like(mix);selected[:,mask]=mix[:,mask];selected[0]=0
            affine=z["false_product"]+dp*z["up0"]+z["phi0"]*du
            for arm,expected in (("L",affine.astype(np.float32)),("F",(phi.astype(np.float32)*u.astype(np.float32))),("G",(affine+selected).astype(np.float32))):
                assert np.max(abs(expected-z[f"{key}_{arm}_product"]))<=1e-4
                he=float(np.max(abs(head(z[f"{key}_{arm}_state"],w)-z[f"{key}_{arm}_scores"])));maxhead=max(maxhead,he);assert he<=.005
            for arm,ideal in (("F",mix),("G",selected)):
                actual=z[f"{key}_{arm}_state"].astype(np.float64)-z[f"{key}_L_state"].astype(np.float64)
                p0=z[f"{key}_L_product"].astype(np.float64);p1=z[f"{key}_{arm}_product"].astype(np.float64)
                d0=z[f"{key}_L_down"].astype(np.float64);d1=z[f"{key}_{arm}_down"].astype(np.float64)
                pr=(p1-p0-ideal)@down.T;dr=(d1-p1@down.T)-(d0-p0@down.T)
                rr=(z[f"{key}_{arm}_state"].astype(np.float64)-mid-d1)-(z[f"{key}_L_state"].astype(np.float64)-mid-d0)
                raw=float(np.max(abs(actual-ideal@down.T)));rawtotal+=1;rawfail+=raw>1e-4;maxraw=max(maxraw,raw)
                closure=float(np.max(abs(actual-ideal@down.T-pr-dr-rr)));maxclosure=max(maxclosure,closure);assert closure<=1e-9
                if arm=="G":assert np.max(abs(actual[0]))==0
                correction=actual.copy();correction[0]=0;common=(z["false_final"].astype(np.float64)+correction).astype(np.float32)
                assert np.max(abs(common-z[f"{key}_{arm}_common_state"]))==0
                he=float(np.max(abs(head(common,w)-z[f"{key}_{arm}_common_scores"])));maxhead=max(maxhead,he);assert he<=.005
            assert np.max(abs(z[key+"_G_state"]-z[key+"_replay_state"]))<=1e-4 and np.max(abs(z[key+"_G_scores"]-z[key+"_replay_scores"]))<=.005
            contributions=z["projection_weights"]*(dp[-1]*du[-1])
            row=dict(context=path.stem,group=rec["group"],**meta,
                parents6411=[float(dp[-1,6411]),float(du[-1,6411])],parents3902=[float(dp[-1,3902]),float(du[-1,3902])],
                gate_units=z[key+"_gate_units"][-1].tolist(),up_units=u[-1,UNITS].tolist(),phi_units=phi[-1,UNITS].tolist(),gain=float(gain[-1,0]),
                initial6411=float(contributions[6411]),initial3902=float(contributions[3902]),initial_group=float(contributions[mask].sum()),initial_full=float(contributions.sum()),
                finite_group=margin(z[key+"_G_common_scores"])-margin(z["false_scores"]),finite_full=margin(z[key+"_F_common_scores"])-margin(z["false_scores"]),
                full_native_error=outcome(z[key+"_F_state"],z[key+"_F_scores"],z))
            rows.append(row);bykey[key]=row
        for a,norm,b in itertools.product(("F","L"),("F","S"),("N","P")):
            keys=[f"{a}_{norm}_{b}11",f"{a}_{norm}_{b}10",f"{a}_{norm}_{b}01",f"{a}_{norm}_00"];sign=[1,-1,-1,1]
            interaction={field:sum(s*np.array(bykey[k][field]) for s,k in zip(sign,keys)) for field in ("gate_units","up_units","phi_units","initial6411","initial3902","initial_group","finite_group","finite_full")}
            zmix=sum(s*z[k+"_normalized"].astype(np.float64) for s,k in zip(sign,keys));mmix=sum(s*z[k+"_mid"].astype(np.float64) for s,k in zip(sign,keys))
            for field,ww in (("gate_units",w["gate_units"]),("up_units",w["up_units"])):
                rounds=sum(s*((z[k+"_gate_units"] if field=="gate_units" else z[k+"_up"][:,UNITS]).astype(np.float64)-z[k+"_normalized"]@ww.T) for s,k in zip(sign,keys))
                actual=sum(s*(z[k+"_gate_units"] if field=="gate_units" else z[k+"_up"][:,UNITS]).astype(np.float64) for s,k in zip(sign,keys))
                error=float(np.max(abs(actual-zmix@ww.T-rounds)));maxinteractionclosure=max(maxinteractionclosure,error);assert error<=1e-9
            if norm=="S":
                rounds=sum(s*(z[k+"_normalized"].astype(np.float64)-w["post_norm"]*(z[k+"_mid"].astype(np.float64)*z["source_gain_"+a])) for s,k in zip(sign,keys))
                error=float(np.max(abs(zmix-w["post_norm"]*(mmix*z["source_gain_"+a])-rounds)));maxinteractionclosure=max(maxinteractionclosure,error);assert error<=1e-9
            interactions.append(dict(context=path.stem,group=rec["group"],attention=a,norm=norm,background=b,
                raw_mid_interaction_norm=float(np.linalg.norm(mmix[-1])),normalized_interaction_norm=float(np.linalg.norm(zmix[-1])),
                **{k:v.tolist() if isinstance(v,np.ndarray) else float(v) for k,v in interaction.items()}))
        for meta in rec["swaps"]:
            key=meta["key"];b=meta["background"];other="P" if b=="N" else "N";bk=f"F_F_{b}11";ok=f"F_F_{other}11"
            own=(z[bk+"_phi"]-z["phi0"])*(z[bk+"_up"]-z["up0"]);donor=(z[ok+"_phi"]-z["phi0"])*(z[ok+"_up"]-z["up0"]);difference=donor-own;difference[0]=0
            if meta["kind"]=="all":edit=difference
            else:
                ids=mask if meta["kind"]=="selected" else rand;edit=np.zeros_like(difference);edit[:,ids]=difference[:,ids];edit*=meta["scale"]
            if meta["kind"]=="norm_random":assert abs(np.linalg.norm(edit)-meta["selected_edit_norm"])<=1e-9
            p0=z[bk+"_F_product"].astype(np.float64);p1=z[key+"_product"].astype(np.float64);assert np.max(abs(p1-(p0+edit).astype(np.float32)))<=1e-4
            actual=z[key+"_state"].astype(np.float64)-z[bk+"_F_state"].astype(np.float64)
            d0=z[bk+"_F_down"].astype(np.float64);d1=z[key+"_down"].astype(np.float64);mid=z[bk+"_mid"].astype(np.float64)
            pr=(p1-p0-edit)@down.T;dr=(d1-p1@down.T)-(d0-p0@down.T);rr=(z[key+"_state"].astype(np.float64)-mid-d1)-(z[bk+"_F_state"].astype(np.float64)-mid-d0)
            raw=float(np.max(abs(actual-edit@down.T)));rawtotal+=1;rawfail+=raw>1e-4;maxraw=max(maxraw,raw)
            closure=float(np.max(abs(actual-edit@down.T-pr-dr-rr)));maxclosure=max(maxclosure,closure);assert closure<=1e-9
            assert np.max(abs(actual[0]))==0
            correction=z[key+"_state"].astype(np.float64)-z[bk+"_L_state"].astype(np.float64);correction[0]=0;common=(z["false_final"].astype(np.float64)+correction).astype(np.float32)
            assert np.max(abs(common-z[key+"_common_state"]))==0
            for state,scores in ((common,z[key+"_common_scores"]),(z[key+"_state"],z[key+"_scores"])):
                error=float(np.max(abs(head(state,w)-scores)));maxhead=max(maxhead,error);assert error<=.005
            if meta["kind"]=="selected":assert np.max(abs(z[key+"_state"]-z[key+"_replay_state"]))<=1e-4 and np.max(abs(z[key+"_scores"]-z[key+"_replay_scores"]))<=.005
            swaps.append(dict(context=path.stem,group=rec["group"],**meta,finite_common=margin(z[key+"_common_scores"])-margin(z["false_scores"])))
    assert len(rows)==1792 and len(swaps)==512 and len(interactions)==512 and len(local)==2816 and rawtotal==4096
    assert all(c["error"]<=c["bound"] for c in controls) and all(c["passed"] for c in local)
    summaries=[]
    for a,norm,state in itertools.product(("F","L"),("F","S"),("00","N10","N01","N11","P10","P01","P11")):
        for schema in (None,"generic","descriptive"):
            rr=[r for r in rows if r["attention"]==a and r["norm"]==norm and r["state"]==state and (schema is None or r["group"]["schema"]==schema)]
            summaries.append(dict(attention=a,norm=norm,state=state,schema=schema,count=len(rr),positive_group=sum(r["finite_group"]>0 for r in rr),
                medians={f:np.median([r[f] for r in rr],axis=0).tolist() for f in ("parents6411","parents3902","initial6411","initial3902","initial_group","finite_group","finite_full","gain")}))
    suff=[]
    for a,norm,b,part in itertools.product(("F","L"),("F","S"),("N","P"),("10","01")):
        values=[]
        for r in [q for q in rows if q["attention"]==a and q["norm"]==norm and q["state"]==b+part]:
            target=next(q for q in rows if q["context"]==r["context"] and q["attention"]==a and q["norm"]==norm and q["state"]==b+"11")
            t=np.array(target["parents6411"]);den=np.linalg.norm(t);q=float(np.linalg.norm(np.array(r["parents6411"])-t)/den) if den>=.001 else None;m=abs(r["finite_group"]-target["finite_group"])
            values.append(dict(context=r["context"],group=r["group"],parent_relative=q,group_error=m,passed=bool(q is not None and q<=.25 and m<=.1)))
        panels=[];strata=[]
        for schema,order,block in itertools.product(("generic","descriptive"),range(2),("chalice","gimbal","larch","marzipan")):
            v=[r for r in values if r["group"]["schema"]==schema and r["group"]["reverse"]==order and r["group"]["block"]==block];assert len(v)==4
            panels.append(dict(schema=schema,order=order,block=block,passed=all(r["passed"] for r in v)))
        for schema,order in itertools.product(("generic","descriptive"),range(2)):
            n=sum(p["passed"] for p in panels if p["schema"]==schema and p["order"]==order);strata.append(dict(schema=schema,order=order,passing_panels=n,passed=n>=3))
        suff.append(dict(attention=a,norm=norm,background=b,part=part,passes=sum(v["passed"] for v in values),median_parent_relative=float(np.median([v["parent_relative"] for v in values if v["parent_relative"] is not None])),
            median_group_error=float(np.median([v["group_error"] for v in values])),whole_pass=all(s["passed"] for s in strata),strata=strata,values=values))
    bridge=[]
    for b in ("N","P"):
        eligible=0;signs=0;wins=0;errors={k:[] for k in ("selected","random","norm_random")}
        for context in sorted({s["context"] for s in swaps}):
            ss={s["kind"]:s for s in swaps if s["context"]==context and s["background"]==b};sham=next(r for r in rows if r["context"]==context and r["attention"]=="F" and r["norm"]=="F" and r["state"]==b+"11")["finite_full"];target=ss["all"]["finite_common"]
            if abs(sham)>.02 and abs(target)>.02 and np.sign(sham)!=np.sign(target):eligible+=1;signs+=np.sign(ss["selected"]["finite_common"])==np.sign(target)
            for k in errors:errors[k].append(abs(ss[k]["finite_common"]-target))
            wins+=all(abs(ss["selected"]["finite_common"]-target)<abs(ss[k]["finite_common"]-target) for k in ("random","norm_random"))
        strata=[]
        for schema,order in itertools.product(("generic","descriptive"),range(2)):
            keys={s["context"] for s in swaps if s["group"]["schema"]==schema and s["group"]["reverse"]==order};n=0
            for context in keys:
                ss={s["kind"]:s for s in swaps if s["context"]==context and s["background"]==b};target=ss["all"]["finite_common"]
                n+=all(abs(ss["selected"]["finite_common"]-target)<abs(ss[k]["finite_common"]-target) for k in ("random","norm_random"))
            strata.append(dict(schema=schema,order=order,wins=int(n),count=len(keys)))
        bridge.append(dict(background=b,eligible=eligible,donor_sign_attained=int(signs),beats_both_controls=int(wins),median_distance={k:float(np.median(v)) for k,v in errors.items()},strata=strata))
    result=dict(qualified=True,contexts=64,counts=status["counts"],controls=len(controls),local_derivative_checks=len(local),
        maximum_local_derivative_error=max(c["coordinate_error"] for c in local),maximum_head_error=maxhead,maximum_norm_error=maxnorm,maximum_selected_parent_replay_error=maxparent,
        maximum_rounding_closure=maxclosure,maximum_interaction_accounting_error=maxinteractionclosure,raw_ideal_failures=int(rawfail),raw_ideal_comparisons=rawtotal,maximum_raw_ideal_error=maxraw,
        summaries=summaries,sufficiency=suff,native_bridge=bridge,rows=rows,swaps=swaps,interactions=interactions,
        original_wholeblock_jacobian_qualified=False,prospective=False,full_question_B_solved=False,
        scope="Retrospective native-attention bridge and receiving carry/write/RMS interventions in block28. Fixed219 units; finite readouts; no earlier-layer attribution, learned features or prospective prediction.",auditor_sha256=sha(Path(__file__)))
    OUT.write_text(json.dumps(result,indent=2,default=lambda x:x.item() if isinstance(x,np.generic) else str(x))+"\n")
    print(json.dumps({k:v for k,v in result.items() if k not in ("rows","swaps","interactions","summaries","sufficiency")},indent=2))
    print(json.dumps([{k:v for k,v in s.items() if k!="values"} for s in suff],indent=2))
if __name__=="__main__":main()
