"""Actual mid-residual/MLP modules and source-scale interventions, without whole JVPs."""

from contextlib import contextmanager
import torch
from gate_up_arithmetic_213 import capture

ATTENTION=("input_rms","qk_product","softmax","weight_value")
UNITS=(6411,3902)
STATES=(("00","S",0,0),("N10","N",1,0),("N01","N",0,1),("N11","N",1,1),
        ("P10","P",1,0),("P01","P",0,1),("P11","P",1,1))

@contextmanager
def captured(layer):
    with capture(layer) as out:
        def save(name):
            def hook(module,args,value):out[name]=value.detach().cpu().double().clone()
            return hook
        handles=[layer.self_attn.o_proj.register_forward_hook(save("attention")),layer.mlp.gate_proj.register_forward_hook(save("gate")),
                 layer.post_attention_layernorm.register_forward_hook(save("normalized"))]
        try:yield out
        finally:
            for h in handles:h.remove()

def inverse_scale(layer,mid):
    return torch.rsqrt(mid.float().square().mean(-1,keepdim=True)+layer.post_attention_layernorm.variance_epsilon)

def normalized(layer,mid,gain=None):
    return layer.post_attention_layernorm(mid) if gain is None else layer.post_attention_layernorm.weight*(mid*gain)

def mlp_inputs(layer,mid,c,mask,pos,gain=None):
    z=normalized(layer,mid,gain);g=layer.mlp.gate_proj(z);u=layer.mlp.up_proj(z);phi=layer.mlp.act_fn(g)
    dp=phi.detach().cpu().double()-c["silu"];du=u.detach().cpu().double()-c["up"]
    derivative=dp*c["up"]+c["silu"]*du
    _,observed=torch.func.jvp(lambda p,v:p*v,
        (c["silu"].to(device=mid.device,dtype=mid.dtype),c["up"].to(device=mid.device,dtype=mid.dtype)),
        (dp.to(device=mid.device,dtype=mid.dtype),du.to(device=mid.device,dtype=mid.dtype)))
    error=float((observed.detach().cpu().double()-derivative).abs().max());assert error<=1e-4,error
    affine=c["gate_up"]+derivative;mix=dp*du;selected=torch.zeros_like(mix);selected[:,:,mask]=mix[:,:,mask];selected[:,:pos+1]=0
    products=dict(L=affine.to(device=mid.device,dtype=mid.dtype),F=phi*u,G=(affine+selected).to(device=mid.device,dtype=mid.dtype))
    return dict(normalized=z,gate=g,up=u,phi=phi,gain=inverse_scale(layer,mid) if gain is None else gain),products,mix,error
