"""Retrospective native-attention bridge, carried-state/write factorial and RMS intervention."""

import hashlib,json
from collections import Counter
from contextlib import nullcontext
from pathlib import Path
import numpy as np
import torch
from torch.nn import functional as F
import ranked_block_response_201 as public
import primitive_diagnostic_211 as primitive
from frozen_block28_derivative_210 import trace
from native_receiver_factorial_221 import ATTENTION,UNITS,STATES,captured,inverse_scale,mlp_inputs
from latent_decisions.target import load_target
from latent_decisions.evidence_policy import digest

R=Path(__file__).resolve().parents[1];RUN=R/"runs/native-receiver-factorial-221"
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def cpu(x):return x.detach().cpu().numpy().copy()
def write(p,o):p.write_text(json.dumps(o,indent=2,default=lambda x:x.item() if isinstance(x,np.generic) else str(x))+"\n")

def main():
    assert not RUN.exists()
    previous=R/"results/source-only-neurons-220/manifest.json";prior=json.loads(previous.read_text())
    assert len(prior["files"])==2312 and all(sha(R/p)==h for p,h in prior["files"].items())
    files=["scripts/run_native_receiver_factorial_221.py","scripts/native_receiver_factorial_221.py","scripts/audit_native_receiver_factorial_221.py",
        "docs/experiments/221-native-carry-attention-factorial.md","scripts/primitive_diagnostic_211.py","scripts/frozen_block28_derivative_210.py",
        "scripts/local_primitive_derivative_210c.py","scripts/gate_up_arithmetic_213.py","scripts/ranked_block_response_201.py","src/latent_decisions/target.py"]
    maskfile=R/"runs/neuron-mixed-interventions-219/selection.json";selection=json.loads(maskfile.read_text());mask=selection["ranking"][:32];random=selection["random_ranking"][:32]
    rtfile=R/"runs/source-receiver-partition-208/runtime.json";rt=json.loads(rtfile.read_text())
    RUN.mkdir();(RUN/"pairs").mkdir();design=dict(source_hashes={p:sha(R/p) for p in files},prior_manifest_sha256=sha(previous),selection_sha256=sha(maskfile),
        mask=mask,random=random,runtime_sha256=sha(rtfile),expected=dict(public_blocks=2432,direct_down=5888,finite_heads=12480,head_gradients=64,local_derivative_checks=2816))
    write(RUN/"design.json",design);write(RUN/"runtime.json",rt)
    model,tok,device=load_target(rt["model"],"mps",offline=True);torch.set_num_threads(2)
    assert digest(tok.get_vocab())==rt["tokenizer_hash"] and digest(model.config.to_dict())==rt["config_hash"]
    assert not model.training and next(model.parameters()).dtype==torch.float32 and model.config._attn_implementation=="eager"
    layer=model.model.layers[27];down=layer.mlp.down_proj.weight.detach().cpu().double()
    assert layer.mlp.gate_proj.bias is None and layer.mlp.up_proj.bias is None
    np.savez_compressed(RUN/"weights.npz",down=cpu(down),post_norm=cpu(layer.post_attention_layernorm.weight),post_eps=np.array(layer.post_attention_layernorm.variance_epsilon),
        gate_units=cpu(layer.mlp.gate_proj.weight[list(UNITS)]),up_units=cpu(layer.mlp.up_proj.weight[list(UNITS)]),norm=cpu(model.model.norm.weight),
        head=cpu(model.lm_head.weight[[895,830]]),eps=np.array(model.model.norm.variance_epsilon))
    counts=Counter();completed=0
    def head(x):
        with torch.no_grad():s=public.head(model,x)
        counts["finite_heads"]+=1;return cpu(s).astype(np.float64)
    for path in sorted((R/"runs/matched-incoming-control-215/pairs").glob("*.npz")):
        r215=json.loads(path.with_suffix(".json").read_text())["record"];assert sha(path)==r215["arrays_sha256"]
        p208=R/"runs/source-receiver-partition-208/forecasts"/path.name;p218=R/"runs/silu-range-falsification-218/pairs"/path.name
        p219=R/"runs/neuron-mixed-interventions-219/captures"/path.name
        checks=[];local=[];rows=[];swaps=[];arrays={}
        def check(kind,error,bound=1e-4,**meta):
            checks.append(dict(kind=kind,error=float(error),bound=bound,**meta));assert error<=bound,checks[-1]
        with np.load(path) as z,np.load(p208) as old,np.load(p218) as old218,np.load(p219) as old219:
            pos=int(old218["position"]);xf=torch.tensor(old["false_boundaries"][27][None],device=device);yf=torch.tensor(old["false_boundaries"][28][None],device=device)
            context=dict(mask=torch.tensor(old["mask"],device=device),rope=tuple(torch.tensor(old[k],device=device) for k in ("rope_cos","rope_sin")))
            c=trace(layer,xf,context);check("false_trace",(c["output"]-yf.cpu().double()).abs().max())
            sf=head(yf);check("false_head",np.max(abs(sf-old["false_scores"])),.005)
            rx=yf.clone().requires_grad_(True);s=public.head(model,rx);grad=torch.autograd.grad(s[1]-s[0],rx)[0][0,-1].detach().cpu().double();counts["head_gradients"]+=1
            check("saved_gradient",np.max(abs(cpu(grad)-old219["gradient"])))
            h=yf[0,-1].detach().cpu().double();w=(model.lm_head.weight[830].detach().cpu().double()-model.lm_head.weight[895].detach().cpu().double())*model.model.norm.weight.detach().cpu().double()
            inv=torch.rsqrt(h.square().mean()+model.model.norm.variance_epsilon);closed=w*inv-h*inv.pow(3)*(w*h).mean();check("closed_gradient",(closed-grad).abs().max())
            arrays.update(position=np.array(pos),false_final=cpu(yf[0,pos:]),false_scores=sf,true_final=z["true_final"].copy(),true_scores=z["true_scores"].copy(),
                phi0=cpu(c["silu"][0,pos:]),up0=cpu(c["up"][0,pos:]),false_product=cpu(c["gate_up"][0,pos:]),gradient=cpu(closed),projection_weights=cpu(down.T@closed))
            xs={"S":xf.clone(),"N":xf.clone(),"P":xf.clone()}
            xs["S"][:,pos]=torch.tensor(old["source_receiver_absolute_source"][26],device=device)
            for b,branch in (("N","native"),("P","predicted")):xs[b][:,pos:]=torch.tensor(z[branch+"_input"][None],device=device)
            check("known_sources",max(float((x[:,pos]-xs["S"][:,pos]).abs().max()) for x in xs.values()))
            for b,x in xs.items():arrays["x_"+b]=cpu(x[0,pos:])
            def actual(x,mode):
                manager=primitive.surgeries(layer,c,context,ATTENTION) if mode=="L" else nullcontext([])
                with manager as lc,captured(layer) as cap,torch.no_grad():out=public.block(layer,x,context)
                assert all(q["passed"] for q in lc);local.extend(lc);counts["local_derivative_checks"]+=len(lc);counts["public_blocks"]+=1
                cap["output"]=out.detach().cpu().double();return out,cap
            for mode in ("F","L"):
                out,cap=actual(xf,mode);check("false_public",(out-yf).abs().max(),mode=mode);check("false_public_head",np.max(abs(head(out)-sf)),.005,mode=mode)
            caps={}
            for mode in ("F","L"):
                caps[mode]={}
                for b,x in xs.items():
                    out,cap=actual(x,mode);ss=head(out);caps[mode][b]=cap
                    for name in ("attention","mid","output"):arrays[f"capture_{mode}_{b}_{name}"]=cpu(cap[name][0,pos:])
                    arrays[f"capture_{mode}_{b}_scores"]=ss
                    check("capture_mid",(x+cap["attention"].to(device=device,dtype=x.dtype)-cap["mid"].to(device=device,dtype=x.dtype)).abs().max(),mode=mode,input=b)
                    if mode=="L" and b!="S":
                        branch="native" if b=="N" else "predicted"
                        check("218_endpoint",np.max(abs(cpu(out[0,pos:])-old218[branch+"_FF_state"])),mode=mode,input=b)
                        check("218_score",np.max(abs(ss-old218[branch+"_FF_scores"])),.005,mode=mode,input=b)
                        for name in ("phi","up"):check("218_operand",np.max(abs(cpu(cap[name][0,pos:])-old218[branch+"_FF_"+name])),mode=mode,input=b)
                    if mode=="F" and b=="N":
                        check("native_whole_endpoint",np.max(abs(cpu(out[0,pos:])-z["true_final"])));check("native_whole_head",np.max(abs(ss-z["true_scores"])),.005)
                    check("source_matched_attention",(cap["attention"][:,:pos+1]-caps[mode]["S"]["attention"][:,:pos+1]).abs().max(),mode=mode,input=b)
            def replay(x,attention,gain,product,mid,expected,ss,label):
                handles=[]
                handles.append(layer.self_attn.o_proj.register_forward_hook(lambda module,args,out:attention))
                if gain is not None:handles.append(layer.post_attention_layernorm.register_forward_hook(lambda module,args,out:module.weight*(args[0]*gain)))
                def product_hook(module,args):return (product,)
                handles.append(layer.mlp.down_proj.register_forward_pre_hook(product_hook))
                def mid_hook(module,args):check("replay_mid",(args[0]-mid).abs().max(),cell=label)
                handles.append(layer.post_attention_layernorm.register_forward_pre_hook(mid_hook))
                try:
                    with torch.no_grad():out=public.block(layer,x,context)
                finally:
                    for handle in handles:handle.remove()
                counts["public_blocks"]+=1;hs=head(out);check("whole_block_replay",(out-expected).abs().max(),cell=label);check("whole_head_replay",np.max(abs(hs-ss)),.005,cell=label)
                return out,hs
            stored={}
            for mode in ("F","L"):
                source_attention=caps[mode]["S"]["attention"].to(device=device,dtype=torch.float32)
                source_mid=xs["S"]+source_attention;source_gain=inverse_scale(layer,source_mid)
                arrays[f"source_gain_{mode}"]=cpu(source_gain[0,pos:])
                for norm in ("F","S"):
                    gain=None if norm=="F" else source_gain
                    for state,b,carry,write_flag in STATES:
                        key=f"{mode}_{norm}_{state}";x=xs[b] if carry else xs["S"]
                        a=caps[mode][b if write_flag else "S"]["attention"].to(device=device,dtype=torch.float32);mid=x+a
                        with torch.no_grad():values,products,mix,error=mlp_inputs(layer,mid,c,mask,pos,gain)
                        local.append(dict(primitive="gate_up",coordinate_error=error,passed=error<=1e-4,cell=key));counts["local_derivative_checks"]+=1
                        arrays[key+"_mid"]=cpu(mid[0,pos:]);arrays[key+"_normalized"]=cpu(values["normalized"][0,pos:]);arrays[key+"_gain"]=cpu(values["gain"][0,pos:]);arrays[key+"_gate_units"]=cpu(values["gate"][0,pos:,list(UNITS)])
                        for name in ("phi","up"):arrays[key+"_"+name]=cpu(values[name][0,pos:])
                        outputs={};scores={};downs={}
                        for arm in ("L","F","G"):
                            with torch.no_grad():d=layer.mlp.down_proj(products[arm]);out=mid+d
                            counts["direct_down"]+=1;outputs[arm]=out;downs[arm]=d;scores[arm]=head(out)
                            for name,value in (("product",products[arm]),("down",d),("state",out)):arrays[f"{key}_{arm}_{name}"]=cpu(value[0,pos:])
                            arrays[f"{key}_{arm}_scores"]=scores[arm]
                        for arm in ("F","G"):
                            correction=outputs[arm].detach().cpu().double()-outputs["L"].detach().cpu().double();correction[:,:pos+1]=0
                            common=(yf.cpu().double()+correction).to(device=device,dtype=torch.float32);cs=head(common)
                            arrays[f"{key}_{arm}_common_state"]=cpu(common[0,pos:]);arrays[f"{key}_{arm}_common_scores"]=cs
                            actual=arrays[f"{key}_{arm}_state"].astype(np.float64)-arrays[f"{key}_L_state"].astype(np.float64)
                            ideal=mix[0,pos:].clone()
                            if arm=="G":
                                partial=torch.zeros_like(ideal);partial[:,mask]=ideal[:,mask];ideal=partial;ideal[0]=0
                                check("group_prefix_source",(outputs["G"]-outputs["L"])[:,:pos+1].abs().max(),0.,cell=key)
                            jm=F.linear(ideal,down).numpy()
                            p0=products["L"][0,pos:].cpu().double();p1=products[arm][0,pos:].cpu().double();d0=downs["L"][0,pos:].cpu().double();d1=downs[arm][0,pos:].cpu().double()
                            pr=F.linear(p1-p0-ideal,down).numpy();dr=((d1-F.linear(p1,down))-(d0-F.linear(p0,down))).numpy()
                            rr=((outputs[arm][0,pos:].cpu().double()-mid[0,pos:].cpu().double()-d1)-(outputs["L"][0,pos:].cpu().double()-mid[0,pos:].cpu().double()-d0)).numpy()
                            check("arithmetic_closure",np.max(abs(actual-jm-pr-dr-rr)),1e-9,cell=key,arm=arm)
                        rp,rs=replay(x,a,gain,products["G"],mid,outputs["G"],scores["G"],key)
                        arrays[key+"_replay_state"]=cpu(rp[0,pos:]);arrays[key+"_replay_scores"]=rs
                        if state in ("00","N11","P11") and norm=="F":
                            check("captured_endpoint",np.max(abs(arrays[key+"_F_state"]-arrays[f"capture_{mode}_{b}_output"])),cell=key)
                            check("captured_head",np.max(abs(scores["F"]-arrays[f"capture_{mode}_{b}_scores"])),.005,cell=key)
                        if state=="00" and norm=="S":
                            other=f"{mode}_F_00";check("source_norm_sham",np.max(abs(arrays[key+"_normalized"]-arrays[other+"_normalized"])),cell=key)
                            check("source_norm_sham_state",np.max(abs(arrays[key+"_F_state"]-arrays[other+"_F_state"])),cell=key)
                        rows.append(dict(key=key,attention=mode,norm=norm,state=state,background=b,carry=carry,write=write_flag))
                        if mode=="F" and norm=="F" and state in ("N11","P11"):
                            stored[b]=dict(x=x,a=a,mid=mid,outputs=outputs,products=products,mix=mix)
            for b in ("N","P"):
                other="P" if b=="N" else "N";base=stored[b];difference=stored[other]["mix"]-base["mix"];difference[:,:pos+1]=0
                selected=torch.zeros_like(difference);selected[:,:,mask]=difference[:,:,mask]
                rand=torch.zeros_like(difference);rand[:,:,random]=difference[:,:,random]
                scale=float(selected.norm()/rand.norm());assert np.isfinite(scale)
                for kind,edit,alpha in (("all",difference,1.),("selected",selected,1.),("random",rand,1.),("norm_random",rand*scale,scale)):
                    key=f"swap_{b}_{kind}";product=(base["products"]["F"].cpu().double()+edit).to(device=device,dtype=torch.float32)
                    with torch.no_grad():d=layer.mlp.down_proj(product);out=base["mid"]+d
                    counts["direct_down"]+=1;ss=head(out);delta=out.detach().cpu().double()-base["outputs"]["L"].detach().cpu().double();delta[:,:pos+1]=0
                    common=(yf.cpu().double()+delta).to(device=device,dtype=torch.float32);cs=head(common)
                    check("swap_prefix_source",(out-base["outputs"]["F"])[:,:pos+1].abs().max(),0.,cell=key)
                    if kind=="norm_random":check("swap_norm_match",abs(float(edit.norm())-float(selected.norm())),1e-9,cell=key)
                    for name,value in (("product",product),("down",d),("state",out),("common_state",common)):arrays[key+"_"+name]=cpu(value[0,pos:])
                    arrays[key+"_scores"]=ss;arrays[key+"_common_scores"]=cs
                    if kind=="selected":
                        rp,rs=replay(base["x"],base["a"],None,product,base["mid"],out,ss,key);arrays[key+"_replay_state"]=cpu(rp[0,pos:]);arrays[key+"_replay_scores"]=rs
                    swaps.append(dict(key=key,background=b,kind=kind,scale=alpha,product_edit_norm=float(edit.norm()),selected_edit_norm=float(selected.norm())))
        assert all(np.isfinite(v).all() for v in arrays.values())
        dest=RUN/"pairs"/path.name;np.savez_compressed(dest,**arrays)
        write(dest.with_suffix(".json"),dict(key=path.stem,group=r215["group"],arrays_sha256=sha(dest),parent215_sha256=sha(path),parent208_sha256=sha(p208),parent218_sha256=sha(p218),parent219_sha256=sha(p219),
            checks=checks,local_checks=local,mids=rows,swaps=swaps))
        completed+=1;write(RUN/"status.json",dict(status="running",completed=completed,counts=dict(counts)));print("221",completed,path.stem,flush=True)
    assert completed==64 and dict(counts)==design["expected"],(completed,dict(counts),design["expected"])
    assert all(sha(R/p)==h for p,h in design["source_hashes"].items())
    write(RUN/"status.json",dict(status="complete",qualified=True,completed=64,counts=dict(counts),original_wholeblock_jacobian_qualified=False))
if __name__=="__main__":main()
