# 221b: can one projection explain the joint gate/up direction?

Registered while221 runs and before inspecting its saved gate/up weight rows. No new model call. This is a separate architecture/geometry diagnostic, not a change to221.

Hypothesis: for6411 or3902 the effective gate and up projection rows may be nearly opposite. If so, some observed opposing parent changes follow a common coordinate rather than requiring two independent causes. Compute rows a=W_gate[i]*gamma_postRMS and b=W_up[i]*gamma_postRMS; alpha=(a dot b)/(a dot a), b_perp=b-alpha*a. Near-opposite geometry requires cosine<=-.8. No alpha is fitted to any state.

The weights-only phase saves cosines, alpha, norms, residual energy, exact row identities and hashes. After221 is independently qualified, test the frozen weight-only prediction DeltaUp=alpha*DeltaGate on the fully native-attention, finite-RMS N11/P11 versus source00 preactivations. Save actual normalized-input changes h=mid*gain−source_mid*source_gain and independently verify DeltaUp−alpha*DeltaGate=b_perp dot h within1e-4. The one-coordinate approximation needs relative absolute up error<=.25 with native magnitude>=.001 in at least75% of cases in EVERY schema/order stratum; report all cases and all norms. Missing/near-zero targets fail rather than passing vacuously.

This predicts one measured parent from another measured parent, not an unknown native response from False alone. It does not establish a learned feature or eliminate the need to explain the upstream coordinate. A failed near-opposite/one-coordinate test means state-dependent joint projection is still required. No thresholds change after execution; source immutable after its first execution. Preserve qualified221 and all prior failures.
