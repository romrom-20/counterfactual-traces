"""Frozen weights-only geometry followed by a separately saved state diagnostic."""

import argparse,hashlib,json
from pathlib import Path
import numpy as np

R=Path(__file__).resolve().parents[1];RUN=R/"runs/native-receiver-factorial-221"
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    p=argparse.ArgumentParser();p.add_argument("--states",action="store_true");args=p.parse_args()
    wp=R/"docs/analysis/221b-projection-geometry-weights.json"
    with np.load(RUN/"weights.npz") as z:
        a=z["gate_units"].astype(np.float64)*z["post_norm"];b=z["up_units"].astype(np.float64)*z["post_norm"]
    geometry=[]
    for j,i in enumerate((6411,3902)):
        alpha=float(a[j]@b[j]/(a[j]@a[j]));perp=b[j]-alpha*a[j];cos=float(a[j]@b[j]/(np.linalg.norm(a[j])*np.linalg.norm(b[j])))
        geometry.append(dict(neuron=i,cosine=cos,alpha=alpha,gate_norm=float(np.linalg.norm(a[j])),up_norm=float(np.linalg.norm(b[j])),
            perpendicular_fraction=float(np.linalg.norm(perp)/np.linalg.norm(b[j])),near_opposite=cos<=-.8))
    if not args.states:
        assert not wp.exists();wp.write_text(json.dumps(dict(scope="Weights-only geometry; no target states used.",geometry=geometry,weights_sha256=sha(RUN/"weights.npz"),source_sha256=sha(Path(__file__)),
            protocol_sha256=sha(R/"docs/experiments/221b-gate-up-projection-geometry.md")),indent=2)+"\n");print(json.dumps(geometry,indent=2));return
    frozen=json.loads(wp.read_text());assert frozen["geometry"]==geometry and frozen["source_sha256"]==sha(Path(__file__))
    audit=json.loads((R/"docs/analysis/221-native-receiver-factorial.json").read_text());assert audit["qualified"]
    out=R/"docs/analysis/221b-projection-geometry-states.json";assert not out.exists();rows=[];maxclosure=0.
    for path in sorted((RUN/"pairs").glob("*.npz")):
        rec=json.loads(path.with_suffix(".json").read_text());assert sha(path)==rec["arrays_sha256"]
        with np.load(path) as z:
            source="F_F_00"
            for branch in ("N","P"):
                target="F_F_"+branch+"11";h=z[target+"_mid"][-1].astype(np.float64)*z[target+"_gain"][-1]-z[source+"_mid"][-1].astype(np.float64)*z[source+"_gain"][-1]
                for j,g in enumerate(geometry):
                    dg=float(z[target+"_gate_units"][-1,j]-z[source+"_gate_units"][-1,j]);du=float(z[target+"_up"][-1,g["neuron"]]-z[source+"_up"][-1,g["neuron"]])
                    predicted=g["alpha"]*dg;perp=float((b[j]-g["alpha"]*a[j])@h);closure=abs(du-predicted-perp);maxclosure=max(maxclosure,closure);assert closure<=1e-4
                    relative=abs(du-predicted)/abs(du) if abs(du)>=.001 else None
                    rows.append(dict(context=path.stem,group=rec["group"],background=branch,neuron=g["neuron"],delta_gate=dg,delta_up=du,predicted_up=predicted,
                        perpendicular_projection=perp,closure=closure,relative_error=relative,passed=bool(relative is not None and relative<=.25)))
    summaries=[]
    for neuron in (6411,3902):
        for branch in ("N","P"):
            rr=[r for r in rows if r["neuron"]==neuron and r["background"]==branch];strata=[]
            for schema in ("generic","descriptive"):
                for order in (0,1):
                    s=[r for r in rr if r["group"]["schema"]==schema and r["group"]["reverse"]==order];assert len(s)==16
                    strata.append(dict(schema=schema,order=order,passes=sum(r["passed"] for r in s),count=len(s),passed=sum(r["passed"] for r in s)>=12))
            summaries.append(dict(neuron=neuron,background=branch,passes=sum(r["passed"] for r in rr),median_relative_error=float(np.median([r["relative_error"] for r in rr if r["relative_error"] is not None])),
                whole_pass=all(s["passed"] for s in strata),strata=strata))
    out.write_text(json.dumps(dict(scope="Retrospective weight-only prediction of one observed parent from another, not False-only prediction of the native state.",geometry=geometry,maximum_identity_error=maxclosure,
        weights_report_sha256=sha(wp),audit_sha256=sha(R/"docs/analysis/221-native-receiver-factorial.json"),summaries=summaries,rows=rows),indent=2)+"\n")
    print(json.dumps(dict(geometry=geometry,maximum_identity_error=maxclosure,summaries=summaries),indent=2))
if __name__=="__main__":main()
