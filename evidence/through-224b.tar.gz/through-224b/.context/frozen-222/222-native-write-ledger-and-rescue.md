# 222: native residual-write ledger, upstream knockout and direction-specific rescue

Registered before222 model execution/ledger analysis. 221's native bridge passed, and its parent response was largely carried into block28. Preserve all prior evidence, including220 rejection,221's strict sufficiency failures,221b's rejected mirrored-row hypothesis and221c's dtype-only audit correction. No browser, fitting, learning, global correction sweep, publication or Git mutation. New scientific sources/auditor/protocol are copied before execution and immutable afterward; corrections separately named without changing bounds.

## Exact ledger, with a deliberately limited interpretation

All64 old208 contexts: run ordinary native False/True models, capturing actual attention output, MLP output, post-attention residual and block output at receiver rows. At the verdict row the initial embedding is unchanged. For layers1..27 the native displacement obeys

    Delta r27 = sum_l(Delta attention_l + Delta MLP_l + Delta addition-rounding_l).

Save both actual addition-rounding terms per block and verify vector closure in CPU64<=1e-9. This is an exact additive ledger of finite native writes. It is not a Taylor decomposition, a causal allocation or a separation of all nonlinear creation from amplification.

Use fixed linear probes from the source-matched block28 normalization intervention already qualified in221: the gate/up weight rows for6411 and3902 times learned MLP RMS weight and source00 inverse RMS scale. The projected final carry must replay221's N10-minus00 preactivation difference with source-fixed scale at1e-4. This directly measures the direction already localized by221 without a new whole-block Jacobian.

## Frozen operation selection

Use only chalice/gimbal (32 old contexts) to rank54 operations: attention/MLP writes in blocks1..27. For each context, normalize the actual final two-dimensional6411 carry projection; score an operation by its signed projection onto that direction. Average scores across those32 contexts; tie by block then attention beforeMLP. Select the two highest POSITIVE operations, or stop if fewer than two. Freeze selection.json before any causal intervention. Larch/marzipan are excluded from operation selection and supply32 retrospective causal cases. These are previously observed synthetic families, not fresh examples.

Report all54 signed projections, cumulative trajectories, positive/negative cancellation, and3902 control projections. A dominant ledger term alone does not establish a mechanism.

## Finite causal tests on the32 operation-excluded contexts

Every arm is an ordinary True-input model with one or two explicit receiving-write interventions; all other blocks remain fully finite/native. Prefix and known Boolean-source rows are preserved. A single intervention therefore starts from the actual native incoming state at that operation, rather than from the inaccurate P trajectory.

For each selected operation capture original native write wN and nativeFalse write wF. Define d=wN−wF. The fixed rank-two plane is span of the final block's effective gate/up weight rows for6411 (learned RMS weight included); it is defined from weights, not fitted to native targets. Project each receiver row into this plane using the stable2×2 Gram matrix.

Seven arms per operation:

1. False clamp: replace receivers by wF.
2. Full rescue: wF+d; must replay the native computation.
3. Plane rescue: wF+P_plane d.
4. Complement rescue: wF+(I−P_plane)d.
5. Norm-matched random edit: wN+random vector matched to the False-clamp edit's receiving Frobenius norm.
6. Plane-norm-matched random rescue: wF+random vector matched to P_plane d; same deterministic random orientation as5, seed from context/operation.
7. Source-only write: receiving write from an actual local native block supplied with False receivers and the known exact Boolean-source state. This distinguishes a direct-source write at the selected block from a write requiring native receiving history.

Also remove both selected writes together, and apply the matched random edits at both sites. Total16 arms/context,512 ordinary intervention models. When both sites are changed, the second fixed clamp is a declared second intervention, not an assertion that its incoming state is still native. Source-only local blocks are evaluated only at the two selected operation layers (reuse if same layer),32 cases each. No neural index is interpreted as a learned feature.

## Outcomes and causal gate

For each ordinary native/intervened model record final boundary27 carry, native last-block6411/3902 gate/up parents, and the frozen32 mixed-product finite common-readout effect using the exact native attention target from221. Execute actual affine/selected down-inputs and finite heads; replay each selected-product result through the public last block. Save actual operands, write edits, state displacements, scores and arithmetic. Old full residual/verdict accuracy bounds are unchanged and are not success criteria for these oracle tests.

For each single selected operation, a strong direction-specific account requires on at least24/32 cases AND at least6/8 in EACH schema/order stratum:

- False clamp reduces the positive native finite32 effect to at most50% of its native value. Native effects<=.02 fail eligibility rather than passing vacuously.
- Plane rescue recovers parent pair to relativeL2<=.25 and finite32 effect to absolute error<=.10 nats, and is closer to native than BOTH complement rescue and plane-norm random rescue.
- Full rescue passes original1e-4 state/.005 score replay controls in every case.

Report all components separately, both operations, both-site removal, every case and Source-only replacement. This is a predeclared causal action gate, not a statistical significance test. If it fails, retain the ledger as descriptive and the knockout evidence only at its supported scope. Do not select a new operation, fit a rotation, relax thresholds or launch a new predictor in222.

## Qualification and counters

Pinned offline Qwen/MPS Float32/eager/eval. No whole-block JVP is used; its earlier coordinate disagreement remains unresolved. Check ordinary native/False trajectories against old208/215 and221, support of Boolean edit, source/prefix preservation, ledger closure, fixed-probe projection replay, applied hook operands and full-rescue endpoints at original bounds. Every product-affine derivative is checked against actual local first AD<=1e-4. Independent CPU64 finite-head replay<=.005; ideal mixed-vector raw failures remain reported, with measured cast/down/add rounding closure<=1e-9.

Expected ordinary model calls:128 ledger models+512 causal models=640. Actual selected-product public last-block replays:576 (64 original native+512 interventions). Explicit down projections:1,152; explicit finite heads:2,368 (64 False checks+4×576 target evaluations). Product derivative checks:576. Reconstruct32 False final-block anchors for the causal phase. Source-only local blocks:32×number of unique selected layers, at most64. CPU64 algebra/model loading excluded. Freeze selection before causal models, hash-bind all parents and inspect every audit assertion before interpretation. No prospective prediction or QuestionB solution is claimed by the ledger or rescue alone.
