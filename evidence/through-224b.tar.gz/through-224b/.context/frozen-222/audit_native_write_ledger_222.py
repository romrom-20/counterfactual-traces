"""Independent finite-write ledger, frozen operation selection and causal rescue audit."""

import hashlib,json,itertools
from pathlib import Path
import numpy as np

R=Path(__file__).resolve().parents[1];RUN=R/"runs/native-write-ledger-222";OUT=R/"docs/analysis/222-native-write-ledger.json"
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def margin(s):return float(s[1]-s[0])
def head(x,w):
    h=x[-1].astype(np.float64);return(h/np.sqrt(np.mean(h*h)+float(w["eps"]))*w["norm"])@w["head"].T

def main():
    assert not OUT.exists();design=json.loads((RUN/"design.json").read_text());status=json.loads((RUN/"status.json").read_text());sel=json.loads((RUN/"selection.json").read_text());seal=json.loads((RUN/"selection-seal.json").read_text())
    assert all(sha(R/p)==h for p,h in design["source_hashes"].items()) and status["status"]=="complete" and status["qualified"]
    expected=dict(design["expected_base"],anchor_blocks=32,source_blocks=32*len({o["layer"] for o in sel["operations"]}));assert status["counts"]==expected
    assert sha(RUN/"selection.json")==seal["sha256"] and seal["intervention_models_before_seal"]==0
    w=dict(np.load(RUN/"weights.npz"));down=w["down"].astype(np.float64);basis=w["basis"].astype(np.float64);projector=basis.T@np.linalg.solve(basis@basis.T,basis)
    assert np.max(abs(projector@projector-projector))<=1e-9 and np.max(abs(projector-projector.T))<=1e-9
    mask=design["mask"];checks=[];ledger=[];causal=[];score_records=[];maxledger=0.;maxclosure=0.;maxhead=0.;maxprobe=0.;rawfail=0;rawmax=0.;local=[]
    def audit_target(z,prefix,anchor):
        nonlocal maxclosure,maxhead,rawfail,rawmax
        get=lambda name:z[prefix+name]
        phi=get("phi").astype(np.float64);up=get("up").astype(np.float64);dp=phi-anchor["False_phi"].astype(np.float64);du=up-anchor["False_up"].astype(np.float64)
        selected=np.zeros_like(dp);selected[:,mask]=dp[:,mask]*du[:,mask];selected[0]=0
        affine=anchor["False_product"].astype(np.float64)+dp*anchor["False_up"]+anchor["False_phi"]*du
        assert np.max(abs(get("L_product")-affine.astype(np.float32)))<=1e-4 and np.max(abs(get("G_product")-(affine+selected).astype(np.float32)))<=1e-4
        actual=get("G_state").astype(np.float64)-get("L_state").astype(np.float64);assert np.max(abs(actual[0]))==0
        p0=get("L_product").astype(np.float64);p1=get("G_product").astype(np.float64);d0=get("L_down").astype(np.float64);d1=get("G_down").astype(np.float64);mid=get("mid").astype(np.float64)
        pr=(p1-p0-selected)@down.T;dr=(d1-p1@down.T)-(d0-p0@down.T);rr=(get("G_state").astype(np.float64)-mid-d1)-(get("L_state").astype(np.float64)-mid-d0)
        closure=float(np.max(abs(actual-selected@down.T-pr-dr-rr)));maxclosure=max(maxclosure,closure);assert closure<=1e-9
        raw=float(np.max(abs(actual-selected@down.T)));rawfail+=raw>1e-4;rawmax=max(rawmax,raw)
        common=(anchor["false_final"].astype(np.float64)+actual).astype(np.float32);assert np.max(abs(common-get("common_state")))==0
        assert np.max(abs(get("G_state")-get("replay_state")))<=1e-4 and np.max(abs(get("G_scores")-get("replay_scores")))<=.005
        for state,scores in ((common,get("common_scores")),(get("L_state"),get("L_scores")),(get("G_state"),get("G_scores"))):
            error=float(np.max(abs(head(state,w)-scores)));maxhead=max(maxhead,error);assert error<=.005
        p6411=np.array([dp[-1,6411],du[-1,6411]]);p3902=np.array([dp[-1,3902],du[-1,3902]])
        assert np.max(abs(p6411-get("parents6411")))==0 and np.max(abs(p3902-get("parents3902")))==0
        error=float(get("local_derivative_error"));assert error<=1e-4;local.append(error)
        return dict(group_effect=margin(get("common_scores"))-margin(anchor["false_scores"]),parents6411=p6411.tolist(),parents3902=p3902.tolist(),initial6411=float(get("initial6411")))
    for path in sorted((RUN/"ledger").glob("*.npz")):
        rec=json.loads(path.with_suffix(".json").read_text());assert sha(path)==rec["arrays_sha256"]
        assert sha(R/"runs/source-receiver-partition-208/forecasts"/path.name)==rec["parent208_sha256"] and sha(R/"runs/native-receiver-factorial-221/pairs"/path.name)==rec["parent221_sha256"]
        checks.extend(rec["checks"]);z=dict(np.load(path));assert all(np.isfinite(v).all() for v in z.values())
        for label in ("F","N"):
            state=z[label+"_states"].astype(np.float64);a=z[label+"_attention"].astype(np.float64);m=z[label+"_mlp"].astype(np.float64);mid=z[label+"_mid"].astype(np.float64)
            assert np.max(abs(mid-state[:-1]-a-z[label+"_round_attention"]))<=1e-9
            assert np.max(abs(state[1:]-mid-m-z[label+"_round_mlp"]))<=1e-9
        delta=z["N_states"].astype(np.float64)-z["F_states"].astype(np.float64)
        wa=z["N_attention"].astype(np.float64)-z["F_attention"];wm=z["N_mlp"].astype(np.float64)-z["F_mlp"]
        rounding=z["N_round_attention"]-z["F_round_attention"]+z["N_round_mlp"]-z["F_round_mlp"]
        gap=float(np.max(abs(delta[27]-delta[0]-np.sum(wa[:27]+wm[:27]+rounding[:27],axis=0))));maxledger=max(maxledger,gap);assert gap<=1e-9
        projections=np.array([d@z["probes"].T for pair in zip(wa[:27,-1],wm[:27,-1]) for d in pair])
        assert np.max(abs(projections-z["operation_projection"]))<=1e-9
        t=delta[27,-1]@z["probes"].T;assert np.max(abs(t-z["carry_projection"]))<=1e-9
        with np.load(R/"runs/native-receiver-factorial-221/pairs"/path.name) as old:
            gain=float(old["source_gain_F"][-1,0]);probes=np.stack((w["gate"][0]*w["gamma"],w["up"][0]*w["gamma"],w["gate"][1]*w["gamma"],w["up"][1]*w["gamma"]))*gain
            assert np.max(abs(probes-z["probes"]))<=1e-9
            exp=np.array([old["F_S_N10_gate_units"][-1,0]-old["F_S_00_gate_units"][-1,0],old["F_S_N10_up"][-1,6411]-old["F_S_00_up"][-1,6411],old["F_S_N10_gate_units"][-1,1]-old["F_S_00_gate_units"][-1,1],old["F_S_N10_up"][-1,3902]-old["F_S_00_up"][-1,3902]])
            err=float(np.max(abs(t-exp)));maxprobe=max(maxprobe,err);assert err<=1e-4
        native=audit_target(z,"native_",z)
        score=projections[:,:2]@(t[:2]/np.linalg.norm(t[:2]));score_records.append((rec,score))
        cumulative=(delta[:28,-1]@z["probes"].T).tolist();ledger.append(dict(context=path.stem,group=rec["group"],carry_projection=t.tolist(),operation_projection=projections.tolist(),
            cumulative=cumulative,projected_rounding=(rounding[:27,-1]@z["probes"].T).tolist(),native=native))
        if path.stem not in sel["excluded"]:continue
        ip=RUN/"interventions"/path.name;ir=json.loads(ip.with_suffix(".json").read_text());assert sha(ip)==ir["arrays_sha256"] and ir["selection_sha256"]==seal["sha256"] and ir["ledger_sha256"]==rec["arrays_sha256"]
        checks.extend(ir["checks"]);iz=dict(np.load(ip));assert all(np.isfinite(v).all() for v in iz.values()) and len(ir["jobs"])==16
        for op in sel["operations"]:
            i,l,kind=op["index"],op["layer"]-1,op["kind"];d=z["N_"+kind][l].astype(np.float64)-z["F_"+kind][l].astype(np.float64);d[0]=0
            p=d@projector;comp=d-p;random=iz[f"op{i}_random_unit"];assert abs(np.linalg.norm(random)-1)<=1e-9 and np.max(abs(random[0]))==0
            for name,expected in (("delta",d),("plane_component",p),("clamp",z["F_"+kind][l]),("full",z["F_"+kind][l]+d),("plane",z["F_"+kind][l]+p),("complement",z["F_"+kind][l]+comp),
                ("rand_edit",z["N_"+kind][l]+random*np.linalg.norm(d)),("rand_rescue",z["F_"+kind][l]+random*np.linalg.norm(p))):
                assert np.max(abs(iz[f"op{i}_{name}"]-expected))<=1e-9
        for job in ir["jobs"]:
            label=job["label"];measured=audit_target(iz,label+"_",z)
            for index,arm in job["patches"].items():
                after=iz[f"{label}_op{index}_after"];before=iz[f"{label}_op{index}_before"];expected=iz[f"op{index}_{arm}"]
                assert np.max(abs(after[1:]-expected[1:].astype(np.float32)))==0 and np.max(abs(after[0]-before[0]))==0
            if label.endswith("_full"):
                assert np.max(abs(iz[label+"_input27"]-z["N_states"][27]))<=1e-4 and np.max(abs(iz[label+"_native_final"]-z["N_states"][28]))<=1e-4 and np.max(abs(iz[label+"_native_scores"]-z["N_scores"]))<=.005
            targetpair=np.array(native["parents6411"]);q=float(np.linalg.norm(np.array(measured["parents6411"])-targetpair)/np.linalg.norm(targetpair));m=abs(measured["group_effect"]-native["group_effect"])
            native_delta=z["N_states"][-1,1:].astype(np.float64)-z["F_states"][-1,1:].astype(np.float64)
            final_edit=iz[label+"_native_final"][1:].astype(np.float64)-z["N_states"][-1,1:].astype(np.float64)
            causal.append(dict(context=path.stem,group=rec["group"],label=label,patches=job["patches"],native_group=native["group_effect"],native_parents=native["parents6411"],**measured,
                final_native_response_relative_error=float(np.linalg.norm(final_edit)/np.linalg.norm(native_delta)),final_residual_edit_norm=float(np.linalg.norm(final_edit)),
                native_margin=margin(z["N_scores"]),intervened_margin=margin(iz[label+"_native_scores"]),final_margin_change=margin(iz[label+"_native_scores"])-margin(z["N_scores"]),
                parent_relative_error=q,group_error=m,rescue_pass=bool(q<=.25 and m<=.1),erasure_pass=bool(native["group_effect"]>.02 and measured["group_effect"]<=.5*native["group_effect"])))
    assert len(ledger)==64 and len(causal)==512 and len(local)==576 and all(c["error"]<=c["bound"] for c in checks)
    means=np.mean([s for r,s in score_records if r["group"]["block"] in ("chalice","gimbal")],axis=0);order=np.lexsort((np.arange(54),-means));chosen=[int(i) for i in order if means[i]>0][:2]
    assert chosen==[o["index"] for o in sel["operations"]] and np.max(abs(means-sel["scores"]))<=1e-9
    gates=[]
    for j,op in enumerate(sel["operations"]):
        values=[]
        for context in sel["excluded"]:
            rr={r["label"]:r for r in causal if r["context"]==context};clamp=rr[f"op{j}_clamp"];plane=rr[f"op{j}_plane"];comp=rr[f"op{j}_complement"];random=rr[f"op{j}_rand_rescue"]
            wins=plane["group_error"]<comp["group_error"] and plane["group_error"]<random["group_error"]
            values.append(dict(context=context,group=plane["group"],erase=clamp["erasure_pass"],rescue=plane["rescue_pass"],beats_both=wins,combined=bool(clamp["erasure_pass"] and plane["rescue_pass"] and wins)))
        strata=[]
        for schema,order_value in itertools.product(("generic","descriptive"),range(2)):
            rr=[r for r in values if r["group"]["schema"]==schema and r["group"]["reverse"]==order_value];assert len(rr)==8
            strata.append(dict(schema=schema,order=order_value,counts={k:sum(bool(r[k]) for r in rr) for k in ("erase","rescue","beats_both","combined")}))
        totals={k:sum(bool(r[k]) for r in values) for k in ("erase","rescue","beats_both","combined")}
        gates.append(dict(operation=op,totals=totals,strata=strata,passed=bool(totals["combined"]>=24 and all(s["counts"]["combined"]>=6 for s in strata))))
    summaries=[]
    for label in sorted({r["label"] for r in causal}):
        for schema in (None,"generic","descriptive"):
            rr=[r for r in causal if r["label"]==label and (schema is None or r["group"]["schema"]==schema)]
            summaries.append(dict(label=label,schema=schema,count=len(rr),median_group=float(np.median([r["group_effect"] for r in rr])),median_group_error=float(np.median([r["group_error"] for r in rr])),
                median_parent_relative=float(np.median([r["parent_relative_error"] for r in rr])),rescue_passes=sum(r["rescue_pass"] for r in rr),erasure_passes=sum(r["erasure_pass"] for r in rr)))
    result=dict(qualified=True,contexts_ledger=64,contexts_causal=32,counts=status["counts"],controls=len(checks),product_derivative_checks=len(local),maximum_product_derivative_error=max(local),
        maximum_ledger_error=maxledger,maximum_probe_replay_error=maxprobe,maximum_rounding_closure=maxclosure,maximum_head_error=maxhead,raw_ideal_failures=int(rawfail),raw_ideal_comparisons=len(local),maximum_raw_ideal_error=rawmax,
        selected_operations=sel["operations"],scores=sel["scores"],gates=gates,summaries=summaries,ledger=ledger,causal=causal,
        prospective=False,original_wholeblock_jacobian_qualified=False,full_question_B_solved=False,
        scope="Retrospective native-write ledger plus finite knockouts/rescues on operation-excluded old families. A projection ledger is not a causal fraction or learned circuit; no False-only prospective predictor.",auditor_sha256=sha(Path(__file__)))
    OUT.write_text(json.dumps(result,indent=2,default=lambda x:x.item() if isinstance(x,np.generic) else str(x))+"\n")
    print(json.dumps({k:v for k,v in result.items() if k not in ("ledger","causal","summaries","scores")},indent=2));print(json.dumps(summaries,indent=2))
if __name__=="__main__":main()
