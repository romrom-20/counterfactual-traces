"""Actual native write captures, rank-two projection and local finite product measurement."""

from contextlib import contextmanager
import torch
from torch.nn import functional as F

@contextmanager
def writes(model,pos):
    values={k:[] for k in ("attention","mlp","mid")};handles=[]
    def save(name):
        def hook(module,args,out):values[name].append(out[0,pos:].detach().cpu().clone())
        return hook
    def before(module,args):values["mid"].append(args[0][0,pos:].detach().cpu().clone())
    for layer in model.model.layers:
        handles.extend((layer.self_attn.o_proj.register_forward_hook(save("attention")),layer.mlp.down_proj.register_forward_hook(save("mlp")),layer.post_attention_layernorm.register_forward_pre_hook(before)))
    try:yield values
    finally:
        for h in handles:h.remove()

def plane_projection(delta,basis):
    gram=basis@basis.T
    return (delta@basis.T)@torch.linalg.solve(gram,basis)

def products(layer,cap,false,mask,pos):
    dp=cap["phi"]-false["phi"];du=cap["up"]-false["up"]
    derivative=dp*false["up"]+false["phi"]*du
    device=layer.down_proj.weight.device if hasattr(layer,"down_proj") else layer.mlp.down_proj.weight.device
    _,j=torch.func.jvp(lambda p,u:p*u,(false["phi"].to(device=device,dtype=torch.float32),false["up"].to(device=device,dtype=torch.float32)),
        (dp.to(device=device,dtype=torch.float32),du.to(device=device,dtype=torch.float32)))
    error=float((j.detach().cpu().double()-derivative).abs().max());assert error<=1e-4,error
    affine=false["product"]+derivative;mix=torch.zeros_like(dp);mix[:,:,mask]=dp[:,:,mask]*du[:,:,mask];mix[:,:pos+1]=0
    return affine.to(device=device,dtype=torch.float32),(affine+mix).to(device=device,dtype=torch.float32),mix,error
