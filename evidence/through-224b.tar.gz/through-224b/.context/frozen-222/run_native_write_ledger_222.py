"""Signed native-write ledger followed by frozen upstream knockouts and rescues."""

import hashlib,json
from collections import Counter
from contextlib import contextmanager
from pathlib import Path
import numpy as np
import torch
from torch.nn import functional as F
import ranked_block_response_201 as public
from native_receiver_factorial_221 import captured
from native_write_ledger_222 import writes,plane_projection,products
from latent_decisions.target import load_target
from latent_decisions.evidence_policy import digest

R=Path(__file__).resolve().parents[1];RUN=R/"runs/native-write-ledger-222"
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def cpu(t):return t.detach().cpu().numpy().copy()
def write(p,o):p.write_text(json.dumps(o,indent=2,default=lambda x:x.item() if isinstance(x,np.generic) else str(x))+"\n")

def main():
    assert not RUN.exists()
    previous=R/"results/native-receiver-factorial-221/manifest.json";old=json.loads(previous.read_text());assert len(old["files"])==2428 and all(sha(R/p)==h for p,h in old["files"].items())
    files=["scripts/run_native_write_ledger_222.py","scripts/native_write_ledger_222.py","scripts/audit_native_write_ledger_222.py","docs/experiments/222-native-write-ledger-and-rescue.md",
        "scripts/native_receiver_factorial_221.py","scripts/gate_up_arithmetic_213.py","scripts/ranked_block_response_201.py","src/latent_decisions/target.py"]
    rtfile=R/"runs/source-receiver-partition-208/runtime.json";rt=json.loads(rtfile.read_text());maskfile=R/"runs/neuron-mixed-interventions-219/selection.json";mask=json.loads(maskfile.read_text())["ranking"][:32]
    RUN.mkdir();(RUN/"ledger").mkdir();(RUN/"interventions").mkdir()
    design=dict(source_hashes={p:sha(R/p) for p in files},prior_manifest_sha256=sha(previous),runtime_sha256=sha(rtfile),selection219_sha256=sha(maskfile),mask=mask,
        expected_base=dict(ordinary_models=640,public_target_blocks=576,direct_down=1152,finite_heads=2368,local_product_checks=576))
    write(RUN/"design.json",design);write(RUN/"runtime.json",rt)
    model,tok,device=load_target(rt["model"],"mps",offline=True);torch.set_num_threads(2)
    assert digest(tok.get_vocab())==rt["tokenizer_hash"] and digest(model.config.to_dict())==rt["config_hash"]
    assert not model.training and model.config._attn_implementation=="eager" and next(model.parameters()).dtype==torch.float32
    last=model.model.layers[27];down=last.mlp.down_proj.weight.detach().cpu().double();gamma=last.post_attention_layernorm.weight.detach().cpu().double()
    gate=last.mlp.gate_proj.weight[[6411,3902]].detach().cpu().double();up=last.mlp.up_proj.weight[[6411,3902]].detach().cpu().double()
    basis=torch.stack((gate[0]*gamma,up[0]*gamma));assert float(torch.linalg.det(basis@basis.T))>1e-6
    np.savez_compressed(RUN/"weights.npz",down=cpu(down),gate=cpu(gate),up=cpu(up),gamma=cpu(gamma),basis=cpu(basis),norm=cpu(model.model.norm.weight),head=cpu(model.lm_head.weight[[895,830]]),eps=np.array(model.model.norm.variance_epsilon))
    counts=Counter();records=[];scores=[]
    def head(x):
        with torch.no_grad():s=public.head(model,x)
        counts["finite_heads"]+=1;return cpu(s).astype(np.float64)
    def target(cap,false,states,context,yf,pos,projection_weights,check):
        with torch.no_grad():p0,p1,mix,error=products(last,cap,false,mask,pos)
        counts["local_product_checks"]+=1
        outs={};ds={};ss={}
        mid=cap["mid"].to(device=device,dtype=torch.float32)
        for label,p in (("L",p0),("G",p1)):
            with torch.no_grad():d=last.mlp.down_proj(p);out=mid+d
            counts["direct_down"]+=1;outs[label]=out;ds[label]=d;ss[label]=head(out)
        effect=outs["G"].cpu().double()-outs["L"].cpu().double();check("target_source_prefix",effect[:,:pos+1].abs().max(),0.)
        common=(yf.cpu().double()+effect).to(device=device,dtype=torch.float32);cs=head(common)
        handle=last.mlp.down_proj.register_forward_pre_hook(lambda module,args:(p1,))
        try:
            with torch.no_grad():replay=public.block(last,states[26],context)
        finally:handle.remove()
        counts["public_target_blocks"]+=1;rs=head(replay);check("target_public_state",(replay-outs["G"]).abs().max());check("target_public_head",np.max(abs(rs-ss["G"])),.005)
        p0c=p0[0,pos:].cpu().double();p1c=p1[0,pos:].cpu().double();d0=ds["L"][0,pos:].cpu().double();d1=ds["G"][0,pos:].cpu().double();m=cap["mid"][0,pos:]
        e=effect[0,pos:];ideal=F.linear(mix[0,pos:],down);pr=F.linear(p1c-p0c-mix[0,pos:],down)
        dr=(d1-F.linear(p1c,down))-(d0-F.linear(p0c,down));rr=(outs["G"][0,pos:].cpu().double()-m-d1)-(outs["L"][0,pos:].cpu().double()-m-d0)
        check("target_rounding_closure",(e-ideal-pr-dr-rr).abs().max(),1e-9)
        dp=cap["phi"][0,-1]-false["phi"][0,-1];du=cap["up"][0,-1]-false["up"][0,-1]
        return dict(phi=cpu(cap["phi"][0,pos:]).astype(np.float32),up=cpu(cap["up"][0,pos:]).astype(np.float32),mid=cpu(m).astype(np.float32),
            L_product=cpu(p0c).astype(np.float32),G_product=cpu(p1c).astype(np.float32),L_down=cpu(d0).astype(np.float32),G_down=cpu(d1).astype(np.float32),
            L_state=cpu(outs["L"][0,pos:]),G_state=cpu(outs["G"][0,pos:]),L_scores=ss["L"],G_scores=ss["G"],common_state=cpu(common[0,pos:]),common_scores=cs,
            replay_state=cpu(replay[0,pos:]),replay_scores=rs,parents6411=np.array([float(dp[6411]),float(du[6411])]),parents3902=np.array([float(dp[3902]),float(du[3902])]),
            initial6411=np.array(float(projection_weights[6411]*dp[6411]*du[6411])),local_derivative_error=np.array(error))
    # Ledger phase: actual native pairs only, no operation intervention before selection is sealed.
    for path in sorted((R/"runs/source-receiver-partition-208/forecasts").glob("*.npz")):
        fr=json.loads(path.with_suffix(".json").read_text())["record"];assert sha(path)==fr["arrays_sha256"]
        p221=R/"runs/native-receiver-factorial-221/pairs"/path.name;group=fr["group"];pos=fr["position"];checks=[]
        def check(kind,error,bound=1e-4):checks.append(dict(kind=kind,error=float(error),bound=bound));assert error<=bound,checks[-1]
        with np.load(path) as fp,np.load(p221) as z221:
            pair={};caps={};fullstates={};contexts={};all_arrays={}
            for bit,label in ((0,"F"),(1,"N")):
                with writes(model,pos) as wc,captured(last) as cap:
                    states,context,ss=public.observe(model,torch.tensor([fr["bases"][bit]["free_input_ids"]],device=device))
                counts["ordinary_models"]+=1;cap["output"]=states[-1].cpu().double();caps[label]=cap;fullstates[label]=states;contexts[label]=context
                arrays={name:cpu(torch.stack(wc[name])) for name in wc};arrays["states"]=cpu(torch.stack([context["input"],*states])[:,0,pos:]);arrays["scores"]=cpu(ss)
                for name,a in arrays.items():all_arrays[label+"_"+name]=a
                pair[label]=arrays
                check("ordinary_prefix",max(float((s[:,:pos]-torch.tensor(fp["false_boundaries"][j+1][None,:pos],device=device)).abs().max()) for j,s in enumerate(states)))
            check("False_208",np.max(abs(pair["F"]["states"]-fp["false_boundaries"][:,pos:])))
            check("known_native_source",np.max(abs(pair["N"]["states"][1:,0]-fp["source_receiver_absolute_source"])))
            check("native221_input",np.max(abs(pair["N"]["states"][27]-z221["x_N"])));check("native221_final",np.max(abs(pair["N"]["states"][28]-z221["F_F_N11_F_state"])))
            check("embedding_receiver_support",np.max(abs(pair["N"]["states"][0,1:]-pair["F"]["states"][0,1:])),0.)
            yf=fullstates["F"][-1];sf=head(yf);check("False_head",np.max(abs(sf-pair["F"]["scores"])),.005)
            native=target(caps["N"],caps["F"],fullstates["N"],contexts["N"],yf,pos,torch.tensor(z221["projection_weights"]),check)
            for name,a in native.items():all_arrays["native_"+name]=a
            check("native221_target",np.max(abs(native["common_scores"]-z221["F_F_N11_G_common_scores"])),.005)
            for label in ("F","N"):
                states=pair[label]["states"].astype(np.float64);a=pair[label]["attention"].astype(np.float64);m=pair[label]["mlp"].astype(np.float64);mid=pair[label]["mid"].astype(np.float64)
                all_arrays[label+"_round_attention"]=mid-states[:-1]-a;all_arrays[label+"_round_mlp"]=states[1:]-mid-m
            delta=pair["N"]["states"].astype(np.float64)-pair["F"]["states"].astype(np.float64)
            writes_delta=(pair["N"]["attention"].astype(np.float64)-pair["F"]["attention"])+(pair["N"]["mlp"].astype(np.float64)-pair["F"]["mlp"])
            rounds=all_arrays["N_round_attention"]-all_arrays["F_round_attention"]+all_arrays["N_round_mlp"]-all_arrays["F_round_mlp"]
            closure=delta[27]-delta[0]-np.sum(writes_delta[:27]+rounds[:27],axis=0);check("native_write_ledger",np.max(abs(closure)),1e-9)
            gain=float(z221["source_gain_F"][-1,0]);probes=torch.stack((gate[0]*gamma,up[0]*gamma,gate[1]*gamma,up[1]*gamma))*gain;all_arrays["probes"]=cpu(probes)
            target_projection=cpu(probes@torch.tensor(delta[27,-1]));all_arrays["carry_projection"]=target_projection
            expected=np.array([z221["F_S_N10_gate_units"][-1,0]-z221["F_S_00_gate_units"][-1,0],z221["F_S_N10_up"][-1,6411]-z221["F_S_00_up"][-1,6411],
                z221["F_S_N10_gate_units"][-1,1]-z221["F_S_00_gate_units"][-1,1],z221["F_S_N10_up"][-1,3902]-z221["F_S_00_up"][-1,3902]])
            check("fixed_probe221",np.max(abs(target_projection-expected)))
            contributions=[]
            for l in range(27):
                for kind in ("attention","mlp"):
                    d=pair["N"][kind][l,-1].astype(np.float64)-pair["F"][kind][l,-1].astype(np.float64);contributions.append(cpu(probes@torch.tensor(d)))
            contributions=np.array(contributions);all_arrays["operation_projection"]=contributions
            t=target_projection[:2];assert np.linalg.norm(t)>=.001
            score=contributions[:,:2]@(t/np.linalg.norm(t));scores.append(dict(key=path.stem,group=group,score=score))
            for name in ("phi","up","product"):all_arrays["False_"+name]=cpu(caps["F"][name][0,pos:]).astype(np.float32)
            all_arrays["projection_weights"]=z221["projection_weights"].copy();all_arrays["false_final"]=pair["F"]["states"][-1];all_arrays["false_scores"]=sf
        out=RUN/"ledger"/path.name;np.savez_compressed(out,**all_arrays)
        rec=dict(key=path.stem,group=group,position=pos,bases=fr["bases"],arrays_sha256=sha(out),parent208_sha256=sha(path),parent221_sha256=sha(p221),checks=checks)
        write(out.with_suffix(".json"),rec);records.append(rec);write(RUN/"status.json",dict(status="ledger",completed=len(records),counts=dict(counts)));print("ledger",len(records),path.stem,flush=True)
    assert len(records)==64
    mean=np.mean([r["score"] for r in scores if r["group"]["block"] in ("chalice","gimbal")],axis=0)
    order=np.lexsort((np.arange(54),-mean));selected=[int(i) for i in order if mean[i]>0][:2];assert len(selected)==2
    selection=dict(scores=mean.tolist(),ranking=order.tolist(),operations=[dict(index=i,layer=i//2+1,kind="attention" if i%2==0 else "mlp") for i in selected],
        discovery=[r["key"] for r in records if r["group"]["block"] in ("chalice","gimbal")],excluded=[r["key"] for r in records if r["group"]["block"] in ("larch","marzipan")])
    write(RUN/"selection.json",selection);seal=sha(RUN/"selection.json");write(RUN/"selection-seal.json",dict(sha256=seal,intervention_models_before_seal=0))
    # Only the two operation-excluded old families are used for causal interventions.
    for rec in records:
        if rec["key"] not in selection["excluded"]:continue
        key=rec["key"];pos=rec["position"];fp=R/"runs/source-receiver-partition-208/forecasts"/(key+".npz")
        with np.load(RUN/"ledger"/(key+".npz")) as zz,np.load(fp) as old:
            z={k:zz[k].copy() for k in zz.files};fb=[torch.tensor(a[None],device=device) for a in old["false_boundaries"]]
            context=dict(mask=torch.tensor(old["mask"],device=device),rope=tuple(torch.tensor(old[k],device=device) for k in ("rope_cos","rope_sin")))
            # Reconstruct only the actual nativeFalse final MLP anchors for target measurement.
            with captured(last) as false,torch.no_grad():fy=public.block(last,fb[27],context)
            counts["anchor_blocks"]+=1;false["output"]=fy.cpu().double()
            checks=[]
            def check(kind,error,bound=1e-4):checks.append(dict(kind=kind,error=float(error),bound=bound));assert error<=bound,checks[-1]
            check("anchor_false",(fy-fb[28]).abs().max())
            baseline={};source_writes={};source_cache={}
            for op in selection["operations"]:
                l=op["layer"]-1;kind=op["kind"];d=torch.tensor(z["N_"+kind][l].astype(np.float64)-z["F_"+kind][l].astype(np.float64));d[0]=0
                plane=plane_projection(d,basis);plane[0]=0;complement=d-plane
                seed=int(hashlib.sha256((key+str(op["index"])).encode()).hexdigest()[:16],16);rng=np.random.default_rng(seed);random=torch.tensor(rng.standard_normal(d.shape));random[0]=0;random/=random.norm()
                n=torch.tensor(z["N_"+kind][l].astype(np.float64));f=torch.tensor(z["F_"+kind][l].astype(np.float64))
                baseline[op["index"]]=dict(clamp=f,full=f+d,plane=f+plane,complement=f+complement,rand_edit=n+random*d.norm(),rand_rescue=f+random*plane.norm(),
                    delta=d,plane_component=plane,random_unit=random)
                check("plane_orthogonality",float((basis@(d-plane).T).abs().max()),1e-9)
                if l not in source_cache:
                    operand=fb[l].clone()
                    if l==0:
                        with torch.no_grad():source=model.model.embed_tokens(torch.tensor([rec["bases"][1]["free_input_ids"]],device=device))[:,pos]
                    else:source=torch.tensor(old["source_receiver_absolute_source"][l-1][None],device=device)
                    operand[:,pos]=source
                    c={};hs=[]
                    for name,module in (("attention",model.model.layers[l].self_attn.o_proj),("mlp",model.model.layers[l].mlp.down_proj)):
                        def save(module,args,out,name=name):c[name]=out[0,pos:].detach().cpu().double().clone()
                        hs.append(module.register_forward_hook(save))
                    try:
                        with torch.no_grad():public.block(model.model.layers[l],operand,context)
                    finally:
                        for h in hs:h.remove()
                    counts["source_blocks"]+=1;source_cache[l]=c
                source_writes[op["index"]]=source_cache[l][kind];baseline[op["index"]]["source"]=source_writes[op["index"]]
            jobs=[(f"op{j}_{arm}",{op["index"]:arm}) for j,op in enumerate(selection["operations"]) for arm in ("clamp","full","plane","complement","rand_edit","rand_rescue","source")]
            jobs.extend((name,{op["index"]:arm for op in selection["operations"]}) for name,arm in (("both_clamp","clamp"),("both_random","rand_edit")))
            output={};results=[]
            for label,patches in jobs:
                handles=[];applied={}
                for op in selection["operations"]:
                    if op["index"] not in patches:continue
                    module=model.model.layers[op["layer"]-1].self_attn.o_proj if op["kind"]=="attention" else model.model.layers[op["layer"]-1].mlp.down_proj
                    replacement=baseline[op["index"]][patches[op["index"]]]
                    def patch(module,args,out,op=op,replacement=replacement):
                        value=out.clone();value[:,pos+1:]=replacement[None,1:].to(device=device,dtype=out.dtype)
                        check("patch_source_prefix",(value[:,:pos+1]-out[:,:pos+1]).abs().max(),0.)
                        applied[op["index"]]=dict(before=cpu(out[0,pos:]),after=cpu(value[0,pos:]));return value
                    handles.append(module.register_forward_hook(patch))
                try:
                    with captured(last) as cap:states,ctx,ss=public.observe(model,torch.tensor([rec["bases"][1]["free_input_ids"]],device=device))
                finally:
                    for h in handles:h.remove()
                counts["ordinary_models"]+=1;cap["output"]=states[-1].cpu().double();assert set(applied)==set(patches)
                check("ordinary_source",np.max(abs(cpu(torch.stack(states)[:,0,pos])-z["N_states"][1:,0])))
                check("ordinary_prefix",max(float((s[:,:pos]-fb[j+1][:,:pos]).abs().max()) for j,s in enumerate(states)))
                measured=target(cap,false,states,ctx,fb[28],pos,torch.tensor(z["projection_weights"]),check)
                for name,a in measured.items():output[label+"_"+name]=a
                output[label+"_input27"]=cpu(states[26][0,pos:]);output[label+"_native_final"]=cpu(states[-1][0,pos:]);output[label+"_native_scores"]=cpu(ss)
                for index,values in applied.items():
                    for name,a in values.items():output[f"{label}_op{index}_{name}"]=a
                if label.endswith("_full"):
                    check("full_rescue_input",np.max(abs(output[label+"_input27"]-z["N_states"][27])))
                    check("full_rescue_final",np.max(abs(output[label+"_native_final"]-z["N_states"][28])))
                    check("full_rescue_head",np.max(abs(output[label+"_native_scores"]-z["N_scores"])),.005)
                results.append(dict(label=label,patches={str(i):v for i,v in patches.items()}))
            for index,values in baseline.items():
                for name,a in values.items():output[f"op{index}_{name}"]=cpu(a).astype(np.float64)
            dest=RUN/"interventions"/(key+".npz");np.savez_compressed(dest,**output)
            write(dest.with_suffix(".json"),dict(key=key,group=rec["group"],selection_sha256=seal,ledger_sha256=rec["arrays_sha256"],arrays_sha256=sha(dest),checks=checks,jobs=results))
        write(RUN/"status.json",dict(status="intervening",completed=len(list((RUN/"interventions").glob("*.json"))),counts=dict(counts)));print("causal",key,flush=True)
    expected=dict(design["expected_base"],anchor_blocks=32,source_blocks=32*len({o["layer"] for o in selection["operations"]}))
    assert dict(counts)==expected,(dict(counts),expected)
    assert all(sha(R/p)==h for p,h in design["source_hashes"].items()) and sha(RUN/"selection.json")==seal
    write(RUN/"status.json",dict(status="complete",qualified=True,counts=dict(counts),expected=expected,original_wholeblock_jacobian_qualified=False))
if __name__=="__main__":main()
