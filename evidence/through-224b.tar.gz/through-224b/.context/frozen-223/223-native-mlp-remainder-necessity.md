# 223: do the nonlinear remainders of MLP22/23 causally matter?

Registered before model execution. Preserve the complete 2,561-file222 closure, all earlier qualifications/failures, and invalidity of replacement-agent conclusions. No browser, fitting, training, global predictor sweep, publication or Git mutation. Scientific helper, runner, auditor and this protocol are copied/hash-sealed before execution and immutable afterward. Corrections require separate names and unchanged bounds.

## Question and intervention

222 established influential native writes, not where the missing nonlinear response originates. At site l=22 or23, let s be the actual post-attention residual entering MLP-input RMSNorm, and define M_l(s)=MLP_l(RMS_l(s)). The False anchor is sF from the ordinary nativeFalse computation. Retain the actual False write wF and the numerically qualified False-state local derivative JF. Define

    A_l(s) = wF + JF (s-sF)
    R_l(s) = M_l(s) - A_l(s).

Only receiving rows after the Boolean source are edited. Removing R replaces the current finite write by A, preserving source/prefix and the False write plus linear response. All attention, residual additions, other MLPs and final readout remain native/finite. This is a retrospective intervention, not a False-only forecast.

Use exactly the32 larch/marzipan contexts excluded from operation selection in222; retain both schemas/orders and all assignment/target cells. Do not select new sites or neurons. Main factorial, ordered22/23: FF ordinary native, LF removeR22, FL removeR23, LL remove both. In LL, R23 is evaluated at the ACTUAL input produced after the22 intervention, not at a cached native23 input. The fixed False anchor/J do not change. A joint remove-and-reinsert-R sham must replay FF.

Three controls apply deterministic random edits at22,23 or both. Their proposed receiving Frobenius norms match the ACTUAL removed-write edit at corresponding sites in LF,FL,LL, respectively. For the joint control these are the LL realized reference norms, even though the random incoming state at23 differs. Seeds are SHA256(context+site); random directions do not use readout or target data. Save proposed and applied edits and casting errors. Also run a nativeFalse model with both affine replacements; zero input displacement must replay False.

## Local derivative qualification before interventions

StageQ:32 ordinaryFalse models; capture exact MPS Float32 False primals for both local M maps. Use frozen-primal CPU64 analytic chain rule for RMS, linear gate/up, SiLU, multiplication and down projection. Check all receiving output coordinates against direct public MPS first-forward AD at1e-4, and independent smooth CPU64 central differences at epsilon1e-5 at1e-4. CPU64 finite differences promote arithmetic and are not claimed to replay the MPS forward map. Three deterministic unit-norm sine covectors give independent public first-reverse contractions at .001+.0001*abs(reverse). Test native receiving direction plus norm-matched sine and cosine directions at both sites in all32 cases. Source/prefix derivative support is zero. False primals must replay at1e-4. No bias is allowed in gate/up/down projections.

Save operands, weights, tangents, finite differences, covectors and gradients. A separate saved-array audit rederives the local analytic chain in NumPy64, checks all qualification comparisons, and seals the32 qualification archives before StageI. StageI cannot start unless that audit passes. Every ACTUALLY realized StageI direction, including altered23 incoming directions, is again checked against direct MPS first AD, CPU64 central differences and the retained reverse gradients. A failure stops interpretation; no bound is relaxed. This does not recertify any old whole-block Jacobian.

## Primary measurements and action rule

Record signed full receiving final displacement, verdict-row displacement and actual finite true-minus-false score margin for every arm. Normalize intervention-native vector differences by the corresponding nativeTrue-minus-False displacement. Primary endpoints are verdict-row relativeL2 deviation and absolute natural margin change. Full receiver vectors, their projection onto native displacement and all scores remain reported separately. Do not add vector norms as causal fractions.

The original matching bounds define a response-preserving case: native verdict displacement norm>=.001, relativeL2<=.05, cosine>=.99 and absolute margin change<=.10nats. For each removal arm, a consistently material, direction-specific remainder effect requires relativeL2>.05 AND absolute margin change>.10, with BOTH larger than its matched random control, on at least24/32 cases AND6/8 in every schema/order stratum. Report each component and all cases; this is a causal action rule, not a significance test. Failure does not prove global linear sufficiency: a native tail can compensate an intervention, and omitted remainders can interact elsewhere.

Retain the frozen21932-neuron mixed-product finite common-False-readout diagnostic as SECONDARY only. Reproduce its native baseline from222. Execute the actual down projections, finite heads and a public final-block selected-product replay. A local diagnostic win cannot substitute for the primary endpoints. Compare with the already measured222 full-write clamp consequences descriptively; no causal percentage decomposition is claimed.

Only a consistently material local remainder warrants a later primitive factorial of RMSNorm, SiLU and gate-up multiplication. No fresh predictor, learned circuit, novelty priority or full QuestionB solution is claimed by223.

## Expected work and numerical accounting

StageQ:32 ordinaryFalse models;64 reverse forward maps/192 backwards;192 direct local JVPs,192 CPU64 directional central-difference comparisons and576 reverse contractions. StageI:32 False anchors+32 affine-False shams+256 ordinaryTrue models=320 ordinary models;576 direct local JVP/central-difference comparisons and1,728 reverse contractions, counting both sites in all8True arms and the False sham. Combined:352 ordinary models,768 local derivative directions/finite-difference comparisons,2,304 reverse contractions. StageI secondary:256 product derivative checks,512 explicit down projections,256 public selected-product final-block replays and1,056 explicit finite heads. All counters are asserted.

Source/prefix edits are exactly zero; source/prefix trajectories retain1e-4 state tolerance. Native and full-rescue states/scores replay at1e-4/.005. Measured CPU64 local remainder+Float32 casting accounting and secondary product/down/add arithmetic close at1e-9. Raw ideal product-vector discrepancies at1e-4 remain separately reported. Random proposed norms match within1e-9; actual cast norm error must stay within1e-4*max(1,reference norm). Independent CPU64 finite-head replay stays within.005. Every source, parent array, audit and forecast metadata artifact is hash-bound. Clean-copy verification is not a second model replication.
