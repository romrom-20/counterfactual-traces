"""Independent NumPy64 local derivative, write-removal and finite-readout audit."""

import argparse,hashlib,itertools,json
from pathlib import Path
import numpy as np
R=Path(__file__).resolve().parents[1];RUN=R/'runs/native-mlp-remainder-223';SITES=(22,23)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,o):p.write_text(json.dumps(o,indent=2,default=lambda x:x.item() if isinstance(x,np.generic) else str(x))+'\n')
def margin(s):return float(s[1]-s[0])
def local(c,w,d):
    a=c['inv'];s=c['s'];dn=w['gamma']*a*(d-s*a*a*np.mean(s*d,axis=-1,keepdims=True))
    dg=dn@w['gate'].T;du=dn@w['up'].T;dp=c['sigma']*(1+c['gate']*(1-c['sigma']))*dg
    return(dp*c['up']+c['phi']*du)@w['down'].T
def smooth(w,s,eps):
    z=w['gamma']*(s/np.sqrt(np.mean(s*s,axis=-1,keepdims=True)+eps));g=z@w['gate'].T;u=z@w['up'].T
    return(g*np.exp(-np.logaddexp(0.,-g))*u)@w['down'].T
def head(s,w):
    h=s[-1].astype(np.float64);return(h/np.sqrt(np.mean(h*h)+float(w['eps']))*w['norm'])@w['head'].T
def initial():
    d=json.loads((RUN/'design.json').read_text());assert all(sha(R/p)==h for p,h in d['source_hashes'].items());w=dict(np.load(RUN/'weights.npz'))
    return d,w,{l:{k:w[f'{l}_{k}'].astype(np.float64) for k in ('gate','up','down','gamma')} for l in SITES}
def cache(z,l):return{k[len(f'{l}_c_'):]:a.astype(np.float64) for k,a in z.items() if k.startswith(f'{l}_c_')}
def derivative(z,prefix,c,w,v,g,eps):
    d=z[prefix+'direction'];j=local(c,w,d);stored=z[prefix+'analytic'];dual=z[prefix+'dual'];fd=z[prefix+'fd']
    assert np.max(abs(j-stored))<=1e-9
    direct=float(np.max(abs(j-dual)));finite=float(np.max(abs(j-fd)));assert direct<=1e-4 and finite<=1e-4
    independent=(smooth(w,c['s']+1e-5*d,eps)-smooth(w,c['s']-1e-5*d,eps))/(2e-5)
    fd_replay=float(np.max(abs(independent-fd)));assert fd_replay<=1e-4
    rev=np.sum(g*d.astype(np.float32).astype(np.float64),axis=(1,2));contract=np.sum(v*j,axis=(1,2))
    assert np.max(abs(rev-z[prefix+'reverse_values']))<=1e-9 and np.max(abs(contract-z[prefix+'contractions']))<=1e-9
    ratio=float(np.max(abs(contract-rev)/(.001+.0001*abs(rev))));assert ratio<=1
    return dict(ad=direct,fd=finite,fd_replay=fd_replay,reverse_ratio=ratio)

def qualification():
    out=R/'docs/analysis/223-local-mlp-qualification.json';assert not out.exists() and not (RUN/'qualification-seal.json').exists()
    d,w,ws=initial();s=json.loads((RUN/'qualification-status.json').read_text());assert s['status']=='complete' and s['counts']==d['expectedQ']
    checks=[];errors=[];files={str((RUN/p).relative_to(R)):sha(RUN/p) for p in ('design.json','runtime.json','weights.npz','qualification-status.json')}
    for key in d['contexts']:
        path=RUN/'qualification'/(key+'.npz');rec=json.loads(path.with_suffix('.json').read_text());assert sha(path)==rec['arrays_sha256'];z=dict(np.load(path));assert all(np.isfinite(a).all() for a in z.values());checks.extend(rec['checks'])
        for p in (path,path.with_suffix('.json')):files[str(p.relative_to(R))]=sha(p)
        parent=R/'runs/native-write-ledger-222/ledger'/path.name;assert sha(parent)==rec['parent222_sha256'];old=dict(np.load(parent))
        assert sha(R/'runs/source-receiver-partition-208/forecasts'/path.name)==rec['parent208_sha256']
        for l in SITES:
            c=cache(z,l);v=z[f'{l}_covectors'];g=z[f'{l}_gradients'];assert np.max(abs(c['s']-old['F_mid'][l-1,1:]))==0 and np.max(abs(c['write']-old['F_mlp'][l-1,1:]))==0
            assert np.max(abs(z[f'{l}_q0_direction']-(old['N_mid'][l-1,1:].astype(np.float64)-c['s'])))==0
            for j in range(3):
                if j:
                    index=np.arange(1,1+c['s'].size,dtype=np.float64).reshape(c['s'].shape);wave=(np.sin if j==1 else np.cos)(index*.017)
                    expected=wave*np.linalg.norm(z[f'{l}_q0_direction'])/np.linalg.norm(wave);assert np.max(abs(expected-z[f'{l}_q{j}_direction']))<=1e-9
                errors.append(derivative(z,f'{l}_q{j}_',c,ws[l],v,g,float(w[f'{l}_eps'])))
        assert np.max(abs(head(z['False_final'],w)-z['False_scores']))<=.005
    assert len(errors)==192 and all(c['error']<=c['bound'] for c in checks)
    result=dict(qualified=True,contexts=32,counts=s['counts'],controls=len(checks),local_derivative_directions=len(errors),maxima={k:max(r[k] for r in errors) for k in errors[0]},
        scope='Local MLP22/23 frozen-primal derivatives only. CPU64 finite differences promote arithmetic; old whole-block Jacobian disagreements remain unresolved.',auditor_sha256=sha(Path(__file__)))
    write(out,result);files[str(out.relative_to(R))]=sha(out);write(RUN/'qualification-seal.json',dict(files=files,intervention_models_before_seal=0,auditor_sha256=sha(Path(__file__))))
    print(json.dumps(result,indent=2))

def intervention():
    out=R/'docs/analysis/223-native-mlp-remainder.json';assert not out.exists();d,w,ws=initial();status=json.loads((RUN/'status.json').read_text());assert status['status']=='complete' and status['counts']==d['expectedI']
    seal=json.loads((RUN/'qualification-seal.json').read_text());assert seal['intervention_models_before_seal']==0 and all(sha(R/p)==h for p,h in seal['files'].items())
    mask=json.loads((R/'runs/neuron-mixed-interventions-219/selection.json').read_text())['ranking'][:32];checks=[];errs=[];rows=[];factorials=[];priors=[]
    maxhead=0.;maxround=0.;rawfail=0;rawmax=0.;product_errors=[]
    def secondary(z,prefix):
        nonlocal maxhead,maxround,rawfail,rawmax
        get=lambda name:z[prefix+name].astype(np.float64)
        dp=get('phi')-z['False_phi'].astype(np.float64);du=get('up')-z['False_up'].astype(np.float64);mixed=np.zeros_like(dp);mixed[:,mask]=dp[:,mask]*du[:,mask]
        affine=z['False_product'].astype(np.float64)+dp*z['False_up']+z['False_phi']*du
        assert np.max(abs(get('L_product')-affine.astype(np.float32)))<=1e-4 and np.max(abs(get('G_product')-(affine+mixed).astype(np.float32)))<=1e-4
        p0=get('L_product');p1=get('G_product');d0=get('L_down');d1=get('G_down');mid=get('mid');effect=get('G_state')-get('L_state');down=w['down28']
        pr=(p1-p0-mixed)@down.T;dr=(d1-p1@down.T)-(d0-p0@down.T);rr=(get('G_state')-mid-d1)-(get('L_state')-mid-d0)
        error=float(np.max(abs(effect-mixed@down.T-pr-dr-rr)));maxround=max(maxround,error);assert error<=1e-9
        raw=float(np.max(abs(effect-mixed@down.T)));rawmax=max(rawmax,raw);rawfail+=raw>1e-4
        common=(z['False_final'].astype(np.float64)+effect).astype(np.float32);assert np.max(abs(common-get('common_state')))==0
        assert np.max(abs(get('G_state')-get('replay_state')))<=1e-4 and np.max(abs(get('G_scores')-get('replay_scores')))<=.005
        for state,score in ((common,get('common_scores')),(get('L_state'),get('L_scores')),(get('G_state'),get('G_scores'))):
            e=float(np.max(abs(head(state,w)-score)));maxhead=max(maxhead,e);assert e<=.005
        pe=float(z[prefix+'local_product_error']);assert pe<=1e-4;product_errors.append(pe)
        return margin(get('common_scores'))-margin(z['False_scores'])
    for key in d['contexts']:
        path=RUN/'interventions'/(key+'.npz');rec=json.loads(path.with_suffix('.json').read_text());assert sha(path)==rec['arrays_sha256'];z=dict(np.load(path));assert all(np.isfinite(a).all() for a in z.values());checks.extend(rec['checks'])
        qp=RUN/'qualification'/path.name;assert sha(qp)==rec['qualification_sha256'];q=dict(np.load(qp));parent=R/'runs/native-write-ledger-222/ledger'/path.name;assert sha(parent)==rec['parent222_sha256'];old=dict(np.load(parent))
        native=z['FF_final'].astype(np.float64);yf=z['False_final'].astype(np.float64);delta=native-yf;norm=float(np.linalg.norm(delta[-1]));assert norm>=.001
        assert np.max(abs(native-old['N_states'][-1,1:]))<=1e-4 and np.max(abs(z['FF_scores']-old['N_scores']))<=.005
        assert np.max(abs(z['False_sham_final']-z['False_final']))<=1e-4 and np.max(abs(z['False_sham_scores']-z['False_scores']))<=.005
        assert np.max(abs(z['rescue_final']-native))<=1e-4 and np.max(abs(z['rescue_scores']-z['FF_scores']))<=.005
        native_group=None;case=[]
        for job in rec['jobs']:
            label=job['label'];modes=job['modes']
            for l in SITES:
                prefix=f'{label}_{l}_';c=cache(q,l);direction=z[prefix+'incoming'].astype(np.float64)-c['s'];j=local(c,ws[l],direction);affine=c['write']+j;before=z[prefix+'before'];remainder=before-affine
                for name,a in (('direction',direction),('tangent',j),('affine',affine),('remainder',remainder)):assert np.max(abs(z[prefix+name]-a))<=1e-9
                assert np.max(abs(z[prefix+'q_direction']-direction))==0
                mode=modes.get(str(l),'F')
                if mode=='L':expected=affine
                elif mode=='R':expected=affine+remainder
                elif mode=='Z':
                    refarm='LF' if label=='rand22' else 'FL' if label=='rand23' else 'LL';ref=z[f'{refarm}_{l}_after']-z[f'{refarm}_{l}_before'];rn=float(np.linalg.norm(ref));unit=z[f'{l}_random_unit'];assert abs(np.linalg.norm(unit)-1)<=1e-9
                    assert abs(float(z[prefix+'reference_norm'])-rn)<=1e-9;expected=before+unit*rn
                else:expected=before
                assert np.max(abs(z[prefix+'proposed']-expected))<=1e-9 and np.max(abs(z[prefix+'after']-expected.astype(np.float32)))==0
                if mode=='L':
                    closure=(z[prefix+'after']-before)+remainder-(z[prefix+'after']-affine);assert np.max(abs(closure))<=1e-9
                if label=='False_sham':assert np.max(abs(direction))==0
                if label in ('FF','LF','FL','LL','rescue','rand22','rand23','randboth') and l==22:assert np.max(abs(z[prefix+'incoming']-old['N_mid'][l-1,1:]))<=1e-4
                errs.append(derivative(z,prefix+'q_',c,ws[l],q[f'{l}_covectors'],q[f'{l}_gradients'],float(w[f'{l}_eps'])))
            if not job['bit']:continue
            group_effect=secondary(z,label+'_sec_')
            if label=='FF':native_group=group_effect;assert abs(group_effect-(margin(old['native_common_scores'])-margin(old['false_scores'])))<=.01
            final=z[label+'_final'].astype(np.float64);edit=final-native;inter=final-yf;den=np.linalg.norm(inter[-1])*norm;cos=float(np.dot(inter[-1],delta[-1])/den) if den>0 else 0.
            qv=float(np.linalg.norm(edit[-1])/norm);qr=float(np.linalg.norm(edit)/np.linalg.norm(delta));dm=margin(z[label+'_scores'])-margin(z['FF_scores'])
            local_norms={str(l):float(np.linalg.norm(z[f'{label}_{l}_after']-z[f'{label}_{l}_before'])) for l in SITES}
            case.append(dict(context=key,group=rec['group'],label=label,verdict_relative_deviation=qv,receiver_relative_deviation=qr,cosine=cos,
                natural_margin=margin(z[label+'_scores']),native_margin=margin(z['FF_scores']),margin_change=dm,absolute_margin_change=abs(dm),
                native_direction_edit_coefficient=float(np.sum(edit*delta)/np.sum(delta*delta)),product_effect=group_effect,native_product_effect=native_group,
                response_preserved=bool(qv<=.05 and cos>=.99 and abs(dm)<=.1),material_both=bool(qv>.05 and abs(dm)>.1),write_edit_norms=local_norms))
        assert np.max(abs(z['LF_23_incoming']-z['LL_23_incoming']))<=1e-4
        assert np.max(abs(z['FF_23_incoming']-z['FL_23_incoming']))<=1e-4
        assert len(case)==8 and native_group is not None;rows.extend(case)
        interaction=z['LL_final'].astype(np.float64)-z['LF_final'].astype(np.float64)-z['FL_final'].astype(np.float64)+native
        factorials.append(dict(context=key,group=rec['group'],receiver_interaction_norm=float(np.linalg.norm(interaction)),verdict_interaction_norm=float(np.linalg.norm(interaction[-1])),
            interaction_projection_native=float(np.sum(interaction*delta)/np.sum(delta*delta)),margin_interaction=margin(z['LL_scores'])-margin(z['LF_scores'])-margin(z['FL_scores'])+margin(z['FF_scores'])))
        pp=R/'runs/native-write-ledger-222/interventions'/path.name;pr=json.loads(pp.with_suffix('.json').read_text());assert sha(pp)==pr['arrays_sha256'];pz=dict(np.load(pp))
        for name,previous_arm in (('LF','op1_clamp'),('FL','op0_clamp'),('LL','both_clamp')):
            pf=pz[previous_arm+'_native_final'][1:].astype(np.float64);pm=margin(pz[previous_arm+'_native_scores'])-margin(old['N_scores'])
            priors.append(dict(context=key,group=rec['group'],removal_arm=name,full_write_clamp_margin_change=pm,full_write_clamp_verdict_relative=float(np.linalg.norm(pf[-1]-native[-1])/norm)))
    assert len(rows)==256 and len(errs)==576 and len(product_errors)==256 and all(c['error']<=c['bound'] for c in checks)
    gates=[]
    for label,control in (('LF','rand22'),('FL','rand23'),('LL','randboth')):
        values=[]
        for key in d['contexts']:
            a=next(r for r in rows if r['context']==key and r['label']==label);b=next(r for r in rows if r['context']==key and r['label']==control)
            beats=a['verdict_relative_deviation']>b['verdict_relative_deviation'] and a['absolute_margin_change']>b['absolute_margin_change']
            values.append(dict(context=key,group=a['group'],preserved=a['response_preserved'],material=a['material_both'],beats_random=beats,combined=bool(a['material_both'] and beats)))
        strata=[]
        for schema,order in itertools.product(('generic','descriptive'),range(2)):
            rr=[r for r in values if r['group']['schema']==schema and r['group']['reverse']==order];assert len(rr)==8
            strata.append(dict(schema=schema,order=order,counts={k:sum(bool(r[k]) for r in rr) for k in ('preserved','material','beats_random','combined')}))
        totals={k:sum(bool(r[k]) for r in values) for k in ('preserved','material','beats_random','combined')}
        gates.append(dict(arm=label,control=control,totals=totals,strata=strata,passed=bool(totals['combined']>=24 and all(s['counts']['combined']>=6 for s in strata))))
    summaries=[]
    for label in ('FF','LF','FL','LL','rescue','rand22','rand23','randboth'):
        for schema in (None,'generic','descriptive'):
            rr=[r for r in rows if r['label']==label and (schema is None or r['group']['schema']==schema)]
            summaries.append(dict(label=label,schema=schema,count=len(rr),response_preserved=sum(r['response_preserved'] for r in rr),material_both=sum(r['material_both'] for r in rr),
                medians={k:float(np.median([r[k] for r in rr])) for k in ('verdict_relative_deviation','receiver_relative_deviation','margin_change','absolute_margin_change','native_direction_edit_coefficient','product_effect')}))
    result=dict(qualified=True,contexts=32,controls=len(checks),counts=status['counts'],local_derivative_directions=len(errs),local_maxima={k:max(r[k] for r in errs) for k in errs[0]},
        product_derivative_checks=len(product_errors),maximum_product_derivative_error=max(product_errors),maximum_finite_head_error=maxhead,maximum_product_rounding_closure=maxround,
        raw_ideal_failures=int(rawfail),raw_ideal_comparisons=len(product_errors),maximum_raw_ideal_error=rawmax,gates=gates,summaries=summaries,rows=rows,factorials=factorials,previous_full_write_clamps=priors,
        prospective=False,original_wholeblock_jacobian_qualified=False,full_question_B_solved=False,
        scope='Retrospective native-tail necessity test of local MLP22/23 remainders with qualified local derivatives. Natural verdict residual/margin primary; fixed neuron product diagnostic secondary. No learned-circuit or False-only prediction claim.',auditor_sha256=sha(Path(__file__)))
    write(out,result);print(json.dumps({k:v for k,v in result.items() if k not in ('rows','factorials','previous_full_write_clamps','summaries')},indent=2));print(json.dumps(summaries,indent=2))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--phase',choices=['qualification','interventions'],required=True);a=p.parse_args();qualification() if a.phase=='qualification' else intervention()
