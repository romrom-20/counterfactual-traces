"""Qualified local False-state MLP derivative and exact finite-write remainder."""

import torch
from torch.nn import functional as F

SITES=(22,23)
def parameters(layer):
    assert all(p.bias is None for p in (layer.mlp.gate_proj,layer.mlp.up_proj,layer.mlp.down_proj))
    return {k:v.detach().cpu().double() for k,v in dict(gate=layer.mlp.gate_proj.weight,up=layer.mlp.up_proj.weight,down=layer.mlp.down_proj.weight,gamma=layer.post_attention_layernorm.weight).items()}

def frozen(layer,cap,start):
    device=layer.mlp.down_proj.weight.device
    s=cap['mid'].to(device=device,dtype=torch.float32)
    with torch.no_grad():
        inv=torch.rsqrt(s.float().square().mean(-1,keepdim=True)+layer.post_attention_layernorm.variance_epsilon)
        sigma=torch.sigmoid(cap['gate'].to(device=device,dtype=torch.float32))
    return {k:v[0,start:].detach().cpu().double() for k,v in dict(s=s,inv=inv,gate=cap['gate'],up=cap['up'],phi=cap['phi'],sigma=sigma,write=cap['down'],product=cap['product'],normalized=cap['normalized']).items()}

def tangent(c,w,d):
    r=c['s'];a=c['inv'];dn=w['gamma']*a*(d-r*a.square()*(r*d).mean(-1,keepdim=True))
    dg=F.linear(dn,w['gate']);du=F.linear(dn,w['up']);dp=c['sigma']*(1+c['gate']*(1-c['sigma']))*dg
    return F.linear(dp*c['up']+c['phi']*du,w['down'])

def smooth(w,s,eps):
    z=w['gamma']*(s*torch.rsqrt(s.square().mean(-1,keepdim=True)+eps))
    return F.linear(F.silu(F.linear(z,w['gate']))*F.linear(z,w['up']),w['down'])

def covectors(shape):
    index=torch.arange(1,1+shape[0]*shape[1],dtype=torch.float64).reshape(shape)
    out=torch.stack([torch.sin(index*k) for k in (.011,.019,.037)])
    return out/out.flatten(1).norm(dim=1)[:,None,None]

def reverse(layer,sfull,start,c):
    s=sfull.detach().clone().requires_grad_(True);y=layer.mlp(layer.post_attention_layernorm(s));grads=[]
    for j,v in enumerate(c):
        p=torch.zeros_like(y);p[0,start:]=v.to(device=y.device,dtype=y.dtype)
        g=torch.autograd.grad((y*p).sum(),s,retain_graph=j<2)[0]
        assert float(g[:,:start].abs().max())==0
        grads.append(g[0,start:].detach().cpu().double())
    return torch.stack(grads)

def qualify(layer,sfull,c,w,d,v,grads,start,eps):
    device=sfull.device;direction=torch.zeros_like(sfull);direction[0,start:]=d.to(device=device,dtype=torch.float32)
    with torch.no_grad():primal,dual=torch.func.jvp(lambda s:layer.mlp(layer.post_attention_layernorm(s)),(sfull,),(direction,))
    analytic=tangent(c,w,d)
    fd=(smooth(w,c['s']+1e-5*d,eps)-smooth(w,c['s']-1e-5*d,eps))/(2e-5)
    rev=(grads*direction[0,start:].cpu().double()).flatten(1).sum(-1)
    contraction=(v*analytic).flatten(1).sum(-1)
    errors=dict(primal=float((primal[0,start:].cpu().double()-c['write']).abs().max()),
        ad=float((dual[0,start:].cpu().double()-analytic).abs().max()),fd=float((fd-analytic).abs().max()),
        support=float(dual[:,:start].abs().max()),reverse=float(((contraction-rev).abs()/(.001+.0001*rev.abs())).max()))
    assert all(errors[k]<=1e-4 for k in ('primal','ad','fd')) and errors['support']==0 and errors['reverse']<=1,errors
    return dict(direction=d,analytic=analytic,dual=dual[0,start:].cpu().double(),fd=fd,reverse_values=rev,contractions=contraction),errors
