"""Two-stage, native-tail causal test of False-state MLP nonlinear remainders."""

import argparse,hashlib,json
from collections import Counter
from contextlib import ExitStack
from pathlib import Path
import numpy as np
import torch
from torch.nn import functional as F
import ranked_block_response_201 as public
from native_receiver_factorial_221 import captured
from native_write_ledger_222 import products
from native_mlp_remainder_223 import SITES,parameters,frozen,tangent,covectors,reverse,qualify
from latent_decisions.target import load_target
from latent_decisions.evidence_policy import digest

R=Path(__file__).resolve().parents[1];RUN=R/'runs/native-mlp-remainder-223'
SCIENTIFIC=['scripts/run_native_mlp_remainder_223.py','scripts/native_mlp_remainder_223.py','scripts/audit_native_mlp_remainder_223.py','docs/experiments/223-native-mlp-remainder-necessity.md',
 'scripts/native_receiver_factorial_221.py','scripts/native_write_ledger_222.py','scripts/gate_up_arithmetic_213.py','scripts/ranked_block_response_201.py','src/latent_decisions/target.py']
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def cpu(x):return x.detach().cpu().numpy().copy()
def write(p,o):p.write_text(json.dumps(o,indent=2,default=lambda x:x.item() if isinstance(x,np.generic) else str(x))+'\n')
def store(out,prefix,values):
    for k,v in values.items():out[prefix+k]=cpu(v) if torch.is_tensor(v) else np.asarray(v)
def check_function(checks):
    def check(kind,error,bound=1e-4):
        checks.append(dict(kind=kind,error=float(error),bound=bound));assert float(error)<=bound,checks[-1]
    return check
def model_and_runtime():
    rt=json.loads((RUN/'runtime.json').read_text());model,tok,device=load_target(rt['model'],'mps',offline=True);torch.set_num_threads(2)
    assert digest(tok.get_vocab())==rt['tokenizer_hash'] and digest(model.config.to_dict())==rt['config_hash']
    assert not model.training and model.config._attn_implementation=='eager' and next(model.parameters()).dtype==torch.float32
    return model,device
def previous(key):
    p=R/'runs/native-write-ledger-222/ledger'/(key+'.npz');rec=json.loads(p.with_suffix('.json').read_text());assert sha(p)==rec['arrays_sha256']
    f=R/'runs/source-receiver-partition-208/forecasts'/p.name;assert sha(f)==rec['parent208_sha256']
    return p,rec,f

def qualification():
    assert not RUN.exists()
    prior=R/'results/native-write-ledger-222/manifest.json';old=json.loads(prior.read_text());assert len(old['files'])==2561 and all(sha(R/p)==h for p,h in old['files'].items())
    selection=R/'runs/native-write-ledger-222/selection.json';sel=json.loads(selection.read_text());assert [o['layer'] for o in sel['operations']]==[23,22] and len(sel['excluded'])==32
    RUN.mkdir();(RUN/'qualification').mkdir();(RUN/'interventions').mkdir()
    design=dict(source_hashes={p:sha(R/p) for p in SCIENTIFIC},previous_manifest_sha256=sha(prior),selection222_sha256=sha(selection),contexts=sorted(sel['excluded']),sites=SITES,
        expectedQ=dict(ordinary_models=32,reverse_forwards=64,reverse_backwards=192,local_jvp=192,finite_difference_checks=192,reverse_contractions=576),
        expectedI=dict(ordinary_models=320,local_jvp=576,finite_difference_checks=576,reverse_contractions=1728,product_checks=256,direct_down=512,public_target_blocks=256,finite_heads=1056))
    write(RUN/'design.json',design);write(RUN/'runtime.json',json.loads((R/'runs/source-receiver-partition-208/runtime.json').read_text()))
    model,device=model_and_runtime();weights={l:parameters(model.model.layers[l-1]) for l in SITES};wa={}
    for l,w in weights.items():store(wa,f'{l}_',w);wa[f'{l}_eps']=np.array(model.model.layers[l-1].post_attention_layernorm.variance_epsilon)
    wa.update(norm=cpu(model.model.norm.weight),head=cpu(model.lm_head.weight[[895,830]]),eps=np.array(model.model.norm.variance_epsilon),down28=cpu(model.model.layers[27].mlp.down_proj.weight).astype(np.float64))
    np.savez_compressed(RUN/'weights.npz',**wa);counts=Counter()
    for n,key in enumerate(design['contexts'],1):
        p,rec,fp=previous(key);pos=rec['position'];start=pos+1;checks=[];check=check_function(checks);arrays={}
        with np.load(p) as old,np.load(fp) as forecast,ExitStack() as stack:
            caps={l:stack.enter_context(captured(model.model.layers[l-1])) for l in SITES}
            states,ctx,ss=public.observe(model,torch.tensor([rec['bases'][0]['free_input_ids']],device=device))
        counts['ordinary_models']+=1
        with np.load(p) as old,np.load(fp) as forecast:
            check('False_222',np.max(abs(cpu(torch.stack([ctx['input'],*states])[:,0,pos:])-old['F_states'])))
            check('False_208',max(float((s-torch.tensor(forecast['false_boundaries'][j+1][None],device=device)).abs().max()) for j,s in enumerate(states)))
            arrays['False_final']=cpu(states[-1][0,start:]);arrays['False_scores']=cpu(ss)
            for l in SITES:
                layer=model.model.layers[l-1];c=frozen(layer,caps[l],start);w=weights[l];sf=caps[l]['mid'].to(device=device,dtype=torch.float32)
                check('False_mid',np.max(abs(cpu(c['s'])-old['F_mid'][l-1,1:])));check('False_write',np.max(abs(cpu(c['write'])-old['F_mlp'][l-1,1:])))
                v=covectors(c['s'].shape);grads=reverse(layer,sf,start,v);counts['reverse_forwards']+=1;counts['reverse_backwards']+=3
                store(arrays,f'{l}_c_',c);arrays[f'{l}_covectors']=cpu(v);arrays[f'{l}_gradients']=cpu(grads)
                native=torch.tensor(old['N_mid'][l-1,1:].astype(np.float64))-c['s'];index=torch.arange(1,1+native.numel(),dtype=torch.float64).reshape(native.shape);assert native.norm()>.001
                directions=[native,*[fn(index*.017)*native.norm()/fn(index*.017).norm() for fn in (torch.sin,torch.cos)]]
                for j,d in enumerate(directions):
                    values,errors=qualify(layer,sf,c,w,d,v,grads,start,float(wa[f'{l}_eps']));store(arrays,f'{l}_q{j}_',values)
                    checks.extend(dict(kind=f'local_{l}_{j}_{k}',error=e,bound=0 if k=='support' else 1 if k=='reverse' else 1e-4) for k,e in errors.items())
                    counts['local_jvp']+=1;counts['finite_difference_checks']+=1;counts['reverse_contractions']+=3
        dest=RUN/'qualification'/(key+'.npz');np.savez_compressed(dest,**arrays)
        write(dest.with_suffix('.json'),dict(key=key,group=rec['group'],position=pos,arrays_sha256=sha(dest),parent222_sha256=sha(p),parent208_sha256=sha(fp),checks=checks))
        write(RUN/'qualification-status.json',dict(status='qualifying',completed=n,counts=dict(counts)));print('qualification',n,key,flush=True)
    assert dict(counts)==design['expectedQ'] and all(sha(R/p)==h for p,h in design['source_hashes'].items())
    write(RUN/'qualification-status.json',dict(status='complete',qualified_controls=True,counts=dict(counts)))

def intervention():
    design=json.loads((RUN/'design.json').read_text());seal=json.loads((RUN/'qualification-seal.json').read_text())
    assert all(sha(R/p)==h for p,h in design['source_hashes'].items()) and all(sha(R/p)==h for p,h in seal['files'].items())
    assert seal['intervention_models_before_seal']==0 and json.loads((R/'docs/analysis/223-local-mlp-qualification.json').read_text())['qualified']
    assert not any((RUN/'interventions').iterdir())
    model,device=model_and_runtime();wz=dict(np.load(RUN/'weights.npz'));weights={l:{k:torch.tensor(wz[f'{l}_{k}']) for k in ('gate','up','down','gamma')} for l in SITES}
    for l in SITES:
        for k,v in parameters(model.model.layers[l-1]).items():assert torch.equal(v,weights[l][k])
    last=model.model.layers[27];mask=json.loads((R/'runs/neuron-mixed-interventions-219/selection.json').read_text())['ranking'][:32];counts=Counter()
    def head(x):
        with torch.no_grad():s=public.head(model,x)
        counts['finite_heads']+=1;return cpu(s).astype(np.float64)
    def secondary(cap,false,states,ctx,yf,pos,check):
        start=pos+1
        with torch.no_grad():pl,pg,mix,err=products(last,cap,false,mask,pos)
        counts['product_checks']+=1;mid=cap['mid'].to(device=device,dtype=torch.float32);out={};dd={};ss={}
        for label,p in (('L',pl),('G',pg)):
            with torch.no_grad():dd[label]=last.mlp.down_proj(p);out[label]=mid+dd[label]
            counts['direct_down']+=1;ss[label]=head(out[label])
        effect=out['G'].cpu().double()-out['L'].cpu().double();check('secondary_source_prefix',effect[:,:start].abs().max(),0.)
        common=(yf.cpu().double()+effect).to(device=device,dtype=torch.float32);cs=head(common)
        h=last.mlp.down_proj.register_forward_pre_hook(lambda module,args:(pg,))
        try:
            with torch.no_grad():replay=public.block(last,states[26],ctx)
        finally:h.remove()
        counts['public_target_blocks']+=1;rs=head(replay);check('secondary_public_state',(replay-out['G']).abs().max());check('secondary_public_head',np.max(abs(rs-ss['G'])),.005)
        return dict(phi=cpu(cap['phi'][0,start:]).astype(np.float32),up=cpu(cap['up'][0,start:]).astype(np.float32),mid=cpu(cap['mid'][0,start:]).astype(np.float32),
            L_product=cpu(pl[0,start:]),G_product=cpu(pg[0,start:]),L_down=cpu(dd['L'][0,start:]),G_down=cpu(dd['G'][0,start:]),L_state=cpu(out['L'][0,start:]),G_state=cpu(out['G'][0,start:]),
            L_scores=ss['L'],G_scores=ss['G'],common_state=cpu(common[0,start:]),common_scores=cs,replay_state=cpu(replay[0,start:]),replay_scores=rs,local_product_error=np.array(err))
    jobs=[('False_sham',0,{22:'L',23:'L'}),('FF',1,{}),('LF',1,{22:'L'}),('FL',1,{23:'L'}),('LL',1,{22:'L',23:'L'}),('rescue',1,{22:'R',23:'R'}),
        ('rand22',1,{22:'Z'}),('rand23',1,{23:'Z'}),('randboth',1,{22:'Z',23:'Z'})]
    for n,key in enumerate(design['contexts'],1):
        p,rec,fp=previous(key);pos=rec['position'];start=pos+1;checks=[];check=check_function(checks);qpath=RUN/'qualification'/(key+'.npz');qrec=json.loads(qpath.with_suffix('.json').read_text());assert sha(qpath)==qrec['arrays_sha256']
        q=dict(np.load(qpath));old=dict(np.load(p));forecast=dict(np.load(fp));out={};rows=[]
        c={l:{k[len(f'{l}_c_'):]:torch.tensor(a) for k,a in q.items() if k.startswith(f'{l}_c_')} for l in SITES}
        v={l:torch.tensor(q[f'{l}_covectors']) for l in SITES};grads={l:torch.tensor(q[f'{l}_gradients']) for l in SITES}
        with ExitStack() as stack:
            fcaps={l:stack.enter_context(captured(model.model.layers[l-1])) for l in SITES};false_last=stack.enter_context(captured(last))
            fs,fctx,fscore=public.observe(model,torch.tensor([rec['bases'][0]['free_input_ids']],device=device))
        counts['ordinary_models']+=1;sf={l:fcaps[l]['mid'].to(device=device,dtype=torch.float32) for l in SITES}
        for l in SITES:check('anchor_mid',(sf[l][0,start:].cpu().double()-c[l]['s']).abs().max())
        check('anchor_final',np.max(abs(cpu(fs[-1][0,start:])-q['False_final'])));check('anchor_scores',np.max(abs(cpu(fscore)-q['False_scores'])),.005)
        out['False_final']=cpu(fs[-1][0,start:]);out['False_scores']=head(fs[-1]);out['False_phi']=cpu(false_last['phi'][0,start:]).astype(np.float32);out['False_up']=cpu(false_last['up'][0,start:]).astype(np.float32);out['False_product']=cpu(false_last['product'][0,start:]).astype(np.float32)
        refs={};randoms={}
        for l in SITES:
            rng=np.random.default_rng(int(hashlib.sha256((key+str(l)+'223').encode()).hexdigest()[:16],16));u=torch.tensor(rng.standard_normal(c[l]['s'].shape));randoms[l]=u/u.norm();out[f'{l}_random_unit']=cpu(randoms[l])
        for label,bit,modes in jobs:
            handles=[];live={};applied={}
            for l in SITES:
                layer=model.model.layers[l-1]
                def before(module,args,l=l):live[l]=args[0].detach().clone()
                def patch(module,args,value,l=l):
                    incoming=live[l][0,start:].cpu().double();before=value[0,start:].detach().cpu().double();d=incoming-c[l]['s'];jt=tangent(c[l],weights[l],d);affine=c[l]['write']+jt;remainder=before-affine
                    mode=modes.get(l,'F');ref=0.
                    if mode=='L':proposed=affine
                    elif mode=='R':proposed=affine+remainder
                    elif mode=='Z':
                        ref=refs[('LF' if label=='rand22' else 'FL' if label=='rand23' else 'LL',l)];proposed=before+randoms[l]*ref
                    else:proposed=before
                    result=value.clone();result[:,start:]=proposed[None].to(device=device,dtype=value.dtype);after=result[0,start:].detach().cpu().double()
                    check('patch_source_prefix',(result[:,:start]-value[:,:start]).abs().max(),0.)
                    check('write_arithmetic',(after-before+remainder-(after-affine)).abs().max(),1e-9)
                    if mode=='Z':
                        check('random_proposed_norm',abs(float((proposed-before).norm())-ref),1e-9);check('random_applied_norm',abs(float((after-before).norm())-ref),1e-4*max(1.,ref))
                    if mode=='R':check('remove_and_reinsert',(after-before).abs().max())
                    applied[l]=dict(incoming=incoming,direction=d,tangent=jt,affine=affine,remainder=remainder,before=before,proposed=proposed,after=after,reference_norm=np.array(ref))
                    if mode=='L' and bit==1:refs[label,l]=float((after-before).norm())
                    return result
                handles.extend((layer.post_attention_layernorm.register_forward_pre_hook(before),layer.mlp.register_forward_hook(patch)))
            try:
                with captured(last) as cap:states,ctx,ss=public.observe(model,torch.tensor([rec['bases'][bit]['free_input_ids']],device=device))
            finally:
                for h in handles:h.remove()
            counts['ordinary_models']+=1
            for l in SITES:
                values,errors=qualify(model.model.layers[l-1],sf[l],c[l],weights[l],applied[l]['direction'],v[l],grads[l],start,float(wz[f'{l}_eps']))
                counts['local_jvp']+=1;counts['finite_difference_checks']+=1;counts['reverse_contractions']+=3
                check('saved_local_tangent',(values['analytic']-applied[l]['tangent']).abs().max(),1e-9)
                checks.extend(dict(kind=f'{label}_{l}_{k}',error=e,bound=0 if k=='support' else 1 if k=='reverse' else 1e-4) for k,e in errors.items())
                store(out,f'{label}_{l}_',applied[l]);store(out,f'{label}_{l}_q_',values)
            check('trajectory_prefix',max(float((s[:,:pos]-torch.tensor(forecast['false_boundaries'][j+1][None,:pos],device=device)).abs().max()) for j,s in enumerate(states)))
            source=old['N_states'][1:,0] if bit else old['F_states'][1:,0];check('trajectory_source',np.max(abs(cpu(torch.stack(states)[:,0,pos])-source)))
            out[label+'_final']=cpu(states[-1][0,start:]);out[label+'_scores']=cpu(ss);out[label+'_boundary27']=cpu(states[26][0,start:])
            if bit==0:
                check('False_sham_state',np.max(abs(out[label+'_final']-out['False_final'])));check('False_sham_head',np.max(abs(out[label+'_scores']-out['False_scores'])),.005)
            else:
                store(out,label+'_sec_',secondary(cap,false_last,states,ctx,fs[-1],pos,check))
                if label in ('FF','rescue'):
                    check('native_endpoint',np.max(abs(out[label+'_final']-old['N_states'][-1,1:])));check('native_head',np.max(abs(out[label+'_scores']-old['N_scores'])),.005)
                    check('native_boundary27',np.max(abs(out[label+'_boundary27']-old['N_states'][27,1:])))
                if label=='FF':check('native_secondary_222',np.max(abs(out[label+'_sec_common_scores']-old['native_common_scores'])),.005)
            rows.append(dict(label=label,bit=bit,modes=modes))
        check('joint23_live_input_replay',np.max(abs(out['LF_23_incoming']-out['LL_23_incoming'])))
        check('single23_native_input_replay',np.max(abs(out['FF_23_incoming']-out['FL_23_incoming'])))
        dest=RUN/'interventions'/(key+'.npz');np.savez_compressed(dest,**out)
        write(dest.with_suffix('.json'),dict(key=key,group=rec['group'],position=pos,arrays_sha256=sha(dest),qualification_sha256=sha(qpath),parent222_sha256=sha(p),jobs=rows,checks=checks))
        write(RUN/'status.json',dict(status='intervening',completed=n,counts=dict(counts)));print('intervention',n,key,flush=True)
    assert dict(counts)==design['expectedI'],(dict(counts),design['expectedI'])
    assert all(sha(R/p)==h for p,h in design['source_hashes'].items())
    write(RUN/'status.json',dict(status='complete',qualified_controls=True,counts=dict(counts),original_wholeblock_jacobian_qualified=False))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--phase',choices=['qualify','intervene'],required=True);a=p.parse_args()
    qualification() if a.phase=='qualify' else intervention()
