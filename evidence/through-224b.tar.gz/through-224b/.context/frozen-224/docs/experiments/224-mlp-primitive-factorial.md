# 224: native-input RMSNorm / SiLU / product factorial at MLP22 and23

Registered before execution. Preserve all2,665 files of the223 closure unchanged, qualified204 scope, all numerical caveats and invalidity of replacement-agent conclusions. No browser, fitting, training, global correction sweep, publication or Git mutation. Copy/hash-seal this protocol, scientific helper, runner and auditor before model execution; afterward they are immutable. Corrections require new names and unchanged bounds.

## Defined intervention and question

223 established that local finite-minus-False-first-order remainders causally matter, not which primitive supplies them. At ONE site at a time (22 or23), hold its native full-sequence post-attention/pre-MLP residual fixed and cross three nonlinear nodes: MLP-input RMSNorm (N), SiLU (S) and gate–up product (P). Each is ordinary finite F or False-affine L, in order N/S/P. Linear projections remain actual public MPS modules. Only receiving rows after the Boolean source are changed. Prefix/source node outputs stay native. All remaining public transformer blocks and the final normalization/readout run finitely on the actual resulting full sequence.

L outputs use the SAME exact MPS False anchors and CPU64 frozen-primal local derivatives qualified in223: zF+JnormF(s−sF); phiF+sPrimeF(g−gF); pF+uF(phi−phiF)+phiF(u−uF). Cast to MPS Float32 only when installing a node output. Parents of later nodes are the ACTUAL outputs produced under earlier switches, not cached native parents. Save before/affine/after node outputs, actual parent increments, gate/up/product/down values and signed write changes.

Use exactly the32 old larch/marzipan contexts from223, both schemas/orders and all assignment/target cells. No new neuron/site selection. Native input is an oracle diagnostic, not a prospective prediction. The opposite22 margin signs do not establish a local sign-generating operation; downstream transmission can also change sign.

## PhaseE: qualify endpoints before the full matrix

For each context observe ordinaryFalse and ordinaryTrue public models and capture both sites. Check False anchors against the sealed223 qualification arrays and native trajectories against222/223. Save full native/False post-attention states, actual remaining full-sequence states, mask and RoPE. Continuations start by executing the chosen public RMS+MLP, add its actual write to the fixed mid-residual, then execute every remaining public block. No later native state is inserted.

At both sites run FFF, LLL and a False-input LLL sham. FFF must replay native write, selected block and remaining native trajectory/head. LLL must replay223's corresponding LF22 or FL23 local affine write, final residual and margin. False LLL must replay ordinaryFalse. Original bounds stay1e-4 per coordinate and.005 per score. A failure stops the remaining factorial; no numerical bridge, threshold relaxation or reinterpretation is allowed. A separate saved-array audit must pass and seal all endpoint artifacts before PhaseH.

Every used RMS, SiLU and product local derivative is checked against direct public MPS first AD AND promoted CPU64 central differences at epsilon1e-5, all receiving coordinates at1e-4. False primals replay at1e-4. Apply these checks also to every hybrid/control's actual parent directions. CPU64 differences promote arithmetic and do not replay the MPS forward map. Passing them does not recertify old whole-block derivatives.

## PhaseH: all partial subsets and matched controls

Run all six partial N/S/P settings (LLF,LFL,LFF,FLL,FLF,FFL) at each site. Together with the endpoint controls this gives all eight settings. Do not change the other selected site's operation; its actual incoming state and native computation respond normally.

For each partial setting, a restoration control starts from the same LLL write and adds a deterministic random receiving vector matching the actual partial-minus-LLL write edit's Frobenius norm. For each one-primitive deletion (LFF,FLF,FFL), a separate deletion control starts from FFF and applies a random vector matching the partial-minus-FFF write edit norm. Separate fixed orientations for restoration/deletion come from SHA256(context+site+purpose+224), never readout or target direction. Six restoration and three deletion controls per site/context. Save proposed and applied edits, match proposed norms within1e-9, and actual casting norm error within1e-4*max(1,reference norm).

These are write-space norm controls for the specified primitive interventions, not independent replications, feature controls or a universal causal allocation.

## Primary quantities and frozen action rules

Primary: actual final verdict-position residual deviation relative to nativeTrue−False displacement, cosine to native displacement, and actual natural true-minus-false margin change. Save full receiving displacement, each continued layer's actual receiving states and signed local write vectors. The32-neuron diagnostic is NOT an outcome in224; its earlier conditional evidence is preserved.

A partial subset is conditionally sufficient if it meets the original native matching bounds (verdict displacement norm>=.001, relativeL2<=.05, cosine>=.99, absolute margin change<=.10nats) AND both verdict/margin errors are smaller than its matched restoration control. A consistent sufficiency gate requires at least24/32 cases and6/8 in EVERY schema/order stratum. Report every subset, gate and case, including failures; the trivial FFF replay is not a discovery. Minimal passing subsets are described by cardinality without fitting weights or combining oracle corrections.

A primitive deletion has a consistently material, direction-specific effect if verdict relative deviation>.05 and absolute natural margin change>.10nats, with BOTH greater than the matched deletion control, on at least24/32 and6/8 in every stratum. Necessity and sufficiency are conditional on this intervention/background. They do not identify a learned circuit or prove general indispensability.

Report all12 matched primitive edges (each factor toggled in each background), their SIGNED local write vectors and natural margin effects, plus the exact three-factor inclusion-exclusion interactions at local writes and final finite margins. Norms/medians do not add as causal fractions. A finite-margin interaction can include downstream/readout effects; it is not automatically an internal primitive interaction.

## Work, qualification and preservation

PhaseE:64 ordinary full models,192 native/False suffix continuations,1,056 remaining public-block evaluations,192 finite heads and576 local primitive derivative directions/FD comparisons. PhaseH:960 native suffix continuations (384 partial+576 random),5,280 remaining public-block evaluations,960 finite heads and2,880 local primitive derivative directions/FD comparisons. Combined:64 ordinary models,1,152 suffix continuations,6,336 remaining public blocks,1,152 finite heads and3,456 primitive derivative directions/FD comparisons. These are finite suffix computations, NOT1,152 ordinary full-model calls. Exact counters are asserted.

Source/prefix node edits are zero, and continued prefix/source trajectories retain1e-4 state bounds. Independent CPU64 finite-head replay stays within.005. Installed affine/cast accounting and paired down-projection/rounding ledger close at1e-9. Every input and scientific source is hash-bound. Reports, failed checks, code, actual logs, figures, viewer and raw-array inventory are preserved. Clean-copy verification is not a second model replication. No fresh False-only forecast, efficiency claim, novelty priority or general QuestionB solution is claimed by this oracle factorial.
