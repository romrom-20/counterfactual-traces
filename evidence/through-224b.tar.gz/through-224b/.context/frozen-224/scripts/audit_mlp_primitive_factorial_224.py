"""Independent NumPy primitive equations, endpoint bridges and signed factorial audit."""

import argparse,hashlib,itertools,json
from pathlib import Path
import numpy as np
R=Path(__file__).resolve().parents[1];RUN=R/'runs/mlp-primitive-factorial-224';SITES=(22,23);NAMES=('norm','silu','product')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,x):p.write_text(json.dumps(x,indent=2,default=lambda a:a.item() if isinstance(a,np.generic) else str(a))+'\n')
def margin(s):return float(s[1]-s[0])
def head(s,w):
    h=s[-1].astype(np.float64);return(h/np.sqrt(np.mean(h*h)+float(w['eps']))*w['norm'])@w['head'].T
def cache(q,l):return{k[len(f'{l}_c_'):]:a.astype(np.float64) for k,a in q.items() if k.startswith(f'{l}_c_')}
def local(name,c,gamma,d):
    if name=='norm':
        a=c['inv'];s=c['s'];return gamma*a*(d[0]-s*a*a*np.mean(s*d[0],axis=-1,keepdims=True))
    if name=='silu':return c['sigma']*(1+c['gate']*(1-c['sigma']))*d[0]
    return d[0]*c['up']+c['phi']*d[1]
def smooth(name,gamma,eps,parents):
    if name=='norm':return gamma*(parents[0]/np.sqrt(np.mean(parents[0]**2,axis=-1,keepdims=True)+eps))
    if name=='silu':return parents[0]*np.exp(-np.logaddexp(0.,-parents[0]))
    return parents[0]*parents[1]
def initialize():
    d=json.loads((RUN/'design.json').read_text());assert all(sha(R/p)==h for p,h in d['source_hashes'].items())
    wp=R/d['weights_path'];assert sha(wp)==d['weights_sha256'];return d,dict(np.load(wp))
def load_case(key,rec):
    qp=R/'runs/native-mlp-remainder-223/qualification'/(key+'.npz');ip=R/'runs/native-mlp-remainder-223/interventions'/qp.name
    assert sha(qp)==rec['parents']['qualification_sha256'] and sha(ip)==rec['parents']['interventions223_sha256']
    mp=R/'runs/native-write-ledger-222/ledger'/(key+'.json');assert sha(mp)==rec['parents']['metadata222_sha256']
    return dict(np.load(qp)),dict(np.load(ip))
def audit_values(z,prefix,site,mode,c,w):
    get=lambda k:z[prefix+k].astype(np.float64);gamma=w[f'{site}_gamma'];eps=float(w[f'{site}_eps']);maxad=0.;maxfd=0.;maxreplay=0.
    for index,name in enumerate(NAMES):
        anchors={'norm':(c['s'],),'silu':(c['gate'],),'product':(c['phi'],c['up'])}[name];base={'norm':c['normalized'],'silu':c['phi'],'product':c['product']}[name]
        parents=tuple(get(f'{name}_parent{j}') for j in range(len(anchors)));deltas=tuple(a-b for a,b in zip(parents,anchors));jt=local(name,c,gamma,deltas);affine=base+jt
        assert np.max(abs(affine-get(name+'_affine')))<=1e-9
        after=get(name+'_after');before=get(name+'_finite');expected=affine.astype(np.float32) if mode[index]=='L' else before
        assert np.max(abs(after-expected))==0
        assert np.max(abs(get('q_'+name+'_analytic')-jt))<=1e-9
        ad=float(np.max(abs(get('q_'+name+'_dual')-jt)));fd=float(np.max(abs(get('q_'+name+'_fd')-jt)));assert ad<=1e-4 and fd<=1e-4
        reference=(smooth(name,gamma,eps,tuple(p+1e-5*d for p,d in zip(anchors,deltas)))-smooth(name,gamma,eps,tuple(p-1e-5*d for p,d in zip(anchors,deltas))))/(2e-5)
        replay=float(np.max(abs(reference-get('q_'+name+'_fd'))));assert replay<=1e-4
        maxad=max(maxad,ad);maxfd=max(maxfd,fd);maxreplay=max(maxreplay,replay)
    assert np.max(abs(get('norm_parent0')-get('mid')))==0
    assert np.max(abs(get('silu_parent0')-get('gate')))==0
    assert np.max(abs(get('product_parent0')-get('silu_after')))==0 and np.max(abs(get('product_parent1')-get('up')))==0
    # Preserve the actual linear projections and measure, rather than erase, their rounding.
    down=get('product_after')@w[f'{site}_down'].T;projection_error=float(np.max(abs(down-get('write_raw'))))
    h=float(np.max(abs(head(get('final'),w)-get('scores'))));assert h<=.005
    assert np.max(abs(get('final')-get('trajectory')[-1]))==0
    return dict(ad=maxad,fd=maxfd,fd_replay=maxreplay,head=h,raw_down_projection=projection_error)

def endpoints():
    out=R/'docs/analysis/224-endpoint-qualification.json';assert not out.exists() and not (RUN/'endpoint-seal.json').exists();d,w=initialize()
    status=json.loads((RUN/'endpoint-status.json').read_text());assert status['status']=='complete' and status['counts']==d['expectedE'];checks=[];errors=[];files={}
    for name in ('design.json','runtime.json','endpoint-status.json'):
        p=RUN/name;files[str(p.relative_to(R))]=sha(p)
    files[d['weights_path']]=d['weights_sha256']
    for key in d['contexts']:
        p=RUN/'endpoints'/(key+'.npz');rec=json.loads(p.with_suffix('.json').read_text());assert sha(p)==rec['arrays_sha256'];z=dict(np.load(p));q,old=load_case(key,rec);checks.extend(rec['checks']);start=rec['position']+1
        for f in (p,p.with_suffix('.json')):files[str(f.relative_to(R))]=sha(f)
        for job in rec['jobs']:
            l=job['site'];prefix=job['label']+'_';errors.append(audit_values(z,prefix,l,job['mode'],cache(q,l),w));name='N' if job['bit'] else 'F'
            assert np.max(abs(z[prefix+'mid']-z[f'{name}_mid{l}'][0,start:]))==0
            assert np.max(abs(z[prefix+'write']-z[prefix+'write_raw']))==0
            if job['label'].endswith('_FFF'):
                assert np.max(abs(z[prefix+'write']-old[f'FF_{l}_before']))<=1e-4
                assert np.max(abs(z[prefix+'trajectory']-z['N_tail_states'][l-22:,start:]))<=1e-4 and np.max(abs(z[prefix+'scores']-z['N_scores']))<=.005
            elif job['label'].endswith('_LLL'):
                arm='LF' if l==22 else 'FL';assert np.max(abs(z[prefix+'write']-old[f'{arm}_{l}_after']))<=1e-4
                assert np.max(abs(z[prefix+'final']-old[arm+'_final']))<=1e-4 and np.max(abs(z[prefix+'scores']-old[arm+'_scores']))<=.005
            else:
                assert np.max(abs(z[prefix+'trajectory']-z['F_tail_states'][l-22:,start:]))<=1e-4 and np.max(abs(z[prefix+'scores']-z['F_scores']))<=.005
        assert np.max(abs(head(z['N_tail_states'][-1],w)-z['N_scores']))<=.005 and np.max(abs(head(z['F_tail_states'][-1],w)-z['F_scores']))<=.005
    assert len(errors)==192 and all(c['error']<=c['bound'] for c in checks)
    result=dict(qualified=True,contexts=32,counts=status['counts'],controls=len(checks),primitive_checks=576,maxima={k:max(e[k] for e in errors) for k in errors[0]},
        scope='Native finite and223 affine endpoint compatibility at original bounds; qualified receiving primitive directions. No old whole-block Jacobian recertification.',auditor_sha256=sha(Path(__file__)))
    write(out,result);files[str(out.relative_to(R))]=sha(out);write(RUN/'endpoint-seal.json',dict(files=files,hybrid_continuations_before_seal=0,auditor_sha256=sha(Path(__file__))))
    print(json.dumps(result,indent=2))

def hybrids():
    out=R/'docs/analysis/224-mlp-primitive-factorial.json';assert not out.exists();d,w=initialize();status=json.loads((RUN/'status.json').read_text());assert status['status']=='complete' and status['counts']==d['expectedH']
    seal=json.loads((RUN/'endpoint-seal.json').read_text());assert seal['hybrid_continuations_before_seal']==0 and all(sha(R/p)==h for p,h in seal['files'].items())
    rows=[];edges=[];interactions=[];checks=[];errors=[];closure=0.
    for key in d['contexts']:
        p=RUN/'hybrids'/(key+'.npz');rec=json.loads(p.with_suffix('.json').read_text());assert sha(p)==rec['arrays_sha256'];z=dict(np.load(p));q,old=load_case(key,rec);checks.extend(rec['checks'])
        ep=RUN/'endpoints'/p.name;assert sha(ep)==rec['endpoint_sha256'];e=dict(np.load(ep));er=json.loads(ep.with_suffix('.json').read_text());start=rec['position']+1
        combined={**e,**z};jobs=[j for j in er['jobs'] if j['bit']]+rec['jobs'];assert len(jobs)==34;contrasts={}
        for job in jobs:
            l=job['site'];prefix=job['label']+'_';c=cache(q,l)
            if job in rec['jobs']:errors.append(audit_values(combined,prefix,l,job['mode'],c,w))
            assert np.max(abs(combined[prefix+'mid']-e[f'N_mid{l}'][0,start:]))==0
            if job['kind']=='random':
                base=job['mode'];purpose=job['purpose'];target=job['target'];bw=e[f's{l}_{base}_write'].astype(np.float64);candidate=z[f's{l}_{target}_write'].astype(np.float64);rn=float(np.linalg.norm(candidate-bw))
                unit=z[f's{l}_{purpose}_unit'];assert abs(np.linalg.norm(unit)-1)<=1e-9
                expected=bw+unit*rn;assert abs(job['reference_norm']-rn)<=1e-9 and np.max(abs(z[prefix+'proposed']-expected))<=1e-9 and np.max(abs(z[prefix+'write']-expected.astype(np.float32)))==0
            else:assert np.max(abs(combined[prefix+'write']-combined[prefix+'write_raw']))==0
            native=e[f's{l}_FFF_final'].astype(np.float64);false=e['F_tail_states'][-1,start:].astype(np.float64);native_delta=native-false;norm=np.linalg.norm(native_delta[-1]);assert norm>=.001
            final=combined[prefix+'final'].astype(np.float64);edit=final-native;delta=final-false;den=np.linalg.norm(delta[-1])*norm;cos=float(np.dot(delta[-1],native_delta[-1])/den) if den>0 else 0.
            qv=float(np.linalg.norm(edit[-1])/norm);dm=margin(combined[prefix+'scores'])-margin(e[f's{l}_FFF_scores'])
            rows.append(dict(context=key,group=rec['group'],site=l,label=job['label'],mode=job['mode'],kind=job['kind'],purpose=job.get('purpose'),target=job.get('target'),
                verdict_relative_deviation=qv,receiver_relative_deviation=float(np.linalg.norm(edit)/np.linalg.norm(native_delta)),cosine=cos,margin_change=dm,absolute_margin_change=abs(dm),
                natural_margin=margin(combined[prefix+'scores']),native_margin=margin(e[f's{l}_FFF_scores']),response_preserved=bool(qv<=.05 and cos>=.99 and abs(dm)<=.1),material_both=bool(qv>.05 and abs(dm)>.1)))
        for l in SITES:
            get=lambda mode,name:combined[f's{l}_{mode}_{name}'].astype(np.float64)
            r=old[f'FF_{l}_remainder'].astype(np.float64);rrnorm=float(np.sum(r*r))
            for index,factor in enumerate(NAMES):
                for other in itertools.product('LF',repeat=2):
                    a=list(other);a.insert(index,'L');lo=''.join(a);a[index]='F';hi=''.join(a)
                    v=get(hi,'write')-get(lo,'write');dy=get(hi,'final')-get(lo,'final');dp=get(hi,'product_after')-get(lo,'product_after')
                    qa=(get(hi,'write_raw')-get(hi,'product_after')@w[f'{l}_down'].T)-(get(lo,'write_raw')-get(lo,'product_after')@w[f'{l}_down'].T)
                    err=float(np.max(abs(v-dp@w[f'{l}_down'].T-qa)));closure=max(closure,err);assert err<=1e-9
                    name=f'{l}_{lo}_to_{hi}';contrasts[name+'_write']=v;contrasts[name+'_final']=dy
                    edges.append(dict(context=key,group=rec['group'],site=l,factor=factor,low=lo,high=hi,write_norm=float(np.linalg.norm(v)),projection_223_remainder=float(np.sum(v*r)/rrnorm),
                        verdict_effect_norm=float(np.linalg.norm(dy[-1])),margin_effect=margin(get(hi,'scores'))-margin(get(lo,'scores'))))
            components={};mcomponents={};fcomponents={}
            for size in (1,2,3):
                for subset in itertools.combinations(range(3),size):
                    name=''.join('NSP'[i] for i in subset);v=np.zeros_like(get('LLL','write'));dy=np.zeros_like(get('LLL','final'));dm=0.
                    for mask in itertools.product((0,1),repeat=size):
                        mode=['L']*3
                        for i,bit in zip(subset,mask):mode[i]='F' if bit else 'L'
                        mode=''.join(mode);sign=(-1)**(size-sum(mask));v+=sign*get(mode,'write');dy+=sign*get(mode,'final');dm+=sign*margin(get(mode,'scores'))
                    components[name]=v;fcomponents[name]=dy;mcomponents[name]=dm;contrasts[f'{l}_component_{name}_write']=v;contrasts[f'{l}_component_{name}_final']=dy
                    interactions.append(dict(context=key,group=rec['group'],site=l,component=name,order=size,write_norm=float(np.linalg.norm(v)),projection_223_remainder=float(np.sum(v*r)/rrnorm),margin_contrast=dm))
            assert np.max(abs(sum(components.values())-(get('FFF','write')-get('LLL','write'))))<=1e-9
            assert np.max(abs(sum(fcomponents.values())-(get('FFF','final')-get('LLL','final'))))<=1e-9
            assert abs(sum(mcomponents.values())-(margin(get('FFF','scores'))-margin(get('LLL','scores'))))<=1e-9
        dest=RUN/'contrasts'/p.name;np.savez_compressed(dest,**contrasts);write(dest.with_suffix('.json'),dict(key=key,arrays_sha256=sha(dest),endpoint_sha256=sha(ep),hybrid_sha256=sha(p)))
    assert len(rows)==1088 and len(edges)==768 and len(interactions)==448 and len(errors)==960 and all(c['error']<=c['bound'] for c in checks)
    gates=[]
    for site in SITES:
        for purpose,modes in (('restore',d['partial']),('delete',d['deletions'])):
            for mode in modes:
                vals=[]
                for key in d['contexts']:
                    a=next(r for r in rows if r['context']==key and r['site']==site and r['label']==f's{site}_{mode}')
                    b=next(r for r in rows if r['context']==key and r['site']==site and r['label']==f's{site}_rand_{purpose}_{mode}')
                    if purpose=='restore':eligible=a['response_preserved'];beats=a['verdict_relative_deviation']<b['verdict_relative_deviation'] and a['absolute_margin_change']<b['absolute_margin_change']
                    else:eligible=a['material_both'];beats=a['verdict_relative_deviation']>b['verdict_relative_deviation'] and a['absolute_margin_change']>b['absolute_margin_change']
                    vals.append(dict(context=key,group=a['group'],eligible=eligible,beats_random=beats,combined=bool(eligible and beats)))
                strata=[]
                for schema,order in itertools.product(('generic','descriptive'),range(2)):
                    rr=[r for r in vals if r['group']['schema']==schema and r['group']['reverse']==order];assert len(rr)==8
                    strata.append(dict(schema=schema,order=order,counts={k:sum(bool(r[k]) for r in rr) for k in ('eligible','beats_random','combined')}))
                totals={k:sum(bool(r[k]) for r in vals) for k in ('eligible','beats_random','combined')}
                gates.append(dict(site=site,purpose=purpose,mode=mode,totals=totals,strata=strata,passed=bool(totals['combined']>=24 and all(s['counts']['combined']>=6 for s in strata))))
    minimal=[]
    for site in SITES:
        passing=[g['mode'] for g in gates if g['site']==site and g['purpose']=='restore' and g['passed']];k=min(map(lambda m:m.count('F'),passing)) if passing else None
        minimal.append(dict(site=site,minimum_finite_primitives=k,modes=[m for m in passing if m.count('F')==k]))
    summaries=[]
    for site in SITES:
        for mode in d['modes']:
            for schema in (None,'generic','descriptive'):
                rr=[r for r in rows if r['site']==site and r['mode']==mode and r['kind']!='random' and (schema is None or r['group']['schema']==schema)]
                summaries.append(dict(site=site,mode=mode,schema=schema,count=len(rr),preserved=sum(r['response_preserved'] for r in rr),material_both=sum(r['material_both'] for r in rr),
                    medians={k:float(np.median([r[k] for r in rr])) for k in ('verdict_relative_deviation','receiver_relative_deviation','margin_change','absolute_margin_change')}))
    result=dict(qualified=True,contexts=32,counts=status['counts'],controls=len(checks),primitive_checks=2880,maxima={k:max(e[k] for e in errors) for k in errors[0]},maximum_paired_down_rounding_closure=closure,
        gates=gates,minimal_subsets=minimal,summaries=summaries,rows=rows,edges=edges,interactions=interactions,prospective=False,original_wholeblock_jacobian_qualified=False,full_question_B_solved=False,
        scope='Retrospective native-input public-node factorial. Native/223 affine endpoints qualified first. Natural verdict residual/margin primary; signed write and finite-margin interactions are conditional contrasts, not causal percentages or learned circuits.',auditor_sha256=sha(Path(__file__)))
    write(out,result);print(json.dumps({k:v for k,v in result.items() if k not in ('rows','edges','interactions','summaries','gates')},indent=2));print(json.dumps(gates,indent=2));print(json.dumps(summaries,indent=2))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--phase',choices=['endpoints','hybrids'],required=True);a=p.parse_args();endpoints() if a.phase=='endpoints' else hybrids()
