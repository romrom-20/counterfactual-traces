"""Actual receiving-node surgeries and independent local derivative checks."""

from contextlib import contextmanager
from itertools import product
import torch
from torch.nn import functional as F

SITES=(22,23);MODES=tuple(''.join(p) for p in product('LF',repeat=3));PARTIAL=tuple(m for m in MODES if m not in ('LLL','FFF'));DELETIONS=('LFF','FLF','FFL')
NAMES=('norm','silu','product')
def derivative(name,c,gamma,d):
    if name=='norm':
        s=c['s'];a=c['inv'];return gamma*a*(d[0]-s*a.square()*(s*d[0]).mean(-1,keepdim=True))
    if name=='silu':return c['sigma']*(1+c['gate']*(1-c['sigma']))*d[0]
    return d[0]*c['up']+c['phi']*d[1]

@contextmanager
def surgery(layer,c,start,mode):
    records={};live={};handles=[];gamma=layer.post_attention_layernorm.weight.detach().cpu().double()
    def apply(name,args,out,flag):
        parents=tuple(v[0,start:].detach().cpu().double() for v in args)
        anchors={'norm':(c['s'],),'silu':(c['gate'],),'product':(c['phi'],c['up'])}[name]
        d=tuple(p-a for p,a in zip(parents,anchors));base={'norm':c['normalized'],'silu':c['phi'],'product':c['product']}[name]
        affine=base+derivative(name,c,gamma,d);finite=out[0,start:].detach().cpu().double()
        value=out.clone()
        if flag=='L':value[:,start:]=affine[None].to(device=out.device,dtype=out.dtype)
        assert float((value[:,:start]-out[:,:start]).abs().max())==0
        records[name]=dict(finite=finite,affine=affine,after=value[0,start:].detach().cpu().double(),**{f'parent{j}':p for j,p in enumerate(parents)})
        return value
    def norm(module,args,out):return apply('norm',args,out,mode[0])
    def silu(module,args,out):
        value=apply('silu',args,out,mode[1]);live['phi']=value.detach();return value
    def up(module,args,out):live['up']=out.detach()
    def before_down(module,args):return(apply('product',(live['phi'],live['up']),args[0],mode[2]),)
    handles.extend((layer.post_attention_layernorm.register_forward_hook(norm),layer.mlp.act_fn.register_forward_hook(silu),layer.mlp.up_proj.register_forward_hook(up),layer.mlp.down_proj.register_forward_pre_hook(before_down)))
    try:yield records
    finally:
        for h in handles:h.remove()

def qualify(layer,c,gamma,records,eps):
    out={};errors=[];device=layer.mlp.down_proj.weight.device
    for name in NAMES:
        parents={'norm':(c['s'],),'silu':(c['gate'],),'product':(c['phi'],c['up'])}[name]
        ds=tuple(records[name][f'parent{j}']-p for j,p in enumerate(parents))
        if name=='norm':
            fn=lambda x:layer.post_attention_layernorm(x)
            smooth=lambda x:gamma*(x*torch.rsqrt(x.square().mean(-1,keepdim=True)+eps))
            expected=c['normalized']
        elif name=='silu':fn=layer.mlp.act_fn;smooth=F.silu;expected=c['phi']
        else:fn=lambda x,y:x*y;smooth=lambda x,y:x*y;expected=c['product']
        with torch.no_grad():primal,dual=torch.func.jvp(fn,tuple(p.to(device=device,dtype=torch.float32) for p in parents),tuple(d.to(device=device,dtype=torch.float32) for d in ds))
        analytic=derivative(name,c,gamma,ds);fd=(smooth(*(p+1e-5*d for p,d in zip(parents,ds)))-smooth(*(p-1e-5*d for p,d in zip(parents,ds))))/(2e-5)
        values=dict(analytic=analytic,dual=dual.detach().cpu().double(),fd=fd)
        for k,v in values.items():out[name+'_'+k]=v
        e=dict(name=name,primal=float((primal.detach().cpu().double()-expected).abs().max()),ad=float((values['dual']-analytic).abs().max()),fd=float((fd-analytic).abs().max()))
        assert all(e[k]<=1e-4 for k in ('primal','ad','fd')),e;errors.append(e)
    return out,errors
