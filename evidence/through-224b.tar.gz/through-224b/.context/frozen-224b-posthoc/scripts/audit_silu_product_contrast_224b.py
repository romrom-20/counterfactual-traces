"""Posthoc actual-vector SiLU-curvature × up-change accounting; zero model calls."""
import hashlib,json
from pathlib import Path
import numpy as np
from audit_mlp_primitive_factorial_224b import R,RUN,initialize,load_case,margin
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    result=R/'docs/analysis/224b-mlp-primitive-factorial.json';out=R/'docs/analysis/224b-silu-product-accounting.json';assert not out.exists();x=json.loads(result.read_text());assert x['qualified'];d,w=initialize();rows=[];rawmax=0.;closure=0.
    dest=RUN/'silu-product-contrasts';assert not dest.exists();dest.mkdir()
    for key in d['contexts']:
        ep=RUN/'endpoints'/(key+'.npz');hp=RUN/'hybrids'/ep.name;er=json.loads(ep.with_suffix('.json').read_text());hr=json.loads(hp.with_suffix('.json').read_text());assert sha(ep)==er['arrays_sha256'] and sha(hp)==hr['arrays_sha256'];z={**dict(np.load(ep)),**dict(np.load(hp))};q,old=load_case(key,hr);arrays={}
        for site in (22,23):
            for n in 'LF':
                modes=[n+'LL',n+'FL',n+'LF',n+'FF'];get=lambda mode,k:z[f's{site}_{mode}_{k}'].astype(np.float64)
                base,a,b,ab=modes
                for k in ('gate','up'):
                    assert max(np.max(abs(get(m,k)-get(base,k))) for m in modes)==0
                assert np.max(abs(get(a,'silu_after')-get(ab,'silu_after')))==0 and np.max(abs(get(base,'silu_after')-get(b,'silu_after')))==0
                c=get(a,'silu_after')-get(base,'silu_after');du=get(base,'up')-q[f'{site}_c_up'];ideal=c*du
                pc=get(ab,'product_after')-get(b,'product_after')-get(a,'product_after')+get(base,'product_after')
                # ProductF cells use actual multiplication; ProductL cells use a cast affine map.
                def product_round(m):return get(m,'product_after')-get(m,'silu_after')*get(m,'up')
                def affine_cast(m):return get(m,'product_after')-get(m,'product_affine')
                pr=product_round(ab)-product_round(b)-affine_cast(a)+affine_cast(base)
                assert np.max(abs(pc-ideal-pr))<=1e-9
                down=w[f'{site}_down'];actual=get(ab,'write')-get(b,'write')-get(a,'write')+get(base,'write');v=ideal@down.T
                def down_round(m):return get(m,'write')-get(m,'product_after')@down.T
                dr=down_round(ab)-down_round(b)-down_round(a)+down_round(base);error=float(np.max(abs(actual-v)));e=float(np.max(abs(actual-v-pr@down.T-dr)));rawmax=max(rawmax,error);closure=max(closure,e);assert e<=1e-9
                prefix=f'{site}_{n}_';arrays.update({prefix+k:v for k,v in dict(curvature=c,up_increment=du,ideal_product=ideal,actual_product_contrast=pc,ideal_write=v,actual_write_contrast=actual,product_rounding_write=pr@down.T,down_rounding_write=dr).items()})
                lm=margin(get(a,'scores'))-margin(get(base,'scores'));fm=margin(get(ab,'scores'))-margin(get(b,'scores'))
                rows.append(dict(context=key,group=hr['group'],site=site,norm=n,linear_product_silu_margin_effect=lm,finite_product_silu_margin_effect=fm,sign_reversal=bool(lm*fm<0),
                    ideal_write_norm=float(np.linalg.norm(v)),actual_write_norm=float(np.linalg.norm(actual)),raw_ideal_coordinate_error=error,raw_ideal_pass=bool(error<=1e-4),rounding_closure=e))
        p=dest/ep.name;np.savez_compressed(p,**arrays);p.with_suffix('.json').write_text(json.dumps(dict(arrays_sha256=sha(p),endpoint_sha256=sha(ep),hybrid_sha256=sha(hp)),indent=2)+'\n')
    assert len(rows)==128
    y=dict(scope='Explicitly posthoc accounting of old224b factorial states. Known bilinear identity; zero new model evaluations. Does not isolate local cross-vector from altered downstream baseline as the cause of final-margin sign reversal.',primary_audit_sha256=sha(result),source_sha256=sha(Path(__file__)),protocol_sha256=sha(R/'docs/experiments/224b-silu-product-posthoc-accounting.md'),
        rows=rows,raw_ideal_failures=sum(not r['raw_ideal_pass'] for r in rows),maximum_raw_ideal_coordinate_error=rawmax,maximum_rounding_closure=closure,sign_reversals={str(site):sum(r['sign_reversal'] for r in rows if r['site']==site) for site in (22,23)},prospective=False,mechanism_of_final_margin_reversal_established=False)
    out.write_text(json.dumps(y,indent=2)+'\n');print(json.dumps({k:v for k,v in y.items() if k!='rows'},indent=2))
if __name__=='__main__':main()
