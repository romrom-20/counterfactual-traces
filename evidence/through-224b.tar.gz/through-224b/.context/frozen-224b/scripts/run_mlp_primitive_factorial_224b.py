"""Endpoint-qualified native full-sequence primitive factorial and matched controls."""

import argparse,hashlib,json
from collections import Counter
from contextlib import ExitStack
from pathlib import Path
import numpy as np
import torch
import ranked_block_response_201 as public
from native_receiver_factorial_221 import captured
from native_mlp_remainder_223 import parameters
from mlp_primitive_factorial_224 import SITES,MODES,PARTIAL,DELETIONS,NAMES,surgery,qualify
from latent_decisions.target import load_target
from latent_decisions.evidence_policy import digest

R=Path(__file__).resolve().parents[1];RUN=R/'runs/mlp-primitive-factorial-224b';WPATH=R/'runs/native-mlp-remainder-223/weights.npz'
SOURCES=['scripts/run_mlp_primitive_factorial_224b.py','scripts/mlp_primitive_factorial_224.py','scripts/audit_mlp_primitive_factorial_224b.py','docs/experiments/224b-mlp-primitive-factorial.md',
 'scripts/native_mlp_remainder_223.py','scripts/native_receiver_factorial_221.py','scripts/gate_up_arithmetic_213.py','scripts/ranked_block_response_201.py','src/latent_decisions/target.py','scripts/run_mlp_primitive_factorial_224.py','scripts/audit_mlp_primitive_factorial_224.py','docs/experiments/224-mlp-primitive-factorial.md']
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,x):p.write_text(json.dumps(x,indent=2,default=lambda v:v.item() if isinstance(v,np.generic) else str(v))+'\n')
def cpu(x):return x.detach().cpu().numpy().copy()
def store(out,prefix,values):
    for k,v in values.items():out[prefix+k]=cpu(v) if torch.is_tensor(v) else np.asarray(v)
def checking(checks):
    def check(kind,error,bound=1e-4):checks.append(dict(kind=kind,error=float(error),bound=bound));assert float(error)<=bound,checks[-1]
    return check
def cache(q,l):return{k[len(f'{l}_c_'):]:torch.tensor(a) for k,a in q.items() if k.startswith(f'{l}_c_')}
def parents(key):
    qp=R/'runs/native-mlp-remainder-223/qualification'/(key+'.npz');ip=R/'runs/native-mlp-remainder-223/interventions'/qp.name
    qr=json.loads(qp.with_suffix('.json').read_text());ir=json.loads(ip.with_suffix('.json').read_text());assert sha(qp)==qr['arrays_sha256'] and sha(ip)==ir['arrays_sha256']
    mp=R/'runs/native-write-ledger-222/ledger'/(key+'.json');mr=json.loads(mp.read_text())
    recorded=R/'results/native-write-ledger-222/recorded-runs/native-write-ledger-222/ledger'/mp.name;assert sha(mp)==sha(recorded)
    return dict(np.load(qp)),dict(np.load(ip)),mr,dict(qualification_sha256=sha(qp),interventions223_sha256=sha(ip),metadata222_sha256=sha(mp))
def model():
    rt=json.loads((RUN/'runtime.json').read_text());m,t,device=load_target(rt['model'],'mps',offline=True);torch.set_num_threads(2)
    assert not m.training and m.config._attn_implementation=='eager' and next(m.parameters()).dtype==torch.float32
    assert digest(t.get_vocab())==rt['tokenizer_hash'] and digest(m.config.to_dict())==rt['config_hash'];w=dict(np.load(WPATH))
    for l in SITES:
        for k,v in parameters(m.model.layers[l-1]).items():assert np.max(abs(cpu(v)-w[f'{l}_{k}']))==0
    return m,device,w

def evaluate(m,l,mid,ref,ctx,c,mode,start,counts,check,override=None):
    layer=m.model.layers[l-1]
    with surgery(layer,c,start,mode) as nodes,captured(layer) as cap,torch.no_grad():raw=layer.mlp(layer.post_attention_layernorm(mid))
    value=raw.clone()
    if override is not None:value[:,start:]=override[None].to(device=mid.device,dtype=mid.dtype)
    check('write_source_prefix',(value[:,:start]-raw[:,:start]).abs().max(),0.)
    with torch.no_grad():
        state=mid+value;states=[state]
        check('continued_source_prefix',(state[0,:start]-ref[l-22,:start]).abs().max())
        for j in range(l,28):
            state=public.block(m.model.layers[j],state,ctx);states.append(state);counts['remaining_public_blocks']+=1
            check('continued_source_prefix',(state[0,:start]-ref[j-21,:start]).abs().max())
        score=public.head(m,state)
    counts['suffix_continuations']+=1;counts['finite_heads']+=1
    q,errors=qualify(layer,c,layer.post_attention_layernorm.weight.detach().cpu().double(),nodes,layer.post_attention_layernorm.variance_epsilon)
    counts['primitive_checks']+=3
    for e in errors:
        for kind in ('primal','ad','fd'):check(e['name']+'_'+kind,e[kind])
    out=dict(mid=cpu(mid[0,start:]),write_raw=cpu(raw[0,start:]),write=cpu(value[0,start:]),gate=cpu(cap['gate'][0,start:]).astype(np.float32),up=cpu(cap['up'][0,start:]).astype(np.float32),
        trajectory=cpu(torch.stack(states)[:,0,start:]),final=cpu(state[0,start:]),scores=cpu(score))
    for name,values in nodes.items():store(out,name+'_',values)
    store(out,'q_',q)
    return out

def endpoints():
    assert not RUN.exists();failed=R/'runs/mlp-primitive-factorial-224/failure.json';assert json.loads(failed.read_text())['hybrids_executed']==0;prior=R/'results/native-mlp-remainder-223/manifest.json';old=json.loads(prior.read_text());assert len(old['files'])==2665 and all(sha(R/p)==h for p,h in old['files'].items())
    oldseal=json.loads((R/'runs/native-mlp-remainder-223/qualification-seal.json').read_text());assert all(sha(R/p)==h for p,h in oldseal['files'].items())
    contexts=json.loads((R/'runs/native-mlp-remainder-223/design.json').read_text())['contexts'];assert len(contexts)==32
    RUN.mkdir();(RUN/'endpoints').mkdir();(RUN/'hybrids').mkdir();(RUN/'contrasts').mkdir()
    design=dict(source_hashes={p:sha(R/p) for p in SOURCES},failed224_sha256=sha(failed),previous_manifest_sha256=sha(prior),weights_path=str(WPATH.relative_to(R)),weights_sha256=sha(WPATH),contexts=contexts,
        modes=MODES,partial=PARTIAL,deletions=DELETIONS,expectedE=dict(ordinary_models=64,suffix_continuations=192,remaining_public_blocks=1056,finite_heads=192,primitive_checks=576),
        expectedH=dict(ordinary_models=0,suffix_continuations=960,remaining_public_blocks=5280,finite_heads=960,primitive_checks=2880))
    write(RUN/'design.json',design);write(RUN/'runtime.json',json.loads((R/'runs/native-mlp-remainder-223/runtime.json').read_text()))
    m,device,w=model();counts=Counter(ordinary_models=0)
    for n,key in enumerate(contexts,1):
        q,old,rec,prefs=parents(key);start=rec['position']+1;checks=[];check=checking(checks);out={};allstates={};contextsGPU={}
        for bit,name in ((0,'F'),(1,'N')):
            with ExitStack() as stack:
                caps={l:stack.enter_context(captured(m.model.layers[l-1])) for l in SITES}
                states,ctx,score=public.observe(m,torch.tensor([rec['bases'][bit]['free_input_ids']],device=device))
            counts['ordinary_models']+=1;allstates[name]=torch.stack([s[0] for s in states[21:]]);contextsGPU[name]=ctx
            out[name+'_tail_states']=cpu(allstates[name]);out[name+'_scores']=cpu(score)
            for l in SITES:
                out[f'{name}_mid{l}']=cpu(caps[l]['mid']).astype(np.float32)
                if not bit:
                    for stored,field in (('s','mid'),('gate','gate'),('phi','phi'),('up','up'),('product','product'),('write','down'),('normalized','normalized')):
                        check('False_anchor',np.max(abs(cpu(caps[l][field][0,start:])-q[f'{l}_c_{stored}'])))
            check('ordinary_native_endpoint' if bit else 'ordinary_False_endpoint',np.max(abs(cpu(states[-1][0,start:])-old['FF_final' if bit else 'False_final'])))
            check('ordinary_head',np.max(abs(cpu(score)-old['FF_scores' if bit else 'False_scores'])),.005)
        for k in ('mask','rope'):
            if k=='mask':check('context_mask',0. if torch.equal(contextsGPU['F'][k],contextsGPU['N'][k]) else float('inf'),0.)
            else:
                for a,b in zip(contextsGPU['F'][k],contextsGPU['N'][k]):check('context_rope',(a-b).abs().max(),0.)
        ctx=contextsGPU['N'];out['mask']=cpu(ctx['mask']);out['rope_cos']=cpu(ctx['rope'][0]);out['rope_sin']=cpu(ctx['rope'][1]);jobs=[]
        for l in SITES:
            c=cache(q,l)
            for tag,mode,name in (('FFF','FFF','N'),('LLL','LLL','N'),('False','LLL','F')):
                label=f's{l}_{tag}';mid=torch.tensor(out[f'{name}_mid{l}'],device=device);v=evaluate(m,l,mid,allstates[name],ctx,c,mode,start,counts,check);store(out,label+'_',v)
                if tag=='FFF':
                    check('FFF_write',np.max(abs(v['write']-old[f'FF_{l}_before'])))
                    check('FFF_full_native_trajectory',np.max(abs(v['trajectory']-out['N_tail_states'][l-22:,start:])));check('FFF_head',np.max(abs(v['scores']-out['N_scores'])),.005)
                elif tag=='LLL':
                    arm='LF' if l==22 else 'FL';check('LLL_223_write',np.max(abs(v['write']-old[f'{arm}_{l}_after'])))
                    out[f'{label}_223_final_difference']=v['final'].astype(np.float64)-old[arm+'_final'].astype(np.float64)
                    out[f'{label}_223_score_difference']=v['scores'].astype(np.float64)-old[arm+'_scores'].astype(np.float64)
                    out[f'{label}_223_boundary27_difference']=v['trajectory'][-2].astype(np.float64)-old[arm+'_boundary27'].astype(np.float64)
                    native_delta=out['N_tail_states'][-1,start:].astype(np.float64)-out['F_tail_states'][-1,start:].astype(np.float64)
                    check('composed_composite_verdict_relative_discrepancy',np.linalg.norm(out[f'{label}_223_final_difference'][-1])/np.linalg.norm(native_delta[-1]),.05)
                    check('composed_composite_margin_discrepancy',abs(float(np.diff(out[f'{label}_223_score_difference'])[0])),.1)
                else:
                    check('False_sham_write',np.max(abs(v['write']-q[f'{l}_c_write'])));check('False_sham_full_trajectory',np.max(abs(v['trajectory']-out['F_tail_states'][l-22:,start:])));check('False_sham_head',np.max(abs(v['scores']-out['F_scores'])),.005)
                jobs.append(dict(label=label,site=l,mode=mode,bit=int(name=='N'),kind='endpoint'))
        path=RUN/'endpoints'/(key+'.npz');np.savez_compressed(path,**out);write(path.with_suffix('.json'),dict(key=key,group=rec['group'],position=rec['position'],arrays_sha256=sha(path),parents=prefs,jobs=jobs,checks=checks))
        write(RUN/'endpoint-status.json',dict(status='qualifying',completed=n,counts=dict(counts)));print('endpoints',n,key,flush=True)
    assert dict(counts)==design['expectedE'],(dict(counts),design['expectedE']);assert all(sha(R/p)==h for p,h in design['source_hashes'].items())
    write(RUN/'endpoint-status.json',dict(status='complete',qualified_controls=True,counts=dict(counts)))

def hybrids():
    d=json.loads((RUN/'design.json').read_text());seal=json.loads((RUN/'endpoint-seal.json').read_text());assert all(sha(R/p)==h for p,h in seal['files'].items())
    assert seal['hybrid_continuations_before_seal']==0 and all(sha(R/p)==h for p,h in d['source_hashes'].items())
    assert not any((RUN/'hybrids').iterdir());m,device,w=model();counts=Counter(ordinary_models=0)
    for n,key in enumerate(d['contexts'],1):
        q,old,rec,prefs=parents(key);start=rec['position']+1;ep=RUN/'endpoints'/(key+'.npz');er=json.loads(ep.with_suffix('.json').read_text());assert sha(ep)==er['arrays_sha256'];e=dict(np.load(ep))
        ctx=dict(mask=torch.tensor(e['mask'],device=device),rope=tuple(torch.tensor(e[k],device=device) for k in ('rope_cos','rope_sin')));ref=torch.tensor(e['N_tail_states'],device=device)
        checks=[];check=checking(checks);out={};jobs=[]
        for l in SITES:
            c=cache(q,l);mid=torch.tensor(e[f'N_mid{l}'],device=device)
            for mode in PARTIAL:
                label=f's{l}_{mode}';v=evaluate(m,l,mid,ref,ctx,c,mode,start,counts,check);store(out,label+'_',v);jobs.append(dict(label=label,site=l,mode=mode,bit=1,kind='factorial'))
            for purpose,modes,base in (('restore',PARTIAL,'LLL'),('delete',DELETIONS,'FFF')):
                rng=np.random.default_rng(int(hashlib.sha256((key+str(l)+purpose+'224').encode()).hexdigest()[:16],16));unit=rng.standard_normal(c['s'].shape);unit/=np.linalg.norm(unit);out[f's{l}_{purpose}_unit']=unit
                basewrite=e[f's{l}_{base}_write'].astype(np.float64)
                for target in modes:
                    candidate=out[f's{l}_{target}_write'].astype(np.float64);norm=float(np.linalg.norm(candidate-basewrite));proposed=basewrite+unit*norm
                    check('random_proposed_norm',abs(float(np.linalg.norm(proposed-basewrite))-norm),1e-9)
                    label=f's{l}_rand_{purpose}_{target}';v=evaluate(m,l,mid,ref,ctx,c,base,start,counts,check,override=torch.tensor(proposed))
                    check('random_base_replay',np.max(abs(v['write_raw']-basewrite)));check('random_applied_norm',abs(float(np.linalg.norm(v['write'].astype(np.float64)-basewrite))-norm),1e-4*max(1.,norm))
                    store(out,label+'_',v);out[label+'_proposed']=proposed;out[label+'_reference_norm']=np.array(norm)
                    jobs.append(dict(label=label,site=l,mode=base,bit=1,kind='random',purpose=purpose,target=target,reference_norm=norm))
        path=RUN/'hybrids'/(key+'.npz');np.savez_compressed(path,**out);write(path.with_suffix('.json'),dict(key=key,group=rec['group'],position=rec['position'],arrays_sha256=sha(path),endpoint_sha256=sha(ep),parents=prefs,jobs=jobs,checks=checks))
        write(RUN/'status.json',dict(status='intervening',completed=n,counts=dict(counts)));print('hybrids',n,key,flush=True)
    assert dict(counts)==d['expectedH'],(dict(counts),d['expectedH']);assert all(sha(R/p)==h for p,h in d['source_hashes'].items())
    write(RUN/'status.json',dict(status='complete',qualified_controls=True,counts=dict(counts),original_wholeblock_jacobian_qualified=False))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--phase',choices=['endpoints','hybrids'],required=True);a=p.parse_args();endpoints() if a.phase=='endpoints' else hybrids()
