# Sol read-only review of 212–215

The existing Sol reviewer completed the independent 213 captures, then reviewed the 214 and 215 runners and auditors without changing them. It reported no substantive correctness issue. It checked source-only subtraction at identical absolute sources, actual local derivatives at every input branch, repeated zero-receiver and baseline replays, state indexing, fixed False prefix/mask/RoPE, native finite replay, and the original 214 surrogate replay.

It confirmed that 1,856 is the correct 214 control count: 214b changes only the expected count and revision label. All numerical calculations and thresholds remain unchanged.

The scope is narrow. 214 is a defined conditional contrast, not exact replacement of the original Jacobian. 215 supports dependence on the receiving input state; it does not identify which receiver feature causes that dependence, establish upstream error as the unique cause of 214 failure, or show that all possible predicted inputs must fail. Entire finite block 28 alone cannot repair the particular predicted input tested. Native-input affine FF still has no joint accuracy passes. Original whole-block Jacobian, learned-circuit and prospective claims remain unsupported.

This records a review delivered in this agent session. It is not replication by an independent research team.
