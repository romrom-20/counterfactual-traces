# Sol read-only review of experiment 217

Before execution, the reviewer found no blocker in state indexing, the one-reset continuation, source/prefix handling, independent whole-model hooks or expected work counts. Its suggested artifact check was added before execution: reconstruct boundary-27 input from the preceding trajectory with the absolute source overwritten.

After the run and saved-array audit, it confirmed that this reconstruction passes, native input matches the observation, and the reported numerical checks and outcomes match the artifacts. Block 24 is the earliest successful TESTED reset for the declared sign/benefit diagnostics. No FF surrogate passes original joint accuracy at any reset.

It cautioned against locating a unique cause between blocks 16 and 24: later resets also leave fewer approximate steps. Errors reappear immediately after the native reset at blocks 9,17 and25. This supports error regeneration under the tested continuation, not a particular native feature, circuit, exact onset or prospective success. The scalar derivative checks do not qualify the unresolved whole-coordinate Jacobian.

This is a separate agent's review within this session, not replication by an independent research team.
