# 189: shared-curvature effects under matched receiver cuts

Completed1536 main+192 separate numerical full-model forwards. All12 artifact controls pass. Selected public score/full-state exactness: True/True; maximum capture error2.91e-11.

Kappa is the sharedC change in the false-to-true verdict-margin response, comparing P+C to P UNDER THE SAMECUT. All maps use paired native trajectories; no false-only predictor, semantic feature, unique learned circuit, competence recovery or priority claim.

- **attention_only_conditional**: 0/16; whole FAIL; strata {'descriptive_0': 0, 'descriptive_1': 0, 'generic_0': 0, 'generic_1': 0}.
- **feedback_restoration**: 0/16; whole FAIL; strata {'descriptive_0': 0, 'descriptive_1': 0, 'generic_0': 0, 'generic_1': 0}.
- **generic_preferential_feedback_fraction**: 1/8; whole FAIL; strata {'0': 1, '1': 0}.
- **norm_only_conditional**: 0/16; whole FAIL; strata {'descriptive_0': 0, 'descriptive_1': 0, 'generic_0': 0, 'generic_1': 0}.
- **up_bottleneck**: 10/16; whole FAIL; strata {'descriptive_0': 4, 'descriptive_1': 4, 'generic_0': 1, 'generic_1': 1}.

The whole rule is at least3of4 sources in EVERYschema/order (or EVERYorder for paired-schema comparisons). Ineligible or favorable subgroups cannot rescue a failed account. All prior188 failures remain failures.

New cuts U,N,W,NU,WU were executed;768parent patch rows from188 are referenced by validated immutable hashes, not counted as new executions or independent replications. Reused186–188cohort. Operation interaction kappa_U-kappa_NU-kappa_WU+kappa_NWU is saved for every case; it is not an additive attribution to native pathways.

Saved-state CPUfloat64 geometry uses pinned output/norm rows, zero full-model forwards. Maximum public-score reconstruction error7.97894e-06; finite product identity error2.66454e-15; actual190 final-only counterfactual error0. These arithmetic identities cannot rescue a failed scientific explanation.
generic: mean U projection term-0.068293nats, mean scale term0.047056; terms oppose in25/32cases. Every individual term is in the saved JSON; averages are descriptive, not a success rule.
descriptive: mean U projection term-0.182102nats, mean scale term0.159692; terms oppose in32/32cases. Every individual term is in the saved JSON; averages are descriptive, not a success rule.

![All paired context effects](figures/189-norm-feedback-cuts.png)

One checkpoint, dependent day templates, dense paired maps and altered receiver baselines limit interpretation. Random/shuffled correction specificity and reliable incomplete-state forecasting remain open.
