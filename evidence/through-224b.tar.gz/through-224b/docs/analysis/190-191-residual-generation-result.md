# What generates the displacement, and what remains unexplained

The diagnostic correction and its transmission are different explanatory targets. At a fixed gate input, adding C with the up branch fixed injects S_l = D_l(C_l * meanUP_l). This exact local write is common to both bits. C itself is the paired curvature remainder mean(phi(c-h),phi(c+h))-phi(c); it uses both native activation trajectories. It is not a separately discovered learned signal or a prospective source prediction.

SiLU curvature supplies C in this diagnostic construction. The down-projection and multiplying up factor determine its local residual direction. Once earlier writes change later inputs, the additional MLP write includes both that fixed source and a propagated-input response. Attention, internal RMS scaling and the live gate input can transform it differently in the two bit states. Multiple source effects cannot be assumed additive under the live computation.

190 executed 1536 main and 192 separate numerical full-model calls. All 15 artifact controls pass; selected scores/full states replay exactly. In addition, there were 1,792 component down-projection evaluations and 224 separate component matrix reconstructions; these are not full-model calls. The atlas uses saved arrays and zero further model calls.

Across both internal-normalization conditions, the first block's measured residual write differs from the literal common source by at most 1.15133589e-05 residual units per coordinate. Its false/true displacement difference is at most 1.52587891e-05. This is an implementation/geometry observation, not an identified semantic feature. The 3,584 atlas rows retain all 64 contexts, 28 blocks and both conditions, with both full-receiver and final-position measurements.

- final_readout_explanation: 0/16 panels; whole FAIL; every stratum {'descriptive_0': 0, 'descriptive_1': 0, 'generic_0': 0, 'generic_1': 0}.
- internal_norm_explanation: 0/16 panels; whole FAIL; every stratum {'descriptive_0': 0, 'descriptive_1': 0, 'generic_0': 0, 'generic_1': 0}.
- norm_conditioned_sign_reversal: 16/16 panels; whole PASS; every stratum {'descriptive_0': 4, 'descriptive_1': 4, 'generic_0': 4, 'generic_1': 4}.
- up_bottleneck_replication: 7/16 panels; whole FAIL; every stratum {'descriptive_0': 3, 'descriptive_1': 3, 'generic_0': 1, 'generic_1': 0}.

Every panel includes all four relation cells. The whole criterion is at least 3/4 sources in EVERY schema/order. Arithmetic identities and favorable subgroups cannot rescue a failed account.

Changing only the final RMS scale leaves the earlier residual exactly unchanged. Projection/scale cancellation is ordinary geometry of a single normalization operation, not evidence of two competing mechanisms. The internal-normalization cut changes the generated trajectory with the diagnostic sources held identical; that is stronger than a final-readout decomposition but remains a distributed intervention, not identification of one native circuit.

![Measured residual propagation and normalization cut](figures/190-residual-generation-atlas.png)

The internal/final interaction kappa_NU-kappa_IU-kappa_FU+kappa_U spans 0.427042–1.140966 nats in generic cells. This is descriptive, not an additive native-pathway attribution.
The internal/final interaction kappa_NU-kappa_IU-kappa_FU+kappa_U spans 2.156704–6.092289 nats in descriptive cells. This is descriptive, not an additive native-pathway attribution.

The final scale has little effect with internal normalization live (U versus FU), but a much larger effect after the internal cut (IU versus NU). The joint response needs both the changed upstream residual and its normalization at readout. Calling either cut alone the explanation misses that conditional relationship. In IU the receiving MLPs and internal RMS operations are affine; attention-weight computation remains nonlinear. A common source can still have different responses through the two state-dependent receivers.

At the final position/block, generic U-versus-IU bit-differential displacement cosine spans -0.090461–0.650495, median 0.261208. These are posthoc geometric summaries, not frozen hypothesis tests.
At the final position/block, descriptive U-versus-IU bit-differential displacement cosine spans 0.204599–0.508822, median 0.288050. These are posthoc geometric summaries, not frozen hypothesis tests.

## A source account calibrated from only one native state

191 executed 512 main + 64 separate numerical calls. All 10 controls pass. All 448 false measurements and mapped forecasts were saved/hashed before ANY native true measurement. Analytic T1/Q2/C3 coefficients use false-state SiLU inputs/outputs alone. The target input literal and all receiving gate inputs, up factors, attention and normalization remain live: this forecasts the result of the polynomial replacement, not the entire true trajectory from a static false vector.

- T1 individual_matching: 0/16; whole FAIL; strata {'descriptive_0': 0, 'descriptive_1': 0, 'generic_0': 0, 'generic_1': 0}.
- T1 balanced_matching: 3/16; whole FAIL; strata {'descriptive_0': 0, 'descriptive_1': 0, 'generic_0': 0, 'generic_1': 3}.
- T1 descriptive maximum true-endpoint error: 9.911823 nats; squared error sum 2472.004478 nats squared.
- Q2 individual_matching: 0/16; whole FAIL; strata {'descriptive_0': 0, 'descriptive_1': 0, 'generic_0': 0, 'generic_1': 0}.
- Q2 balanced_matching: 14/16; whole FAIL; strata {'descriptive_0': 2, 'descriptive_1': 4, 'generic_0': 4, 'generic_1': 4}.
- Q2 descriptive maximum true-endpoint error: 4.928894 nats; squared error sum 529.129584 nats squared.
- C3 individual_matching: 0/16; whole FAIL; strata {'descriptive_0': 0, 'descriptive_1': 0, 'generic_0': 0, 'generic_1': 0}.
- C3 balanced_matching: 16/16; whole PASS; strata {'descriptive_0': 4, 'descriptive_1': 4, 'generic_0': 4, 'generic_1': 4}.
- C3 descriptive maximum true-endpoint error: 0.971130 nats; squared error sum 16.858142 nats squared.

True-endpoint error equals bit-effect error because the false endpoint is exact; those are the same success/failure, not independent confirmations. Half-retention is descriptive and does not rescue precise matching. The complete audit includes all retention strata, endpoints and failures. Higher polynomial order has no guaranteed convergence over the finite shifts or recursively altered inputs.

What remains unresolved: prediction of the particular finite residual displacement through a compact, causally validated state-dependent transport account; generation of a useful curvature/source account without paired native activation calibration; and why training gives the schemas these responses. A measured atlas is not a transport forecast. The paired diagnostic is not an endogenous feature. One small Qwen checkpoint, dependent synthetic day prompts, dense interventions, and earlier grounding/specificity failures remain. No novelty priority, deployment failure or complete mechanism claim follows. Attached literature claims were not independently verified; no browsing was used.
