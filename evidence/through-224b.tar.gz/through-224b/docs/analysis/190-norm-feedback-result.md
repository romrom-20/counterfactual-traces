# 190: shared-curvature effects under matched receiver cuts

Completed1536 main+192 separate numerical full-model forwards. All15 artifact controls pass. Selected public score/full-state exactness: True/True; maximum capture error2.98e-08.

Kappa is the sharedC change in the false-to-true verdict-margin response, comparing P+C to P UNDER THE SAMECUT. All maps use paired native trajectories; no false-only predictor, semantic feature, unique learned circuit, competence recovery or priority claim.

- **final_readout_explanation**: 0/16; whole FAIL; strata {'descriptive_0': 0, 'descriptive_1': 0, 'generic_0': 0, 'generic_1': 0}.
- **internal_norm_explanation**: 0/16; whole FAIL; strata {'descriptive_0': 0, 'descriptive_1': 0, 'generic_0': 0, 'generic_1': 0}.
- **norm_conditioned_sign_reversal**: 16/16; whole PASS; strata {'descriptive_0': 4, 'descriptive_1': 4, 'generic_0': 4, 'generic_1': 4}.
- **up_bottleneck_replication**: 7/16; whole FAIL; strata {'descriptive_0': 3, 'descriptive_1': 3, 'generic_0': 1, 'generic_1': 0}.

The whole rule is at least3of4 sources in EVERYschema/order (or EVERYorder for paired-schema comparisons). Ineligible or favorable subgroups cannot rescue a failed account. All prior188 failures remain failures.

Four new day blocks were held out of hypothesis specification, with fresh per-context paired calibration. All256 comparisons of final-only cuts leave the FULLblock28 residual EXACT (FU=U, NU=IU). Any score change in those matched pairs occurs after that residual, in the final scale/readout. Both native bit states calibrate the intervention, so this is new-context mechanism confirmation, not forecasting.

Saved-state CPUfloat64 geometry uses pinned output/norm rows, zero full-model forwards. Maximum public-score reconstruction error7.20848e-06; finite product identity error2.66454e-15; actual190 final-only counterfactual error7.20848e-06. These arithmetic identities cannot rescue a failed scientific explanation.
generic: mean U projection term0.057896nats, mean scale term0.039878; terms oppose in13/32cases. Every individual term is in the saved JSON; averages are descriptive, not a success rule.
descriptive: mean U projection term-0.014023nats, mean scale term0.128023; terms oppose in29/32cases. Every individual term is in the saved JSON; averages are descriptive, not a success rule.

![All paired context effects](figures/190-norm-feedback-cuts.png)

One checkpoint, dependent day templates, dense paired maps and altered receiver baselines limit interpretation. Random/shuffled correction specificity and reliable incomplete-state forecasting remain open.
