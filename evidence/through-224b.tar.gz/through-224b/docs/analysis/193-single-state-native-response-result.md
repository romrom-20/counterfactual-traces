# Can one false computation predict the native Boolean flip?

This is the first continuation here that seals full-network native-response predictions without any target-state computation in the forecasting phase. The known input literal and model weights are available. The input direction is the embedding difference at the single Boolean position. Native RMS, attention, SiLU and multiplying branches all enter first directional derivatives at the false state. That is a white-box AD baseline, not a compact identified mechanism or training explanation.

All 64 ordinary false readouts and 64 differentiated false invocations were saved before ANY native true or finite-dose observation. There are 320 ordinary main model invocations, 64 differentiated invocations with one forward-AD level, 16 separate numerical ordinary invocations and 8 reverse-differentiated numerical invocations. Differentiated invocations have different costs and are counted separately. The earlier192 engineering preflights separately add two ordinary false and two differentiated false invocations; the reporting-only hash failure and its separate correction are preserved. No true-state preflight observation occurred. The192second-order attempt failed its fixed numerical qualification and is preserved; none of its second-order numbers is interpreted as a scientific finding here.

All 10 artifact controls pass. Native numerical score/state exactness: True/True. Maximum reverse-versus-forward derivative contraction error 0.000176668; fixed bound 0.001 + 0.0001*abs(reverse reference). These margin and two trajectory-projection checks do not establish coordinatewise equality of every derivative tensor.

- secondary/diagnostic dose0.125_order1_balanced_matching: 16/16 panels; whole PASS; strata {'descriptive_0': 4, 'descriptive_1': 4, 'generic_0': 4, 'generic_1': 4}.
- secondary/diagnostic dose0.125_order1_individual_matching: 16/16 panels; whole PASS; strata {'descriptive_0': 4, 'descriptive_1': 4, 'generic_0': 4, 'generic_1': 4}.
- secondary/diagnostic dose0.125_order1_residual_matching: 0/16 panels; whole FAIL; strata {'descriptive_0': 0, 'descriptive_1': 0, 'generic_0': 0, 'generic_1': 0}.
- secondary/diagnostic dose0.25_order1_balanced_matching: 16/16 panels; whole PASS; strata {'descriptive_0': 4, 'descriptive_1': 4, 'generic_0': 4, 'generic_1': 4}.
- secondary/diagnostic dose0.25_order1_individual_matching: 2/16 panels; whole FAIL; strata {'descriptive_0': 0, 'descriptive_1': 0, 'generic_0': 1, 'generic_1': 1}.
- secondary/diagnostic dose0.25_order1_residual_matching: 0/16 panels; whole FAIL; strata {'descriptive_0': 0, 'descriptive_1': 0, 'generic_0': 0, 'generic_1': 0}.
- secondary/diagnostic dose0.5_order1_balanced_matching: 0/16 panels; whole FAIL; strata {'descriptive_0': 0, 'descriptive_1': 0, 'generic_0': 0, 'generic_1': 0}.
- secondary/diagnostic dose0.5_order1_individual_matching: 0/16 panels; whole FAIL; strata {'descriptive_0': 0, 'descriptive_1': 0, 'generic_0': 0, 'generic_1': 0}.
- secondary/diagnostic dose0.5_order1_residual_matching: 0/16 panels; whole FAIL; strata {'descriptive_0': 0, 'descriptive_1': 0, 'generic_0': 0, 'generic_1': 0}.
- secondary/diagnostic dose1.0_order1_balanced_matching: 0/16 panels; whole FAIL; strata {'descriptive_0': 0, 'descriptive_1': 0, 'generic_0': 0, 'generic_1': 0}.
- PRIMARY dose1.0_order1_individual_matching: 0/16 panels; whole FAIL; strata {'descriptive_0': 0, 'descriptive_1': 0, 'generic_0': 0, 'generic_1': 0}.
- PRIMARY dose1.0_order1_residual_matching: 0/16 panels; whole FAIL; strata {'descriptive_0': 0, 'descriptive_1': 0, 'generic_0': 0, 'generic_1': 0}.

The native primary margin rule is <=0.10 nats error in ALL four relation cells/panel; residual rule is <=5% relative error AND >=0.99 cosine, with actual displacement >=0.001. The whole rule needs at least 3/4 sources in EVERY schema/order. Evidence balancing and successful small doses cannot rescue failed native individual or residual accounts. The first-order forecast was frozen in advance, with no fitted coefficients or refinement.

![Single-state forecast versus dose](figures/193-single-state-native-forecast.png)

Native dose, order 1: maximum individual margin error 17.612133 nats; maximum final-position relative displacement error 1.277564; cosine range -0.414671–0.145996.

Interpretation: prospective accuracy would establish a bounded single-state prediction result for these dependent prompts, with derivatives through known weights. Failure would show that local first-order response is insufficient at the finite Boolean change, not that counterfactual prediction in general is impossible. Layerwise held-out errors locate breakdown after forecast sealing; they cannot be used to refit and claim another prospective success on the same cases. Identification of a small set of causal nonlinear source/transport components remains a separate next test. Earlier grounding/specificity failures, one checkpoint, synthetic dependent day tasks and absence of an independent team remain. No novelty priority or complete mechanism claim.
