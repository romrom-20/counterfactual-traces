# Native source generation remains a forecasting boundary

194 completed768main+96separate numerical ordinary full-model calls. All11controls pass; selected public scores/full28trajectories replay EXACTLY, maximum capture discrepancy1.42e-14. A scoped false-anchor/prefix test passed before launch.

Every coefficient uses only nativeFalse. All704forecasts/False calls are globally sealed before ANY nativeTrue measurement. This is a nonlinear surrogate that evaluates finite normalization,attention and branch multiplication on predicted counterfactual inputs; it is not derivative-only transport or a compact circuit model. Source_C3 changes only the Boolean's SiLU sites; receiver_C3 changes only later positions; all_C3 changes both. No nativeTrue trajectory calibrates coefficients.

- individual_matching / all_T1: 0/16; wholeFAIL; strata{'descriptive_0': 0, 'descriptive_1': 0, 'generic_0': 0, 'generic_1': 0}.
- individual_matching / all_Q2: 0/16; wholeFAIL; strata{'descriptive_0': 0, 'descriptive_1': 0, 'generic_0': 0, 'generic_1': 0}.
- individual_matching / all_C3: 0/16; wholeFAIL; strata{'descriptive_0': 0, 'descriptive_1': 0, 'generic_0': 0, 'generic_1': 0}.
- individual_matching / source_C3: 0/16; wholeFAIL; strata{'descriptive_0': 0, 'descriptive_1': 0, 'generic_0': 0, 'generic_1': 0}.
- individual_matching / receiver_C3: 0/16; wholeFAIL; strata{'descriptive_0': 0, 'descriptive_1': 0, 'generic_0': 0, 'generic_1': 0}.
- residual_matching / all_T1: 0/16; wholeFAIL; strata{'descriptive_0': 0, 'descriptive_1': 0, 'generic_0': 0, 'generic_1': 0}.
- residual_matching / all_Q2: 0/16; wholeFAIL; strata{'descriptive_0': 0, 'descriptive_1': 0, 'generic_0': 0, 'generic_1': 0}.
- residual_matching / all_C3: 0/16; wholeFAIL; strata{'descriptive_0': 0, 'descriptive_1': 0, 'generic_0': 0, 'generic_1': 0}.
- residual_matching / source_C3: 0/16; wholeFAIL; strata{'descriptive_0': 0, 'descriptive_1': 0, 'generic_0': 0, 'generic_1': 0}.
- residual_matching / receiver_C3: 0/16; wholeFAIL; strata{'descriptive_0': 0, 'descriptive_1': 0, 'generic_0': 0, 'generic_1': 0}.
- balanced_matching / all_T1: 0/16; wholeFAIL; strata{'descriptive_0': 0, 'descriptive_1': 0, 'generic_0': 0, 'generic_1': 0}.
- balanced_matching / all_Q2: 6/16; wholeFAIL; strata{'descriptive_0': 2, 'descriptive_1': 2, 'generic_0': 1, 'generic_1': 1}.
- balanced_matching / all_C3: 7/16; wholeFAIL; strata{'descriptive_0': 3, 'descriptive_1': 4, 'generic_0': 0, 'generic_1': 0}.
- balanced_matching / source_C3: 8/16; wholeFAIL; strata{'descriptive_0': 4, 'descriptive_1': 4, 'generic_0': 0, 'generic_1': 0}.
- balanced_matching / receiver_C3: 14/16; wholePASS; strata{'descriptive_0': 4, 'descriptive_1': 4, 'generic_0': 3, 'generic_1': 3}.

Both PRIMARY whole accounts (individual preference and full final-position displacement) fail in every arm:0/16panels. The receiver-only cubic approximation retains the SECONDARY evidence contrast in14/16panels and meets the whole3/4EVERYstratum rule. Moving that approximation to the Boolean source loses all generic evidence panels; source-only passes8/16, all descriptive, and all-C3passes7/16, all descriptive. Those whole accounts fail. This is a source/receiver asymmetry conditional on the particular approximation, not a unique native pathway attribution.

The residual rule remains<=5%relativeL2 AND>=0.99cosine; individual/evidence margin bound0.10nats. Every panel includes allfour relation cells. Evidence matching cannot rescue either native primary account. Counterfactual known-function evaluations are substantial; a single false calibration is different from doing no counterfactual computation.

![Every source/receiver outcome](figures/194-source-receiver-curvature.png)

all_T1: worst individual margin error9.155655nats, evidence error1.200357nats, residual relative error1.490116.
all_Q2: worst individual margin error6.160923nats, evidence error0.768637nats, residual relative error0.658171.
all_C3: worst individual margin error7.708420nats, evidence error0.579105nats, residual relative error1.078978.
source_C3: worst individual margin error7.688816nats, evidence error0.577187nats, residual relative error1.068149.
receiver_C3: worst individual margin error0.928596nats, evidence error0.101807nats, residual relative error0.185470.

A separate1792-row post-observation diagnostic evaluates the false cubic at actual nativeTrue preactivations. It distinguishes pointwise truncation error at source/later rows and reports whether the step exceeds the SiLU Taylor-series radius sqrt(xF²+pi²). These nativeTrue inputs are ORACLE diagnostic information, never forecast calibration; pointwise counts/error do not identify a causal feature or explain all propagated response. A third-order polynomial can fail even within that radius; outside it, the infinite Taylor series centered at false does not converge at the native true input.

The primary Question B remains unresolved. We have now falsified a strict native first-order predictor and source-inclusive low-order SiLU surrogates, while a weaker evidence response survives when the source encoder stays native. A useful next account must predict source generation, not only transport a fitted paired correction. One checkpoint/dependent tasks/dense maps/failed grounding and specificity remain. No priority or complete mechanism claim.
