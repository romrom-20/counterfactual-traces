# First-block operation repairs with false-state transport

Numerical qualification: FAIL; results are not qualified scientific conclusions.. Fingerprint: `1e4a5370ada4cfa1230f22bf9c06f4646f1c63d76be7c661f90d37cbc3da0386`.

The two supplied Boolean prefixes differ only at the known embedding. Seven individual first-block operations are repaired using their finite known functions; the remaining operations and entire downstream computation use false-state derivatives. All forecasts were sealed globally before nativeTrue observation. Exact-block and exact-source arms are controls, not discoveries.

The displacement error denominator is the norm of the actual native displacement. Individual preference bound0.10nats; residual bound relativeL2≤0.05 and cosine≥0.99, native norm≥0.001. Whole account needs≥3/4blocks in every schema/order. Comparative progress means halving source error and either final residual or absolute preference error, in all four cells. Progress cannot substitute for native matching.

**linear**: source matching 0/16 (whole FAIL), individual matching 0/16 (whole FAIL), residual matching 0/16 (whole FAIL), prospective progress 0/16 (whole FAIL). Median source error 0.708403, final error 1.08392; absolute preference error median 12.3115nats, max 18.7156nats.

**input_rms**: source matching 0/16 (whole FAIL), individual matching 0/16 (whole FAIL), residual matching 0/16 (whole FAIL), prospective progress 0/16 (whole FAIL). Median source error 0.552444, final error 1.10479; absolute preference error median 12.258nats, max 18.4934nats.

**qk_product**: source matching 0/16 (whole FAIL), individual matching 0/16 (whole FAIL), residual matching 0/16 (whole FAIL), prospective progress 0/16 (whole FAIL). Median source error 0.698292, final error 1.08479; absolute preference error median 12.3016nats, max 18.7756nats.

**softmax**: source matching 0/16 (whole FAIL), individual matching 0/16 (whole FAIL), residual matching 0/16 (whole FAIL), prospective progress 0/16 (whole FAIL). Median source error 0.717367, final error 1.08198; absolute preference error median 12.3696nats, max 18.724nats.

**weight_value**: source matching 0/16 (whole FAIL), individual matching 0/16 (whole FAIL), residual matching 0/16 (whole FAIL), prospective progress 0/16 (whole FAIL). Median source error 0.708502, final error 1.09157; absolute preference error median 12.4069nats, max 18.6431nats.

**post_rms**: source matching 0/16 (whole FAIL), individual matching 0/16 (whole FAIL), residual matching 0/16 (whole FAIL), prospective progress 0/16 (whole FAIL). Median source error 0.517265, final error 1.07783; absolute preference error median 12.2295nats, max 18.3732nats.

**silu**: source matching 0/16 (whole FAIL), individual matching 0/16 (whole FAIL), residual matching 0/16 (whole FAIL), prospective progress 0/16 (whole FAIL). Median source error 0.719408, final error 1.08097; absolute preference error median 12.2786nats, max 18.6887nats.

**gate_up**: source matching 0/16 (whole FAIL), individual matching 0/16 (whole FAIL), residual matching 0/16 (whole FAIL), prospective progress 0/16 (whole FAIL). Median source error 0.832205, final error 1.10378; absolute preference error median 12.4967nats, max 19.3582nats.

**exact_block** — local finite-computation control: source matching 16/16 (whole FAIL), individual matching 0/16 (whole FAIL), residual matching 0/16 (whole FAIL), prospective progress 0/16 (whole FAIL). Median source error 3.9306e-06, final error 1.09528; absolute preference error median 12.1595nats, max 18.3073nats.

**exact_source** — local finite-computation control: source matching 16/16 (whole FAIL), individual matching 0/16 (whole FAIL), residual matching 0/16 (whole FAIL), prospective progress 0/16 (whole FAIL). Median source error 3.9306e-06, final error 1.09486; absolute preference error median 12.0922nats, max 18.2182nats.

![All registered repairs](../figures/196-first-block-repair.png)

Full results: [independent artifact audit](196-independent-audit.json), [numerical verification](196-numerical-recheck.json), [summary](196-first-block-repair-summary.json), [registered protocol](../experiments/196-first-block-primitive-repair.md), [methods/additional accounting](../experiments/196-methods-addendum.md).

195 stopped on its derivative coordinate tolerance before any nativeTrue observation and remains [a preserved technical failure](195-technical-failure.json).196 uses automatic primitive derivatives; every check bound is unchanged. One small checkpoint, dependent synthetic templates and failed earlier grounding controls constrain all claims. No unique learned mechanism, universal model result, deployment failure, or novelty priority is established. Local correction does not explain downstream behavior unless that prospective prediction improves.

Reproduce from the qualified193 parent in the same offline environment: run196runner, artifactauditor, numerical recheck, then artifactauditor again. Study output directories must be absent; do not overwrite an executed run. Full-model counts128ordinary+640False-tailAD; numerical verification16ordinary+80reverseAD. Local computations and engineering/failed195 costs are separate in the methods addendum. No training/generation; raw arrays/modelweights are excluded from Git.
