# Nonlinear injection versus false-state amplification

Discovery-only diagnosis on the64old qualified193pairs. NativeTrue trajectories supply local remainders and an oracle first-block start; the error-direction projection also uses observed error. This is not a new prospective forecast or identification of a learned semantic feature.

State means the full sequence matrix. With e=actual displacement−predicted displacement and an exact starting displacement, e_(l+1)=J_l e_l+R_l. Standard first-order reverse adjoints transport each local remainder to two scalar objectives. Final margin error additionally includes the nonlinear final readout remainder. Projection onto the actual final error direction reconstructs the final verdict-row error norm; this is one projection, not every transported vector.

All64margin budgets and64residual projection budgets passed the fixed.001+.0001abs(observed error) bound; all3456local forward/reverse contractions passed. Maximum margin budget discrepancy 8.83288e-05nats; residual projection budget discrepancy 0.00175081hiddenunits. Original196primitive reverse-over-reverse disagreement remains unresolved; no second full-network derivatives are used.

Residual-error ranking top2blocks: [18, 21]. Margin-error ranking top2blocks: [16, 18]. These are mean absolute projected contributions normalized by error size, with cancellation possible; they are not additive causal percentages. Median final readout remainder 1.73441nats. The two objectives do not pick exactly the same blocks.

![Local remainders and projected transport](../figures/199-local-remainder-amplification.png)

The rankings can select a testable repair, but only a repair computed from false-state information on new contexts can establish prospective progress. The next registered budget retains finite known functions at discovery-ranked blocks16/18/21 and the first block, with other block transitions linearized atFalse; equally sized low-ranked controls are3/7/27. DiscoveryTrue remainders are never inserted into heldout predictions. A successful macro-block repair would still leave the operation inside those blocks unidentified.

Evidence: [full audit](199-independent-audit.json), [summary](199-layerwise-remainder-summary.json), [protocol](../experiments/199-layerwise-nonlinear-remainder.md), [prospective repair registration](../experiments/201-discovery-ranked-finite-block-repair.md). 64ordinaryFalse fullcalls,64False forwardAD fullcalls,64False reverse fullcalls,1728local blockJVPs; no nativeTrue fullcalls, training, or generation in this diagnostic.
