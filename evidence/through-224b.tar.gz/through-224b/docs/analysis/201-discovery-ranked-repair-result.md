# A remainder ranking did not produce an accurate heldout repair

The code's independent numerical checks passed, while allscientific native matching and joint-progress accounts failed. This distinction is essential: a trustworthy computation can test an unsuccessful explanation.

On199's old paired193discovery data, residual-error projection ranked blocks18/21highest; marginerror ranked16/18highest. The registered union16/18/21and equally sized low-ranked controls3/7/27were fixed before any new nativeTrue trajectory. On64newpairs across cobalt/indium,pebble/stone,fresco/stencil,reef/shoal, the forecast always computed the first block finitely using the known embedding edit; only selected laterblocks retained finite known functions. Allotherblock transitions used nativeFalse Jacobians. Final readout was finite except in the source_linear baseline. Up to4wholeblocks, including the first, were finite; this is a known-weight surrogate with substantial local computation, not a small learned circuit or simulation-free prediction.

Allsix arms scored0/16panels for individual native margin error≤0.10nats,0/16for final residual relativeL2≤0.05/cosine≥0.99, and0/16for the registered joint-progress criterion of halving both final residual and absolute margin error. Everypanel contains fourdependent cells; whole pass requires≥3/4blocks in every schema/order. The source matching control passed16/16for everyarm.

**source_linear**: median final relativeerror 1.08595; median absolute marginerror 12.108nats. Allprimary native andjointprogress wholeaccounts FAIL.

**exact_readout**: median final relativeerror 1.08595; median absolute marginerror 12.0633nats. Allprimary native andjointprogress wholeaccounts FAIL.

**residual_blocks**: median final relativeerror 1.04228; median absolute marginerror 12.0292nats. Allprimary native andjointprogress wholeaccounts FAIL.

**margin_blocks**: median final relativeerror 1.04549; median absolute marginerror 12.1275nats. Allprimary native andjointprogress wholeaccounts FAIL.

**union_blocks**: median final relativeerror 1.02955; median absolute marginerror 12.0377nats. Allprimary native andjointprogress wholeaccounts FAIL.

**control_blocks**: median final relativeerror 1.14643; median absolute marginerror 11.805nats. Allprimary native andjointprogress wholeaccounts FAIL.

![Every prospective repair retained](../figures/201-ranked-repair.png)

The union lowered median residualerror from1.08595to1.02955, but this small change did not meet the declared progress criterion or recover individual behavior. Matchedcontrols worsened residualerror to1.14643 while their median absolute marginerror was11.805nats, compared with12.0377for the union. We cannot infer a useful sparse mechanism from this ranking.

A plausible unresolved explanation is input-state dependence:199's local remainders were evaluated at the actual native counterfactual inputs, whereas201's finite block repairs receive predicted inputs that may already be wrong. The test does not establish this explanation or identify an operation causing the discrepancy. Another boundary is that fixing the first block does not fix subsequent nonlinear encoding at the Boolean source. Source encoding across depth, source-to-receiver attention and receiving-position nonlinear computation still need separation; no claim that the source has been ruled out entirely.

Numerical evidence:16freshpublicnative replays and48independent whole-model hook forecasts matched savedstate rows exactly; maximum score discrepancy 5.72205e-06. Eightstandardreverse baseline checks passed, maximum contraction discrepancy 5.66244e-05. Hookconstruction shares the forwardADbackend with forecasting but differs structurally; standardreverse checks cover the source_linear arm. The original196primitive reverse-over-reverse coordinate discrepancy remains unresolved and is not retroactively certified by these checks.

200's initialpreflight had a fixture-wiring error before any model evaluation; the initial201import preflight failed before model loading. Originalfailedsources/logs remain preserved.201provides byte-identical numerical helper aliases and the correct paired-prefix fixture import. The corrected checkpoint preflight passed all12arm/schema comparisons before the study. No bound or method changed in either correction.

Evidence: [artifact audit](201-independent-audit.json), [numerical verification](201-numerical-recheck.json), [all-arm summary](201-ranked-repair-summary.json), [fixed selection/method registration](../experiments/200-discovery-ranked-finite-block-repair.md), [wiring correction protocol](../experiments/201-discovery-ranked-finite-block-repair.md), [paired diagnostic](199-layerwise-nonlinear-remainder-result.md). One small checkpoint, dependent synthetic templates, no independent team and earlier failed grounding controls constrain allclaims. No commit,push orLessWrong publication has been made.
