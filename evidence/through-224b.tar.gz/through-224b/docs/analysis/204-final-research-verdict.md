# Correct intermediate states do not rescue the tested counterfactual predictor

The missing oracle experiment is complete. Following the eight-case numerical sample, the full run executed **896 genuine oracle continuations across all 64 original 201 pairs**: two predictor arms, seven reset boundaries, every case. All mandatory reset controls passed. The separate direct Jacobian error identity did not fully qualify. **Question B remains open; publication remains on hold.**

This is retrospective diagnosis of a predictor, not a new prospective success or identification of a learned mechanism.

## Audit of the replacement work

The earlier apparent reset was `final_error_norm - incoming_error_norm`; it never computed a resumed model trajectory. Its Stage 1 projection did not evaluate a model Jacobian. Its tiny identity-status file contained no quantitative verification. Its later loader constructed a tensor and then executed `pass`.

It also confused absolute native states with forecast displacements. `true_rows - false_rows` is the native displacement; forecast error compares that vector with `{arm}_delta_rows`. `false_first` is a block-one output, not an embedding. Comparing `source_first_delta` directly with an absolute `true_first` state is invalid.

Correct measurement gives maximum first-block coordinate error **1.19e-7**, rather than the reported roughly 42% forecast error. The original source control checked vectors, not merely scores. A zero-displacement baseline has median final relative error **1.0** and median margin error **10.03 nats**, beating every 201 arm at the median on both measurements. All failures are retained. See the [implementation audit](202-replacement-implementation-audit.md).

## What actually ran

Reset before public block k means k−1 completed blocks. The fixed boundaries were **1, 3, 8, 11, 16, 21, 27**; k=1 is the embedding boundary. One entire native displacement matrix was supplied once, including the causal prefix. No later native state was inserted.

The remaining computation retained the original 201 arms. `source_linear` uses a finite first block, native-False Jacobians thereafter, and a linearized readout. `union_blocks` additionally evaluates blocks 16/18/21 and the final normalization/readout finitely at the current predicted inputs. No later block is relinearized around the true state.

All **896** predicted-state reset replays reproduced the ordinary forecast exactly. All **896** native reset boundaries had zero displacement error. All **448** exact public native continuations reproduced remaining native states and public scores exactly. Native replays, head anchors and False-state JVP primals also passed. The preceding eight-case sample passed **224** alternate whole-model dual-hook comparisons; those checks share the forward-AD backend.

Bounds stayed at `1e-4` per coordinate and `0.005` per public score. The full run used 576 ordinary public-model calls, 69,312 local block JVPs and 2,688 local finite-block calls; head operations are counted separately in the [run record](../../results/genuine-oracle-202-204/recorded-runs/genuine-oracle-continuation-204-full/status.json).

## Measured outcomes

- **Source-linear, unreset:** median final relative displacement error **1.086**, absolute margin error **12.11 nats**.
- **Source-linear, reset before block 16:** relative error **1.350**, margin error **14.29 nats**. Residual error worsened in **64/64 cases**; no case improved its margin error.
- **Union arm, reset before block 16:** relative error **0.768**, margin error **5.81 nats**. Margin improved in all cases, while residual error improved in 38/64.
- **Union arm, reset before block 21:** relative error **0.616**, margin error **4.53 nats**. Both improved in every case.
- **Reset before block 27:** both arms ended with median relative error **0.220** and cosine **0.981** after the two remaining hybrid blocks. Margin error was **3.42 nats** with the linear readout and **2.07 nats** with the finite readout. Every case improved relative to its unreset arm, but these medians remain outside the original matching bounds.

All individual cases and source/schema/order strata are retained in the [full audit](204-full-oracle-vector-audit.json) and [trajectory summary](204-full-oracle-summary.json).

![Full reset results](../figures/204-full-genuine-oracle.png)

## What this establishes

Correct incoming state is insufficient for an accurate remaining prediction under this approximation. Error reappears even after supplying the complete correct state shortly before the end of the network. Accumulated incoming-state drift alone is therefore insufficient as an account of the tested failure.

Incoming state still matters, and the finite-block arm responds differently from the linear tail. Removing an earlier error can remove an accidental offset against later approximation error. That explains how a reset can worsen the final forecast without implying a learned compensatory mechanism.

For native final displacement A and actually computed ordinary/reset predictions P and Q, the signed account is

\[
A-P=(A-Q)+(Q-P).
\]

The [measured vector account](205-full-measured-reset-separation.json) closes exactly. Component norms are not added as causal fractions. For the linear tail, Q−P corresponds to the tested transport of the incoming correction; for the finite-block arm it also includes changed nonlinear evaluations at different predicted inputs. See the [derivation and limits](205-what-a-genuine-reset-establishes.md).

This does not identify RMSNorm, softmax, SiLU or gate/up multiplication as the missing operation. A large local remainder norm alone cannot establish downstream importance.

## The numerical boundary remains

The independent direct `J(error)` identity failed **424/18,432** full-state checks at the unchanged `1e-4` bound, with maximum discrepancy **3.50e-4**. Failures occurred at blocks 16 and 28. **Stage 1 is not fully numerically qualified.** A budget formed from two evaluated JVPs closes algebraically; that is not independent derivative validation. The older 196 primitive reverse-over-reverse disagreement also remains unresolved.

A local CPU precision diagnostic reduced the block-28 additivity discrepancy to approximately `8e-14`, passing reverse-mode and finite-difference checks. None of its CPU forward replays met the original full-coordinate MPS bound. It cannot replace or retroactively certify the frozen computation. See the [precision report](206-local-precision-result.md).

![Matched layerwise norms](../figures/207-full-layerwise-norms.png)

## Next test and reproduction

The [208 specification](../experiments/208-source-receiver-partition-proposal.md) tests ongoing nonlinear source generation at every depth while transmitting receiving-state changes linearly. It requires fresh contexts and globally sealed False-only forecasts before new native-True observation. It has **not** been coded or executed. Its direct whole-block implementation may cost more than a counterfactual forward pass; success would support a state partition before establishing a compact primitive mechanism.

The [bundle README](../../results/genuine-oracle-202-204/README.md) records the checkpoint/runtime, definitions, historical failures, hashes and commands. Raw arrays remain local and regenerate offline. The repository contains an [inline-data evidence viewer](../../results/genuine-oracle-202-204/genuine-oracle-reset.canvas.tsx).

All results concern one small Qwen checkpoint and dependent synthetic templates. There is no independent research-team replication or novelty-priority assessment. No browser, literature search, training, commit, push, PR or LessWrong publication was used in this continuation.
