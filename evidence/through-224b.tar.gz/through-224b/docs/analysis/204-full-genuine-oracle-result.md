# Genuine oracle resets: full scope

Retrospective model continuations executed; this is not a prospective forecast. Reset k means BEFORE public block k, with k−1 completed blocks. Full-sequence states, causal mask/RoPE and original201 arms are retained.

All mandatory reset replay/boundary/exact-native controls passed. Direct J(error) coordinate identity failed 424/18432 checks at the unchanged1e-4 bound. Stage1 is NOT fully numerically qualified. Two-evaluated-JVP algebraic closure is separately checked and is not independent derivative validation. Original196 derivative disagreement remains open.

- source_linear, before block 1: median final verdict residual relative error 1.08595, cosine -0.0567443, absolute margin error 12.108nats; residual improves 0/64, margin improves 0/64 versus the SAME unreset arm.
- source_linear, before block 3: median final verdict residual relative error 1.12386, cosine -0.183661, absolute margin error 12.1087nats; residual improves 1/64, margin improves 32/64 versus the SAME unreset arm.
- source_linear, before block 8: median final verdict residual relative error 1.1989, cosine -0.306348, absolute margin error 12.1524nats; residual improves 1/64, margin improves 32/64 versus the SAME unreset arm.
- source_linear, before block 11: median final verdict residual relative error 1.12648, cosine -0.0903034, absolute margin error 11.4609nats; residual improves 28/64, margin improves 32/64 versus the SAME unreset arm.
- source_linear, before block 16: median final verdict residual relative error 1.34957, cosine -0.271283, absolute margin error 14.2861nats; residual improves 0/64, margin improves 0/64 versus the SAME unreset arm.
- source_linear, before block 21: median final verdict residual relative error 0.926479, cosine 0.539603, absolute margin error 6.44599nats; residual improves 32/64, margin improves 64/64 versus the SAME unreset arm.
- source_linear, before block 27: median final verdict residual relative error 0.219778, cosine 0.981235, absolute margin error 3.41681nats; residual improves 64/64, margin improves 64/64 versus the SAME unreset arm.
- union_blocks, before block 1: median final verdict residual relative error 1.02955, cosine 0.118028, absolute margin error 12.0377nats; residual improves 0/64, margin improves 0/64 versus the SAME unreset arm.
- union_blocks, before block 3: median final verdict residual relative error 1.05559, cosine 0.028714, absolute margin error 12.034nats; residual improves 1/64, margin improves 32/64 versus the SAME unreset arm.
- union_blocks, before block 8: median final verdict residual relative error 1.07765, cosine -0.0409362, absolute margin error 11.9041nats; residual improves 2/64, margin improves 38/64 versus the SAME unreset arm.
- union_blocks, before block 11: median final verdict residual relative error 1.04371, cosine 0.139006, absolute margin error 11.0081nats; residual improves 20/64, margin improves 59/64 versus the SAME unreset arm.
- union_blocks, before block 16: median final verdict residual relative error 0.767809, cosine 0.66909, absolute margin error 5.80538nats; residual improves 38/64, margin improves 64/64 versus the SAME unreset arm.
- union_blocks, before block 21: median final verdict residual relative error 0.616431, cosine 0.85309, absolute margin error 4.53207nats; residual improves 64/64, margin improves 64/64 versus the SAME unreset arm.
- union_blocks, before block 27: median final verdict residual relative error 0.219778, cosine 0.981235, absolute margin error 2.07434nats; residual improves 64/64, margin improves 64/64 versus the SAME unreset arm.

These interventions remove prior full-state error once; any later discrepancy is measured by actual hybrid computation. They do not identify a primitive operation, show a dominant learned mechanism, or provide a false-only heldout success. Medians over dependent templates are descriptive; stratified and individual results remain in the JSON. Numerical additivity failures prevent claiming a fully validated direct vector transport decomposition.

Evidence: [vector audit](204-full-oracle-vector-audit.json), [summary and trajectories](204-full-oracle-summary.json), [replacement audit](202-replacement-implementation-audit.md), [fixed reset protocol](../experiments/203-genuine-oracle-continuation.md), [explicit additivity separation](../experiments/204-separated-reset-and-additivity-checks.md). No browsing, training, commits, pushes or publication.
