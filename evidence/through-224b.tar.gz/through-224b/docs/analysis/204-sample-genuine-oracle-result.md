# Genuine oracle resets: sample scope

Retrospective model continuations executed; this is not a prospective forecast. Reset k means BEFORE public block k, with k−1 completed blocks. Full-sequence states, causal mask/RoPE and original201 arms are retained.

All mandatory reset replay/boundary/exact-native controls passed. Direct J(error) coordinate identity failed 52/2304 checks at the unchanged1e-4 bound. Stage1 is NOT fully numerically qualified. Two-evaluated-JVP algebraic closure is separately checked and is not independent derivative validation. Original196 derivative disagreement remains open.

- source_linear, before block 1: median final verdict residual relative error 1.1125, cosine -0.129375, absolute margin error 12.1502nats; residual improves 0/8, margin improves 0/8 versus the SAME unreset arm.
- source_linear, before block 3: median final verdict residual relative error 1.1513, cosine -0.237299, absolute margin error 12.2031nats; residual improves 1/8, margin improves 4/8 versus the SAME unreset arm.
- source_linear, before block 8: median final verdict residual relative error 1.24828, cosine -0.301029, absolute margin error 12.4177nats; residual improves 1/8, margin improves 4/8 versus the SAME unreset arm.
- source_linear, before block 11: median final verdict residual relative error 1.12117, cosine -0.109289, absolute margin error 11.7571nats; residual improves 3/8, margin improves 4/8 versus the SAME unreset arm.
- source_linear, before block 16: median final verdict residual relative error 1.3744, cosine -0.267138, absolute margin error 14.1049nats; residual improves 0/8, margin improves 0/8 versus the SAME unreset arm.
- source_linear, before block 21: median final verdict residual relative error 0.920436, cosine 0.574918, absolute margin error 6.4457nats; residual improves 4/8, margin improves 8/8 versus the SAME unreset arm.
- source_linear, before block 27: median final verdict residual relative error 0.217157, cosine 0.981695, absolute margin error 3.335nats; residual improves 8/8, margin improves 8/8 versus the SAME unreset arm.
- union_blocks, before block 1: median final verdict residual relative error 1.04286, cosine 0.138973, absolute margin error 11.9964nats; residual improves 0/8, margin improves 0/8 versus the SAME unreset arm.
- union_blocks, before block 3: median final verdict residual relative error 1.05848, cosine 0.0362537, absolute margin error 12.0681nats; residual improves 1/8, margin improves 4/8 versus the SAME unreset arm.
- union_blocks, before block 8: median final verdict residual relative error 1.09337, cosine -0.0337678, absolute margin error 12.0602nats; residual improves 2/8, margin improves 5/8 versus the SAME unreset arm.
- union_blocks, before block 11: median final verdict residual relative error 1.05363, cosine 0.139006, absolute margin error 11.2299nats; residual improves 2/8, margin improves 6/8 versus the SAME unreset arm.
- union_blocks, before block 16: median final verdict residual relative error 0.771458, cosine 0.670968, absolute margin error 5.57329nats; residual improves 6/8, margin improves 8/8 versus the SAME unreset arm.
- union_blocks, before block 21: median final verdict residual relative error 0.606516, cosine 0.841817, absolute margin error 4.36865nats; residual improves 8/8, margin improves 8/8 versus the SAME unreset arm.
- union_blocks, before block 27: median final verdict residual relative error 0.217157, cosine 0.981695, absolute margin error 2.01884nats; residual improves 8/8, margin improves 8/8 versus the SAME unreset arm.

These interventions remove prior full-state error once; any later discrepancy is measured by actual hybrid computation. They do not identify a primitive operation, show a dominant learned mechanism, or provide a false-only heldout success. Medians over dependent templates are descriptive; stratified and individual results remain in the JSON. Numerical additivity failures prevent claiming a fully validated direct vector transport decomposition.

Evidence: [vector audit](204-sample-oracle-vector-audit.json), [summary and trajectories](204-sample-oracle-summary.json), [replacement audit](202-replacement-implementation-audit.md), [fixed reset protocol](../experiments/203-genuine-oracle-continuation.md), [explicit additivity separation](../experiments/204-separated-reset-and-additivity-checks.md). No browsing, training, commits, pushes or publication.
