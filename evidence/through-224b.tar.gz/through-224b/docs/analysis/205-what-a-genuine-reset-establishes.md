# What a genuine reset establishes

The intervention changes the state of the tested **hybrid predictor**. It does not establish a learned compensatory mechanism in the native transformer. Its evidential value comes from executing two continuations with different incoming states, not from the algebraic identity used afterward to compare their errors.

Let A be the actual final native displacement, P the ordinary final prediction, and Q the final prediction obtained after a genuine oracle reset. Define signed vectors:

\[
E=A-P,\qquad E_{reset}=A-Q,\qquad T=Q-P.
\]

Then

\[
E=E_{reset}+T.
\]

Here T is measured from **actually executed** continuations. The earlier replacement script instead subtracted scalar norms without computing Q; that could not measure a reset effect.

For a source_linear reset after blockone, the remaining surrogate is a composition of false-state linear maps. In ideal arithmetic, with tail map L and incoming native/predicted displacements d and p,

\[
T=L(d-p).
\]

Thus T measures the tested surrogate's propagation of the incoming-state correction. The remaining error E_reset is what that surrogate still gets wrong after a correct incoming state is supplied. Neither term is an independent noise source or a learned feature. The local native nonlinear remainders depend on the evolving counterfactual state and can be correlated across depth.

Removing incoming error need not improve final accuracy. In particular,

\[
\|E_{reset}\|^2-\|E\|^2=\|T\|^2-2\langle E,T\rangle.
\]

A reset improves squared error only when its correction has enough positive projection onto the existing final error. If an earlier prediction error happened to offset later approximation error, correcting that earlier error can make the final forecast worse. This is vector geometry within a misspecified predictor, not evidence that the transformer learned to generate errors that compensate one another.

For union_blocks, a reset can also change the inputs to finite nonlinear blocks. Writing its hybrid tail as H gives T=H(d)−H(p); it is generally incorrect to replace this with one fixed linear map applied to d−p. The state-dependent finite-block changes are part of the measured reset effect. A large local remainder norm, or a large incoming error norm, therefore cannot by itself establish causal dominance.

The per-case signed projections in [205sample](205-sample-measured-reset-separation.json) close the vector account. Their norms do not add. Separately aggregated medians of projections need not add either. The additional direct-J(error) coordinate discrepancy in203/204 remains unqualified; algebraic reset-error accounting does not resolve it or the older196primitive disagreement.

A successful explanation of QuestionB needs a predictor for the relevant nonlinear finite response, not merely accurate initial conditions for an inaccurate tail model. The [208proposal](../experiments/208-source-receiver-partition-proposal.md) specifies one falsifiable source/receiver partition. It has not been executed, and even a successful whole-block implementation would require explicit computational-cost limits before it could be called a compact mechanism.
