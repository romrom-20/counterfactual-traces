# A high-precision local reference does not certify the original MPS path

The registered CPU diagnostic executed all five precision modes at blocks2 and28 for one fixed existing204sample case. The original forecast computation and all203/204coordinate bounds remain unchanged. See [the complete record](206-local-derivative-precision.json) and [fixed protocol](../experiments/206-local-derivative-precision.md).

At block28, the publicCPUfloat32 derivative-additivity discrepancy was0.00020313262939453125, failing the same1e-4bound. Promoting the block tofloat64 while keeping the public internally forcedfloat32 normalizers/softmax reduced this discrepancy to9.19417e-7. Promoting both normalization and softmax arithmetic gave7.81597e-14. That reference passed its standardreverse contractions and centralfinite-difference checks; the largest block28centraldifference discrepancy was4.48933e-8 at the fixed epsilon1e-5.

These results show that a closely related higher-precision local calculation can satisfy derivative linearity and independent numerical checks. They support arithmetic precision as a candidate explanation of the local additivity failure. They do not isolate one arithmetic operation as its sole cause or establish the cause of the original196primitive discrepancy.

Crucially, NONE of the CPU modes passed the full-coordinate forward replay against the originalMPSFalse block output at1e-4. Even publicCPUfloat32 differed by0.000244140625 atblock2 and0.000152587890625 atblock28. Thus206does not qualify a drop-in replacement for the frozenMPScomputation. Its internally consistent promoted-precision result cannot retroactively turn203/204failed coordinate checks into passes. The current Stage1 direct vector identity remains unqualified; genuine204reset validity rests on its separate same-backend/public-model replay, boundary and exact-continuation controls.

No training, newTrue observation, original source modification, threshold relaxation, browser, push or publication. The executed206script retains a RuffF821closure/delete style warning; its complete run exited0. No code was changed after execution to remove that warning.
