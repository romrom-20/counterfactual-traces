# Qualified block interaction; failed prospective source–receiver account

Both requested experiments completed, in order. The two-block factorial qualified before208implementation began.208then sealed all64fresh forecasts before any new ordinary nativeTrue measurement. The numerical controls passed; the prospective candidate failed both original primary success and registered partial progress. QuestionB remains open.

## What the controlled two-block experiment establishes

The qualified209c factorial starts every arm from the same saved native FULLsequence state before publicblock27, retaining the originalFalse-state Jacobians. Allfourreadouts are FINITE, so normalization readout linearization is not a confound. Letters below order blocks27then28; L=originalFalseJVP,F=finiteblock.

- LL: median residualerror21.98%; marginerror2.074nats.
- FL:21.80%;2.000nats.
- LF:15.79%;0.449nats.
- FF:1.76e-8relativeerror;0nats.

Neither isolated finite block passes the original joint criteria in any of64cases; both finite blocks pass64/64. Block28finite improves all64margin predictions, but29margin-only passes coexist with zero residual-bound passes. The result is conditional on this native oracle boundary, not prospective success.

The signed factorial interaction is measured, not inferred by subtracting norms. Its verdict-vector projection opposes the missing LLdisplacement in64/64cases, while its FINITE-margin effect is positive64/64. Its vector norm is a median0.244times the LLerrornorm; this is not an explained fraction. The finite-margin interaction has median0.368nats. Splitting using the synthetic additive endpoint gives median0.333nats from the residual interaction's readout consequence and0.041nats from readout combination. Medians do not add. Different vector/scalar signs do not identify two competing learned mechanisms.

[Detailed factorial result](209-two-block-factorial-result.md) retains all cases and schema/order/source distributions. In particular, the generic LFmargin median0.034nats can look successful while residualerror remains7.56%. The scalar cannot substitute for the vector measurement.

## What the fresh source–receiver test establishes

At everyblock, the registered predictor uses only the nativeFalse trajectory, known Boolean embedding edit, model weights and the fixed update:

    delta_next = F(hFalse + S delta) − hFalse_next + JFalse (I−S)delta.

S selects only the edited Boolean INPUTrow. The finite source term changes outputs at ALLpositions; receiving-row input changes are transmitted linearly. An explicitly registered absolute-source carry avoids Float32subtraction/addition reconstruction. The source is not clamped to an observedTrue activation. Candidate and baseline are computed before the separate trivial full-finite control within every example, and that control never supplies their inputs.

Fresh contexts: marzipan/nougat, gimbal/fulcrum, larch/tamarack, chalice/goblet; both schemas/orders, four assignment/target cells each. All128input sequences were absent from1024historical sequences in514available forecast records. These64pairs remain dependent synthetic templates.

All forecasts sealed **2026-10-15 09:04:30.534343UTC**. The last forecast completed09:04:29.417434UTC. False-only numerical verification completed before the first ordinary nativeTrue measurement at **09:05:25.417705UTC**. The run completed09:06:03.848289UTC. Source files and predictions remained frozen throughout evaluation.

Median final-verdict relativeL2error / absolute margin-response error:

- Original source_linear: **1.092996 /12.257484nats**.
- Same blocks, finite head: **1.092996 /12.226837nats**.
- Source–receiver candidate: **1.556543 /5.763094nats**.
- Full-finite known-edit control: **1.71e-8 /0nats**.
- Zero displacement: **1.0 /10.245451nats**.

Candidate: **0/64joint individual passes;0/16primary panels;0/16partial-progress panels**. Every schema/order stratum has0/4passing source blocks under both panel criteria. Original bounds remain relativeL2<=.05,cosine>=.99,native norm>=.001,marginerror<=.10nats, ALLfourcells per panel and>=3/4source blocks in EVERYstratum. Partialprogress requires halving BOTH errors against source_linear in ALLfourcells. No lower pooled median is substituted for success.

The candidate improves marginerror64/64 compared with both the original baseline and zero displacement, yet improves residualerror versus source_linear only32/64 and beats zero residual prediction only29/64. Its median final cosine is0.0390 and predicted/native normratio1.126: restoring displacement magnitude does not restore its direction. The finite head alone leaves residuals unchanged and barely alters marginerror.

Schema remains consequential. Candidate generic-schema medians:0.773220relativeerror/4.273043nats; descriptive:2.078212/7.344412nats. The candidate verdict-error curve has pooled median1.018641 afterblock27 and1.556543 afterblock28. This is a descriptive observation of the frozen candidate trajectory, not a fresh causal localization or an adaptive repair. All28depths and allstrata remain in [the complete208audit](208-source-receiver-partition.json) and [descriptive comparisons](208-error-comparisons.json).

Crucially, **the candidate absolute Boolean-source trajectory matches nativeTrue exactly at every one of28depths in all64cases**. The first-block fullsuffix and full-finite native controls also pass. The tested end-to-end failure is therefore not rescued by making ongoing source computation exact. Under this qualified computation, a finite-source/linear-receiver account is insufficient. The missing finite receiving-state response, its source interaction, and propagation of prior receiver error remain possible contributors; this experiment does not separate those contributions or name a responsible primitive.

## Numerical qualification, preserved limits, cost

209c:544state/score checks and576first-reverse projections passed. Maxcoordinate9.54e-7,maxscore7.63e-6,maxprojection2.144e-5. Its original209attempt failed0/64at1.373291e-4;209bfailed9/64at1.068115e-4. Sources/logs/statuses/partial arrays are preserved.209cimplemented the intended exact absolute reset and consecutive finite operands; no threshold was relaxed.

208:376state/score checks and1296first-reverse projections passed. Maxcoordinate1.19e-7,maxscore5.25e-6,maxprojection7.10e-6; source replayerror0. All bound comparisons use the original1e-4coordinate/.005score and.001+.0001abs(reverse) contraction tolerances. Alternatewhole-public-model dual hooks are structurally independent but share forwardAD. Standard first-reverse checks qualify only tested projections, not all derivative coordinates.

**204 is preserved as a qualified retrospective RESET diagnostic subject to its documented checks.** Its424/18432direct J(error) identity failures and196primitive derivative disagreement remain unresolved. Nothing here retrocertifies them. Invalid replacement-agent norm-subtraction resets, absolute-state/forecast metric mixups and unexecuted Stage1/2 conclusions remain invalid and unmodified.

Main208cost:128ordinary models(64False+64True),3648localfiniteblocks,3456localJVPs,64headJVPs,448finitehead evaluations. Verification additionally24wholepublicFalseAD runs,240nestedfiniteblock evaluations,16nestedfiniteNorm evaluations,216reverseblockforwards/648backwards and216headforward/backward pairs. Candidate alone costs28wholefiniteblocks+27receiverJVPs per context, potentially more than a nativeTrue forward. This is not an efficient compact explanation.

No learned circuit, normalization/attention/SiLU causal mechanism, training origin, novelty priority or general QuestionB solution is identified. Primitive-level causal interventions are still required. These two experiments narrow the explanation: neither isolated late block accounts for the oracle-tail failure, and ongoing exact source encoding does not make linear receiving-state transmission sufficient on fresh examples. Publication remains on hold; no browser, training, staging, commit, push, PR or post was used.

![Actual controlled and prospective results](../figures/208-209-factorial-partition.png)

Reproduction: [offline bundle instructions](../../results/source-receiver-factorial-208-209/README.md), [208registration](../experiments/208-source-receiver-partition-registration.md), [qualified209c registration](../experiments/209c-absolute-finite-factorial.md).
