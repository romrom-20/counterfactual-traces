# Two-block factorial: neither isolated finite block is sufficient

209c qualified all64historical contexts from the verified native full-sequence reset BEFORE publicblock27 (boundary26 completedblocks). Every arm uses the original nativeFalse linearization when linear, and the SAME FINITE final normalization/logitreadout. No further native reset is made. This is a retrospective surrogate diagnostic, not a prospective prediction test or learned-circuit identification.

The four arms, letters ordered27then28:

- LL: median final-verdict displacement relativeL2error0.219777678; absolute margin-response error2.074340820nats;0/64joint individual passes.
- FL:0.218011343;1.999858856nats;0/64passes.
- LF:0.157887584;0.449043274nats;0/64passes.
- FF:1.76e-8;0nats;64/64passes.

Making28finite improves marginerror64/64 and residualerror62/64.29/64marginerrors pass0.10nats, but0/64residualerrors pass0.05relativeL2. Making27finite improves either error only32/64. The generic-schema LFmargin median is0.034412384nats while its residual median remains0.075606222; descriptive-schema medians0.884840012nats/0.248011832. A convincing scalar margin does not establish a recovered displacement vector. Source/order/schema results and all64cases remain in the numeric audit.

## Signed block effects and interaction

Let each D denote the final predicted displacement. Define c27=D_FL−D_LL,c28=D_LF−D_LL,I=D_FF−D_FL−D_LF+D_LL. These are measured vectors and sum to D_FF−D_LL. No norms are subtracted to fabricate a continuation, and no L2norm fractions are called explained causal fractions.

At the verdict row, c27 and c28 both have positive projection toward the missing LL displacement in all64cases. I has NEGATIVE projection in all64cases. I's norm divided by the LLerrornorm ranges0.187826–0.348304,median0.243766. This is a magnitude comparison, not an explained fraction. Making both blocks finite is not equivalent to summing their isolated finite corrections. The negative interaction projection describes geometry within this controlled surrogate; it does not demonstrate learned compensation.

All four margins use the same finite G. The margin interaction is positive64/64, median0.368131638nats. Evaluate the synthetic additive endpoint D_add=D_FL+D_LF−D_LL in Float32, and split it exactly as:

    interaction_margin = [G(D_FF)−G(D_add)]
                       + [G(D_add)−G(D_FL)−G(D_LF)+G(D_LL)].

The residual-interaction consequence has median0.333276749nats (positive64/64). The readout-combination component has median0.041414261nats, positive37/64 and negative27/64. Medians need not add. The different signs of the residual projection and margin interaction are not contradictory: a vector projection toward one residual-error direction and a nonlinear scalar readout measure different quantities. Neither is a named primitive mechanism.

## Qualification and preserved failures

All544required state/score controls passed; maximum coordinate discrepancy9.54e-7 and score discrepancy7.63e-6. LLreplays204's before27 union_blocks tail, whose head is finite; this is not the3.42-nat source_linear result with its linear head. FFmatches native remaining states and scores.32alternatewhole-public-model dual-hook constructions cover allfourarms on the original eight-case sample. SameforwardADbackend, structurally distinct implementation only.

All576standardFIRSTreverse/JVPprojection comparisons passed on relevant block27 and both block28 directions at ALL64Falseanchors. Maxabsolute projection error2.144e-5; fixedbound.001+.0001abs(reverse). This does not certify every derivative coordinate, resolve196primitive reverse-over-reverse disagreement, or retrocertify204's424/18432failed direct J(error) identities.204remains a qualified retrospective RESET diagnostic, not fully derivative-qualified evidence.

Original209stopped0/64 on FFnative-state error1.373291e-4>1e-4: it reconstructed the initial native state using Float32False+delta.209bused absolute native input for27 but inadvertently retained subtract/add reconstruction into finite28; it stopped9/64 at1.068115e-4>1e-4. Both sources/logs/statuses/partialarrays are preserved unchanged.209ccarries absolute native26 into finite27 and its absolute output into consecutive finite28, matching the intended exact native reset in real arithmetic. Thresholds, cases, Jacobians and analysis were unchanged. Maximum corrected residual control error is below1e-6. There was no threshold relaxation or selection of surviving cases.

## What this resolves

Under this fixed reset and finite readout,28's isolated finite response repairs much of the margin discrepancy but cannot recover the vector;27's finite correction is also needed for full recovery, and its effect depends on whether28is finite. The interaction is nonzero and structured. This constrains an account attributing the remaining failure solely to either block's isolated response. It does not identify the internal operation causing that interaction, a learned circuit, or a prospective solution to QuestionB.

208implementation began only after209c completed and its array audit qualified. That separate fresh-context test retains the source–receiver partition proposal and globally sealed forecasts.

Numeric evidence: [endpoint/vector audit](209c-two-block-factorial.json), [signed-effect distributions](209c-factorial-effects.json). Frozen protocols: [original209](../experiments/209-two-block-factorial.md), [209b](../experiments/209b-absolute-finite-factorial.md), [qualified209c](../experiments/209c-absolute-finite-factorial.md). Actual run: `runs/two-block-factorial-209c`; failed runs retain original names.
