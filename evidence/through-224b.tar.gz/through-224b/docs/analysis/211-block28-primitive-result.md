# Block28: gate–up interaction repairs margin, but no single primitive explains the full response

The requested primitive diagnostic completed on all64qualified209ccontexts under BOTH incoming states. The strongest operation-specific result is that the measured finite **gate–up product interaction**, inserted only at receiving positions, improves final-verdict residual AND marginerror in64/64cases in each condition. It substantially repairs the margin without recovering the full displacement. SiLU curvature alone improves the vector while worsening the margin in everycase. MLP-inputRMSNorm contributes strongly to the receiving-vector discrepancy, but the benefit of correcting it depends on the incoming error geometry.

These are qualified effects of explicitly defined FINITE interventions. The original wholeblockMPSJacobian is still coordinate-unqualified. Reference accounting and finite causal effects are reported separately, with all numerical failures retained. No learned circuit, unique complete mechanism, prospective predictor or208generalization is established.

## Setup and actual interventions

Start from the same native full-sequence state BEFORE publicblock27 as209c. At block28 compare N=native finite27absoluteoutput and L=originalFalse27+linear27displacement. NativeFalse28 anchors, causal mask/RoPE, pinnedQwen2.5-1.5B-Instruct/MPSFloat32/eager/eval and Boolean tokens stay unchanged. There are128branchcases, not128independentexamples; all64contexts are retrospective dependent synthetic templates.

For everyprimitive/group, replace only that operation's finite response with its False-anchored affine function. The actualpublicMPSblock recomputes everyotheroperation finitely at its changed input. Interventions cover: attentioninputRMS/QKproduct/softmax collectively AND individually; attentionweight–value multiplication; MLP-inputRMSNorm; SiLU; gate–up product. Fixed V/O projections are linear; their finite numerical remainders are not called learned curvature. A separate derivative-free2×2 clamps attentionroutingweights and/or values toFalse while recomputing outputprojection/MLP finitely.

Each actualsurgery's effect is **C=fullfiniteoutput−lesionedoutput**. Measure C on ALLreceivingrows (strictly after the Boolean source), plus source/verdict/fullsuffix. Then add ONLYC'sreceivingrows to the ORIGINAL209cJacobian forecast and evaluate the SAMEFINITEreadout. This is retrospective sufficiency testing using an oracle measured effect; it is not a forecast. Lesioning the finitegraph and inserting its effect into the linearforecast are distinct tests and can have different consequences.

Allsource/prefix computations use the fullsequence. Prefixeffects are explicitly checked; compact suffixvectors and prefixmaxima are saved with hashes of the fullparentstates. Neither a vectornorm subtraction nor an output-error scalar substitutes for executing a block.

## Signed receiving-position effects

Below are medians of the actual FINITE surgery effects. Each pair is **vectornorm / signed projection toward the missing native receiving displacement**, in residual units. Positive projection points toward the correction of the ORIGINALsame-branchJacobian error. Separate medians do not add; these lesion effects are not an additive decomposition.

- Attentionnorm/routing: N **3.827 /−0.298**; L **3.854 /−0.110**. Native projection negative64/64; Lpositive13/64. Its receiving correction does not improve residualerror in anycase.
- Attentionweight–value interaction: N **2.391 /+1.026**; L **3.098 /+1.328**. Projection positive64/64 in both.
- MLP-inputRMSNorm: N **12.952 /+10.509**; L **13.132 /+5.174**. Projection positive64/64 in both; large globalalignmentchange despite similar vectornorms.
- SiLU: N **6.611 /+1.852**; L **6.581 /+1.621**. Vector alignment is positive in everycase, yet final margin gets worse when this correction is inserted alone.
- Gate–up: N **10.868 /+7.626**; L **11.818 /+8.429**. Both alignment and paired endpoint improvement persist in allcases.

The independently labeled frozen-reference budget retains all seven local remainders separately. Its native-input attentioninputRMS contribution projects negatively in64/64cases, while QK andsoftmax project positively in64/64. Native median receiving projections:−1.177,+1.175,+0.234. Such cancellation describes the tested geometry; it does not identify learned compensation or competing semantic features. Alllinear-projection/residual-rounding terms and the reference/public mismatch remain separate.

## Does correcting each discrepancy repair the final verdict?

Numbers below are **median final VERDICT-token relativeL2error / absolute margin-response error in nats**, after inserting the actual measured finite surgery effect only at receivingrows. They are not receiving-region average errors.

Original Nbaseline: **0.218011 /1.999859**. Original Lbaseline: **0.219778 /2.074341**.

- Gate–up correction: N **0.153940 /0.307753**; L **0.157121 /0.168722**. Both improve64/64perbranch. Zerojoint accuracy passes. For the whole receivingregion, relativeerror also improves: approximately19.5%→14.5% under N and19.3%→14.5% under L.
- MLP-inputRMS correction: N **0.134665 /1.891935**; L **0.189057 /1.917440**. Both improve64/64N and63/64L;0jointpasses. It repairs much more vectorerror with a correct incomingstate than with the block27-linear input.
- SiLU correction: N **0.212827 /2.537357**; L **0.215952 /2.537739**. Residual improves64/64perbranch, margin worsens64/64perbranch. It fails the required two-endpoint test.
- Attentionweight–value correction: N **0.205641 /1.870380**; L **0.205332 /1.943907**. Both improve64/64perbranch, but errors remain large.
- Collective attentionnorm/routing correction: N **0.224285 /2.016891**; L **0.226305 /2.086679**. No pairedimprovement in eitherbranch.

No individual receiving correction passes the original joint criterion in anycase: relativeL2<=.05,cosine>=.99,nativenorm>=.001 ANDabsmarginerror<=.10nats. Native fullfinite28 recovers exactly64/64. Lfullfinite28 remains at0.157888/0.449043. Gate–up insertion can have a better margin than Lfullfinite28 while neither has an accurate vector; this is not a claim that the complete model is less correct or learned to compensate.

## What the gate–up intervention means

Writing the actual finite gate andup activations as phi0+DeltaPhi and u0+DeltaU:

    Delta(phi * u) = u0 * DeltaPhi + phi0 * DeltaU + DeltaPhi * DeltaU.

The affine gate–up lesion removes the product crossterm in real arithmetic while retaining the finite inputs to that product. Downprojection/residual addition follow; there is no later internal nonlinearity in block28. The final normalization/readout remains finite. This is a specific operation-level hypothesis tested by an actual local intervention, not inference from a largeactivationnorm. Finite SiLU changes are already contained in DeltaPhi; SiLU curvature alone is a different intervention and fails the paired endpoint test.

The equation is real-arithmetic algebra. **It is not a coordinate-certified equality between the saved frozen-reference component and the actualMPSsurgeryeffect.** The separate211ccrosscheck fails that1e-4equality bound in128/128comparisons, maximum0.000770254; median relativeL2disagreement7.32e-5. Smallrelativeerror does not turn those failures into passes. Thus the independently measured finite effect supports the intervention-specific conclusion above, while the exact floating-point Jacobian/source-transport attribution remains unqualified.

## Local behavior versus inaccurate incoming state

For the frozen MLP-RMS receiving component, N/Lvector cosine has median0.99715 and relativevectorchange0.0905. For its actual finite surgeryeffect, cosine0.99779 and relativechange0.0710. Its receivingvector is broadly similar under bothincomingstates, but projection toward the TOTALnative missingvector falls from10.509 to5.174. Its smaller benefit under Ltherefore does not imply the primitive ceased to generate a local discrepancy: the error that needs correcting also changed.

Gate–up finite receivingeffects change more: N/Lcosine0.96752, relativevectorchange0.27196 and normratio1.10961. Their correction improves both endpoints under eitherinput, but does not repair the upstream error. These paired observations separate local nonlinear response from its usefulness at a different inaccurate incoming state; they do not uniquely assign the upstream cause.

## Necessity and attention pathway controls

Lesioning gate–up in the otherwise finite native28block produces0.124148residualerror and2.280857nat marginerror. Lesioning SiLU instead gives0.069927/0.524309; lesioning MLP-inputRMS gives0.129325/0.063452. This supports a strong role for the product in the margin and for MLPnormalization in the vector under these interventions. It does not make either alone sufficient.

Affinizing attentioninputRMS,QKandsoftmax together while leaving everythingelsefinite gives native0.039623/0.033627 and64/64originaljointpasses. Thus their nonlinear responses are not necessary for accuracy at the registered bounds in this specific correct-input setting with a finiteMLP/valueproduct. Attention itself remains involved: clamping routingweights entirely toFalse gives native0.086889/0.192904; clampingvalues gives0.083612/0.050983; clampingboth0.140045/0.124340. Those interventions remove finite first-order pathway changes too and must not be confused with curvature-only lesions. Allreceivingvector contrasts and the finite routing/value interaction are saved.

Under L, the corresponding clamps give0.208571/0.609444,0.206437/0.452179 and0.268044/0.518581. Everycase/branch/source/schema/order remains visible; no pooled median is used as a success rule.

## Qualification, failures and reproducibility

Sol's210 originalwholeblock compatibility fails8/128native/linear directions, maximum1.43736e-4, while the relevant originalMPSadditivity identity fails15/64, maximum1.99795e-4. Original196/204disagreements remain unresolved.210b/210c locallyqualify seven primitives,896checks each, with publicprimitive firstAD andCPU64centralFD; actualnode max2.33614e-6public/1.51401e-6FD. These are local, not complete tangent-transport certification.

211passed1600finite state/score/sham/reference-accounting controls, maxcoordinate4.76837e-7,maxscore7.62939e-6. It rechecked1920local affine derivatives on actualsurgicaldirections, max2.33614e-6. Signed reference budget closure2.45e-13 is algebraic, not independent derivative validation.211c's128coordinate-equality failures remain explicit. Originalauditor211stopped on a missing`pairs/`in the parentpath before reading endpoints; separatelynamed211bauditor corrected only thatpath and recorded its ownhash. No model, arrays, thresholds or interventioncode changed.

Actual211cost:2240local finite interventionblocks,192manual primitive traces,5248finitehead evaluations,128reference budgets and128reference-tangent replays. No newordinaryTrueexamples,208runs, browser, training, Git stage/commit/push or publication. Frozen scientific sources, parenthashes, checks, signedvectors, endpoints, failed attempts and everycase are retained.

**Verdict:** gate–up multiplication is the most useful single tested correction for the margin; MLP-input normalization is a substantial vector contributor; isolated SiLU curvature is insufficient and directionally misleading for the margin. This is partial operation-level causal evidence, not a complete mechanism. The next discriminating question is their JOINT effect under predicted receiverstates; this experiment did not register or execute that joint repair or a broader208test. Hold208generalization until that account and numerical scope are defensible.

![Actual signed primitive effects and interventions](../figures/211-block28-primitives.png)

Evidence: [complete211arrayaudit](211-block28-primitives.json), [210qualification](210-block28-derivative-qualification.md), [saved-vector failures/sensitivity](211c-saved-vector-crosschecks.json), [frozen211registration](../experiments/211-block28-primitive-diagnostic.md), [reproductionbundle](../../results/block28-primitives-210-211/README.md).
