# A conditional product term explains a local error, but does not rescue the predictor

**The suggested factorial was worth doing.** The gate–up correction remains behaviorally useful after MLP-input RMSNorm repair in the controlled block-28 setup. Its effect is not merely compensation for a linearized normalization input. Measured rounding accounts for the new captured mixed-term discrepancies. However, the same fixed last-block repair fails on the old 208 predictor. A matched-context control then shows why a context-independent additive repair is an inadequate description: changing only the receiving input states can reverse the product correction's signed behavioral effect.

This is progress on a local computational explanation and its limits. It is not a solution to Question B, a learned-circuit identification, a fresh prospective success, or a literature priority claim. No browser or literature search was used in this continuation.

## What was tested and what counts as success

All runs use the original pinned Qwen2.5-1.5B-Instruct revision `989aa7980e4cf806f80c7fef2b1adb7bc71aa306`, MPS Float32, eager attention, eval mode and finite final readout. Contexts are related synthetic templates, not independent replications. The 212/213 examples are the 64 qualified 209c examples. The 214/215 examples are the 64 already-observed 208 examples. Every model computation uses the full sequence; compact saved arrays retain its causal suffix after unchanged-prefix checks.

The unchanged joint accuracy criterion requires native verdict displacement norm at least .001, relative L2 error at most .05, cosine at least .99 and absolute margin-response error at most .10 nats. Whole-test success requires all four assignment/target cells in a panel, with at least three of four panels passing in every schema/order stratum. Median improvement is not success. None of the nontrivial repairs below passes the joint test on any individual example. The only 64/64 native passes are ordinary full-finite block controls supplied with native input.

## 212/213: distinguish product interaction from numerical disagreement

Use post-SiLU gate activation phi and up activation u. In real arithmetic,

    Δ(phi ⊙ u) = Δphi ⊙ uFalse + phiFalse ⊙ Δu + Δphi ⊙ Δu.

213 separately captures and projects all three signed vectors. Its finite-product and affine-product runs have exactly matched parents, so their difference isolates the defined product intervention, conditional on those parents. Strict equality of the CPU64 projected mixed vector and the actual MPS intervention effect **fails in all 256 conditions** at the original 1e-4 coordinate bound; maximum disagreement is .000990471. Those failures remain failures.

New independent captures measure product/cast rounding, downprojection rounding and residual-addition rounding separately. Their signed sum accounts for the discrepancy to 3.05224e-13, without fitted coefficients. Downprojection rounding dominates. This qualifies an arithmetic account for these newly matched captures. It does not retroactively certify the old 211c saved vectors, whose matching internal rounding captures were unavailable, or resolve the original whole-block derivative identity.

212 crosses MLP-input RMSNorm and the gate–up product, each False-affine or finite. Letters are ordered RMSNorm, product. Two backgrounds remain distinct: other primitives all finite, and other nonlinear primitives all False-affine. The former tests conditional local effects; native-input FF in that background is a trivial finite-block control. The latter tests a defined local surrogate. Its LL remains numerically distinct from the original MPS Jacobian: all 128 strict coordinate comparisons fail, maximum .00106430. We do not rename that surrogate an exact Jacobian.

In the finite background, the product correction improves both verdict residual and margin error before and after RMSNorm repair in **64/64 native-input cases**. With block-27-linear input, product repair still improves margin error in all 64 after RMS repair, but residual error in only 35/64. Median receiving product-effect norm increases about 5.3% at native input and 3.1% at linear27 input; its benefit does not disappear after normalization repair.

The measured signed factorial interaction is

    I = FF − FL − LF + LL.

It equals the RMS-dependent change in projected mixed term plus the separately measured change in numerical terms to 4.13332e-13. All 512 unadjusted mixed-vector comparisons still fail the strict coordinate bound. Interaction receiver norms have medians 1.572 residual units at native finite background and 1.417 at linear27 finite background; their signed projection toward the native-minus-LL error is positive in all 64 cases in each condition. These norms are not additive explanatory fractions.

For the otherwise False-affine block, native-input joint repair reduces median verdict relative error from .2180 to .08529 and margin error from 1.99986 to .28333 nats. Under linear27 input, the corresponding values are .21978 to .17218 and 2.07434 to .16559. These are substantial local improvements with **0/64 joint passes** in both conditions.

212 passed 9,216 required controls, 5,376 actual local derivative checks and 768 finite-readout gradient checks. Maximum local derivative error is 2.48897e-6. The closed-form final RMS readout gradient agrees with standard first reverse to maximum 6.08897e-7 on the tested projections. Scalar reverse checks and local checks do not certify the unresolved whole-block coordinate identities.

## Why the SiLU correction can improve vector error while worsening margin error

Adding the measured receiving-row SiLU vector to the original forecast changes the margin by median **−.53750 nats** at native input and **−.46340** at linear27 input. The product vector changes it by **+2.31557** and **+1.83496**, respectively. SiLU worsens original-forecast margin error in all 64; the product vector improves it in all 64, under both inputs.

Initial readout-gradient projections already capture these opposite signs. Median finite-minus-initial corrections are −.00462/−.00434 nats for SiLU and −.01647/−.03182 for the product. On these measured segments the opposing signs are not generated mainly by final-readout curvature. This is a signed finite-readout measurement, not inference from residual norms.

At its own native lesioned endpoint, the same SiLU correction restores finite behavior and improves margin error in all 64. Thus it is not an inherently harmful operation. A vector that corrects one endpoint can worsen another endpoint because the starting errors differ. This also rules out treating all individually helpful corrections as interchangeable additive ingredients.

![Signed finite readout effects](../figures/212-readout-directions.png)

## 214: the fixed correction does not transfer to the old 208 predictor

All four candidates use the old False-state computation and known predicted incoming displacement, with the same saved absolute source row. Subtract the new operation contrast at the source-only input from that at the full predicted input, retain receiving rows, then add it to the saved 208 endpoint. This removes that new contrast's source-only contribution. It does not prove exact replacement of the old source/receiver update; the separately recorded affine-LL/old-receiver-J comparison fails all 64 coordinate checks, maximum .00103760.

All candidates were globally sealed at 12:44:12.597134 UTC before this run first opened saved native observations at 12:44:12.637539. **This is still retrospective:** 208 native measurements had already been seen in earlier work. No native-control arrays in the old forecast archive were read by the candidate phase.

Median verdict relative error / absolute margin error:

- Original source_receiver baseline: **1.55654 / 5.76309 nats**.
- RMSNorm correction: **1.59312 / 5.78397**.
- Product correction: **1.61722 / 6.51684**.
- Joint correction: **1.62725 / 6.38182**.

Every correction improves both metrics in **0/64** cases. No primary or half-both-errors partial-progress panel passes. The finite-head source-linear and zero-displacement baselines are retained; no arm is omitted.

214 passed 1,856 required controls, 6,144 actual local derivative checks and 192 standard reverse projections. Source-update replay, baseline replay, prefix/source contrast checks and independently repeated zero-receiver controls have zero observed error. Maximum local derivative error is 3.56983e-6; maximum reverse-projection error is 7.68161e-6. These checks qualify this defined correction, not the original whole-block Jacobian.

## 215: hold the context and source fixed, change only the receiving input

214 alone changed both the example set and the approximation regime relative to 212. It could not establish which difference mattered. 215 therefore compares the exact same 208 context at its native state after block27 and its previously sealed predicted incoming state. Prefix, mask, RoPE, False anchors and source row are identical; source equality is checked explicitly. Native input is an oracle diagnostic, never a prospective predictor input.

At **native input**, the product correction improves both metrics before and after RMS repair in **64/64 cases**. Joint repair in the otherwise False-affine block reduces median verdict relative error **.22739 → .08866** and margin error **2.22163 → .30410 nats**. It still passes **0/64** joint accuracy tests. The product's median margin effect after RMS repair is **+2.52829 nats**.

At the **forecast receiving input**, incoming receiver relative error is median .90755, and incoming verdict relative error is 1.01864. Product correction improves residual error in **0/64** cases before or after RMS repair. After RMS repair it improves margin error in 25/64 and both metrics in **0/64**; its median signed margin effect is **−.59275 nats**. The defined LL surrogate's final relative error / margin error is **1.54981 / 5.86167**, versus **1.62239 / 6.48380** for joint repair.

A post-hoc paired description finds **39/64** product-effect sign reversals after RMS repair; **35/64** remain reversals when requiring native change above +.02 and forecast change below −.02 nats. The .02 guard is separately reported and changes no accuracy criterion. Every individual signed effect is retained in 215b.

The plot's separation is schema-dependent. In the post-hoc full schema/order description (215c), **all 32 descriptive-schema pairs** reverse after RMS repair: native-input median margin changes are +4.467/+4.310 nats for the two orders, versus −1.261/−1.262 at forecast input. Generic-schema native medians are +1.327/+1.298, versus forecast medians +.0986/+.0897, with 7/32 raw sign reversals. This is a descriptive pattern in previously tested, dependent templates. It does not establish a learned schema circuit or a validated rule for unseen examples.

Even running the **entire finite block28** at this forecast input produces median final error **1.61040 / 6.48024**, with 0/64 joint passes and no residual improvement relative to the defined LL in any case. Its native-input counterpart exactly replays native output and scores. Thus making the final block finite alone cannot repair these particular inaccurate incoming states. This does not rule out a future correction that explicitly compensates upstream error.

215 passed all 1,408 controls and 4,608 actual local derivative checks, maximum derivative error 3.56983e-6. All native finite replays, four 214 surrogate replays, input-source equality checks and prefix controls have zero error. An additional read-only code review found no substantive correctness issue in 213–215. It is an independent review within this agent session, not replication by another research team.

![Paired product effects at matched contexts](../figures/215-paired-product-effects.png)

## What this explains, and what remains open

The local product approximation omits a concrete mixed term. In the qualified captures that term plus measured arithmetic differences explains the finite product intervention effect. Normalization changes the term's parents; it modulates but does not remove the local behavioral benefit. The broader intervention effect depends strongly on the receiving input state, including sign changes at fixed context and source. A context-independent missing-vector story is insufficient for these data.

We have not identified which receiving features cause the sign change, how upstream layers generate those features, a unique cause of the 208 failure, or a compact False-state-only transport rule that accurately predicts them. Native-input success cannot answer that prospective question. The failed transfer and finite-block control give no basis for launching this candidate as a fresh accuracy demonstration. The next defensible predictive work must improve or model the receiver trajectory earlier, with a frozen rule and new contexts; another unfrozen sweep of last-block additive fixes is not justified by these results.

The strongest supported result is a **conditional primitive explanation with a demonstrated input-regime limitation**. The gated-product algebra is standard; no novelty or priority claim about it is made. The empirical signed interventions and boundaries are the contribution of this continuation. No learned circuit, grounding competence, deployment failure or general solution to Question B is claimed.

## Preserved failures and reproduction

The original 212 attempt passed its first pair's calculations then failed JSON serialization of a NumPy boolean. The separately named 212b changes scalar serialization only. Its 161 saved arrays exactly replay the failed attempt's completed first-pair archive: maximum difference zero. The original 214 auditor failed on an incorrect aggregate control count; 214b corrects 1600 to 1856 because 256 repeated zero-receiver prefix checks were omitted from the expected total. No model rerun, numerical bound, arm, formula or outcome changed for that audit correction. All failed sources, logs and available arrays remain local; saved metadata and hashes are packaged.

204 remains a qualified retrospective reset diagnostic subject to its documented checks. Its direct derivative failures, the original primitive disagreement, 209/209b failures, 210 whole-block compatibility failures and 211c saved-vector failures remain visible. Invalid replacement-agent conclusions stay invalid. Publication and pushing remain on hold.

Raw audit reports: [212 factorial](212-rms-product-factorial.json), [213 arithmetic](213-gate-up-arithmetic-audit.json), [214 transfer](214-last-block-transfer.json), [215 matched input](215-matched-incoming-control.json), [215b paired signs](215b-paired-readout-signs.json), [215c schema strata](215c-schema-readout-regimes.json). Scientific registrations are under `docs/experiments/212*` through `215*`; code is under `scripts/`. The new offline viewer includes all factorial backgrounds and inputs, every fixed arm, selected-context signed vectors and preserved numerical failures. The reproduction bundle extends the prior closure without changing it; raw model weights and NPZ arrays are local, while code, registrations, numeric reports, figures and recorded metadata are hash-preserved.
