# The vector changes, and receiver error regenerates after a correct reset

**The attachment proposed two useful tests. Both are now executed and audited.** The product-effect reversal persists when its readout reference is held fixed, so a change in the correction vector carries the prominent sign contrast. Receiver resets then show that this is not fixed by supplying an accurate early state once: the original approximation creates fresh receiver error immediately after the tested native resets. A reset after block 24 restores the useful local correction in all 64 cases, while still failing native prediction accuracy.

This narrows the local failure and constrains an early-error-only explanation. It does not explain the complete endogenous native receiver trajectory, identify a learned circuit, or provide an accurate False-state-only predictor. No browser or literature search was used for experiments 216–217. The later user-authorized Goodfire investigation is separate from their design, forecasts and interpretation.

## 216: a common readout does not remove the sign reversal

Use all 64 previously observed208/215 contexts. Let C_N and C_P be the measured after-RMSNorm product correction vectors from native and forecast receiving input, respectively. Each is the actual FF−FL finite-intervention effect. Keep only receiving rows and cross both vectors with three fixed final states: native-FL, forecast-FL and False final. Every behavioral change is measured with the actual finite head. Off-diagonal combinations are vector transplants, not rerun primitive effects at those bases.

At the fixed native-FL base, C_N raises the verdict margin in 64/64 cases, median **+2.52829 nats**. C_P lowers it in 38/64, median **−1.09713**. At the fixed forecast-FL base the medians are **+1.66029** and **−.59275**, with 39 negative C_P effects. At the fixed False final base, medians are **+2.22251** and **−.87522**, again 39 negative C_P effects.

All 32 descriptive-schema cases retain opposite vector effects at every fixed base. Holding the vector fixed and changing native-FL to forecast-FL changes its sign in 0/64 native vectors and 1/64 forecast vectors. Readout position changes magnitudes, so it still matters. The supported distinction is that changing the readout base cannot by itself explain these prominent matched sign reversals.

All 384 finite changes share the sign of their initial fixed-base gradient projection. Closed-form RMS readout gradients agree with standard first reverse, maximum coordinate error 1.23310e-8 and contraction error 4.29093e-7. Finite-minus-initial remainders are nonzero, with maximum absolute .069392 nats. We retain them rather than replacing the finite head with a linear forecast.

The registered symmetric crossed accounting splits each natural diagonal difference algebraically into vector and base contrasts. Median vector contrast is 2.89976 nats and base contrast .194084; median natural diagonal difference is 3.09478. Separate medians need not add. These are finite crossed contrasts, not unique causal fractions or proof that readout geometry is negligible in every setting.

216 passed all 1408 required checks, including exact natural receiving-endpoint/head replays. It executed 576 finite heads and 192 standard first-reverse gradients. Its original saved-array auditor passed the numerical assertions but failed while serializing NumPy summary integers. The original source/log remain; separately named 216b converts serialization only, reruns the same saved-array assertions and calls no model. No threshold, vector, base or scientific outcome changed.

![Correction vectors at fixed readout bases](../figures/216-fixed-readout-vector-cross.png)

## 217: replace the receiving state once, then resume the tested approximation

Boundary k means k completed blocks. The registered grid is **0,8,16,24,27**. At each boundary, replace receiving rows with saved native True rows; retain the False prefix and independently verified exact Boolean-source trajectory. Boundary0 has zero receiver displacement and replays the original predictor. Boundary27 replays the native incoming state from215. These are oracle diagnostics on old examples.

After the one reset, actually execute the original208 update at every remaining block:

    delta[l+1] = finite_source[l+1] − false[l+1] + J_false[l](receiving delta[l]).

Each source-only finite block is recomputed independently. Every retained receiver JVP is executed, not inferred by norm subtraction. No native future receiver state supplies a later update. The original numerical first-forward-AD operation is retained; its old whole-block coordinate disagreement remains unresolved.

At the resulting boundary 27 input, evaluate product-affine FL and product-finite FF with finite MLP-input RMSNorm and the other nonlinear primitives False-affine, exactly as215. Measure both the natural FL→FF effect and the same receiving correction transplanted into a fixed native-FL readout base. The registered native-like sign guard is positive common-base change beyond .02 nats. It is a diagnostic separate from accuracy. Also evaluate the original final208 update and an entire finite block 28 control.

All 64 contexts and all 5 resets are retained:

- **Reset0:** median incoming receiver relative error at 27 **.90755**; common-base product effect **−1.09713 nats**;24/64 pass the sign guard;0/64 natural corrections improve both residual and margin error.
- **Reset8:** error **.90878**; effect **−1.10062**;24/64 sign passes;0/64 improve both.
- **Reset16:** error **.86473**; effect **−1.20495**;31/64 sign passes;1/64 improves both.
- **Reset24:** error **.28832**; effect **+1.87230**;64/64 sign passes;64/64 improve both.
- **Reset27:** native input error **0**; effect **+2.52829**;64/64 sign passes;64/64 improve both.

The prescribed four-cell panels and schema/order strata pass the sign/benefit diagnostics only at 24 and 27. **24 is the earliest successful tested reset.** This does not identify an exact threshold between 16 and 24, a unique causal block, or the first time a native feature emerges. Later resets also leave fewer approximation steps in which error can return.

In descriptive-schema cases, the fixed-base effect remains negative in all 32 at resets 0, 8 and 16, then becomes positive in all 32at24 and 27. Reset 16 restores positive effects in the generic schema but fails the descriptive schema. A pooled positive-case count cannot substitute for the registered requirement to pass every schema/order stratum.

## Error returns immediately after an accurate state is supplied

The saved layerwise continuations add an important distinction:

- After resetting8, the first resumed update at block 9 has median receiving error **.31692**, growing to **.90878** before block 28.
- After resetting16, block 17 already has error **.32435**, growing to **.86473** before 28.
- After resetting24, block 25 has error **.18354**, then 26 has **.26286** and 27 has **.28832**.
- Even the native reset before 28 produces receiver error **.19576** after the original approximate final update.

The error at each reset is zero by construction. Thus the tested update introduces fresh error after exact input; its failure cannot be attributed solely to propagation of an error created before the reset. These measurements do not uniquely separate subsequent error generation from amplification, identify which primitive generates it, or recertify the original Jacobian mathematically. They demonstrate a reproducible failure of this specific executed continuation rule across multiple downstream segments.

![Selected reset diagnostics and accuracy](../figures/217-selected-receiver-resets.png)

![Error at each resumed block](../figures/217-receiver-error-after-resets.png)

## Useful correction is still different from accurate prediction

After reset 24, product repair reduces the defined surrogate's median verdict residual error **.36923→.32010** and margin error **2.46483→.76390 nats**. The original208 final update has error **.42832/2.50034**. Making the entire final block finite gives **.30891/.92378**. None meets the original joint accuracy criterion in any of the 64 cases.

At native reset 27, the FF surrogate reaches **.08866/.30410**, again 0/64 joint passes. Only the entire finite block at the native incoming state exactly matches the native target; this is the expected trivial control. No FF surrogate passes joint accuracy at any tested reset. No fresh-context demonstration is claimed.

Original accuracy bounds remain verdict native displacement norm≥.001, relative L2≤.05, cosine≥.99 and absolute margin-response error≤.10 nats. Each four-cell panel requires every assignment/target cell; a whole pass requires at least3/4 panels in EVERY schema/order stratum. Related synthetic contexts are not64 independent replications.

## Numerical qualification

217 passed **20976 required controls**, **4224 actual local primitive derivative checks**, and **12288 standard first-reverse scalar projection checks** covering every used JVP direction. Maxima are coordinate control 9.53674e-7, score control 6.55651e-6, local primitive derivative 4.04878e-6, reverse projection 2.03590e-5, and saved update reconstruction 3.81470e-6. Bounds remain coordinates 1e-4, scores .005 and reverse projection .001+.0001abs(reference).

A structurally separate whole-model forward-AD hook implementation replays all five resets on the registered 16 marzipan contexts, covering every schema/order/assignment/target combination:80 whole-model replays with 2240 nested source-finite blocks. False primals, post-reset trajectories, known sources and finite heads agree within the original bounds. The saved-array auditor independently reconstructs each boundary 27 input from the preceding trajectory and known absolute source.

Model work includes 4096 local block JVPs,2112 finite blocks,768 surrogate blocks and 1856 finite heads. Sol performed an additional read-only review before execution and of the final saved results, finding no substantive correctness issue. This is a separate agent's code/artifact review within the same session, not independent research-team replication.

These checks qualify the defined oracle continuations and finite-intervention comparisons. They do not turn the old whole-block coordinate failures into passes. 204 remains a qualified retrospective reset diagnostic, and invalid replacement-agent conclusions remain invalid. All earlier failures and closures are retained.

## A conditional explanation to test next

Own reasoning from the implemented algebra suggests a more specific variable than total residual error. Let **d be the change in post-RMS OUTPUT entering the gate/up projections**, not the change in the pre-normalization residual. In this defined surrogate SiLU is False-affine, so, in real arithmetic,

    DeltaPhi = diag(sPrimeFalse) W_gate d
    DeltaU   = W_up d
    C        = W_down (DeltaPhi ⊙ DeltaU).

At a fixed False final readout gradient gFalse, its initial projection is a conditional quadratic form:

    q(d) = dᵀ Q d
    Q = sym[W_gateᵀ diag((W_downᵀ gFalse) ⊙ sPrimeFalse) W_up],
    sym(A) = (A + Aᵀ)/2.

Only the verdict row contributes to the final token's readout. Q uses False-state activations/weights and a False-state readout gradient; the counterfactual normalized receiver displacement d is still unknown. Different directions can have opposite q values. Pure scaling of a fixed direction cannot reverse this ideal quadratic projection because q(cd)=c²q(d).

This is an **untested conditional quantitative consequence of the defined affine-SiLU surrogate**, not an independently established network mechanism or a new prediction result. Actual product effects retain the arithmetic terms measured in 213, and finite readout effects retain curvature measured in 216. Near-zero signs need particular care. The quadratic form is in normalized-input change; composing it with finite RMSNorm does not make it quadratic in the raw pre-RMS residual change.

The next informative primitive intervention would hold False Q fixed, measure which gate/up input changes cross its signed response, and test whether an earlier False-state-only update predicts that variable. The current oracle resets do not specify that update. I have therefore not presented a reset-assisted rule as a fresh prospective predictor. A new rule needs a concrete mechanism, frozen predictions and genuinely new contexts before an accuracy claim.

## Saved artifacts

Raw reports: [216 finite-head cross](216-vector-readout-cross-audit.json) and [217 selected resets](217-selected-receiver-reset.json). Registrations and immutable model/audit sources are under `docs/experiments/216*`, `217*` and `scripts/`. Figures and an offline interactive viewer retain all fixed bases, all five resets, every case and every endpoint. The new reproduction bundle extends the prior 1807-file closure unchanged, records raw-array hashes, and preserves the 216 serialization failure and correction. Scientific runners and saved-array audits were executed; a clean-copy hash/plan check is not a second full model replication. Publication and pushing remain on hold.
