# Goodfire prompted a falsification test, not an explanation by analogy

The user authorized browser use only for [Neural Networks Are Already Clean](https://already-clean.goodfire.com/). I inspected that first-party essay and its linked text version after experiments 216–217 had finished. No outside papers or search results supplied the following experiment.

## What the essay contributes

Goodfire's essay advocates explanations of native network computations that can fail concrete tests. Its [language-model discussion](https://already-clean.goodfire.com/#language-models) and [sign-regime discussion](https://already-clean.goodfire.com/#gentle-microscopes) suggest examining both signs of gate/value activity: a positive product can arise from two positive or two negative factors. The essay presents broad claims about network legibility as a research position; our experiment does not verify those claims. Its [discussion of testing explanations](https://already-clean.goodfire.com/#testing-explanations) is a useful methodological lead.

Our measured correction concerns **changes** in gate and up activations, `DeltaPhi * DeltaU`. Those increments are different from the essay's absolute gate/value signs. A count of negative-negative coordinates is not evidence that a particular learned feature explains our result. Down-projection weights, cancellation and the receiving readout all matter.

## The concrete objection we tested

The defined 215–217 surrogate linearizes SiLU around False. Real SiLU has a finite lower bound, approximately −.27846454; its tangent need not respect it. An apparently meaningful product effect could therefore depend on impossible post-gate activations. Before interpreting sign regimes, we should replace the tangent with real SiLU while holding the other choices fixed.

Experiment 218 registered all 64 old contexts, both native and forecast inputs, and a SiLU-affine/finite × product-affine/finite factorial. MLP-input RMSNorm remains finite; the attention nonlinearities remain False-affine. It retains actual finite readouts, a common False final readout, captured primitive operands, arithmetic remainders, parent replays and local derivative checks. This is a retrospective diagnostic, with no new prospective forecasts.

## What happened

The objection's premise was real: affine SiLU produced below-bound receiving activations in every native and forecast context, with minima −2.05650 and −.87715. Real SiLU eliminated all violations beyond the frozen 1e-4 guard.

The proposed explanation did not survive its test. Under both SiLU choices, the natural product effect was positive for all 64 native inputs and negative for the same 39 forecast inputs. The native median changed from +2.52829 to +2.45460 nats; the forecast median changed from −.592751 to −.594346. At the common False readout, native/forecast sign disagreements were 39/64 with affine SiLU and 40/64 with finite SiLU. Thus impossible affine gate values are **not necessary for these observed reversals** in the specified setup.

This replacement changes the whole SiLU function, so it does not isolate range clipping as a causal factor or show that extrapolation has no effect on magnitudes. Attention is still approximate. The result does not validate a native learned circuit, and no tested arm meets the original joint prediction criterion. Even finite SiLU plus finite product at native input has median verdict relative error .04808 and margin error .21793 nats; the latter exceeds the original .10 bound, and all 64 joint tests fail.

218 passed 5,440 required controls and 3,840 local derivative checks. Original whole-block Jacobian coordinate failures remain unresolved. The unadjusted mixed-term vector equality still fails in all 256 comparisons; separately measured arithmetic terms close the discrepancy to 2.78e-13. They remain part of the result.

## What is worth pursuing next

The useful lead is a **signed, readout-weighted gate/up contribution**, rather than an absolute activation count. In the finite-SiLU setting, define each neuron's mixed contribution at a fixed False readout as

    a_i = (W_down[:, i] dot gFalse) * DeltaPhi_i * DeltaU_i.

This projection is a diagnostic, not a finite behavioral identity. A stronger follow-up would freeze a partition using False-state quantities, intervene on its actual product terms, retain all arithmetic remainders and finite readout changes, and test both native and forecast incoming states. A successful local partition would still need an earlier False-state-only rule that predicts its gate/up increments on fresh contexts before true states are measured.

I would not start a broad feature search or claim a universal mechanism from this essay. Experiments 216–218 constrain the problem more sharply: the prominent reversal is carried by a changed correction vector, its sign can be restored by a sufficiently late receiver reset on the tested grid, and it persists with real SiLU. **Why the earlier approximation sends the receiver into that different response direction remains open.** This is progress toward Question B, not its solution.

Primary evidence: [216–217 report](217-receiver-state-mechanism-result.md), [218 saved-array audit](218-silu-range-falsification-audit.json), and [218 numerical report](218-silu-range-falsification.md). Publication, pushing and priority claims remain on hold.
