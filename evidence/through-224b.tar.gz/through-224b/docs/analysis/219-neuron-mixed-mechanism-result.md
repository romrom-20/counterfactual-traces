# A stable 32-neuron mixed-product account, with a substantial long tail

**The proposed neuron-level experiment worked as a retrospective causal diagnostic.** A fixed 32-neuron set selected on chalice/gimbal carries a median 52.7% of the absolute native-minus-forecast mixed-term contrast on larch/marzipan. Directly swapping those mixed terms reproduces the all-neuron donor sign in all 18 guarded sign-reversal cases in both directions. It beats cardinality- and product-norm-matched random controls in every tested schema/order stratum. This localizes a useful part of the defined response without identifying a learned feature or explaining its upstream origin.

All 64 examples were already observed in 208/215/218. Excluding two families from mask selection is retrospective separation, not a fresh-context demonstration. The model is pinned Qwen2.5-1.5B-Instruct, MPS Float32/eager/eval. SiLU and MLP-input RMSNorm are finite; attention nonlinearities remain False-affine. 218 and its numerical caveats are unchanged.

## The signed quantity

At each context's fixed False-final readout gradient g, neuron i contributes the initial projection

    a_ab,i = (W_down[:,i] dot g) * DeltaPhi_a,i * DeltaU_b,i,

where a,b identify native N or forecast P parent increments relative to the same False anchors. Every contribution is saved, including signs. These sums are initial projections in nats; finite behavior is evaluated through the actual head. The contrast a_NN−a_PP is split exactly into symmetric gate and up terms. This is conditional algebraic accounting, not a unique causal allocation.

The primary concentration denominator is the sum of absolute neuron contrasts. Median |net| / absolute mass on the 32 selection-excluded contexts is .4872, so cancellation matters. A fraction of signed net alone would overstate concentration.

## Compact control and a distributed tail coexist

The fixed top 8, 32, 128 and 512 groups carry respectively **46.6%, 52.7%, 58.8% and 69.6%** of absolute contrast on the selection-excluded families. A per-case oracle ranking gives 46.6%, 53.2%, 60.2% and 72.2%. The fixed ranking transfers well across these old families, but it does not explain the entire vector: reaching 90% of absolute contrast requires a median **2,215.5 of 8,960 neurons**.

The causal edit changes actual receiving product coordinates before the public down projection. It replaces only the selected opposite-minus-own mixed terms, holding the incoming background and other product terms fixed. Source/prefix edits are zero. Finite-head outcomes are measured both naturally and after transplanting the resulting correction into the same False final readout. Crosses and transplants are synthetic interventions, not native trajectories.

For fixed k=32 on the 32 mask-excluded contexts:

- All 18 eligible native→forecast and all 18 forecast→native cases attain the all-neuron donor-effect sign. Eligibility requires opposite sham/all-neuron signs with both effects exceeding .02 nats in magnitude.
- Selected edits approach the all-neuron finite common-readout effect more closely than **both** matched controls in all 32 contexts in each direction, including all 8/8 cases in each schema/order stratum.
- Median distance to that benchmark, pooled across the 64 directional tests, is **.10988 nats**, versus **3.01963** for cardinality-matched random and **3.06572** for product-norm-matched random.

Random masks come from the complement of the selected top 512, as preregistered. Norm matching is in receiving **product coordinates**, not residual or readout norm. These controls test specificity within this intervention design; they are not independent statistical replications.

Both k=32 and k=128 pass the predefined compact-account action rule. k=8 fails its 50% absolute-mass requirement, despite strong causal effects; k=512 is outside the eligible compact range. No threshold was changed after seeing the data. The action rule is not a significance or novelty test.

## Both gate and up changes matter

On the selection-excluded descriptive-schema contexts, median initial mixed projections for NN, NP, PN and PP are respectively **+3.78621, −1.09378, −.50391 and −1.89852 nats**. Thus either forecast operand can reverse the aggregate initial projection when crossed with the other native operand. The generic-schema medians remain positive: +1.09389, +.39266, +.43584 and +.10634. Actual finite crossed interventions and their rounding terms are retained separately.

The symmetric accounting gives excluded-family median gate contrast **+1.33061** and up contrast **+1.73218**, with median total **+3.06280** nats. Separate medians need not sum exactly. Neither operand alone provides a complete account.

## A more specific pattern: a positive contribution shrinks

Posthoc 219b inspects saved operands, with no new model calls or mask selection. The leading neuron is index **6411**. Its native-minus-forecast contrast is positive in all 64 cases. Its own mixed contribution does not generally reverse sign:

- In the descriptive schema, median gate increment is −3.28952 native versus −.47506 forecast; median up increment is +3.16745 versus +.19419. Its readout weight is negative. Their opposing-sign product therefore makes a positive contribution, median **+3.76471 native versus +.03368 forecast**.
- Neuron **3902** contributes negatively in all 64 cases. Descriptive medians are **−.84138 native versus −1.38498 forecast**.

The prominent aggregate reversal therefore includes the loss of a strong positive contribution alongside persistent or larger negative terms. It is not necessary for the leading positive neuron to change sign. These are descriptive operand measurements; the directly established causal group is the fixed set, not a claimed single-neuron learned circuit. Absolute gate/up sign regimes alone would miss the role of increments, projection weights and cancellation.

## Numerical qualification

All **11,584 required controls** and **2,944 actual local primitive derivative checks** pass. Model work comprises 704 block evaluations, 2,048 direct down-projection interventions, 4,864 finite heads and 64 first-reverse head gradients. All 384 whole-block product-hook replays, 384 replay heads, and 2,048 unchanged prefix/source controls have **zero** discrepancy. Maximum local derivative discrepancy is 3.42036e-6; maximum fixed-readout reverse-gradient contraction discrepancy is 3.94646e-7. The independent CPU64 finite-head replay has maximum score discrepancy 9.54278e-6 against .005.

Raw ideal mixed-displacement equality fails the original 1e-4 coordinate bound in **644/2,048** intervention comparisons, maximum .00107212. Independently measured product-cast, down-projection and residual-addition rounding close every discrepancy within **3.33527e-13**. Those raw failures remain failures. The original whole-block Jacobian coordinate disagreement remains unresolved. Passing these local checks does not recertify it.

## The next frozen hypothesis

The compact-account gate warrants a fresh test, but the upstream explanation is still a hypothesis. A specific possibility is that the executed False-linear receiver forecast suppresses a direct Boolean-source response along the selected gate/up projections. For 6411, that would shrink the positive mixed term while leaving negative terms such as 3902 comparatively strong.

The next test should compute a source-only prediction from False receiving states and the known Boolean-source trajectory, compare it to the existing receiver forecast, and seal both predictions before fresh native True states are measured. It must predict the selected operands and finite common-readout effect, rather than merely make an output somewhat better. A weak win with large remaining error will not count as a predictive mechanism. This does not justify another end-to-end correction sweep.

Raw evidence: [219 audit](219-neuron-mixed-interventions.json), [219b operand description](219b-selected-neuron-parents.json), registration under `docs/experiments/219*`, and immutable scientific sources under `scripts/*219*.py`. Original parent arrays and new captures/interventions remain local with hashes. No browser, publication, staging, commit or push was used.
