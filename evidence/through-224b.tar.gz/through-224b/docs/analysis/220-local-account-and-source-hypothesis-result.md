# A causal local account, and a rejected upstream explanation

**219 establishes a stable local mixed-product account; 220 rejects the proposed direct-source explanation of its origin.** The useful new distinction is that a large positive correction can disappear without the dominant neuron's contribution reversing sign. The original receiver forecast greatly underestimates that positive product term while retaining negative terms. Direct Boolean-source influence at the final block does not supply the missing response in the tested setup.

This is progress in identifying the error that an upstream theory must explain. It is not a solution to Question B, learned-feature identification, or an accurate predictor of full native behavior.

## What 219 established

The [219 report](219-neuron-mixed-mechanism-result.md) retains all 64 old contexts. A fixed 32-neuron group selected on two families carries median 52.7% of absolute signed contrast on the other two families. The quantity is the **fixed-readout projection at the verdict position**, not a fraction of full receiver residual norm. It changes the finite common-readout effect to the all-neuron donor sign in all 18 guarded opposite-sign cases in both directions, beating cardinality- and product-coordinate-norm-matched random controls in every tested schema/order stratum. The complete absolute contrast has a long tail: median 2,215.5 neurons for 90%.

All effects here use the defined attention-False-affine, finite-SiLU/MLP-RMS block-28 computation. The fixed readout is the actual finite head at a common False final state. Off-diagonal input/product combinations are interventions, not native trajectories. No neuron name is inferred from its sign.

## Why a quiet neuron can have a large mixed correction

One concrete old gimbal/descriptive example, hash prefix `06046f56`, makes the multiplication geometry clear. For neuron 6411, the ideal CPU64 product expansion is:

    False product                       -15.332344
    native gate first-order term        +10.382348
    native up first-order term          +15.657502
    native mixed term                   -10.602530
    actual native finite product         +0.104976

The first-order product would be **+10.707506**, whereas the finite product is near zero. The mixed term corrects that overshoot. Its fixed-readout weight is −.373942, so the negative product correction contributes **+3.964736 initial projection nats**. Under forecast parents, the corresponding mixed term is only −.100364, contributing **+.037530** nats. Product-cast, down-projection and residual-addition rounding remain separate from this ideal arithmetic.

This is a property of the same multiplication operation, not evidence for two competing learned mechanisms. A large mixed correction need not imply a large final neuron activation or an interpretable concept.

Across descriptive old cases, median native versus forecast increments at this neuron are gate **−3.28952 versus −.47506** and up **+3.16745 versus +.19419**. Both operands often move in the native direction, but much too little. Their product is attenuated more strongly. Meanwhile neuron 3902 remains negative, with median contribution **−.84138 versus −1.38498**. The aggregate can change sign through this uneven balance of magnitudes. A uniform scaling of every direction would not reproduce that pattern. The group interventions validate a fixed set's causal contribution; these individual operand descriptions do not establish a single-neuron circuit.

## 220: freeze an upstream explanation and risk a fresh test

The hypothesis was: the executed receiver forecast suppresses a substantial direct Boolean-source response along the selected gate/up directions. Predict the local response using **S**, a source-only input before block 28: retain False receivers and insert the known exact Boolean-source state. Compare with **P**, the unchanged executed 208 finite-source/False-first-AD receiver forecast. No fitted constants or target rescaling are allowed.

The frozen targets are the 32-neuron group's finite common-readout effect, neuron 6411's initial mixed projection, and its two-dimensional gate/up increment. After prediction, **N** is measured from native True incoming states using the same local attention-affine computation. This is a selected surrogate target, not the complete network's native verdict response.

All 16 new belfry/thimble prompt pairs cover assignment, target, order and schema. Their 32 full token-sequence hashes are absent from the historical paired-forecast catalog. All False observations, S/P predictions, local derivatives and upstream scalar checks were completed before the forecast seal at **04:15:51.889636 UTC on 16 October 2026**. The first native True phase started after that seal; the last observation was at 04:16:10.963272 UTC. There was no full-finite True upper control during prediction. This is a narrow fresh test within one synthetic template family and one checkpoint.

## The hypothesis fails decisively

The source-only rule passes **0/16** cases on each frozen criterion: group effect, neuron effect and parent increments. Every schema/order panel has zero passes. Criteria required small absolute errors and improvement over P, with at least 3/4 passes in every four-cell stratum. They were not changed after execution.

For the eight descriptive cases, median selected-group finite effects are:

- **Measured N: +3.46773 nats.**
- **Source-only S: −.000639 nats.**
- **Receiver forecast P: −1.96834 nats.**

The corresponding neuron 6411 initial contributions are **+3.56724**, **+.000180** and **+.038833** nats. Source-only is smaller than P in all eight cases, contrary to the proposed suppression account. Median parent relative errors are **1.00837 for S** and **.88020 for P**. The nearly absent direct-source prediction cannot explain the large native parent changes.

Generic cases also fail: native selected-group effect **+.95762** nats, S **−.001032**, P **+.008629**. Their native 6411 contribution is +.96045, compared with −.000234 and +.16508. The P forecast contains part of the native-direction response, but its magnitude is insufficient.

The result constrains the origin. With the known source held fixed, replacing native receiving input with False receiving input removes almost all selected-group response. In this setup, the strong positive response depends on a receiving state built before block 28. The source-only test does not identify which earlier operation builds it, distinguish new nonlinear error from amplification throughout the preceding network, or establish that actual native attention behaves identically to the surrogate.

![Fresh forecasts versus measured local responses](../figures/220-source-only-neuron-hypothesis.png)

## Numerical qualification and limits

All **480 controls**, **688 local primitive derivative checks** and **1,296 upstream first-reverse projection checks** pass. Maximum local derivative discrepancy is 2.17398e-6; upstream projection discrepancy 1.33713e-5; independently reconstructed P update discrepancy 9.53674e-7; independent CPU64 head replay discrepancy 7.86734e-6 against .005. Original coordinate and scalar bounds remain unchanged.

Model work includes 16 ordinary False and 16 later ordinary True forwards, 448 finite-source blocks, 432 original receiver JVPs, 160 local surrogate/replay blocks, 48 direct product interventions and 272 finite heads. Every upstream receiver direction is checked with three first-reverse contractions. These checks qualify the executed comparisons; the original whole-block coordinate Jacobian disagreement remains unresolved.

For these 48 small selected-group edits, raw ideal-vector discrepancies are below 1e-4, maximum 6.34778e-5. Independently measured arithmetic closes within 5.68422e-14. This does not change 219's 644 raw failures or 218's 256 raw failures. All previous files and failure statuses remain preserved.

## What is now understood, and what remains open

The local effect has a concrete algebraic and causal account: selected gate/up mixed terms, dominated by a strongly attenuated positive contribution and persistent negative contributions, carry much of the fixed-readout contrast. A 32-neuron intervention group transfers across two old families, and its frozen native-incoming response is measured on fresh prompts.

The origin is still unresolved. The next useful question is **which earlier receiver computations jointly produce the gate and up changes that create the strong positive term**. A targeted upstream causal trace of these variables would address that question. Another global repair sweep or a new interpretation of neuron sign regimes would not answer it. I have not launched either, and have not described the upstream mechanism as solved.

Code, registrations, forecast seals, arrays, failed hypothesis, numerical checks, figures and an offline viewer are preserved. No browser, publication, staging, commit or push was used in 219–220. The [219 audit](219-neuron-mixed-interventions.json), [219b saved operands](219b-selected-neuron-parents.json) and [220 prospective audit](220-source-only-neuron-hypothesis.json) contain every case.
