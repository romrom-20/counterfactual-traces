# The neuron account survives native attention; most of its parent response is carried in

**221 closes the surrogate gap, then localizes the response to the receiving residual entering the last block.** The fixed219 neuron group still controls the contrast with fully native attention. The final attention write alone produces almost none of the response; the carried residual produces most of the gate/up changes. That does not identify the earlier operation that built the carried state, and the small final attention adjustment remains important at the strict finite-effect bound.

All64 old208 contexts remain retrospective and dependent synthetic examples of one pinned Qwen checkpoint. Nothing here establishes a learned feature, a competent verifier failure or a complete False-state-only counterfactual predictor. The rejected220 hypothesis and every prior numerical caveat are preserved.

## Native attention does not remove the causal neuron account

Unlike219/220, the primary221 arm uses fully native attention, native MLP-input RMSNorm and real SiLU. Native incoming-state/full-product endpoints replay the actual native final states and scores with **zero error**. The old attention-affine comparator exactly replays218.

With native attention, replacing the frozen32 mixed terms reaches the all-neuron donor sign in **35/35 guarded opposite-sign cases in both directions**. Selected swaps approach the all-neuron benchmark more closely than both cardinality- and product-norm-matched controls in **64/64 cases in each direction**, including16/16 in every schema/order stratum. Median finite common-readout distance is .08251 nats for native→forecast selected swaps and .14165 for forecast→native, versus roughly3.04–3.09 for the controls. This is a native-attention transfer of the specified product-intervention account, not a new neuron selection.

## Separate the carried input from the attention write

All inputs share the known Boolean-source state. S has False receivers; N/P have native/forecast receivers. The crossed mid-residuals are:

    00 = xS + aS       source-only baseline
    10 = xB + aS       receiving carry only
    01 = xS + aB       attention write only
    11 = xB + aB       both, replaying the captured computation

Here aB is an actual captured attention output. Crossed writes are synthetic causal interventions. They do not simulate a native trajectory with a different input.

Under native attention and ordinary finite RMS, descriptive-schema median finite32 common-readout effects are **−.00050, +3.42446, +.00063 and +3.68115 nats** for00/10/01/11. Generic medians are **−.00042, +1.13072, −.00027 and +1.11695**. The bulk of the positive response is therefore present when the native receiving residual is carried through with only the source-only attention write.

Carry-only has median6411 gate/up parent relative error **.02618** against both-input11; attention-write-only has error **.98028**. This supports targeting the incoming residual. It does **not** make carry-only a sufficient explanation at the registered joint bound: it passes32/64 cases, all generic, while descriptive cases have median parent error .03587 but group-effect error **.25244 nats**, exceeding .10. Attention-write-only passes0/64. Small parent changes matter because the subsequent product and readout remain nonlinear.

![Native bridge and factorial](../figures/221-native-bridge-and-factorial.png)

## Normalization modulates the effect without generating its main positive term

Freeze the MLP-input inverse RMS scale to the source-only00 value while preserving the actual input, learned norm weight, real SiLU and finite readout. For the full native descriptive state, the median finite32 effect changes **+3.68115→+3.59476 nats**; generic changes **+1.11695→+1.09448**. The strong positive response persists. The forecast descriptive effect becomes more negative, **−1.84088→−2.40557**. This scale intervention does not rescue the forecast.

Pre-SiLU gate/up factorial interaction becomes numerically tiny with a fixed denominator, as expected for a linear projection of the summed inputs. Independently measured input and projection rounding account for the remainder. That expected algebra is not evidence for a newly identified normalization mechanism. The causal observation is that the positive native product response survives the scale intervention, while its magnitude and the forecast balance change.

## A simple mirrored-weight explanation also fails

Separately registered221b asks whether the gate/up weight rows are almost opposite, so one coordinate could explain their opposing changes. Effective rows include the learned MLP norm weight. Their cosines are **−.13214 for6411** and **−.13493 for3902**, far from the frozen near-opposite threshold−.8. A weight-only prediction of up change from gate preactivation change fails all64 native cases for each neuron, with median relative errors .85423 and .77640.

This rejects that one-coordinate shortcut. It does not prove independent learned causes: input covariance and a common normalization gain can still couple the activations. The earlier computation must explain the measured joint projection, rather than relying on nearly mirrored weight rows.

![Measured neuron-parent coordinates](../figures/221-neuron-parent-plane.png)

## Numerical qualification and the preserved auditor failure

The model run passed all64 cases. The original immutable saved-array auditor then failed a1e-9 projection-interaction identity because one matrix product intended as Float64 was still multiplying two Float32 arrays. **221c** changes only the normalized-input operand cast in that accounting product. It performs no model calls and changes no bound, intervention, neuron mask or outcome. The original auditor, pre-execution seal, failure log and separately registered correction are retained.

The corrected audit passes **14,784 controls** and **2,816 local derivative checks**. Model work is2,432 public blocks,5,888 explicit down projections,12,480 finite heads and64 first-reverse head gradients. All whole-block replays, replay heads, source-scale shams, native final endpoints and218 endpoints have zero discrepancy. Maximum local derivative error is3.42036e-6; independent CPU64 head-score error9.93636e-6; selected-parent projection replay9.33528e-6, within the unchanged bounds.

Raw ideal-vector equality still fails **1,926/4,096** comparisons at1e-4, maximum .00128667. Independently measured product-cast/down-projection/residual-addition rounding closes all discrepancies within3.64738e-13. Interaction accounting closes within7.10543e-15. These bounds do not turn any old raw equality failure into a pass. The original whole-block Jacobian remains unqualified;221 does not use that operator for its primary finite interventions.

## Why this is progress, and the next decisive step

The experiment rules out an important artifact, retains the product account in the actual native final block, and separates carried state from a final attention write. It also prevents the expected normalization geometry from being mistaken for a complete origin story. Those are new causal constraints, not merely another better output score.

The remaining target is **which earlier attention/MLP writes produce the carried gate/up direction**. A signed native residual-write ledger can locate candidates exactly in a fixed projection; finite knockouts and direction-specific rescues must then test those candidates. A projection ledger alone is not a causal explanation, and a retrospective rescue is not a prospective predictor. That targeted upstream test follows221; another global correction sweep does not.

Raw evidence: [221 corrected saved-array audit](221-native-receiver-factorial.json), [221b weights](221b-projection-geometry-weights.json), [221b parent test](221b-projection-geometry-states.json), and the221/221b/221c registrations and immutable scientific sources. No browser, training, publication, staging, commit or push was used.
