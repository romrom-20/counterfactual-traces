# Two native MLP writes matter, but a fixed final-plane account fails

**222 establishes a new causal constraint, not a complete origin mechanism.** Replacing the receiving writes of MLP22 and MLP23 together with their paired False writes reduces the positive32-neuron product effect by at least50% in32/32 operation-excluded old contexts. Matched random edits do so in0/32. Yet neither selected site's fixed rank-two rescue passes the registered combined causal gate:0/32 for each. This is evidence against the simple claim that the two writes act only by directly carrying the final6411 gate/up direction.

The distinction matters for the user's question about going in circles. The native-attention bridge in221 and the finite upstream interventions here add constraints absent from the previous output-correction sweeps. Repeating broad corrections would not answer the remaining question. We can explain a local product response and identify important upstream writes; we still cannot predict their native displacement from False receiving history alone.

## What was frozen and executed

All64 original208 contexts supplied ordinary native True/False trajectories and actual per-block attention/MLP writes. The exact vector ledger includes both residual-addition rounding terms. It uses final-block gate/up rows for6411/3902, learned norm weights and the already qualified221 source00 inverse RMS gain as fixed linear probes. It does not use the unresolved original whole-block Jacobian.

Only chalice/gimbal32 were used to rank54 attention/MLP operations by their signed projection onto the native final6411 parent direction. The two largest positive mean scores were **MLP23:.79228** and **MLP22:.58343** activation units. Selection was sealed before any intervention model. These scores are descriptive write projections, not causal fractions. The other two old families, larch/marzipan32, supplied512 intervention models. They are operation-excluded examples, not fresh or independent replications.

Each single-site intervention begins on the native True trajectory. The source and prefix remain unchanged; receiving writes are explicitly replaced. Every remaining computation is finite/native. Arms are False clamp, exact full rescue, rank-two plane rescue, orthogonal-complement rescue, norm-matched random edit, plane-norm random rescue and source-only write. The plane is the span of the effective final-block gate/up rows for6411. Both-site clamps and matched random edits are also executed. When both sites are clamped, the later incoming state has changed; it is a declared joint intervention, not an asserted native state.

The measured local effect is the frozen219 group of32 mixed-product increments, down-projected and evaluated through the actual finite head at the same False final state. This is a specified product-intervention diagnostic. Actual natural-model final states and margins are recorded separately.

## What the causal removals show

Across the32 causal cases, the median native finite32 effect is **2.12942nats**. Joint clamping gives **.65850nats**, with median paired erasure **69.28%**, meeting the predeclared50% erasure criterion in32/32. Both random edits give2.18606nats and erase at least half in0/32.

The actual natural verdict preference also changes: the median signed margin shift is **−5.35062nats** under joint clamping, compared with **−.30165nats** under both random edits. This does not establish that the32-neuron diagnostic mediates the natural margin change; the upstream intervention affects many coordinates. Final receiving-residual edit norms are similar relative to the native True−False response: median .76958 for joint clamps and .76165 for both random edits. Large residual distance alone does not indicate comparable behavioral consequences.

There is a schema-dependent split in the predeclared single-site erasure counts. MLP23 erases at least half in **14/16 descriptive and0/16 generic** cases. MLP22 does so in **11/16 generic and0/16 descriptive** cases. Continuous paired median erasure is39.2%/53.0% for MLP23 in generic/descriptive, and51.7%/32.6% for MLP22. These observations concern these tested prompt/schema conditions; they do not isolate lexical semantics or identify learned features.

![Joint write removal and actual natural margin](../figures/222-joint-write-knockout.png)

## Why the compact direction account does not pass

MLP23 plane rescue is closer in finite32 effect to native than both complement and matched random rescue in32/32 cases. It passes the absolute local rescue bounds in7/32, all generic. Those are not the cases where the clamp meets the50% erasure criterion. The combined registered gate therefore passes **0/32**, and fails the required24/32 and6/8-per-stratum rule. Its median parent relative error is .11522, but finite32 effect error is **.44544nats**, exceeding .10.

MLP22 plane rescue passes the local rescue bounds in0/32 and beats both controls in6/32. Its median parent relative error is .16183 and effect error **.43719nats**. Its combined gate also passes **0/32**. All64 full-rescue interventions replay native boundary27, final states and scores with zero discrepancy.

The missing directions matter outside the local diagnostic. MLP23 plane rescue leaves a median final residual edit .60197 times the native response and a−3.03581nat natural margin shift; its complement rescue leaves .06626 and−1.22124nats. MLP22 gives .55025/−1.85480 for the plane and .05878/−.83371 for the complement. A projection can improve the chosen neuron diagnostic without reconstructing the broader native state or verdict preference.

Source-only replacement does not reproduce either native write's downstream diagnostic: strict rescue passes0/32 at each site. This is consistent with the failed220 source-only hypothesis and the221 receiving-carry localization. It does not establish which upstream primitive produced the necessary receiving history.

![Signed ledger and all single-site arms](../figures/222-native-ledger-and-interventions.png)

## What is and is not explained

The resulting picture is specific: earlier receiving computation supplies a state on which MLP22/23 writes depend; those writes causally influence the later native product response; a direct final gate/up projection of those writes is insufficient. The original one-coordinate mirrored-weight idea was already rejected in221b, and the final RMS denominator intervention did not remove the main positive term in221. Those boundaries remain intact.

**The failed plane rescue does not itself prove nonlinear propagation.** Even a linear tail can rotate omitted directions into relevant ones. This test cannot distinguish linear mixing from internal normalization, attention feedback or nonlinear MLP transmission. Nor does it explain why the original208 False-state linear transport fails: that operator's coordinate qualification remains unresolved. The new finite interventions do not rely on it and do not rehabilitate it.

The narrower useful next question is which primitive operations inside the native MLP22/23 response generate the write difference, and which parts can be anticipated from False operands under a specified computation budget. A full native counterfactual simulation is an available reference computation, not the sought compressed explanation. No stable compact account has emerged here that justifies another end-to-end correction sweep or a claimed fresh False-only predictor. Publication remains held; QuestionB remains open.

## Numerical qualification and preservation

The independent saved-array auditor passed **4,896 controls** and **576 product first-derivative checks**, maximum error2.28750e−6 against1e−4. Work executed:640 ordinary models,576 selected-product public last-block replays,1,152 explicit down projections,2,368 finite heads,32 False anchor blocks and64 source-only local blocks. The native write ledger closes with **zero** discrepancy. Fixed-probe replay against221 has maximum9.57678e−6; independent CPU64 head-score replay8.57911e−6 against.005.

Raw ideal-vector equality fails **1/576** comparisons at1e−4, maximum .000111711. Measured product-cast/down/addition rounding closes the discrepancy within7.10577e−14 at the unchanged1e−9 bound. A rounding-accounted equality does not turn the raw failure into a pass.

The protocol, runner, helper and auditor were copied/hash-sealed before execution and remained unchanged. The operation selection was sealed before causal models. The original221 auditor failure, separate221c correction, qualified204 diagnostic, invalidity of replacement-agent conclusions and original derivative disagreements remain preserved in the prior closure. Model arrays stay local and are inventoried by hash. The closure includes actual logs, recorded run metadata, code, numeric report, images, interactive viewer source and reproduction instructions. Clean-copy hash/plan checks are zero-model checks, not a second model replication. No browser, training, publication, staging, commit or push.

Evidence: [numeric audit and every case](222-native-write-ledger.json), [registered protocol](../experiments/222-native-write-ledger-and-rescue.md), [immutable model runner](../../scripts/run_native_write_ledger_222.py), [independent auditor](../../scripts/audit_native_write_ledger_222.py), [reproduction and preservation](../../results/native-write-ledger-222/README.md), and the prior [221 result](221-native-carry-mechanism-result.md).
