# The local nonlinear remainders matter, and the product diagnostic does not determine their behavioral sign

**223 answers the revised causal question positively.** At MLP22 and MLP23, retaining the actual False write and its qualified linear response while removing only the finite-minus-first-order remainder materially changes both the native verdict residual and natural margin in32/32 cases at each site and jointly. The preregistered direction-specific action gate passes:30/32 for22,32/32 for23 and31/32 jointly, with every schema/order stratum above its required6/8. This is stronger than222's full-write ablation: the nonlinear parts themselves contribute under these interventions.

It remains a retrospective result on32 old, dependent synthetic contexts of one pinned Qwen checkpoint. It does not identify a particular nonlinear primitive, a learned feature/circuit, a complete account of208's prediction failure or a successful False-only counterfactual predictor. QuestionB remains open. The result now warrants a targeted primitive factorial; it does not warrant a global correction sweep.

## What was removed, and what was retained

At each selected site, s is the actual post-attention residual before MLP-input RMSNorm. Define M(s)=MLP(RMS(s)), anchor at the nativeFalse state sF and actual nativeFalse write wF, and use the qualified local derivative JF:

    A(s) = wF + JF(s−sF)
    R(s) = M(s)−A(s).

Only receiving rows after the Boolean source are edited. Removing R replaces the live finite write by A; source/prefix, attention, all other MLPs, residual additions and final normalization/readout stay native and finite. The22/23 factorial is FF native, LF removeR22, FL removeR23 and LL remove both. In LL, R23 is evaluated at its actual altered input following the22 intervention. It is not a cached native23 correction. False anchors and derivatives stay fixed.

Additional arms remove and reinsert both remainders, apply matched random edits at either/both sites, and apply both affine replacements on an ordinary False input. Proposed random edit norms match the actual removed-write edits in the corresponding removal arm. Joint random23 matches the realized LL reference norm despite its different incoming state; this is explicitly declared. Controls test specificity within this design, not independent statistical replication or readout-matched alternatives.

## The primary natural response changes

Primary measurements are the actual verdict-position residual deviation relative to the nativeTrue−False displacement, and the absolute change in the actual natural true-versus-false margin. Full receiving vectors are also saved. Material means relative verdict deviation>.05 and absolute margin change>.10nats. The action gate additionally requires both to exceed the paired matched random result in at least24/32 cases and6/8 per schema/order stratum. These are frozen action thresholds, not significance tests.

Median verdict relative deviation / absolute natural margin change:

- RemoveR22: **.23355 / .59114nats**; matched random22: .14407 / .15783.
- RemoveR23: **.25075 /1.05531nats**; matched random23: .14189 / .09216.
- Remove both: **.33115 /1.68394nats**; matched random both: .21511 / .22090.

All32 cases in all three removal arms cross both material thresholds. Both primary deviations exceed random in30/32,32/32 and31/32, respectively. None preserves the native response under the original joint matching bounds. All native and remove/reinsert controls preserve it32/32. The numerical result supports a causal role for these composite local remainders. It does not prove that they are the first origin, only origin, or indispensable components under every possible intervention.

Full receiving norms tell a different part of the story. Joint-removal median relative receiving deviation is .30828, versus .32539 for joint random edits. Thus the larger natural margin effects do not merely track a larger all-receiver norm. Norms and medians are not additive causal fractions.

![Qualified remainder factorial](../figures/223-native-mlp-remainder-factorial.png)

## A context-dependent sign that the neuron diagnostic misses

The following sign counts are explicitly **posthoc descriptions**, not newly preregistered hypotheses or fresh confirmation. The primary gates above were unchanged.

RemovingR22 raises the actual natural verdict margin in **16/16 generic** contexts, median **+.70107nats**, but lowers it in **16/16 descriptive** contexts, median **−.35641nats**. RemovingR23 lowers the margin in all32 contexts: generic median−.37792, descriptive−2.02819nats. Joint removal raises the generic margin16/16, median+.42275, and lowers the descriptive margin16/16, median−3.15982nats. These effects concern the tested prompt/schema conditions; lexical semantics, length and learned feature identity are not separately established here.

At the same time, removingR22 increases the frozen32-neuron product diagnostic in **all32** contexts. Generic median goes1.13648→1.40491nats; descriptive3.68115→4.62576. In descriptive contexts the local diagnostic therefore increases while the actual natural margin decreases. The product diagnostic is an informative conditional local quantity, not a complete mediator or monotonic proxy for the model's natural verdict preference. Earlier219/221 group interventions remain valid at their defined scope; this experiment prevents expanding them into a complete behavioral mechanism.

The finite margin factorial interaction has descriptive-schema median−.72712nats and generic+.04382. This contrast contains changed23 incoming states and the entire native downstream/readout response. It does not uniquely identify a22→23 interaction or two competing learned mechanisms.

## Why this differs from the earlier write clamp

222 replaced each selected receiving write by its paired False write, removing both linear and remainder contributions.223 retains the False write and linear response. Both interventions have causal effects, but their signs need not match. For example, removing the whole MLP22 write difference lowers the generic native margin, whereas removing only its remainder raises it. This is not a contradiction; they are different interventions on different components of the same computation.

![Remainder removal versus whole-write clamp](../figures/223-remainder-versus-write-clamp.png)

Posthoc native local remainder norms have medians11.44718 at22 and13.76342 at23, compared with tangent norms30.94635/34.48547. The maximum full receiving-vector discrepancy from public AD is6.16e−5/7.40e−5, many orders below the remainder norms. This supports treating the measured remainders as substantial finite departures, rather than simply the observed derivative precision mismatch. It does not recertify the old whole-block derivatives. Component norms are not causal percentages.

## Derivative qualification and arithmetic

Scientific sources, protocol and auditor were copied/hash-sealed before the first model call. Before any intervention model,32 ordinaryFalse computations qualified both local maps at native directions plus norm-matched sine/cosine directions: **192 local derivative directions**,192 independent CPU64 finite-difference comparisons and576 first-reverse contractions. An independent saved-array audit passed1,152 recorded controls and sealed qualification before StageI.

Every actual intervention-generated direction was then separately qualified, including changed23 inputs: **576 further derivative directions**,576 CPU64 finite-difference comparisons and1,728 reverse contractions. StageI passed **6,752 recorded controls**. Control and derivative counts overlap; they are not independent replications. Both phases used the unchanged1e−4 coordinate bound. Maximum discrepancy against direct public MPS AD is **1.33998e−5**, against promoted CPU64 central differences **4.98854e−6**. Independent NumPy64 finite-difference reconstruction agrees with the saved reference within1.96e−9. CPU64 finite differences promote arithmetic; they do not claim to replay the original MPS forward map.

Combined work: **352 ordinary models**,64 additional local reverse forwards/192 backwards,768 local public JVP directions,768 CPU64 finite-difference comparisons and2,304 reverse contractions. StageI secondary work:256 product derivative checks,512 explicit down projections,256 public last-block selected-product replays and1,056 finite heads. Maximum product derivative error2.68619e−6 and independent CPU64 head replay8.05228e−6, within their unchanged bounds. Native, False-sham and remove/reinsert endpoints/readouts replay exactly; source/prefix edits remain zero.

All256 new raw ideal-product comparisons pass1e−4, maximum8.41583e−5. Independently measured product-cast/down/addition rounding closes within7.10544e−14 at1e−9. This does not alter the raw failures in earlier experiments. The original whole-block Jacobian coordinate disagreement, original196 discrepancy, qualified204 scope and invalidity of replacement-agent conclusions remain preserved.

## What this justifies next

The influential-writer versus nonlinear-remainder distinction has now been tested. Both composite local remainders have material, direction-specific natural-response consequences in the declared setting. The narrower next target is to separate MLP-input normalization, SiLU curvature and gate–up multiplication inside these remainders, retaining native incoming states, direct signed write measurements and natural downstream endpoints. In particular, the primitive account should explain whyR22's natural margin effect changes sign with prompt condition whileR23's does not in these cases.

A native-tail null in a future primitive test would not prove global linearity: native tails can compensate edits, and missing remainders can interact elsewhere. A positive primitive attribution would still be retrospective. A prospective explanation requires a concrete False-only update, a specified computation budget and predictions sealed before fresh nativeTrue measurements. Merely evaluating the complete known counterfactual network is a reference computation, not the sought compact explanation.

The new closure preserves the2,561 prior files unchanged and adds code, protocol, pre-execution copies, qualification seal, actual logs, numeric audits, posthoc descriptions, images, viewer source and reproduction instructions. Numerical arrays remain local with sizes/hashes inventoried. A clean-copy hash/plan check is not a second executed model replication. No browser, training, publication, staging, commit or push.

Evidence: [primary audit and every case](223-native-mlp-remainder.json), [local qualification](223-local-mlp-qualification.json), [explicitly posthoc descriptions](223-posthoc-descriptions.json), [registered protocol](../experiments/223-native-mlp-remainder-necessity.md), [model code](../../scripts/run_native_mlp_remainder_223.py), [independent auditor](../../scripts/audit_native_mlp_remainder_223.py), and [reproduction instructions](../../results/native-mlp-remainder-223/README.md).
