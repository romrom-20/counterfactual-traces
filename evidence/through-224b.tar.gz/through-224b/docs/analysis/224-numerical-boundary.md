# Preserve failed224 and distinguish the actual-node graph in224b

224 stopped on the first context at MLP22's all-linear endpoint. Its final receiving-coordinate discrepancy from223 was **1.678466796875e−4**, exceeding the pre-execution **1e−4** bound. No partial factorial ran and the first case had not yet been archived. The original traceback, failed-run design/runtime, failure record and scientific sources are preserved. The failed comparison is not a successful derivative check or primitive attribution.

The separate224b endpoint phase covers all32 contexts and both sites before any partial factorial. It treats the composed actual-node graph as a different numerical intervention background. Native/False replays and local node/linear-projection equations retain their original coordinate bounds. A separate saved-array audit qualifies576 primitive directions: maximum direct-public-AD discrepancy **1.0854052e−6**, promoted CPU64 central-difference discrepancy **1.0880461e−6**, and independent NumPy FD reconstruction difference **2.6645353e−10**. These do not recertify the old whole-block Jacobian or resolve196's original discrepancy.

The composed/composite final-coordinate comparison fails1e−4 in **59/64** site/context cases, with maximum **2.8991699e−4**. Its largest relative verdict-displacement discrepancy is **7.0026672e−6**, and largest natural margin discrepancy **1.9073486e−5nats**. Both coordinate failures and small behavioral discrepancies are reported. The latter do not retrospectively change224's bound. The separately registered deletion gate in224b requires effects100 times the measured same-case discrepancy, in addition to material natural-response effects and matched random controls. This bounds a particular implementation contrast; it is not a bound on every possible numerical error.

## Exact local accounting

In exact compatible arithmetic, composing the three affine primitives and linear projections gives the composite derivative. Actual calculations retain Float32 intermediate casts and public linear modules;223 instead installs a CPU64 composite affine write after one final cast. Frozen False primals are the values of the recorded MPS computation. Their real-valued matrix products need not equal those recorded values exactly.

Let n be the qualified RMSNorm tangent at the supplied native displacement, a the False SiLU derivative, G/U/D the gate/up/down matrices, and subscript0 the recorded False anchor. The uncast composite reference is

    wComp = w0 + D [u0 * a * G n + phi0 * U n].

The all-linear actual-node write difference is the signed sum of: the gate-path deviation from g0+Gn; the up-path deviation from u0+Un; the installed SiLU affine cast; the installed product affine cast; the down-projection difference relative to the False anchor; and the old composite write's output cast. The endpoint audit calculates these from saved actual parents/outputs and closes their vector sum within **2.0765460e−14**, against1e−9. Median vector norms are approximately7.59e−5/7.43e−5 for gate/up paths,2.12e−6/2.12e−6 for SiLU/product casts,1.99e−4 for the down-anchor term and2.25e−6 for the composite cast. These norms do not add as signed effects or causal percentages.

This accounting identifies numerical differences between the two defined local calculations; it is not evidence of competing learned mechanisms. It does not make the final trajectories identical. Native-input suffix continuations remain oracle diagnostics, and general QuestionB remains open.

The RMSNorm affine intervention includes its full first-order radial/tangential response. It is **not** the earlier denominator-freezing intervention. A role for this primitive therefore means a role for finite departures from that local affine map, not merely a change in RMS scale or a learned normalization feature.

Evidence: [failed224 record](../../runs/mlp-primitive-factorial-224/failure.json), [224 frozen protocol](../experiments/224-mlp-primitive-factorial.md), [separate224b protocol](../experiments/224b-mlp-primitive-factorial.md), [endpoint audit](224b-endpoint-qualification.json), and [saved-array auditor](../../scripts/audit_mlp_primitive_factorial_224b.py).
