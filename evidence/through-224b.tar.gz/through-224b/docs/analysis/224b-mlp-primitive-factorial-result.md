# No partial primitive subset recovers the response; the product background reverses SiLU's effect at23

**The controlled test rules out the tested single-operation shortcut.** None of the six partial RMSNorm/SiLU/product subsets preserves both the native verdict residual and natural margin in any of the32 old contexts, at either selected MLP. At22, individually linearizing any one of the three operations passes the frozen material-effect and matched-control gate. At23, SiLU does; normalization and product have weaker, schema-dependent margin effects and fail the cross-stratum gate.

The sharper lead is explicitly **posthoc**: at23, making SiLU finite raises the natural margin when the gate–up product is affine, but lowers it when that product is finite. This reversal occurs in all32 contexts under both normalization settings:64/64 dependent context/normalization pairs. At22 the SiLU effect is positive in all four backgrounds, with0/64 analogous reversals. Actual gate/up inputs are identical across the S/P switches at a fixed normalization setting.

The known bilinear curvature-times-up-change term, plus measured arithmetic differences, accounts for the local write interaction. **It does not yet identify the cause of the final-margin sign reversal.** The product switch also changes the baseline seen by the finite downstream network. That is the next distinction to test. This is retrospective evidence, not a learned circuit, a fresh False-only predictor or a solution to QuestionB.

## What was tested

Use the same32 operation-excluded larch/marzipan contexts from223, crossing schema, field order, assignment and target. No new site or neuron selection. At one site at a time—MLP22 or23—supply its native full-sequence post-attention residual. Switch receiving rows after the Boolean source between finite F and False-affine L at three nodes, in order N/S/P:

    N_L(s) = z0 + Jnorm0(s−s0)
    S_L(g) = phi0 + siluPrime0(g−g0)
    P_L(phi,u) = p0 + u0*(phi−phi0) + phi0*(u−u0).

The subscript0 denotes recorded False anchors. Linear projections remain actual public MPS modules; affine node values are installed after their specified Float32 cast. Each later primitive receives the actual parents produced under earlier switches. Prefix/source outputs are protected. Every remaining public transformer block and final normalization/readout runs finitely on the intervened full sequence; no later native state is inserted.

RMSNorm L includes its complete first-order radial/tangential response. It is not the earlier denominator-freezing intervention. Normalization geometry and gate–up multiplication are known operations; finding that they matter here does not make their algebra novel.

All eight settings are retained. The six partial settings have write-norm-matched random restoration controls from LLL. Each single deletion has a separate random control from FFF. Orientations are deterministic, independent of target/readout direction and shared within the specified context/site/control family. These controls test the declared edits, not every possible direction or independent statistical replication.

## Frozen necessity and sufficiency results

Preserving the native response requires verdict relativeL2 deviation≤.05, cosine≥.99 and absolute natural margin change≤.10nats. Restoration must also beat its matched random on both errors. A whole gate requires≥24/32 and≥6/8 in every schema/order stratum. **Every partial setting has0/32 eligible cases at both sites**; no partial subset passes. Native FFF replays all32, as a control rather than a discovery.

Deletion requires verdict relative deviation>.05 and absolute margin change>.10nats, both larger than its matched random, and both exceeding100 times the measured same-case composed/composite implementation contrast. Combined counts are:

- MLP22: remove finite RMSNorm **32/32**, SiLU **30/32**, product **32/32**. All three whole gates pass, including every stratum. The SiLU generic strata each pass7/8.
- MLP23: remove finite RMSNorm **14/32**, SiLU **32/32**, product **17/32**. Only SiLU's whole gate passes. Normalization has0/16 combined generic cases; product has1/16. Their descriptive counts are14/16 and16/16, respectively.

These are conditional effects of the specified primitive replacements. Failure of a partial subset does not prove universal indispensability, and failure of a deletion's joint gate does not establish irrelevance.

The latter boundary is visible at23. In generic contexts, product deletion has median verdict-vector relative deviation **.10326**, but median absolute margin change only **.01053nats**. Normalization deletion has median relative deviation **.08408** and absolute margin change **.06402nats**. A weak margin effect can coexist with a substantial residual-vector change.

![Actual native response under all primitive settings](../figures/224b-primitive-factorial-response.png)

[Every gate and stratum](../figures/224b-primitive-factorial-gates.png) and the full per-case audit retain all failures. Norms and medians are not additive causal fractions.

## The more specific posthoc pattern

At23, hold normalization finite. Restoring finite SiLU from an affine SiLU:

- With product L, **raises** the margin in32/32 cases: generic median **+.26015nats**, descriptive **+.33210**.
- With product F, **lowers** it in32/32 cases: generic median **−.16645nats**, descriptive **−1.55669**.

Holding normalization affine yields the same sign switch in every context. At22, all four SiLU-restoration edges instead raise the margin in32/32 cases each. The local SiLU operation does not have a single downstream behavioral sign independent of its product background and layer.

This also cautions against interpreting223's composite remainder sign as the sign of one primitive. At22, product deletion raises the natural margin in all contexts, while normalization or SiLU deletion lowers it in all contexts. Removing the entire remainder is a different intervention with different interactions. The factorial reports actual signed vectors and all inclusion–exclusion terms; it does not allocate unique causal percentages to operations.

![Posthoc conditional SiLU reversal](../figures/224b-silu-product-sign-reversal.png)

These counts describe old, dependent templates. They are not a fresh prediction, a priority claim or evidence that earlier218/208 native-versus-forecast failures have been explained.

## What generates the local interaction, and what remains unresolved

The separate posthoc accounting checks all128 site/context/normalization cases, using only saved arrays. At fixed N, actual gate and up parents are exactly equal across the four S/P cells. Define C as the actual finite-minus-affine SiLU output and dU=u−u0. Ignoring arithmetic differences, the SiLU write increment is D(u0*C) with product L, and D(u*C) with product F. Their difference is

    K_ideal = D(C*dU).

The actual signed four-cell write contrast is saved, along with C, dU, its ideal product/write and separately measured product/cast/down-projection arithmetic terms. **5/128 raw ideal coordinate comparisons fail1e−4**, maximum **1.86077e−4**; those failures remain. The independently accounted signed rounding terms close the actual vector identity within **1.88708e−14**, against1e−9. This is an arithmetic explanation of the local interaction in the intervened graph, not a new mathematical law or a complete behavioral explanation.

For the final sign, let w be the affine-S/affine-P write, A the SiLU write increment with product L, B the product-induced baseline shift with SiLU L, and K the actual S/P write interaction. Let T include the actual residual addition, finite remaining blocks and finite margin readout. The observed SiLU effects are exactly

    E_L = T(w+A) − T(w)
    E_F = T(w+B+A+K) − T(w+B).

This isolates the unanswered question: does K change the sign of the transmitted SiLU increment, does B change the tail's response to A, or do both matter? Existing cells change both. Directly testing T(w+B+A) and T(w+A+K), with arithmetic and matched controls, would distinguish those explanations. **That further intervention has not been executed here.** Naming the bilinear term alone would overstate what is established.

The signed local/final component vectors, all12 primitive edges per case/site and seven inclusion–exclusion components are preserved. A [component figure](../figures/224b-signed-factorial-components.png) shows their signed projections and finite-margin effects. Final-margin interactions include the responding tail/readout; medians need not sum to the median total.

## Numerical qualification and the failed224 boundary

224 failed before any partial factorial: its composed LLL endpoint differed from223's composite-affine intervention by1.67847e−4 in a final coordinate, above the frozen1e−4 bound. Original sources, sealed copies, log and failure record are unchanged. The first raw case had not yet been archived. **224 is not relabeled as successful.**

224b was separately registered before its model calls. Its actual-node graph is its own intervention background; no endpoint-specific patch or numerical bridge is installed. Native/False endpoint replays, node equations and public linear-projection replays retain1e−4 bounds, and independent finite-head replay retains.005. The composed/composite discrepancy remains explicit: final coordinate comparisons fail59/64, maximum2.89917e−4, while maximum relative verdict discrepancy is7.00267e−6 and margin discrepancy1.90735e−5nats. The100× guard supplements the original material/control gates; it does not repair224 or bound every numerical error. See the [numerical boundary note](224-numerical-boundary.md).

Endpoint sources and artifacts were sealed before partial combinations. The separate saved-array audit passed4,416 endpoint checks and17,568 hybrid/control checks. There were576 endpoint and2,880 hybrid/control primitive-direction comparisons, including repeated directions. Maximum public first-AD discrepancy **1.22864e−6**, promoted CPU64 FD discrepancy **1.08805e−6**, and independent NumPy FD reconstruction discrepancy **2.66454e−10** all pass their frozen bounds. CPU64 FD promotes arithmetic; it does not replay the MPS forward map. Actual gate/up/down projections are checked separately, with maximum hybrid/control down error8.34655e−5. Paired signed down-projection accounting closes within2.27319e−14. Maximum independent finite-head discrepancy is9.44325e−6.

Work comprises **64 ordinary model evaluations,1,152 finite suffix continuations,6,336 remaining public-block evaluations and1,152 finite heads**, on pinned Qwen2.5-1.5B-Instruct/MPS Float32/eager. Suffix computations are not ordinary full-model calls. The later posthoc accounting makes zero additional model calls. The saved-array audit is a separate code path, not an independent research team or a second model replication.

## Implication for QuestionB

This test narrows the local explanation: the tested primitive subsets cannot recover the full native vector/margin response, and23 has a reproducible conditional SiLU sign reversal whose local vector interaction is accounted for. It does not explain how the upstream Boolean edit generates the required receiving state from False alone. It does not reconcile the old whole-block Jacobian disagreement or the original196 primitive discrepancy, identify a learned circuit, or establish a general account of208. Qualified204 and invalid replacement-agent conclusions retain their earlier status.

The next justified mechanism test separates B from K, before another end-to-end correction sweep. A prospective QuestionB claim still requires a concrete False-only update with a declared computation budget and sealed forecasts on fresh contexts. Evaluating the complete known counterfactual network is a reference, not the sought compact explanation. No browser, training, publication, staging, commit or push occurred.

Evidence: [primary audit and every case](224b-mlp-primitive-factorial.json), [endpoint qualification](224b-endpoint-qualification.json), [posthoc descriptions](224b-posthoc-descriptions.json), [posthoc signed-vector accounting](224b-silu-product-accounting.json), [frozen protocol](../experiments/224b-mlp-primitive-factorial.md), [actual-node helper](../../scripts/mlp_primitive_factorial_224.py), [runner](../../scripts/run_mlp_primitive_factorial_224b.py), [auditor](../../scripts/audit_mlp_primitive_factorial_224b.py), and [preservation/reproduction instructions](../../results/mlp-primitive-factorial-224b/README.md).
