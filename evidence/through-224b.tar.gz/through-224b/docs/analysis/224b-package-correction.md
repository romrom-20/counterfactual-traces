# Preservation check correction, with no experimental changes

The first packaging invocation redirected its own completion message to `.context/224b-packaging.log`. The file glob included that still-open log before the message was printed. The first zero-model preservation check therefore failed that file's hash; it did not invalidate or rerun a model computation.

The original manifest is retained as `.context/224b-initial-packaging-manifest.json`, its finalized output as `.context/224b-initial-packaging.log`, and the actual failed verification log as `.context/224b-package-verification-failed.log`. Packaging was not considered a validated evidence closure at that point. The rebuilt manifest includes those failed-attempt artifacts. Its new completion output is written outside the included224-prefix file glob, avoiding self-reference. Scientific protocols, helpers, runners, auditors, seals, arrays and numerical results are unchanged.

The subsequent canonical raw-array verification and clean-copy hash/plan checks are the preservation checks to consult. They do not constitute model replication. Their completion logs are outside the closure they verify.
