# 104–105: separate sentiment alphabet from absence representation

Frozen before inference, 7 October 2026 local time. Both 103 models completed and
passed integrity checks. Its composition account failed. On its 32 fresh cases,
Granite scored 31 numeric versus 24 semantic, Qwen 20 versus 24. Both semantic
formats missed all eight factual/no-opinion cases. That comparison confounded
sentiment alphabet, absence marker, and response-instruction wording.

## Fixed experiment sequence

104 is a factorial diagnostic: 16 new reviews (four aspect blocks, each with
negative, explicit-neutral, positive and factual/no-opinion cases). Eight arms:
six common-instruction arms plus exact 098/103 legacy numeric and semantic prompts
as bridges. Some blocks include an unrelated neutral opinion, fixed within block.
No causal effect of context is claimed from this block-level assignment.

105 is a confirmation frozen at the same time: 48 new reviews (eight new aspect
blocks × negative, neutral, positive, empty, fact and other-aspect-only opinion).
It uses the same six common-instruction arms, distinct targets and different
review templates. It runs regardless of 104 outcomes, with no selected arm,
threshold tuning, added examples or changed instructions. No confirmation data
are inferred before 104 is complete on that model. Both pinned models run both
stages regardless of scientific failures. Maximum 832 ordinary generations.

The six arms cross:

- Opinion values: semantic strings negative/neutral/positive or numeric 1/5/9.
- Insufficient-evidence value: JSON null, string "null", or string "insufficient".

All common arms have identical instruction scaffolding, JSON key, category
definitions, review and mapping-key order. Only the mapped values change. A JSON
mapping declares the values explicitly. This avoids confusing a parser's null
with an invalid answer. The strict parser rejects numeric strings, bools,
duplicate JSON keys, nonfinite numbers and unassigned values. A string "null"
is valid only in that arm. Invalid/truncated answers are errors, never abstentions.

## Predictions and frozen decision rules

The primary architecture is Granite, where 103 exposed the largest relevant
contrast. Qwen is an unconditional transfer test, not a gate for Granite analysis.
This model-specific hypothesis is specified before 104/105, not selected after
their results. All model/arm/state results remain reported.

Primary: the change in correct insufficient-evidence decisions for JSON null
minus string "insufficient", averaged equally over the two opinion alphabets.
Compute paired differences within aspect blocks; bootstrap blocks 5,000 times,
seed 10401. Intervals describe these few authored blocks, not population or
prompt-distribution uncertainty. Both studies must separately have a difference
>=25 points and a strictly positive lower bound. In 105 the three absence types
are equally weighted. Also require opinion accuracy >=90% under JSON null, no
more than five points lower than under "insufficient", and the absence gain
>=15 points in each opinion alphabet. A pass is an absence-representation effect
under this task, not a novel method or a universally competent classifier.

Secondary contrasts distinguish two accounts:

- JSON null versus string "null": a gain >=15 points with positive interval in
  both stages supports a serialization-type contribution within this protocol.
- String "null" versus string "insufficient": a gain >=15 points with positive
  interval in both stages supports a lexical-code contribution.

Neither contrast alone identifies an internal mechanism. If legacy semantic
failure disappears under the common template, report response-instruction
wording as an alternative to the broad "semantic versus numeric" story.

Practical repair is a separate, stricter endpoint: semantic+JSON-null must reach
>=90% total and >=75% in every state, and improve >=10 points over the stronger
of common numeric+JSON-null and semantic+"insufficient" in 105. Count the best
baseline before comparing, not the weaker convenient one. No best-arm selection.

105 includes absence types with and without the target name and lexical-neutral
paraphrases. A success confined to one state or one checkpoint remains bounded
accordingly. Synthetic labels are authored, not independently human-adjudicated;
natural-review generalization and research novelty require further evidence.

## Execution and integrity

Pinned Qwen2.5-1.5B and Granite-3.1-2B, public float32 deterministic generation,
repetition penalty 1.0, at most 80 generated tokens, offline cached weights.
Each query starts from a fresh chat and cache. Rotate arm execution order by a
fixed row-ID hash. Save messages, prompt/output token IDs, raw text, parsed value,
decoded category and token-limit status. Gold labels are used only for evaluation.
Freeze source dependencies, this protocol, all data and both stages before launch.
Hash every complete row and runtime; exclusive process locks; resumable atomic
writes; per-query heartbeat; caffeinate during detached execution. Technical
errors halt; scientific failures do not. Audit every complete stage by reparsing
raw outputs and verifying exact prompts, hashes and output coverage.

Run: `PYTHONPATH=src .venv/bin/python scripts/run_absence_alphabet_104.py --launch`.
Status and result files: `runs/absence-alphabet-104-105/`.
