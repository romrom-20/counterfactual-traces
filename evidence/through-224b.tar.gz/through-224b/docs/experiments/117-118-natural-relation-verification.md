# 117–118: question-conditioned support with an identical passage and candidate

Frozen before model inference. Motivation: 115/116 improved aggregate abstention
while deleting correct supported answers. Exact string grounding does not show
that the string answers the requested question. Test that distinction on natural
human annotations, with no fabricated blank-review controls.

## Data and selection

Official SQuAD 2.0 dev JSON, downloaded 2026-10-07 from
https://rajpurkar.github.io/SQuAD-explorer/dataset/dev-v2.0.json
SHA256 80a5225e94905956a6446d296ca1093975c4d3b3260f1d6c8f68bc2ab77182d8.
Eligible paragraphs have 150–1600 characters; questions at most 200 characters.
Match one answerable and one impossible question in the same paragraph with an
EXACT common string in answerable answers and impossible plausible_answers;
both original offsets must match. Candidate length 1–100 characters.
For every article, select the smallest SHA256 of `117:<positive ID>:<negative
ID>:<candidate>` among eligible tuples. Sort articles by SHA256 `117:<title>`;
take first 24, first 12 are 117, next 12 are 118. One pair per article;
48 questions, 24 articles/paragraphs; no overlap between stages. All gold answers
retained for scoring. No model-dependent inclusion. This is a selected matched
subset, not a representative benchmark, and not training-decontaminated.

## Inference and controls

Pinned Granite 2B and Qwen 1.5B revisions from 104; float32, public generate,
greedy, repetition_penalty=1, max80 new tokens, max2048 prompt tokens, no
truncation. Both stages and models unconditional. Fresh KV caches every call.

1. Direct: short exact passage span or JSON null when passage cannot answer.
2. Retrieval control: same prompt but top two sentences by question-term overlap
   (lowercase regex words minus fixed stopwords); tie original order, restore
   selected original order. No answer or gold in retrieval.
3. Span-only control: direct nonnull answer not literally in original context
   becomes null; invalid direct remains invalid. No extra model call.
4. Verified: same span check, then fresh-context boolean support verification of
   model-generated answer using original question and full paragraph. False
   means null; true retains answer; invalid verification stays invalid. Never
   substitutes annotated answer or repairs already-null/invalid answers.
5. Annotated-candidate diagnostic: same verification prompt on the identical
   human-annotated candidate for both paired questions. This uses gold proposals
   and is NOT a deployable pipeline or a practical accuracy score.

The verifier asks whether the paragraph establishes the candidate as an answer
to the exact question, including entities, relations, dates and qualifiers.
No model reasoning trace is requested. Strict typed JSON, no fences/trailing
text/duplicate fields/extra keys. Length-limited outputs invalid, never null.
Save exact messages, prompt/output IDs, runtime, hashes. Annotated candidate
never appears in direct/retrieval/generated-answer verification except when the
model independently generates that text. No cross-question chat history.

## Endpoints (fixed before inference)

Primary deployable utility per model must pass EACH stage:
- verified exact match >= 10/12 answerable and abstention >= 9/12 impossible;
- verified retains >=95% of direct exact-correct answerable outputs (empty
  denominator fails), and answerable accuracy loss <=5 percentage points;
- verified gains >=2/24 total exact matches over EACH direct, span-only and
  retrieval control. Invalids score zero, including impossible questions.

Mechanism diagnostic per model must pass EACH stage: annotated-candidate
verification >=10/12 correct in EACH support class and >=9/12 pairs where both
questions are correctly distinguished. Always accept/reject controls get12/24
individual and0/12 pair accuracy. This diagnostic cannot rescue practical failure.

Report normalized SQuAD exact match and token F1, separately by answerability;
all valid nonnull exact-correct answers lost, invalid counts, span-grounded
hallucinations, and retrieval gold-span retention as descriptive diagnostics.
Official normalizer lowercases, removes ASCII punctuation and articles, fixes
whitespace. Score all provided gold answers, null for impossible. No threshold
fitting. Article/paragraph pair is unit; no inference across all SQuAD examples.

Novelty boundary: SQuAD2, Read+Verify (2018/2019), Retro-Reader (2020/2021)
already address these problems. This run tests a bounded explanatory prediction
and a practical baseline, not a new general algorithm. No claim about beliefs.
