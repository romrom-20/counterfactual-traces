# 119–120: can comparative support judgments escape absolute-verdict collapse?

Freeze before inference. 117/118 found that Qwen mostly rejects both members of
same-candidate supported/unsupported pairs while Granite often accepts both.
Prediction: contrasting questions may make the relevant relation difference
accessible. Competing account: any improvement merely exploits a promise that
exactly one question is supported, or a position preference. Test both accounts.

## Natural data and independence

Official SQuAD2 train-v2.0.json (downloaded 2026-10-07), SHA256
68dcfbb971bd3e96d5b46c7177b16c1a4e7d4bdef19fb204502738552dede002,
https://rajpurkar.github.io/SQuAD-explorer/dataset/train-v2.0.json.
The train split is used as a fresh evaluation source here; NO weights are trained.
Possible checkpoint pretraining exposure is not excluded.

Within 150–1600-character paragraphs, find exact candidate strings of length
1–100 with at least two answerable questions and two impossible questions whose
plausible_answers contain that same string. Questions max200 characters; verify
all offsets. Pick two of each class by SHA256 `119:<question ID>`, require four
unique question strings. Candidate/paragraph tuple key is SHA256 of
`119:<positive ID 1>:<positive ID 2>:<negative ID 1>:<negative ID 2>:<candidate>`.
Take minimum tuple per article; sort articles by SHA256 `119:<title>` and take
first eight. First four form119, next four120. All32 questions retain original
human labels and text, no synthetic blank controls or duplicate-question pairs.
No model-dependent inclusion. These articles must not overlap117/118 articles.

Eight source blocks were inspected before freezing. Some benchmark wording is
awkward (notably Data_compression); no selected row was removed or substituted.
One candidate is supported by two distinct questions in each paragraph and is a
plausible distractor for two others. Human labels are not infallible. The analysis
unit is article/paragraph;32 mixed pairs are NOT32 independent articles.

## Three tasks

- Single: the exact117/118 VERIFY_RULE, one question and proposed answer.4/block.
- Joint: full paragraph, same candidate, two questions; independently output
  booleans first_supported and second_supported. Both/neither explicitly allowed.
  All six unordered combinations of four questions, in BOTH orders:12/block.
- Forced: only the four mixed-class combinations, in BOTH orders. The prompt
  promises exactly one is supported and asks which.8/block. This supplies an
  oracle support-count promise; it is diagnostic, not a deployable repair.

24calls/block/model =192/model,384 total. Two models, two stages unconditional.
Gold labels determine sampling, forced-arm eligibility and scoring only. Single
and joint prompts receive no gold label or support-count promise. All tasks use
fresh conversations/cache and hash-ordered execution within each block.

Greedy public generation on pinned Granite2/Qwen1.5, float32, repetition penalty1,
80new tokens,2048prompt budget, no truncation. Strict typed JSON. Invalid/limited
outputs fail; boolean/integer distinction and duplicate fields checked.
Source/data/runtime and all exact messages/token outputs saved with checksums.

## Primary endpoint (per checkpoint, BOTH stages required)

Use exact paired decisions correct in BOTH presentation orders:
- >=12/16 mixed pairs correctly distinguished by joint judgments;
- >=4/16 more than conjunction of the two corresponding single judgments;
- >=3/4 both-supported pairs and >=3/4 neither-supported pairs correct;
- >=15/16 mixed pairs have valid order-consistent decisions (even if wrong).

Order consistency remaps booleans back to question identity, not output position.
Mixed pair denominator16/stage shares only4articles; no independent-pair p-value.
Single judgments are reused for pair controls; do not count them as fresh calls.
Report all gates, both stages and all classes; forced success cannot rescue
joint failure. Forced both-order accuracy is secondary. Always first/second has
zero both-order mixed accuracy. Always both/neither has zero mixed accuracy.

If only forced improves, the evidence supports better discrimination with an
oracle promise, not reliable absolute verification. If joint improves only on
mixed pairs but fails both/neither, do not claim calibrated support recognition.
If neither improves, close this comparison hypothesis; do not search prompt
variants until one passes. No claim of a successful practical pipeline follows
from any arm because candidates and contrast questions come from gold annotations.

Prior art includes LLM Comparative Assessment (2307.07889), Pairwise or Pointwise
(2504.14716), and self-correction limitations (2310.01798). Pairwise evaluation
itself is not new. A possible narrow contribution is the controlled failure-mode
diagnosis across identical candidates, natural contrasting questions, support
counts and order checks. Any novelty claim needs stronger independent evidence.
