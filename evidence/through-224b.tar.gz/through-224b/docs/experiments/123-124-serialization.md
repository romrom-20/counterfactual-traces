# 123–124: Do support judgments follow actual serialization order?

Locally frozen before inference. This follows a failed manipulation in121–122:
listing the two keys in the opposite order never changed emitted order. That
result does not identify the source of the repeated false/true pattern.

## Design

Pinned Granite3.1-2B and Qwen2.5-1.5B, float32 MPS, greedy public API, fresh
conversation/cache per query, repetition penalty1.0, max80 generated tokens,
max2048 prompt tokens with no truncation. Identical messages in all three arms.
No oracle exactly-one promise; both and neither remain admissible.

- Free: ordinary generation, exact119 joint prompt.
- Forward: finite token grammar admits exactly the four canonical JSON strings
  with first_supported serialized before second_supported.
- Reverse: same four semantic states, second_supported serialized first.

Canonical spacing is Python json.dumps default. The grammar includes EOS. No
semantic state is removed. Constrained arms also have all four complete-string
log probabilities measured with the public forward API, including EOS. Report
raw complete-string MAP and locally grammar-normalized MAP separately from
greedy generation. These probabilities concern four particular strings; they
are not calibrated probabilities of truth. Raw-MAP changes can reflect string
likelihood factors including later punctuation/field names, not only judgments.

123 uses the first four119 articles, already observed.124 uses four new article
blocks from the same public training split, excluding all eight119–120 articles.
Fresh selection repeats the eligibility rule using SHA256 seed124 for question,
within-article tuple and article ranking. No model-dependent selection. Selection
and labels are frozen jointly;124 runs regardless of123 results. These are fresh
experimental stimuli, not guaranteed absent from model training.

Each article supplies two supported and two unsupported questions sharing the
same answer candidate. Use the first supported/first unsupported mixed pair,
the two supported questions, and the two unsupported questions. Present every
pair in both orders: six queries/article. The selected mixed pair is fixed by
the question hash, not chosen for large previous effects. Four articles/stage,
eight total,48 contexts/model ×3arms =144 generations/model,288 overall.
192 constrained contexts also receive four-candidate scoring. Shared questions
and paragraphs are not independent samples.

## Predictions and decision rule

For each model and stage separately, the strong serial-pattern account earns
support only if (1) actual requested key order is achieved for every constrained
output, (2) false-then-true in emitted order occurs in at least75% of forward
and reverse contexts, (3) reversing serialization swaps the two semantic
judgments (and changes them) in at least75% of contexts. Thresholds use all24
contexts/stage, including both/neither. Confirmation requires all criteria in
both123 and124 for that model. No pooling to rescue a failed model/stage.

Report semantic-change and exact-swap counts, first/second-question acceptance,
actual emitted vectors, accuracy by gold class, article-level effects, and
question-order consistency. Compare free→forward to expose effects of imposing
the canonical grammar itself. Free outputs on123 are token-replay controls
against119; all24/model must match. No free replay exists for new124 stimuli.

Complete-string MAP and locally normalized MAP are prespecified diagnostics:
do order effects remain when not selecting one token greedily? Report their
semantic flips/swaps without relabeling them as the primary test. A strong
greedy effect with no raw-MAP effect suggests a decoding-specific contribution;
a raw-MAP effect does not isolate an internal belief or a unique mechanism.
Changing serialization also changes conditional token prefixes. This design
identifies a causal effect of the serialization intervention under this grammar,
not pure abstract slot identity independent of the emitted field names.

## Integrity and bounds

Record exact messages, input/output token IDs, grammar strings/token IDs,
all scores, runtime and source hashes. Require reconstructed greedy from
teacher-forced public logits to match actual constrained public generation
on every constrained query. For the first mixed presentation of the first
article in each stage, each order gets an independent full-logits reference
for all four strings:32 reference scores overall, tolerance0.003 log units.
Verify normalization and selected-sequence agreement. Separate saved-artifact
auditor rederives source selection, parsing and metrics. Preserve every result,
including failed hypotheses. No optional stopping or publication during the run.
