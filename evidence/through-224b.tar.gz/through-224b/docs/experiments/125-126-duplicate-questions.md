# 125–126: Can a joint verifier contradict itself on identical questions?

Prospective local freeze, motivated by119–122 and partial Granite123 outputs.
The follow-up was designed while123/124 was still running: early reverse-order
outputs retained the semantic first=false/second=true pattern. It is not an
independent explanation selected without looking at those exploratory results.
No125/126 inference precedes this freeze.126 executes regardless of125 outcome.

## Hypothesis and setup

If the model imposes a distinction between two support slots without needing
actual question differences, it will assign different booleans to two verbatim
copies of the same question, passage, and candidate answer. This endpoint does
not require trusting answerability annotations: equal propositions must receive
equal truth values. It measures inconsistency within one response, not hidden
beliefs, intent, calibration, or proof of a unique internal mechanism.

Use the exact119 joint instructions, including explicit permission for both and
neither. User first_question and second_question are byte-identical. A matched
singleton uses117's unchanged verifier prompt. Independent fresh chats, no
conversation history. Pinned Granite2/Qwen1.5, float32 MPS, greedy public generate,
penalty1.0, max80 generated/max2048 input tokens, no truncation or constraints.

125 uses first four119 articles and the first supported/first unsupported
question selected in that frozen design.126 selects four new articles from the
same SQuAD train release, excluding all119–120 and124 articles. Eligibility:
150–1600-char context, questions≤200 chars, common exact candidate1–100chars
with verified offsets and at least one supported and one unsupported question.
Pick each class question by SHA256126:qid, then minimum tuple by hash
126:positiveid:negativeid:candidate, then articles by hash126:title. No outcome
selection. There are2 questions/article ×8 articles ×2arms ×2models =64calls.

## Endpoints

Primary: valid duplicate objects with unequal booleans / all8 duplicate queries
per model/stage. Invalid responses count as failures, not contradictions. The
strong pattern is supported only if at least6/8 contradict, with at least3/4
in each annotated class, on both125 and126 for a model. These thresholds describe
prevalence, not a significance test. No article pooling rescues a failed stage.

Report both counts and every output vector; first/second-slot agreement with
the matched singleton; singleton annotated accuracy; consistency and paired
correctness on the duplicates; per-article counts; invalid/truncated responses.
Singleton125 queries should replay the corresponding119 token IDs exactly
(8/model), checked independently. No repair claim is made by a contradiction.

The article is the source block. Two class questions in an article share a
passage/candidate. Four new articles are not a population estimate and may have
been in pretraining. Save all cases and source/runtime/output hashes, reconstruct
selection and metrics with separate audit code, and retain failed thresholds.
No further adaptive prompt search is part of this experiment.
