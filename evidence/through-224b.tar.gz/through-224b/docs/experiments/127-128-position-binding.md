# 127–128: separate input position, output position and field names

Frozen locally before inference. Motivated by the model-specific serialization
split in123/124; no new mechanism is assumed. Two observed articles (first two119
blocks) plus four fresh128 articles, both stages run unconditionally.

## Factorial intervention

For each original query, retain two named question identities. Independently
cross input question-field serialization (forward/reverse), output verdict-field
serialization (forward/reverse), and naming book:

- ordinal: first_question / second_question → first_supported / second_supported;
- neutral: cedar_question / maple_question → cedar_supported / maple_supported.

“Neutral” denotes nonordinal wording, not a guarantee of zero token associations.
The shared joint rule allows both/neither and judges exact support relations.
Append an explicit binding sentence matching each input key to its output key,
and state that names define identity regardless of order. Without this sentence,
“first” could ambiguously refer to physical position after input reordering.
The same rule is used for both input and both output orders within a book.
The book change renames input and output fields and their binding instruction;
it is not an isolated output-token perturbation.

Use a finite four-state grammar, default json.dumps spacing, EOS included.
All four semantic states remain legal in every condition. Parse by named
identity, not physical input or output order. These are greedy generations;
no new complete-string MAP claim is made in this experiment.

Six queries/article: first supported/first unsupported mixed pair, the two
supported questions, the two unsupported questions, each in both identity
assignments. The input serialization manipulation is separate from assignment
of question text to named keys. Each article thus contributes48 factorial
queries/model. Six articles ×48 ×2models =576 factorial generations.

For the two observed articles, repeat the old123 ordinal prompts under both
output grammars, with no new binding sentence:24 controls/model,48 overall.
These must reproduce saved123 output token IDs exactly. Compare factorial
ordinal/input-forward outputs with these anchors to quantify effects of the
new binding instruction. Total624 generations. No prompt tuning after outputs.

## Source and runtime

SQuAD2 train SHA25668dcfbb971bd3e96d5b46c7177b16c1a4e7d4bdef19fb204502738552dede002.
Fresh selection uses123 eligibility (150–1600-char context, questions≤200chars,
exact candidate1–100chars, ≥2 supported and ≥2 unsupported questions), with seed
128 for question, tuple and article hashes. Exclude all119–120,124 and126
articles. Select4 new articles, with no outcome-dependent exclusion. Public
data may have appeared in model training. Shared article conditions are not
independent samples; stage127 has only2 source blocks,128 has4.

Pinned Granite2 and Qwen1.5 revisions from123; float32 MPS, public generate,
greedy, repetition penalty1.0, fresh chats/cache, max80 output and2048 prompt
tokens, no truncation. Save source/runtime hashes, prompts, IDs, grammars,
semantic outputs and per-article records. Independent analysis rederives source
selection and all metrics. Old frozen files remain unchanged.

## Prespecified signatures and bounds

Evaluate EACH model ×book ×stage separately. For matched queries, reversing
input order and reversing output order provide separate paired comparisons.
Report exact semantic swaps (must change both verdicts), any semantic changes,
semantic invariance, acceptance of each named identity, each input slot and each
output slot; correctness by gold class; and every input×output cell.

Three strong behavioral signatures are specified before inference:

1. Output-slot pattern: emitted false→true in ≥75% of queries in EACH of the
   four input×output cells; output reversal swaps semantic verdicts in ≥75% of
   matched comparisons; input reversal preserves semantic verdicts in ≥75%.
2. Input-position pattern: physical second input accepted and physical first
   rejected jointly in ≥75% of queries in EACH cell; input reversal swaps
   semantic verdicts in ≥75%; output reversal preserves them in ≥75%.
3. Named-second pattern: first named identity false, second named identity true
   in ≥75% of queries in EACH cell; both input and output reversal preserve
   semantic verdicts in ≥75% of matched comparisons.

These are descriptive prevalence thresholds, not hypothesis-test p-values or
proof of a unique internal mechanism. Report all three, including unclassified
cells. A signature is locally replicated only if the same signature passes in
both127 and128 for that model/book; no pooling rescues a failed stage.

Main target: adjudicate Granite's ordinal input-position versus named-second
accounts. Qwen output-slot behavior is a transfer prediction. The neutral book
is a prespecified wording stress test; a changed signature narrows the previous
claim to its field vocabulary/binding context. It does not by itself identify a
specific token or internal circuit. If no signature passes, stop at the recorded
failure rather than search for another wording variant in this run.

The binding sentence may itself disrupt the old effect. Anchor comparisons
must accompany interpretation. No claim of better verification follows merely
from moving a bias; report supported and unsupported correctness separately.
