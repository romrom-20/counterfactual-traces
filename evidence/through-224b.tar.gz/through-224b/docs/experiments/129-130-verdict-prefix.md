# 129–130: does one written verdict change the next?

Locally frozen before inference. Qwen's output-slot pattern survived 123–124
and ordinal names in 127–128, but nonordinal transfer failed the full criteria.
Granite's clean named-second account failed fresh validation. This experiment
tests a new prediction about dependence on the preceding generated verdict,
not another wording repair or a claim of an internal circuit.

## Intervention and competing predictions

Reuse exactly the ordinal, input-forward prompt and binding instruction from
127. Cross forward/reverse output order with three grammar conditions:

- baseline: all four Boolean pairs are legal;
- first written Boolean forced false: either value remains legal for the second;
- first written Boolean forced true: either value remains legal for the second.

Force the first *emitted* identity, not always the first named question.
No passage, question, input token or system instruction changes across arms.
Clamp only through the finite output grammar. JSON spacing and EOS inclusion
remain the same. Baseline uses the original four-state grammar; each clamp
has exactly two states, sharing the same forced prefix until the free second
Boolean. Audit that the two remaining token sequences have one divergent token
and a common suffix for each tokenizer, so the only free choice is the second
Boolean. If that tokenizer premise fails, stop rather than reinterpret a
multi-token branch as an isolated Boolean decision.

For every query and output order, report the pair (second verdict after forced
false, second verdict after forced true). Its four possibilities distinguish:
contrast (true,false), constant acceptance (true,true), copying (false,true),
and constant rejection (false,false). These are operational response patterns,
not mutually exclusive model-wide mechanisms.

Primary Qwen question: does the second-slot acceptance account survive forcing
the first verdict true, or does the second verdict systematically reverse?
Granite is a prespecified cross-model comparison, not a required pooled success.

Three strong signatures, evaluated separately by model and stage:

1. Contrast: paired response (true,false) in at least 75% of queries in EACH
   output order.
2. Constant second-slot acceptance: paired response (true,true) in at least
   75% of queries in EACH output order.
3. Evidence-aligned invariance: the second judgment equals its annotated gold
   under BOTH clamps in at least 75% of queries in EACH output order AND each
   supported/unsupported stratum. Constant answers cannot pass this signature.

A signature replicates only if all its criteria pass in both observed stage
129 and fresh stage 130 for that model. Report every cell, including failures,
without pooling or threshold relaxation. The other two paired response types
are descriptive even if prevalent. No additional wording or naming book will
be searched in this run.

Also record changes relative to baseline, second-verdict accuracy under each
clamp and gold status, named identity and physical output slot. A forced wrong
first verdict makes whole-pair accuracy an inappropriate repair endpoint.
These are descriptive prevalence thresholds over correlated conditions, not
p-values. Existing annotation errors remain possible. Prefix sensitivity and
the first two signatures require no gold labels.

## Source, sample and controls

Stage 129: first two frozen 119 articles (Comics, Paper), with six presentations
each: mixed, both supported and neither supported, each reversed in named
question assignment. Stage 130: four fresh SQuAD2 train articles selected by
the 127 eligibility algorithm with seed 130, excluding every article used in
119–120, 124, 126 and 128. Context 150–1600 characters, question <=200, exact
candidate span 1–100; two supported and two unsupported questions sharing the
candidate, all four question strings distinct. Select before outcomes and
retain source defects with a separate note. Source SHA256 is
68dcfbb971bd3e96d5b46c7177b16c1a4e7d4bdef19fb204502738552dede002.

Six articles × six presentations × two output orders × three arms × two models
= 432 generations. The 48 observed baseline controls must exactly reproduce
127 ordinal/input-forward saved token IDs. Within every three-arm comparison,
the clamp matching the baseline's first Boolean must exactly reproduce the
entire baseline token sequence. This checks that removing an unchosen first
branch does not otherwise change decoding. Other-clamp effects may then be
attributed to the forced output prefix within this setup.

Pinned Granite 3.1 2B and Qwen2.5 1.5B revisions, float32 MPS, public generate,
fresh conversations/cache, greedy policy with repetition penalty 1.0, max 80
output tokens and 2048 input tokens without truncation. Runtime hashes must
match 127. Save exact prompts, token IDs, candidate strings/sequences, outputs,
source hashes and per-query data. Freeze runner and protocol in the manifest.
Independent audit code reconstructs selection, grammar, parsing, controls and
all endpoints without importing this runner.

No complete-string likelihood or hidden-state mechanism claim is made. Forcing
an earlier verdict may put the model on an unlikely prefix; measure this as a
controlled generation intervention, not as its spontaneous reasoning. Fresh
articles are unseen in this investigation, not necessarily in model training.
Do not claim novelty merely from autoregressive dependence.
