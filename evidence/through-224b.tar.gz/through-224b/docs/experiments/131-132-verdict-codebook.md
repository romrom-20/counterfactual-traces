# 131–132: literal Boolean contrast versus contrast between support judgments

Freeze locally before inference. Motivated by129/130's opposite-second response,
which does not distinguish literal value alternation from decoded semantic
contrast. Prior103 found failed code lookup, so mapping competence is a required
interpretation control. This is a new mechanism discrimination test, not a
verification repair or a claim that label remapping is new.

## Factorial intervention

Keep first_question/second_question input identities and forward input/output
field order. The output keys are first_verdict and second_verdict throughout
the main experiment. Explicitly define true/false for each key:

- Book00: true=supported for both fields.
- Book10: true=unsupported for first; true=supported for second.
- Book01: true=supported for first; true=unsupported for second.
- Book11: true=unsupported for both fields.

False means the opposite status in every mapping. Change only these mapping
sentences between main books; all questions, evidence, key names and surrounding
instructions remain identical. Retain the original exact-support rubric and
explicit allowance for both/neither. Neutral verdict keys avoid calling a
true value 'supported' when the mapping defines it as unsupported.

For every book/query, force the first emitted Boolean false or true through the
grammar, leaving the second free. All corresponding support states are legal.
Every clamped grammar has two canonical strings differing at one free token;
check this for both tokenizers and abort if it fails. Within each book, input
tokens are identical across clamps. Decode a Boolean by XOR with that field's
inversion bit. Grammar and candidate raw strings are identical across books.

Two incompatible operational predictions:

1. Literal contrast: the second RAW Boolean is the opposite of the first RAW
   Boolean under both clamps, irrespective of book. Paired response TF when
   written as (second after forced false, second after forced true).
2. Semantic contrast: the second DECODED support judgment is the opposite of
   the first DECODED support judgment under both clamps. This predicts raw TF
   in books00/11 and raw FT in books10/01. Both book inversions cancel; one
   inversion changes the predicted raw response direction.

Report the four raw response types TF,TT,FT,FF in every model/book/stage,
decoded support pairs, second acceptance and correctness by gold support class,
and per-article outcomes. Thresholds are fixed descriptive proportions, not
p-values over independent trials.

## Competence and bridge controls

An encoding-only task supplies the two support statuses directly, requiring
no passage interpretation. Cross all four given status pairs with all four
books:16 unconstrained-first, four-state-grammar outputs per model. Interpret
a mapping as demonstrated only if all4 pairs encode both fields correctly.
All16 must pass to interpret a whole four-book signature. Passing this simple
control does not prove the model follows the mapping in the main task.

For both observed articles, replay129's forward-output false/true clamped
prompts with original first_supported/second_supported keys. All48 controls
across models must exactly reproduce129 token IDs. Compare these with new
book00 outputs to report the effect of the new keys and mapping instructions.
The book00 contrast signature itself must pass before extending the old
phenomenon to the new scaffold.

## Prespecified decisions

For each model, calculate raw literal-contrast and decoded semantic-contrast
prevalence separately for EVERY book in EVERY stage. Each strong four-book
signature requires at least75% in all4 books in both stages. No pooling rescues
a failed book or stage. Interpretation also requires all16 encoding controls
correct and book00 contrast >=75% in each stage. Report raw signature flags
separately from competence-qualified interpretation flags.

Thus a code-following model that changes from raw contrast to raw copying only
in the single-inversion books supports the semantic-contrast prediction under
this scaffold. A code-following model retaining raw contrast in every book
supports literal-value dependence under this scaffold. Neither identifies a
neural circuit or a general implicit exactly-one belief. If lookup fails or
neither full pattern passes, the discrimination remains unresolved; report it
without tuning another mapping, threshold or prompt in this run.

Both models and both stages run unconditionally. Do not interpret any changed
error pattern as improved evidence recognition. No repair endpoint is claimed.

## Sample, runtime and record

Stage131 uses the first2 articles in frozen130 selection: Mary_(mother_of_Jesus)
and Circadian_rhythm. This choice is ordinal in the old manifest, not selected
for effect strength. Stage132 uses four new articles from SQuAD2 train, seed132
with the130 eligibility/ranking algorithm, excluding119/120,124,126,128,130.
Dataset SHA25668dcfbb971bd3e96d5b46c7177b16c1a4e7d4bdef19fb204502738552dede002.
Each article supplies the same six presentations: mixed/both/neither, each in
both named assignments. Four books × two clamps × six presentations × six
articles × two models =576 main generations;48 replay controls and32 encoding
controls bring the total to656. No output-order factor is added here; previous
129/130 tested both orders, and this claim is bounded to forward serialization.

Pinned Granite3.1 2B and Qwen2.5 1.5B, public generate, float32 MPS, greedy,
explicit repetition penalty1.0, fresh conversations/cache,80 output and2048
input token limits with no truncation. Runtime hashes match129. Save all
source/protocol hashes, exact prompts/token IDs, grammar strings, generated
tokens, raw and decoded values. Separate audit code reconstructs source
selection and every endpoint without importing this runner. Four public fresh
article blocks are not independent observations for every repeated condition,
nor guaranteed unseen during pretraining. No new full-string MAP claim.
