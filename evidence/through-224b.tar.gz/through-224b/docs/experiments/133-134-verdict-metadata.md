# 133–134: a preceding judgment versus an unrelated metadata bit

Freeze runner and this protocol before inference.131/132 failed mapping competence, so do not repeat inversions or infer a lexical cause. Test whether second-verdict contrast extends to a preceding Boolean explicitly unrelated to evidence. This is behavioral scope discrimination, not a neural-circuit identification or general agent benchmark.

## Conditions

Use the119 exact-support rubric, including both/neither permission. Keep input question identities, passage and proposed answer fixed in two paired-output conditions. Both use first_value then second_value with normal true=supported interpretation for second_value.

- Judgment: first_value judges first_question, true=supported.
- Metadata: first_value is an arbitrary metadata bit with neither value carrying meaning about either question or the passage. Do not judge first_question. Either bit is explicitly permitted.

Only the first-field role sentence changes across these two conditions. Output grammar, second-field definition and all input content are identical. In each force first_value false or true while second_value remains free. Every grammar has two canonical output strings differing at exactly one free token; abort on token mismatch. Across clamps, input token IDs must be identical, and corresponding output paths must differ only at the forced first Boolean.

Isolated control removes first_question and first_value and asks only second_value. It measures correctness and agreement with each paired condition. It changes task distribution, so improvements cannot alone identify the mechanism.

On both observed articles replay131's normal00 first_verdict/second_verdict clamps exactly. Require24 replay token sequences per model identical to131. New judgment-role output contrast must independently meet the criterion; anchors cannot rescue failed scaffold transfer.

Direct-status controls give second_question support false or true, crossing both first-field roles and both clamps:8 per model. Grade only second_value; all4 second outputs per role must equal given status. These establish simple copying competence and whether contrast already appears without passage interpretation. In judgment controls the first status is explicitly false, and forced true may be inconsistent; in metadata both first values are legal. This distinction is intentional and both roles remain reported.

## Frozen decisions

Paired response TF means second true after forced false, second false after forced true. TT/FF mean constant output; FT means copying. Report all counts and correctness by gold second support, every model/role/stage/article. No pooling rescues failed stages or gold strata.

For each model:

1. Judgment-transfer criterion: TF>=75% separately in133 and134.
2. Metadata-contrast signature: judgment transfer plus metadata TF>=75% separately in both stages, and all4 direct metadata controls correct. This supports dependence beyond a first support judgment under this scaffold. It does not imply all Boolean outputs behave this way.
3. Judgment-specific signature: judgment transfer, all4 direct controls correct in EACH role, and metadata second_value correct under BOTH clamps for>=75% of supported cases and>=75% of unsupported cases separately in EACH stage. This is deliberately stricter than mere disappearance of contrast.
4. Otherwise neither explanatory signature passes. Report unqualified raw effects and all failed prerequisites. No changed threshold, prompt tuning or selected-model rescue.

Report isolated accuracy separately in both gold strata, paired correctness under both clamps, and comparisons to isolated per query. No repair criterion is preregistered, no neural mechanism or full-string MAP claim. A first judgment clamp can be incorrect or unlikely; the metadata bit has no prescribed correct value.

## Sample and execution

Stage133 takes first2 articles from frozen132 selection in manifest order, not by effect strength:Electric_motor and Jews. Stage134 takes4 new SQuAD2 train articles using seed134 and the132 eligibility/ranking algorithm, excluding the119/120,124,126,128,130,132 selection chain. Prelaunch source review additionally excludes Sahara: the selected positive question asks for the third hottest desert, while the passage supports third largest and largest hot. Take the next ranked eligible article without inspecting model outcomes. Source hash68dcfbb971bd3e96d5b46c7177b16c1a4e7d4bdef19fb204502738552dede002. Read all selected sources before launch; retain wording and document ambiguity.

Six presentations per article (mixed,both,neither in both named assignments). Six articles×6 queries×5 main outputs×2 models=360;48 anchor outputs and16 direct controls total424. Both stages and models run unconditionally.

Pinned Granite3.1 2B and Qwen2.5 1.5B; runtime hashes match119/131. Public generate, greedy,float32 MPS,penalty1.0,fresh conversation/cache,80 output/2048 input tokens,no truncation. Save every prompt/token, grammar, generated token, prediction, source/runtime/fingerprint hash. Separate audit must reconstruct without importing this runner. Public related questions are dependent and not guaranteed unseen in pretraining. Four fresh article blocks do not establish general prevalence.
