# 135–136: does an arbitrary metadata bit gate evidence sensitivity?

Freeze runner and protocol before inference. This hypothesis is post-hoc relative to Granite's completed133/134 run: metadata false accepted36/36 second answers; metadata true got21/24 fresh cases right.133/134's original strong signatures failed for Granite. These new criteria must not retroactively rescue those failures. Design drafted while Qwen133/134 was still running and finalized after its completion:Qwen passed133/134's metadata-contrast signature, with21/24 fresh metadata comparisons contrasting. Both models run unconditionally here.

## Actual evidence intervention

Primary task has exactly one question. Four synthetic blocks contain two explicit relational facts. Swapping the two values changes whether the fixed candidate answers the fixed question. Candidate text occurs in BOTH contexts; all names/values remain present. This removes absence-of-span and external-knowledge explanations. Two independently written question forms per block ask the same relation. No ignored first_question or two-judgment framing remains.

Blocks owner/location form stage135; opening_day/material form stage136. Their literal contexts/questions and assignments are frozen in the runner. This is transfer across relation/template families, not natural-data replication or general task prevalence. All source sentences must be inspected before launch. Unsupported means the fixed answer is assigned to the other subject, not that the passage lacks the answer token.

Two output schemas:generic first_value/second_value and descriptive record_flag/supported. The first bit is explicitly arbitrary metadata; either value is legal and neither means anything about support. The second bit alone judges the question, with normal true=supported coding. In each schema force the metadata false or true, leaving verdict free. Within each evidence context/query/schema, input tokens are identical across clamps and output paths differ only at the first Boolean. Each clamped grammar has one free token; abort if tokenizer checks fail.

Singleton controls remove the metadata output, retain only that schema's verdict key and use identical evidence content. Direct-status controls give the support label explicitly, crossing both statuses/schemas/clamps:8/model. All4 direct outputs per schema must be correct. Passing simple encoding does not guarantee main-task evidence use.

Replay133/134 metadata prompts for all6 queries×2 clamps on Electric_motor and Jews:24/model. All must match saved output tokens exactly. These are execution bridges, not a claim that the new single-question scaffold reproduces the earlier task's prevalence. Different framing and evidence simplicity are explicit changes. Synthetic effects qualify only within the new task.

## Prespecified signatures

For every model/schema/stage independently, report:

- Acceptance and correctness under each flag, separately in supported/unsupported contexts.
- Paired evidence responses (verdict in supported context, verdict in unsupported context), under each flag and singleton.
- Paired flag responses (verdict after false, verdict after true), in each support class.
- Every block/question outcome and all controls.

Eight matched evidence pairs/schema across both stages:4/stage. Thresholds are descriptive75% per required stratum, not p-values. No pooling rescues a failed schema/stage/status.

False-flag gating prediction: second verdict accepts in BOTH evidence contexts under metadata false in>=75% of pairs; under metadata true it is correct in BOTH contexts in>=75% of pairs. This must hold separately in both schemas and stages. Interpretation additionally requires every direct-status control correct and singleton correct in BOTH contexts>=75% of pairs in both schemas/stages. Passing establishes metadata-conditioned sensitivity to the relational swap in this task, not a neural gate or a practical repair. Report the analogous reverse-flag pattern separately as an alternative fixed prediction; do not rename a failure as success for the original directional hypothesis.

Universal contrast prediction: second verdict opposes the metadata bit in>=75% of queries in EACH support class/schema/stage. This differs from false-flag gating: universal contrast rejects even supported evidence under a true metadata bit. Require all direct-status controls correct for a competence-qualified contrast claim.

Evidence-invariant prediction: verdict correct under BOTH metadata values in>=75% of queries in EACH support class/schema/stage, with all direct controls correct. No new accuracy-gain or repair signature. Singleton and earlier natural-data correctness remain separate endpoints.

If no full signature passes, retain all failures and distinguish annotation-free synthetic findings from natural-task observations. There is no selected-model rescue or prompt/threshold tuning in this run.

## Runtime and record

Four blocks×2 questions×2 contexts×2 schemas×3 outputs(clampfalse,clamptrue,singleton)=96/model. Add8 direct controls and24 replays=128/model,256 total. Stage135 and136 and both pinned models run regardless of earlier outcomes.

Pinned Granite3.1 2B and Qwen2.5 1.5B, public generate,float32 MPS,greedy,penalty1.0,fresh conversation/cache,80 output/2048 input tokens,no truncation. Runtime hashes match119/133. Hash synthetic literals, this protocol, runner and dependency chain. Save every prompt/token, grammar, generated token, raw output, prediction and hash. Independent audit must reconstruct without importing this runner and must compute evidence-pair endpoints from saved outputs. No full-string MAP or neural intervention is run. No claim of novelty priority or behavior of full agent workflows.
