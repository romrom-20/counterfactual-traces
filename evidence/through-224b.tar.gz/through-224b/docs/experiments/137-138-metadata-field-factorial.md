# 137–138: which output field name controls copying?

Freeze before inference.135/136 failed all full frozen signatures. A post-hoc Qwen pattern nevertheless warrants a new test: generic keys accepted every case under both metadata values; descriptive record_flag/supported copied the metadata bit in16/16 query-context presentations. Direct-status controls passed. This test must not turn that observation into a preregistered135 finding.

## Independent name factors

Retain135's exact one-question support rubric and arbitrary-metadata instruction. Cross first key first_value/record_flag with second key second_value/supported:

- vv:first_value/second_value.
- rs:record_flag/supported.
- vs:first_value/supported.
- rv:record_flag/second_value.

Only these names and their corresponding references in the identical instruction template change. Input passage/question/candidate are identical across schemas; no other wording changes. Metadata values are both legal and explicitly have no meaning about evidence or correctness. Normal true=supported coding throughout. Force metadata false/true with identical input tokens within every schema/query/context. The support Boolean is free; grammar pairs must differ at one free token, corresponding paths across clamps at only the first Boolean. Both models/stages unconditional.

Stage137 uses135's first two synthetic blocks(owner/location), in manifest order. Replay the diagonal vv/rs conditions exactly against135 generic/descriptive prompts, token IDs and outputs:32/model. These records serve simultaneously as main factorial cells and replay controls; no double-counted additional generations.

Stage138 uses two new synthetic blocks(code/capacity), each two explicit subject/value facts, two question forms and two swapped contexts. Candidate and every passage word remain present. Read all literal sources before launch. Different relation/templates are confirmation of this task's behavioral endpoint, not natural-data prevalence or proof of grounding ability.

Each of4 blocks×2 question forms×2 contexts×4 schemas×2 clamps=128 outputs/model. Direct-status controls cross4 schemas×2 supplied statuses×2 clamps=16/model. Total144/model,288 outputs. Singleton competence previously failed and is not reused as a necessary guard for an output-copying claim. All evidence correctness counts still reported; no evidence-recognition or repair claim.

## Frozen predictions

Paired FLAG response is (support verdict after metadata false, support verdict after metadata true):FT copies;TT always accepts;TF contrasts;FF always rejects. Report all four types separately in EACH model/schema/stage/actual support class, plus per-block counts and correctness. First-field metadata has no correct value, so either clamp is legitimate.

Every whole pattern requires>=75% of its predicted response in EACH actual support class in EACH schema in BOTH stages; no pooled rescue. Additionally require all16 direct-status controls correct and the observed diagonal vv accepting/rs copying criterion passing in stage137. Exact diagonal replay must pass for execution validity. Passing simple direct controls does not prove the main-task instruction is internally interpreted as intended.

1. First-name account:rv/rs copyFT;vv/vs acceptTT. Copying tracks record_flag irrespective of the verdict name.
2. Second-name account:vs/rs copyFT;vv/rv acceptTT. Copying tracks supported irrespective of the metadata name.
3. Conjunction account:rs copiesFT;vv/vs/rv acceptTT. Both descriptive names together are required under this instruction template.

These distinguish three concrete explanations for the observed diagonal difference. They are not exhaustive possible circuits or semantic accounts. If hybrids yield a different response, none passes. Record generic copying/contrast effects without renaming them as success for one of these accounts. Granite has no selected explanation from135; it runs the same factorial and criteria and may fail the diagonal bridge. No model selection rescues that failure.

No threshold/prompt tuning, complete-string MAP, neural intervention or verification recommendation. Name changes also change token identities and instruction references; a passed account locates the behavioral dependency within those bundled name changes, not a human-level meaning or unique learned circuit. Field-identifier prior art precludes a broad novelty claim.

## Runtime and provenance

Pinned models, public generate,float32 MPS,greedy,penalty1.0,fresh chats/cache,80 output/2048 input tokens,no truncation. Runtime hashes match119/135. Save literal synthetic sources, exact prompts/tokens/grammar/predictions, all source/runtime/design hashes. Separate audit must reconstruct the factorial and fresh sources without importing runner137, verify every diagonal replay and compute all criteria from saved outputs.
