# 141–142: does the schema change baseline preference or flag coupling?

Freeze before inspecting new token scores.137/138 completed and failed all three full frozen accounts. Qwen nonetheless copied in32/32 record_flag comparisons, always accepted16/16 under first_value/second_value, and mixed copying9/16 with acceptance7/16 under first_value/supported. These are behavioral observations; no unique cause was established.

Discrete outputs hide margin changes. An unchanged true verdict can still become much more likely after the earlier bit changes. The next measurement tests whether names merely shift a baseline preference under a shared flag effect, or also change the strength of flag dependence.

## Readout

Replay every137 output and direct control through the identical public greedy generate configuration, now asking for generation scores. At the sole free Boolean step, record the finite scores for the two legal false/true tokens. Check only those two tokens are finite. Their difference L=score(true)-score(false) is log odds conditional on those two legal tokens at that prefix, in nats; it is not full-string likelihood, MAP, unrestricted truth probability or calibrated confidence. Penalty1.0; grammar masking leaves those two legal values unchanged. Save both scores, IDs, full prompts/paths, divergence index and selected token. Every replay must match137 exactly. No manual model-head readout or omitted model logits scaling.

Within each schema/query/context define Delta=L(after metadata true)-L(after metadata false). Compare the four Deltas. An additive descriptive account L(x,s,b)=A(x,s)+C(x,b) implies Delta does not depend on schema. Test practical equivalence using max_s abs(Delta_s-Delta_vv)<=0.25 nats for each query/context.0.25 is a frozen tolerance corresponding to approximately1.28× odds, not a numerical-error tolerance or established cognitive boundary.

Stage141 contains all four observed137/138 relations, all144 outputs/model including16 direct controls. Stage142 has two new explicitly constructed relations, price/destination, each two question forms and two swapped contexts, all four schemas and both clamps:64/model. Total208/model,416 outputs. Both models/stages run unconditionally. No singleton repeat; its failed grounding controls remain failed.

## Frozen endpoints

Report every L and Delta by model/schema/support class/stage/block. Keep correctness, greedy responses, direct controls and replay validity separate.

- Schema-independent coupling is compatible within the selected tolerance only if at least75% of query/context groups satisfy practical equivalence in EACH actual support class in BOTH stages.
- Schema-dependent coupling passes the selected descriptive criterion only if at least75% exceed that same tolerance in EACH actual support class in BOTH stages.
- A separately frozen hidden positive-coupling signature requires Delta>0.25 in>=75% of groups in EACH schema/support class in BOTH stages. This can coexist with schema dependence. It does not mean every Boolean output visibly copies.

Whole descriptive signatures require all16 directly supplied-status outputs correct, all144 exact replay outputs/model, and valid single-free-token score capture. Otherwise report the measurements with failed prerequisites. Intermediate cases pass neither coupling account. No pooled rescue; all margins and per-block failures remain visible. These small dependent templates do not justify population p-values or a claim of exact mathematical equality.

Also report the first-name contrast0.5*(Delta_rs+Delta_rv-Delta_vs-Delta_vv), second-name contrast0.5*(Delta_rs+Delta_vs-Delta_rv-Delta_vv), and interaction Delta_rs-Delta_rv-Delta_vs+Delta_vv descriptively, without selecting a new significance threshold.

## Fresh literal inspection and scope

Price candidate:five coins. Round ticket costs five in supported context and nine in unsupported; square ticket has the other price. Destination candidate:Mira. Silver parcel is addressed to Mira in supported context and Oren in unsupported; bronze parcel has the other destination. Two question forms per subject unambiguously ask price or addressee. All passage words and candidate text remain present under swaps. Read these literals and forms before launch; no postlaunch changes. These template families are not independent natural samples.

Same pinned checkpoints/runtime,float32MPS,80 output/2048 input tokens,fresh chats/cache,greedy,penalty1.0. Archive source/design/runtime hashes. Separate audit reconstructs new literals/prompts/paths, score-selection identities, strict parsing, replay matches and all frozen criteria without importing runner141. No neural intervention or verification repair. A margin decomposition is a behavioral explanation, not a circuit identification or novel general agent mechanism.

## Technical restart

139/140 stopped before saving its first record because Python candidate tuples were compared directly to saved JSON candidate lists. The failure artifact is preserved; its frozen code/protocol remain unchanged.141/142 normalizes freshly constructed candidate pairs to lists before comparison. No prompt, token path, score readout, model, source, criterion or endpoint changes. The corrected comparison is tested against saved137 records before launch. Source hashing includes the frozen failed139 implementation and its upstream chain. No139 token margins were inspected.
