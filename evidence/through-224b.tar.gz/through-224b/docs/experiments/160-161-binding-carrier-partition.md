# 160–161: where does the bit-conditioned relationship response travel?

Freeze before inference. This test follows the counterbalanced result in 155–159: Qwen's balanced relationship contrast B is near zero after false metadata and positive after true metadata. Score-order reversals also exclude a common scalar recalibration. Neither result establishes where the effect is computed or stored. No literature search, web access, Ego Browser access, or browser operation is part of this experiment.

## Competing predictions

At the middle post-block residual, the metadata-token state might carry the change in B with little contribution from later output states. Alternatively, the later output states might carry it, with metadata-token replacement insufficient. The two partitions could also be redundant, complementary, or context dependent. The bit caused the original change in all cases; this experiment tests its route after this layer. No learned feature, circuit, or logical gate is assumed.

Stage 160 reuses all four 155 blocks: amber, coral, azure, elm. Stage 161 fixes four unseen day blocks: jade/ruby Thursday/Tuesday; chalk/slate Monday/Friday; navy/pearl Tuesday/Thursday; beech/fir Friday/Sunday. These are dependent templates from one known relation family. Candidate is always the second listed day. Both question targets, both assignments, both sentence orders, both schemas, and both clamps remain fully crossed. Candidate coverage is narrower than 155. There is no score-based fixture selection or replacement after results. Both models and both stages run unconditionally.

## Intervention and execution controls

Use exactly 155's metadata-first messages, grammar, and sole free public Boolean margin L. Each false/true pair has an identical prompt and equal free-prefix length; the input IDs differ at one metadata Boolean. Capture the full float32 post-block states hF and hT at the middle block: Qwen 14/28, Granite 20/40. Every position before the metadata token must be bitwise identical. Also capture the final-block metadata-token row for the fixed negative controls. Save full states, token paths, prompts, scores, layers, shapes, hashes, and runtime. States occupy roughly 1 GiB overall; no existing runs are deleted.

The donor is the opposite-bit run of the same source, question, and schema. For each recipient bit, patch four arms:

- Identity: recipient rows from metadata through the last prefix position.
- Token: donor metadata-token row only.
- Suffix: all donor rows strictly after metadata through the last prefix position.
- Both: donor metadata and suffix rows together.

Every other position stays bitwise unchanged. Each hook fires exactly once and is removed in finally cleanup. Use the public model with `use_cache=False`, `logits_to_keep=1`, float32 MPS, eval, pinned offline checkpoints, and eager attention. No training, manual head, cache, truncation, or actual completion generation. Measurements are intervened public scores.

Because pre-bit states are identical, the both patch reconstructs the entire donor middle residual. All its scores must reproduce the donor exactly. Identity scores must reproduce the recipient exactly. These are architectural replay controls, not discoveries. All 128 stage-160 baseline scores per model must replay 155 exactly, including prompts and token IDs. Stage 161 has no old replay. Parent 155's generation and numerical controls are prerequisites, not new generations or newly repeated controls.

Fixed last-block negative control: amber and jade, assignment 0, target 0, sentence order 0, both schemas and both bits (8/model). Replace only the final-block metadata-token row. No later attention remains and the final norm/head are positionwise, so verdict scores must remain exactly native. Failure disqualifies accounts; it does not trigger a changed design.

Counts per model: 256 baseline forwards, 1,024 middle patches, and 8 final-block negative patches. Overall: 512 baselines + 2,064 patches = 2,576 physical public forwards; no cache copies or generations. Save 128 paired records/model, each containing both baselines and eight middle patches, plus the fixed negative controls.

## Frozen estimands and gates

For each block/schema/sentence order/recipient bit, compute B over all four question-target × assignment cells as in 155: mean supported margin minus mean unsupported margin. Let R be native recipient B, D native opposite-bit B, T token-patched B, S suffix-patched B, and A both-patched B. This behavioral interaction does not establish verifier competence.

All execution controls must pass. Carrier accounts additionally require `abs(D-R) > 0.20` nats in at least 75% of panels in **every** stage/schema/sentence-order stratum (four blocks each). This is twice the 0.10 account tolerance, so native and donor compatibility regions cannot overlap. Small-gap groups remain reported. Selected eligible cases cannot rescue failed qualification.

Each whole account must fit at least 75% of panels in **every** stage/schema/sentence-order/recipient-bit stratum (four panels each):

1. Metadata only: `abs(T-D) <= .10` and `abs(S-R) <= .10`.
2. Suffix only: `abs(S-D) <= .10` and `abs(T-R) <= .10`.
3. Both single parts sufficient: `abs(T-D) <= .10` and `abs(S-D) <= .10`.
4. Additive partition response: `abs(A-T-S+R) <= .10`.

Coverage, effect qualification, and controls are mandatory. No pooled mean or favorable schema, model, or arm rescues failure. Report raw compatibility separately from qualification, all B values, token/suffix errors relative to both endpoints, and interaction `I_B = A-T-S+R`. These are practical approximation tests of defined hybrid residual interventions, not semantic composition or identified neural features. Failure of all accounts could reflect downstream context dependence. Passing one does not establish an exclusive carrier, learned circuit, lost knowledge, or disabled competent verification. Earlier grounding and specificity failures remain.

## Separate verification

The artifact auditor imports no 160 runner. Reconstruct all fixtures, messages, grammar, truth, position balance, token paths, hashes, full state NPZ files, causal-prefix identities, patch spans, traces, score arithmetic, B panels, and subgroup gates.

Numerical rerun fixed before inference: jade, candidate Tuesday, sentence order 0, generic schema, all four question-target × assignment cells and both bits. Recapture eight baseline states/model; rerun token, suffix, and both patches (24/model); rerun the two jade assignment-0/target-0 generic final-block negatives. Total 34/model, 68 overall. Replace rows by independent concatenation, rather than the runner's slice assignment. Score tolerance .005 nats and state maximum absolute error 1e-5; report exact matches where present. This is a selected separate-code check, not all-score replication or an independent research team.

Launched runner, protocol, and source ancestors are immutable. Preserve all failures. Hypotheses follow causal ordering and the residual partition, rather than a paper's explanation. No novelty priority claim.
