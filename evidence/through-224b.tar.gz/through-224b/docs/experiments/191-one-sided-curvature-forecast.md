# Can curvature from one native state generate the missing preference response?

Registered after186 failed prospective first-order refinements and189 showed normalization-dependent response, before ANY191 native or forecast call. User asks about endogenous displacement generation, not a retrospective correction signal or a novel propagation method. C in187–190 is a paired finite-difference diagnostic, not a separately generated learned feature. Test a stronger source-generation account using ONLYfalse native receiver activation inputs/outputs and the known SiLU function.

Four new-to-this-continuation blocks: cypress/larch Monday/Friday; quartz/agate Tuesday/Sunday; meridian/zenith Thursday/Saturday; tundra/taiga Wednesday/Monday. Same dependent day relation, two schemas, two orders, both assignments and targets=64pairs/16four-cell panels. BOTH native states have NOTbeen measured for these prompts. Parent190 must qualify first, but no191 maps use its true states or verdicts.

Measure nativeFalsexF/yF at all28 receiver SiLU sites. False-anchored live-input polynomial maps, with z=x-xF:

T1=yF+d1*z; Q2=T1+d2*z²/2; C3=Q2+d3*z³/6.

For s=sigmoid(xF),q=s*(1-s),t=1-2*s:
d1=s*(1+xF*(1-s)); d2=q*(2+xF*t); d3=q*(3*t+xF*(t²-2*q)).

Coefficients are analytic and fixed from nativeFalse, not fitted; no forecast refinement, true activation calibration, target-score selection or endpoint correction. All inputs, attention/norms and up branches remain live. This is a change to pointwise curvature only. Allthree maps must preserve false scores/full residuals/activation trajectories EXACTLY. Receiver rows strictly after the irrelevant bit, all28layers. Prefix/metadata rows must remain native after measuring true. Reconstructed prompt pairs have identical lengths and differ exactlyone token.

Save and hash ALL64nativeFalse+384mapped forecasts/identities (448forward calls) BEFORE ANY64nativeTrue measurement. Strict global forecast-manifest/UTC ordering, source/runtime/fingerprints/NPZ hashes and physical512 count. All forecast logits count as executions; no oracle arms/cached score copies. Allthree maps are declared in advance. Finite-score failure is a technical/model-approximation failure to preserve, not grounds to add clipping after execution.

Primary individual true-endpoint matching <=0.10nats in ALLfourcells/panel; >=3of4sources EVERYschema/order. Secondary counterbalanced evidenceB_true matching same rule/tolerance. Because nativeFalse is anchored exactly, these also equal bit-effect error accounts; do not count them as independent successes. Descriptive half-retention accounts require native|deltaM|>=0.5nats (or|deltaB|>=0.20), same sign and >=half magnitude in allcells/panel; no retention rescue for matching. AllT1/Q2/C3 failures and strata reported. Native and corrected scores include every endpoint, no favorable output/schema selection.

Independent artifact reconstruction of all28coefficients, actual polynomial formulas/trace spans, all192exactFalseidentities, nativePhi/publicmargin arithmetic, true-timing/manifest and complete512 executions. Separate numerical64=selectedcypress/order0/BOTHschemas/ALLfourcells*(2fresholdnatives+6mappedcalls), independent float64 derivatives and concatenation hooks, public logits/full residuals. Scores0.005/full state1e-4/capture1e-5 stay fixed. Main512 plus64 numerical=576full-model forwards. No browser/literature/network/agents/posting. Executed code/protocol/numerical dependencies immutable.

A success would show that false-state local curvature can generate the observed response under this approximation; it would not identify a unique semantic circuit or training cause. A failure would reject this one-state Taylor account, rather than justify reconstructingC from true states and calling that prediction. Grounding/specificity failures, one checkpoint and dependent prompts remain. No novelty priority claim.
