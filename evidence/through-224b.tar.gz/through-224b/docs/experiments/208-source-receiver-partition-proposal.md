# Proposed next discriminating experiment — not executed or registered

This is a specification for a future prediction test, not a result or a claim of a novel mechanism. No208code, new forecasts or nativeTrue evaluations exist.204is an oracle diagnosis;205accounts for measured reset vectors;206does not certify a replacementMPSderivative implementation. Publication remains on hold.

## Question

Is finite nonlinear generation at the Boolean source sufficient when receiving-position state changes are transmitted linearly, or are nonlinear responses to receiving-state changes and their interaction with the source edit necessary for accurate prediction?

The original201repair fixes the source only in blockone. That does not test ongoing source encoding. A ranked finite-block search does not separate source-state and receiver-state roles. This partition tests a structural hypothesis rather than increasing the number of selected finite blocks.

Let S select ONLY the Boolean source row of the full-sequence displacement. Keep the verified zero displacement before that row. At everyblock define the candidate update using only the nativeFalse state, current predicted displacement, known edit and weights:

    delta_next = F(hFalse + S delta) - F(hFalse) + JFalse (I-S) delta.

No observedTrue activation is inserted. Initialdelta is the known Boolean embedding difference. The finite term changes only the source INPUT row, but its OUTPUT includes all positions; it includes the downstream effect of changing that source within this block. The second term transmits incoming RECEIVER state changes linearly. It omits nonlinear receiver-state response and source/receiver interactions. This is not merely clamping the predicted source OUTPUT to a nativeTrue row.

Because causal attention prevents later receiving positions from influencing the source, the source trajectory should be exact by induction in real arithmetic: earlier prefix states are unchanged, and the finite source computation receives its own correct previous source state. This is an architectural control, not discovery of a learned feature. Whole-sequence numerical source replay must still pass the original bounds.

## Bounded prospective test

Freeze code, block roles, prompt set and all success criteria before any newTrue evaluation. Use new contexts absent from201/204, with every paired prompt retaining the single-token Boolean edit and matched causal mask/RoPE. Keep at least the original source_linear baseline and the source/receiver-partition candidate; retain a full-finite known-edit computation as a trivial upper control. Globally seal allFalse-only forecasts before any new nativeTrue call. No fitted amplitudes, coefficient searches or discoveryTrue residual insertion.

Keep individual margin error<=0.10nats, verdict displacement relativeL2<=0.05/cosine>=0.99/norm>=0.001 and the original all-four-cell panel/whole-stratum criteria. Keep the zero-displacement baseline. Registered partial progress must halve BOTH residual and absolute margin error versus source_linear; a lower pooled median alone is not success. Preserve all contexts/arms and schema/order/source stratification. Local matching of the source is a control, not end-to-end success.

Numerical qualification must cover publicFalse anchors, finite source-only block reconstruction, receiver-only JVPs and final readout. Use both alternate whole-model hook construction and standardfirstreverse contractions for relevant forecast directions, at the original bounds. Keep196/203/204failures visible; do not require an unpassed check to have passed or silently recertify it. Any new operation-attribution claim needs its own qualified reconstruction. The direct MPS J(error) coordinate discrepancy remains a separate unresolved issue, even if this different predictor passes behavioral verification.

## Interpretive limits and cost

If the source is accurate throughout depth while native final predictions still fail, the source-only nonlinear/receiver-linear account is insufficient. That would motivate receiving-state curvature and its interaction with source changes; it would not identify RMSNorm, attention softmax or SiLU as the cause. If it succeeds, it supports this tested state partition, not a unique primitive operation or training-origin explanation.

The direct implementation evaluates one finite WHOLE block plus a receiver-direction JVP at everydepth, even though only one input row changes in the finite term. It may cost more than simply running the counterfactual network. Report that cost explicitly. This is a mechanistic surrogate test, not yet a compact efficient circuit. A later implementation could compute the source row from the unchangedFalse prefix and derive the one-key attention update; that is a separate validation task, not an achieved result.
