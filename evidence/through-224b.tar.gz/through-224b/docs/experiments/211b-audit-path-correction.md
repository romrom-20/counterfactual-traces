# Read-only audit path correction

Original211modelrun completed64/64 with controls passed. Its immutable auditor then stopped before reading any endpoint: parent binding used runs/two-block-factorial-209c/<key>.npz instead of runs/two-block-factorial-209c/pairs/<key>.npz. Preserve originalsource and .context/211-audit.log. Separately named211bauditor corrects ONLYthat parentpath and adds its ownsourceSHA to report. No model, input, intervention, derivative, array, count or threshold changes; no rerun of211model. Sources originallysealedin211design remain unchanged.
