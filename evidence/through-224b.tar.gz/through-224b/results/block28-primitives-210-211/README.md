# Block28 primitive diagnostic

Read [the full scientific result](../../docs/analysis/211-block28-primitive-result.md). All64qualified209ccontexts were tested under native and block27-linear incoming states, from the same native reset before27. Finite gate–up surgery-effect insertion improves finalverdict residual ANDmargin in64/64cases perbranch, but achieves0joint accuracy passes. MLP-inputRMS matters strongly to vectorerror; SiLU insertion improves vectors but worsens margin64/64. No208extension or publication.

Two scopes remain distinct:211defined FINITE interventions qualify; originalMPSwholeblockJacobian coordinate compatibility does NOT. Sol's210reports preserve8/128coordinatecompatibility failures;211cpreserves128/128reference/surgerycoordinate-equality failures. Localprimitivechecks and actualsurgicaldirectionchecks pass. Referencebudgetclosure does not certify originalderivatives or a unique learnedcircuit. All failedsource/log/report artifacts remain immutable. The read-only211auditor pathfailure is retained; separatelynamed211bcorrected only the parent`pairs/`path without rerunningmodelcode.

This manifest extends the unchanged1210-file208–209closure. New sources/protocols/reports/checks/source-snapshots/plots/viewer and recorded runmetadata/pairJSONs are hashed. `recorded-runs/` is historicalmetadata, not canonical assert-protected live runpaths. RawNPZvectors and weights are localonly; regenerate offline for numerical re-audit. Verify the package without weights or modelcalls:

```sh
PYTHONPATH=src:scripts .venv/bin/python scripts/reproduce_block28_primitives_210_211.py --verify-only
PYTHONPATH=src:scripts .venv/bin/python scripts/reproduce_block28_primitives_210_211.py --plan
```

The closure and commandplan were also checked in an isolated clean copy, zero modelcalls. That is not a second modelreproduction. Static scientific figure rendered/visuallyinspected; offlineCanvas compiled using cached esbuild, host/browser rendering not observed. [PNG](../../docs/figures/211-block28-primitives.png), [SVG](../../docs/figures/211-block28-primitives.svg), [viewer source](block28-primitive.canvas.tsx).

For a new numerical reproduction use a FRESH checkout, originaloffline`.venv`dependencies, cached pinnedQwen1.5Bweights and MPS. Canonical210/210b/210c/211run directories must be absent. Then run:

```sh
HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 OMP_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 PYTHONPATH=src:scripts .venv/bin/python scripts/reproduce_block28_primitives_210_211.py
```

If qualified209cpairs or204fullmask/RoPE arrays are absent, the wrapper regenerates the existing204prerequisites and209c ONLY. It does not execute208. Existingnewnumericreports move to a non-overwritingarchive. It runs210,210b,210c,211,correctedread-only211baudit,211ccrosschecks,plotandviewer. Scientific failures remain recorded failures even when programs complete normally. Newtimestamps/hashes/rounding may differ; every originalbound remains binding. No thresholds are relaxed and no stale success status is reused.

Main211actualcost:2240local finite interventionblocks,192manualprimitive traces,5248finitehead evaluations,128reference budgets/128reference-tangent replays.210qualificationcosts are separately recorded. These are retrospective known-weight diagnosticcomputations, not an efficient prospective circuit or a general solution toQuestionB.
