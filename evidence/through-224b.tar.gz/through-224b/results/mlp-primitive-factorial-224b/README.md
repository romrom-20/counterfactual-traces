# Native-input primitive factorial224b

This package extends the2,665-file223 closure and preserves the failed224 endpoint comparison. It tests receiving-row RMSNorm, SiLU and gate–up-product interventions at MLP22 and23, one site at a time, on32 old larch/marzipan contexts. The actual public downstream blocks and final readout remain finite.

The registered graph is N/S/P, each finite F or False-affine L. Later nodes receive the actual outputs under earlier switches. Every used primitive direction receives direct public first-AD and promoted CPU64 finite-difference checks. Complete native and False controls are audited and sealed before the six partial subsets and their matched random controls run. See the frozen protocols in `docs/experiments/224-mlp-primitive-factorial.md` and `docs/experiments/224b-mlp-primitive-factorial.md`.

224 failed its final-coordinate bridge to223's composite-affine intervention. It stopped before any partial factorial and before saving the first raw case. Its original code, sealed copies, traceback, design/runtime and explicit failure record remain preserved. 224b defines the composed actual-node graph as its own intervention background. It does not repair that bridge by changing a tolerance or patching an endpoint. Signed implementation contrasts are measured explicitly; deletion gates also require100 times the measured contrast. This is one comparison, not a comprehensive numerical-error bound.

## Read and inspect

The result report is `docs/analysis/224b-mlp-primitive-factorial-result.md`; numerical outputs are `224b-endpoint-qualification.json` and `224b-mlp-primitive-factorial.json` in that directory. All cases, failed gates, conditional edges and interactions are included. Separately labeled posthoc descriptions and SiLU/product signed-vector accounting use zero additional model calls. Five raw ideal-product/write comparisons fail their coordinate tolerance and remain recorded; the separate measured rounding ledger closes without changing those failures. Figures have224b prefixes under `docs/figures/`; the offline viewer source is `.context/mlp-primitive-factorial-224b.canvas.tsx`.

`recorded-runs/` preserves metadata and hash bindings. `local-raw-inventory.json` inventories128 local endpoint, hybrid, factorial-contrast and posthoc SiLU/product NPZ archives. The unchanged223 weights are reused by path/hash. Prior closures retain their original inventories. The large model and raw arrays are not embedded in this package, and they must be restored to execute a model replay.

## Verify or reproduce

Zero-model preservation and plan checks:

```sh
.venv/bin/python scripts/reproduce_mlp_primitive_factorial_224b.py --verify-only --plan
.venv/bin/python scripts/reproduce_mlp_primitive_factorial_224b.py --verify-only --verify-local-arrays
```

The second command also requires the canonical local224b arrays. Neither command reruns the model or constitutes independent replication.

For model execution use a fresh checkout with the original hash-bound223/222 inputs, unchanged weight archive, offline pinned Qwen2.5-1.5B-Instruct revision989aa7980e4cf806f80c7fef2b1adb7bc71aa306 and the recorded MPS Float32/eager environment. Run the reproduction script without flags. It executes endpoint runner → endpoint audit/seal → hybrid runner → hybrid audit → posthoc descriptions/accounting → plots, and refuses to overwrite the canonical run. The old failed224 record is restored as provenance, not silently counted as a fresh model replay.

224b comprises64 ordinary model evaluations and1,152 finite suffix continuations, including6,336 remaining-block evaluations and1,152 finite heads. Its3,456 primitive directions have AD/FD comparisons. Suffix computations are not ordinary full-model calls. Logs distinguish original qualification, hybrid computation and saved-array audits.

## Interpretation boundary

This is a retrospective oracle-input test of specified primitive interventions on one small checkpoint and dependent synthetic contexts. It is not a False-only prediction, a learned-feature/circuit identification, an independent-team replication or a general solution to QuestionB. Finite-margin interactions include the responding tail and readout; norms are not additive causal fractions. Failed old whole-block derivatives and the original primitive derivative disagreement are not recertified. Qualified204 and the invalid replacement-agent conclusions retain their earlier status. There is no browser use, training, publication or push in this work.
