# Native MLP22/23 nonlinear-remainder necessity

Read `docs/analysis/223-native-mlp-remainder-result.md` and the complete numeric report `docs/analysis/223-native-mlp-remainder.json`. Unlike222's full-write clamp,223 retains the actual False write and the qualified False-state linear response, removing only the finite-minus-first-order remainder. The22/23 factorial uses actual live incoming states and native finite tails. Actual natural verdict residual/margin are primary; the frozen32-neuron product effect is secondary.

These are32 old operation-excluded synthetic contexts and retrospective interventions, not fresh False-only predictions, learned-circuit identification or a complete QuestionB solution. A null effect under native tails does not establish global linearity. The original whole-block Jacobian and historical derivative disagreements remain unresolved.

The manifest extends all2,561 preserved222 files unchanged. It includes the pre-execution scientific source/protocol/auditor copies, the qualification audit and seal preceding intervention models, actual logs, numerical controls, recorded case metadata, reports, scientific figures and offline viewer source. Original numerical arrays and weights remain local with sizes/SHA256 hashes inventoried. Failed historical attempts and qualified204 scope remain preserved; invalid replacement-agent conclusions remain invalid.

Zero-model verification and execution plan:

```sh
PYTHONPATH=src:scripts .venv/bin/python scripts/reproduce_native_mlp_remainder_223.py --verify-only
PYTHONPATH=src:scripts .venv/bin/python scripts/reproduce_native_mlp_remainder_223.py --plan
```

For a numerical repeat use a fresh checkout with compatible Mac MPS dependencies, pinned offline Qwen2.5-1.5B-Instruct revision `989aa7980e4cf806f80c7fef2b1adb7bc71aa306`, original208 forecasts,222 ledger/intervention arrays and metadata,219 frozen mask and the inherited preservation files. The wrapper refuses to overwrite the canonical run. It archives generated numeric reports, qualifies the local derivatives, independently audits/seals qualification, executes interventions only after that pass, independently audits outcomes, and draws figures.

```sh
HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 OMP_NUM_THREADS=1 \
VECLIB_MAXIMUM_THREADS=1 PYTHONPATH=src:scripts \
.venv/bin/python scripts/reproduce_native_mlp_remainder_223.py
```

Clean-copy hash/plan checks are not second executed model replications. CPU64 finite differences promote arithmetic and do not replay the MPS forward map. No browser, training, publication, staging, commit or push.
