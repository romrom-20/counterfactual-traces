# Native attention, receiving carry/write and normalization

Read `docs/analysis/221-native-carry-mechanism-result.md`. The frozen neuron account transfers to native attention. Most parent response is carried into the final block; carry-only still fails the strict whole-test finite-effect bound. Normalization modulates the effect, and mirrored gate/up weights do not explain it. This is retrospective causal localization, not earlier-layer attribution, learned-feature identification or a complete counterfactual predictor.

The manifest extends all2,312 previous preserved files unchanged. It retains scientific sources/protocol/auditor copied before execution, the original221 auditor's Float32/Float64 accounting failure, the separately sealed221c cast-only correction with unchanged bounds, zero-model221b geometry diagnostics, actual logs, data reports, figures, viewer source and recorded metadata. New raw arrays/weights and historical input arrays remain local with sizes/hashes inventoried.

Verify or inspect the zero-model-call plan:

```sh
PYTHONPATH=src:scripts .venv/bin/python scripts/reproduce_native_receiver_221.py --verify-only
PYTHONPATH=src:scripts .venv/bin/python scripts/reproduce_native_receiver_221.py --plan
```

For a model repeat, use a fresh checkout with compatible Mac MPS dependencies, pinned offline Qwen2.5-1.5B-Instruct revision `989aa7980e4cf806f80c7fef2b1adb7bc71aa306`, and the original hash-bound raw208/215/218/219 parents and selection metadata. The wrapper refuses to overwrite the canonical run, archives numeric reports, executes221, uses the separately named corrected221c saved-array auditor, reruns both221b diagnostic phases and generates figures. It does not relabel the original failed auditor as a successful run.

```sh
HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 OMP_NUM_THREADS=1 \
VECLIB_MAXIMUM_THREADS=1 PYTHONPATH=src:scripts \
.venv/bin/python scripts/reproduce_native_receiver_221.py
```

The model execution and corrected saved-array audit completed in the working workspace. A clean-copy hash/plan check is not a second executed model replication. Original whole-Jacobian and raw ideal-vector failures remain recorded. No publication, staging, commit or push.
