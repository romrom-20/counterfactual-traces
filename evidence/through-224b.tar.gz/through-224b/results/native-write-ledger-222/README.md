# Native write ledger and finite upstream interventions

Read `docs/analysis/222-native-write-mechanism-result.md` and the case-level numeric audit `docs/analysis/222-native-write-ledger.json`. The ledger is descriptive. Causal claims are restricted to the executed finite write clamps/rescues and their registered action gate. These are operation-excluded old synthetic families, not fresh independent examples or a False-only forecast.

The manifest extends the complete 2,428-file221 closure unchanged. It preserves scientific sources, protocol and auditor copied before the first model execution; frozen operation selection before causal execution; actual logs; recorded per-case metadata; reports and scientific figures; and the offline viewer source. Original arrays/weights remain local, with file sizes and SHA256 hashes inventoried. Earlier raw ideal-vector failures, whole-block derivative disagreements and qualified204 scope remain preserved. Invalid replacement-agent conclusions are not restored.

Zero-model verification or the execution plan:

```sh
PYTHONPATH=src:scripts .venv/bin/python scripts/reproduce_native_write_222.py --verify-only
PYTHONPATH=src:scripts .venv/bin/python scripts/reproduce_native_write_222.py --plan
```

For a numerical model repeat, use a fresh checkout with compatible Mac MPS dependencies, pinned offline Qwen2.5-1.5B-Instruct revision `989aa7980e4cf806f80c7fef2b1adb7bc71aa306`, and the original hash-bound208 forecasts,221 pairs,219 selection and prior manifest files. The wrapper refuses to overwrite the canonical run, archives generated numeric reports, and runs the frozen model sequence, independent saved-array auditor and figures.

```sh
HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 OMP_NUM_THREADS=1 \
VECLIB_MAXIMUM_THREADS=1 PYTHONPATH=src:scripts \
.venv/bin/python scripts/reproduce_native_write_222.py
```

A clean-copy hash/plan verification is not a second model replication. No browser, training, publication, staging, commit or push. No learned circuit or complete QuestionB solution is established by an additive ledger or an oracle rescue.
