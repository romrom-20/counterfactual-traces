# Signed neuron products and direct causal edits

Read `docs/analysis/219-neuron-mixed-mechanism-result.md` and the qualified numeric audit. All 64 old contexts remain retrospective. Two old families select a fixed ranking; two are excluded from selection. This is an attention-affine, finite-SiLU/MLP-RMS surrogate, not learned-feature identification or fresh prediction. The 32- and 128-neuron groups pass the predefined compact-account action rule; the full absolute contrast has a long tail.

The manifest extends every prior 2,089 file unchanged. It preserves scientific sources/auditor/protocol copied before execution, frozen selection, reports, actual logs, figures, viewer source, and recorded run metadata. New raw captures/interventions/weights and historical input datasets remain local; inventories record their hashes. Original whole-block Jacobian and raw ideal-vector failures are retained. 219b is a separately identified posthoc saved-operand description, with no new model calls.

Zero-model-call verification:

```sh
PYTHONPATH=src:scripts .venv/bin/python scripts/reproduce_neuron_mixed_219.py --verify-only
PYTHONPATH=src:scripts .venv/bin/python scripts/reproduce_neuron_mixed_219.py --plan
```

To repeat the model work, use a fresh checkout with compatible Mac MPS dependencies, pinned offline Qwen2.5-1.5B-Instruct revision `989aa7980e4cf806f80c7fef2b1adb7bc71aa306`, and the original hash-bound raw 208/215/218 input dataset restored to its canonical locations. The wrapper does not silently regenerate or rebind historical inputs. It refuses to overwrite the original 219 run, archives the old numeric report, and executes capture/selection/interventions, independent audit and figures:

```sh
HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 OMP_NUM_THREADS=1 \
VECLIB_MAXIMUM_THREADS=1 PYTHONPATH=src:scripts \
.venv/bin/python scripts/reproduce_neuron_mixed_219.py
```

Generate the managed-workspace viewer separately with `scripts/build_neuron_mixed_canvas_219.py`. Recomputed timestamps/hashes and hardware may differ; retain original evidence. The working model run and saved-array audit have executed. Clean-copy hash/plan verification is not a second executed model replication.
