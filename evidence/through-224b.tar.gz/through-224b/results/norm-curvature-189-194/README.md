# Shared curvature, normalization, and single-state native-response forecasting

This bundle accompanies the [focused LessWrong draft](../../docs/drafts/lesswrong-shared-curvature-normalization.md). It records the current research milestone and its unresolved primary question: can a native counterfactual residual displacement and behavioral response be predicted from one false computation?

The draft and reports distinguish paired diagnostic reconstruction (189–190), false-calibrated SiLU with a live counterfactual receiver (191), and genuinely false-only native directional-derivative forecasting (192). Every frozen account, failed stratum, numerical qualification, and figure remains available. No priority or complete-mechanism claim is made.

## Included

- Original immutable experiment runners, protocols, auditors and numerical implementations, plus their explicit import/source-hash dependency closure.
- Audited scalar endpoints, per-context forecast errors, all qualification criteria and numerical check results in `docs/analysis/`.
- Standalone PNG/SVG scientific figures and local research draft.
- Run designs, pinned runtime metadata, and explicit historical prerequisites under `provenance/` and `prerequisites/`.
- Recorded package versions in `environment-lock.txt`, hardware/runtime information in `environment.json`, and a SHA256 manifest.

Raw multi-gigabyte activation arrays and model weights are not in Git. Fresh execution regenerates arrays under gitignored `runs/`. The published scalar audits summarize the original arrays and retain their provenance; without those arrays, a clean checkout verifies the bundle/source integrity, not every original coordinate. A fresh full rerun executes the coordinate-level auditors on regenerated arrays.

## Environment

The registered implementation uses Python 3.12, a Mac with MPS, float32, eager attention, evaluation mode and no generation caches. This is a pinned Qwen2.5-1.5B-Instruct experiment, not a CPU/CUDA portability claim. Create an environment from the recorded lock and install this package:

```sh
python3.12 -m venv .venv
.venv/bin/pip install -r results/norm-curvature-189-194/environment-lock.txt
.venv/bin/pip install --no-deps -e .
```

The runners are offline. The checkpoint must already be cached at revision `989aa7980e4cf806f80c7fef2b1adb7bc71aa306`. If necessary, the person reproducing the run can cache it separately before starting the offline pipeline:

```sh
.venv/bin/python -c 'from huggingface_hub import snapshot_download; snapshot_download("Qwen/Qwen2.5-1.5B-Instruct", revision="989aa7980e4cf806f80c7fef2b1adb7bc71aa306")'
```

That optional download is not part of the measured experimental pipeline.

## Verify the published bundle without model calls

```sh
PYTHONPATH=src:scripts .venv/bin/python scripts/reproduce_curvature_findings.py --verify-only
PYTHONPATH=src:scripts .venv/bin/python scripts/reproduce_curvature_findings.py --plan
```

These commands verify the listed file hashes and registered source fingerprints. They do not claim independent numerical reproduction.

## Fresh confirmation of 190–194

In a clean checkout with no existing run directories:

```sh
HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 PYTHONPATH=src:scripts \
  caffeinate -i .venv/bin/python scripts/reproduce_curvature_findings.py --mode fresh-190-194
```

This copies the **historical 189 design/runtime/audit qualification** into the explicitly required prerequisite paths, then executes the unchanged 190, 191, 192, 193 and194 runners, separate numerical implementations and complete artifact audits, serially. It regenerates their saved-state analyses and figures. It does not rerun or freshly certify 189.

190–191 execute 2,304 ordinary full-model calls including numerical checks.192 and193 each add336ordinary and72differentiated invocations including numerical checks.192is numerically unqualified and preserved as a failed technical attempt;193is the fresh first-order-only test. Differentiated invocations are separately counted and have different costs.190 additionally performs 1,792 component down-projection evaluations and 224 separate component matrix reconstructions. Raw arrays require several dozen GB; the full190 traces alone occupy about25GB in the original run.

## Reproduce 186–194, including 189's referenced parent cuts

```sh
HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 PYTHONPATH=src:scripts \
  caffeinate -i .venv/bin/python scripts/reproduce_curvature_findings.py --mode from-186
```

This uses an explicitly **historical185 prerequisite**, then freshly executes186–194.186 and187 generate the paired states that188 and189 require;189's three parent cuts are references rather than duplicate executions. Total8,024 ordinary and144 differentiated invocations, with component computations separately counted. Neither mode replays the two engineering preflights unless they are invoked explicitly; their original failure/correction provenance is retained.

The wrapper refuses existing run directories or different prerequisite bytes. It does not edit source, monkeypatch scientific modules, relax controls, clip forecasts, or overwrite prior runs. Auditors write fresh qualification JSON at their registered `docs/analysis/` paths; rerunning will therefore replace published result JSON locally with newly measured results. Runtime mismatches and threshold failures are retained as failures.

## Independent numerical check and limits

189–191 numerical checks use fresh public model readouts and separately implemented intervention hooks.192 uses fresh native trajectories and reverse-over-reverse derivatives of the margin and two deterministic linear projections of all28 residual trajectories. The192second-order derivative contractions failed the fixed bound (maximum discrepancy0.1402097); they are not interpreted as qualified scientific evidence.193checks first derivatives only, on fresh prompts, with the same bound. The wrapper retains192as an expected qualification failure and continues193, which depends on qualified191. Those projection checks do not certify coordinatewise identity of every derivative tensor. All fixed bounds are in the immutable protocols.

The templates are dependent, one small Qwen checkpoint is used here, and earlier grounding/specificity failures remain. Success of balanced evidence or small embedding doses cannot rescue failed native individual-preference or residual accounts. The research primary question is not equivalent to reproducing an audited diagnostic correction, and remains subject to the reported forecasting boundaries.

194 separately adds864ordinary model calls including numerical checks. Its source/receiver crossing is calibrated only from nativeFalse but executes mapped counterfactual forward passes, retaining finite known normalization/attention/multiplication functions. It does not match193's derivative-only computation budget. Everyprimary individual-preference/residual account fails; the receiver-only secondary evidence account survives. This is a source-generation forecasting boundary, not a solved generalmechanism.
