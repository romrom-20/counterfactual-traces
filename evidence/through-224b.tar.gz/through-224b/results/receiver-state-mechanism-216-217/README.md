# Fixed-readout crosses and selected receiver resets

216 separates a changed correction vector from a changed finite readout reference. 217 replaces native receiving states once at boundaries 0,8,16,24,27, then actually resumes the original208 finite-source/False-first-AD-receiver update. These are retrospective/oracle diagnostics on 64 related old208 contexts. They do not establish a learned circuit, exact earliest error layer, or prospective counterfactual prediction.

Read `docs/analysis/217-receiver-state-mechanism-result.md` and the raw 216/217 audits. The portable offline viewer source is `.context/receiver-state-mechanism-216-217.canvas.tsx`; figures are under `docs/figures/216*` and `217*`.

The manifest extends the unchanged previous 1807-file preservation closure. It includes scientific code, registrations, failed 216 auditor and serialization-only 216b correction, frozen sources, numeric reports, figures, logs and recorded run metadata. Successful raw NPZ arrays and pinned model weights remain local; sizes/hashes are listed in `local-raw-inventory.json`. Archived metadata is stored under `recorded-runs/` and is not installed as live canonical run status.

Zero-model-call verification and execution plan:

```sh
PYTHONPATH=src:scripts .venv/bin/python scripts/reproduce_receiver_state_216_217.py --verify-only
PYTHONPATH=src:scripts .venv/bin/python scripts/reproduce_receiver_state_216_217.py --plan
```

Fresh regeneration requires a compatible Mac MPS backend, project dependencies and offline cached Qwen2.5-1.5B-Instruct revision `989aa7980e4cf806f80c7fef2b1adb7bc71aa306`. The wrapper refuses to overwrite canonical new runs, archives the old numeric reports, reconstructs missing 208/215 parents through the preserved earlier pipeline, and executes 216 → corrected 216b audit → 217 → 217 audit → figures sequentially:

```sh
HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 OMP_NUM_THREADS=1 \
VECLIB_MAXIMUM_THREADS=1 PYTHONPATH=src:scripts \
.venv/bin/python scripts/reproduce_receiver_state_216_217.py
```

Scientific thresholds remain coordinates 1e-4, scores .005, reverse projections .001+.0001abs(reference), and original joint accuracy relative L2≤.05/cosine≥.99/native norm≥.001/margin error≤.10. The .02-nat common-base sign guard is a separate diagnostic. Original whole-block Jacobian coordinate failures remain unqualified; scalar projections and replay do not change that status. Native-input full finite block 28 is a trivial control.

The actual model runs and saved-array audits were executed in the working workspace. A clean-copy hash/plan check is separate from a second end-to-end model replication. Recomputed timestamps/digests differ; preserve the original evidence. No browser, push or publication was used.
