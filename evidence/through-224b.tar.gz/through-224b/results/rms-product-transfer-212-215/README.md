# RMSNorm/product diagnostic and its transfer limit

The 212b/213 local diagnostic supports a conditional gate–up effect that remains useful after normalization repair. 214 fails retrospective transfer to the old 208 predictor. 215 holds context/source fixed and shows receiving-input dependence, including behavioral sign reversals. No nontrivial candidate passes the original joint accuracy test. The original whole-block derivative coordinate failures remain unresolved.

Read `docs/analysis/215-rms-product-mechanism-and-transfer.md`. Static figures are under `docs/figures/212*`, `214*`, `215*`. The offline viewer's portable source is `.context/rms-product-transfer-212-215.canvas.tsx`; its builder writes the original workspace's managed Canvas path.

The manifest extends the prior unchanged 1390-file preservation closure. It includes code, pre-execution registrations, executed-source snapshots, numeric reports, figures, logs, run metadata under `recorded-runs/`, and the actual failed212 first-pair NPZ under `failed-artifacts/`. Successful raw arrays remain local and their hashes/sizes are enumerated in `local-raw-inventory.json`. Model weights are not bundled. Recorded metadata is never installed as canonical live run status.

Zero-model-call integrity check and executable plan:

```sh
PYTHONPATH=src:scripts .venv/bin/python scripts/reproduce_rms_product_212_215.py --verify-only
PYTHONPATH=src:scripts .venv/bin/python scripts/reproduce_rms_product_212_215.py --plan
```

To regenerate, use a fresh checkout/extraction with the preserved files, the project's Python dependencies, locally cached pinned Qwen weights and a compatible Mac MPS backend. The wrapper refuses to overwrite canonical new runs. It archives old numeric reports, regenerates missing raw 204/209c/211 and 208 prerequisites using the preserved earlier code, then executes 213, 212b, 214, 215 and their corrected auditors in order. It leaves historical failed attempts preserved rather than relabeling them. This costs model evaluations and differs from verification:

```sh
HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 OMP_NUM_THREADS=1 \
VECLIB_MAXIMUM_THREADS=1 PYTHONPATH=src:scripts \
.venv/bin/python scripts/reproduce_rms_product_212_215.py
```

Original coordinate/score bounds remain 1e-4/.005; joint accuracy bounds remain relativeL2 .05, cosine .99, minimum native norm .001 and margin error .10 nats. The failed strict mixed-vector and original-Jacobian comparisons must remain failures. 212b is a scalar-serialization fix; 214b is an auditor count fix. Neither changes scientific calculations or thresholds. Completing this pipeline does not establish a learned circuit, a generalization result on unseen inputs or a solution to Question B.

The scientific runners and auditors were actually executed in this workspace. Hash verification and a clean-copy plan check are separate checks; a second full model replication in that copy has not been performed. No browser, push or publication was used for this continuation.

Fresh execution creates new timestamps, digests and hardware-dependent floating-point outputs. Reproduction means meeting the same defined checks and retaining the same scientific failure categories, not replacing the archived records or claiming byte-identical rerun metadata.
