# SiLU range falsification on the matched receiver setup

The completed 218 test removes below-bound gate activations by replacing False-affine SiLU with real SiLU. The same 39 native/forecast natural product-effect sign reversals persist. Attention remains False-affine; this is not a range-clipping-only intervention, native learned-circuit identification or prospective prediction. Every arm fails the original joint accuracy criterion.

Read `docs/analysis/218-silu-range-falsification.md` for the numerical result and `218-goodfire-followup.md` for the first-party Goodfire investigation and next test rationale. The offline viewer is `.context/silu-range-falsification-218.canvas.tsx`, with scientific figures under `docs/figures/218*`.

The manifest extends all 1,988 files in the previous closure unchanged, including the earlier 1,807-file closure. It preserves sources, registration, reports, actual logs, figures and recorded metadata. Executed sources/protocol were hash-sealed before model loading; their separately archived copies were created **after execution**, once hashes were verified. These copies are not pre-execution snapshots. No correction run or threshold change was required. Raw NPZ arrays and pinned model weights remain local; `local-raw-inventory.json` records array sizes and hashes. The full copyrighted Goodfire essay is not redistributed in this bundle.

Verify or inspect the plan with zero model calls:

```sh
PYTHONPATH=src:scripts .venv/bin/python scripts/reproduce_silu_range_218.py --verify-only
PYTHONPATH=src:scripts .venv/bin/python scripts/reproduce_silu_range_218.py --plan
```

Regenerate only in a fresh checkout, with compatible Mac MPS/project dependencies and offline cached Qwen2.5-1.5B-Instruct revision `989aa7980e4cf806f80c7fef2b1adb7bc71aa306`:

```sh
HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 OMP_NUM_THREADS=1 \
VECLIB_MAXIMUM_THREADS=1 PYTHONPATH=src:scripts \
.venv/bin/python scripts/reproduce_silu_range_218.py
```

The wrapper refuses to overwrite the canonical run, preserves old numeric reports, reconstructs missing 208/215 parents through the earlier preserved pipeline, and executes the registered runner, saved-array audit and figure generation sequentially. Managed viewer generation is a separate presentation step in the original workspace.

Model execution and the saved-array audit have passed in the working workspace. Clean-copy hash/plan verification is not a second executed model replication. Original whole-block coordinate Jacobian and unadjusted mixed-term equality failures remain failures. No publication, staging, commit or push is included.
