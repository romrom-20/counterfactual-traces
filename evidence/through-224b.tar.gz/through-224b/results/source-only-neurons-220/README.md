# Frozen fresh test of the source-only upstream hypothesis

Read `docs/analysis/220-local-account-and-source-hypothesis-result.md` and the numeric audit. The source-only hypothesis is rejected: 0/16 individual passes on every frozen local criterion. This does not erase 219's stable retrospective causal group or change any numerical tolerance. It is a native-incoming attention-affine local target, not full native behavioral prediction.

The preservation manifest extends all 2,250 previous files unchanged. It includes sources/auditor/protocol copied before execution, actual logs, historical input catalog, 16 sealed forecast records, manifest and observation ordering, numerical report, failed hypothesis, figures, viewer source and reproduction tools. New raw forecasts/observations/weights stay local; sizes and hashes are inventoried. No native True forward occurred before every forecast was sealed. No full-finite True upper control was computed during prediction.

Zero-model-call verification and plan:

```sh
PYTHONPATH=src:scripts .venv/bin/python scripts/reproduce_source_only_neurons_220.py --verify-only
PYTHONPATH=src:scripts .venv/bin/python scripts/reproduce_source_only_neurons_220.py --plan
```

To repeat, use a fresh checkout with compatible MPS dependencies, pinned offline Qwen2.5-1.5B-Instruct revision `989aa7980e4cf806f80c7fef2b1adb7bc71aa306`, original frozen `runs/neuron-mixed-interventions-219/selection.json`, and the historical paired-forecast JSON metadata for input freshness checks. Do not replace the canonical run or silently change the mask. Historical native True arrays are not needed by this predictor.

```sh
HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 OMP_NUM_THREADS=1 \
VECLIB_MAXIMUM_THREADS=1 PYTHONPATH=src:scripts \
.venv/bin/python scripts/reproduce_source_only_neurons_220.py
```

The wrapper archives the original numeric report and executes forecast sealing, later observations, independent audit and figures. The managed-workspace viewer is a separate presentation step using `scripts/build_neuron_hypothesis_canvas_220.py`. A clean-copy hash/plan check is not a second executed model replication. Original whole-block coordinate Jacobian failures remain unqualified. No correction sweep, publication, staging, commit or push.
