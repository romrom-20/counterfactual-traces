# Controlled late-block factorial and prospective source–receiver partition

Completed15October2026 on the original pinnedQwen2.5-1.5B-Instruct/MPSFloat32/eager stack. No network, training, publication or Git staging/commit/push.204retains its documented qualified retrospective RESET scope;196/203/204derivative discrepancies remain unresolved. Invalid replacement-agent conclusions remain invalid.

Read [the scientific verdict](../../docs/analysis/208-209-research-verdict.md). Qualified209cfactorial: neither isolated finite block27/28 passes any individual joint criterion; both finite recover64/64oracle tails, with nonzero signed interaction.208freshsealedforecasts: exact source replay at28depths, but0/64candidatepasses and0/16partial-progresspanels. The candidate improves scalar margins yet has worse pooled final residualerror. Neither study identifies a learned circuit or responsible primitive.

## Evidence and immutable failures

`manifest.json` extends the423-file202–207closure without altering its manifest. New scientific source/protocol/audit files, all numeric reports, plots, viewer, source snapshots, completed run metadata, pair JSON records, forecast manifest, False-only derivative checks and historical-input catalog are hashed. `recorded-runs/` contains preserved run metadata ONLY, not canonical assert-protected run directories. `historical-input-records/` preserves the514past forecast JSON records used to reject prompt overlap. RawNPZstates and cached model weights remain local; regenerate them for a numerical re-audit.

209failed0/64 and209bfailed9/64 at the unchanged1e-4native-state threshold. Their original files/logs/status/partialmetadata remain preserved.209ccorrects absolute native/finite-chain operands; its controls qualify. No thresholds changed.209cqualified BEFORE208implementation execution;208all64forecasts sealed09:04:30.534343UTC BEFORE the first nativeTrue measurement09:05:25.417705UTC. Every208prediction/arm/case is retained.

## Verification and reproduction

From the repository root with the existing offline environment:

```sh
PYTHONPATH=src:scripts .venv/bin/python scripts/reproduce_factorial_partition_208_209.py --verify-only
PYTHONPATH=src:scripts .venv/bin/python scripts/reproduce_factorial_partition_208_209.py --plan
```

These commands make zero model calls and need no weights. Hash verification is not a fresh numerical re-run. The complete package was also checked from an isolated clean copy. Static scientific figures were rendered and visually inspected; the self-contained offlineCanvas compiled with cached esbuild. A browser/host render was not observed.

To execute a NEW numerical reproduction, use a fresh checkout with the recorded source, the original `.venv` dependencies and pinned cached checkpoint available. Canonical209c/208run directories must be absent. Then run:

```sh
HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 OMP_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 PYTHONPATH=src:scripts .venv/bin/python scripts/reproduce_factorial_partition_208_209.py
```

If qualified204fullrawpairs are absent, the existing offline202–207reproducer regenerates its193/199/201/204prerequisites first, preserving historical reports in its non-overwriting archive. The new wrapper archives the four existing208/209numeric reports, then executes209c, its two audits/summaries,208, its two audits/summaries, plots and viewer. Every new208forecast is again globally sealed before that run's nativeTrue evaluation.209/209b historical failures are preserved, not required to recur identically on a different numerical stack.

A new reproduction will generate new timestamps/hashes and may differ numerically; it must pass the SAMEstate/score/derivative bounds and report every failure. The verification performed for this package did not rerun the entire historical pipeline a second time.

Main208cost:64False+64Trueordinary models,3648localfiniteblocks,3456localJVPs,64headJVPs,448finitehead evaluations; verification counts are in the complete audit. Candidate per context:28wholefiniteblocks+27receiverJVPs, potentially more costly than nativeTrue computation. This is a fixed structural hypothesis test, not an efficient compact predictor.

Viewer source: [source-receiver-factorial.canvas.tsx](source-receiver-factorial.canvas.tsx). Figures: [PNG](../../docs/figures/208-209-factorial-partition.png), [SVG](../../docs/figures/208-209-factorial-partition.svg). Registrations: [208](../../docs/experiments/208-source-receiver-partition-registration.md), [209c](../../docs/experiments/209c-absolute-finite-factorial.md).
