"""Post-observation location of native first-order forecast error: Boolean source vs verdict."""

import json
from pathlib import Path

import audit_single_state_native_response_193 as audit
import numpy as np

from latent_decisions.evidence_policy import digest, write_json

ROOT = Path(__file__).resolve().parents[1]


def measure(actual, predicted):
    norm = float(np.linalg.norm(actual))
    pn = float(np.linalg.norm(predicted))
    return {
        "actual_displacement_norm": norm,
        "predicted_displacement_norm": pn,
        "relative_error": float(np.linalg.norm(actual - predicted) / norm) if norm else None,
        "cosine": float(np.dot(actual, predicted) / (norm * pn)) if norm and pn else None,
    }


def main():
    a = json.loads(audit.OUT.read_text())
    assert a["numerical_qualified"] and all(a["controls"].values())
    contexts = []
    for c in a["cells"]:
        if c["dose"] != 1.0:
            continue
        g = {k: c[k] for k in ("block", "schema", "reverse", "assignment", "target")}
        key = digest(g)
        fr = audit.native.read_record(audit.RUN / "qwen15/forecasts" / f"{key}.json")["record"]
        obs = audit.native.read_record(audit.RUN / "qwen15/observations" / f"{key}.json")["record"]
        fp = audit.RUN / "qwen15/forecasts" / f"{key}.npz"
        op = audit.RUN / "qwen15/observations" / f"{key}.npz"
        assert (
            audit.native.hashed(fp) == fr["states_sha256"]
            and audit.native.hashed(op) == obs["states_sha256"]
        )
        pos = fr["position"]
        with np.load(fp, allow_pickle=False) as f, np.load(op, allow_pickle=False) as o:
            actual = o["actual_1.0_states"].astype(np.float64) - f["native_false_states"].astype(
                np.float64
            )
            predicted = f["d1_states"].astype(np.float64)
            rows = []
            for layer in range(28):
                rows.append(
                    {
                        "layer": layer + 1,
                        "boolean_source": measure(actual[layer, pos], predicted[layer, pos]),
                        "verdict_position": measure(actual[layer, -1], predicted[layer, -1]),
                        "full_receiving_rows": measure(
                            actual[layer, pos + 1 :].ravel(), predicted[layer, pos + 1 :].ravel()
                        ),
                    }
                )
            contexts.append({**g, "layers": rows})
    assert len(contexts) == 64
    result = {
        "fingerprint": a["fingerprint"],
        "source_sha256": audit.native.hashed(Path(__file__)),
        "audit_sha256": audit.native.hashed(audit.OUT),
        "posthoc": True,
        "model_invocations": 0,
        "contexts": contexts,
        "scope": "Native flip first-order forecast errors at changed Boolean source token versus final verdict and all receiving rows. Predictions were sealed before any observed true state. Error locations examined AFTER observations; not a new held-out prediction or unique causal pathway attribution.191 keeps the native true metadata-source encoder live, as well as receiver attention/norm/up; its false-SiLU coefficient success does not establish one-state source prediction.",
    }
    write_json(ROOT / "docs/analysis/193-boolean-source-breakdown.json", result)
    for schema in ("generic", "descriptive"):
        for layer in (1, 2, 10, 28):
            rows = [c["layers"][layer - 1] for c in contexts if c["schema"] == schema]
            print(
                schema,
                layer,
                {
                    kind: (
                        min(r[kind]["relative_error"] for r in rows),
                        float(np.median([r[kind]["relative_error"] for r in rows])),
                        max(r[kind]["relative_error"] for r in rows),
                    )
                    for kind in ("boolean_source", "verdict_position")
                },
            )


if __name__ == "__main__":
    main()
