"""Saved-state product decomposition and exact final-scale counterfactuals;0 forwards."""

import argparse
import json
import math
from pathlib import Path

import audit_factorial_curvature_routes_189 as prior
import audit_fresh_norm_split_190 as fresh
import numpy as np
from safetensors import safe_open
from transformers import AutoConfig
from transformers.utils.hub import cached_file

from latent_decisions.evidence_policy import write_json

ROOT = Path(__file__).resolve().parents[1]


def radial_diagnostic(h0, h1, direction, epsilon, fixed_scale=None):
    delta = h1 - h0
    alpha = float(delta @ h0 / (h0 @ h0))
    radial = (1 + alpha) * h0

    def margin(h):
        scale = (
            fixed_scale
            if fixed_scale is not None
            else 1 / math.sqrt(float(np.mean(h * h)) + epsilon)
        )
        return float(direction @ h) * scale

    energy = float(delta @ delta)
    return {
        "radial_scale": 1 + alpha,
        "radial_energy_fraction": float(alpha * alpha * (h0 @ h0) / energy) if energy else 0.0,
        "radial_path_margin_change": margin(radial) - margin(h0),
        "remaining_path_margin_change": margin(h1) - margin(radial),
        "total_margin_change": margin(h1) - margin(h0),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--experiment", type=int, choices=(189, 190), required=True)
    args = parser.parse_args()
    audit = prior if args.experiment == 189 else fresh
    a = json.loads(audit.OUT.read_text())
    b = json.loads((audit.RUN / "design.json").read_text())
    native = audit.native
    assert (
        a["complete"]
        and a["numerical_qualified"]
        and all(a["controls"].values())
        and a["fingerprint"] == b["fingerprint"]
    )
    spec = b["design"]["models"]["qwen15"]
    cfg = AutoConfig.from_pretrained(
        spec["model"], revision=spec["revision"], local_files_only=True
    )
    assert cfg.tie_word_embeddings
    path = cached_file(
        spec["model"], "model.safetensors", revision=spec["revision"], local_files_only=True
    )
    with safe_open(path, framework="pt", device="cpu") as archive:
        assert "lm_head.weight" not in archive.keys()
        norm = archive.get_tensor("model.norm.weight").float().numpy().astype(np.float64)
        output = np.stack(
            [
                archive.get_slice("model.embed_tokens.weight")[i : i + 1].float().numpy()[0]
                for i in (895, 830)
            ]
        ).astype(np.float64)
    direction = (output[1] - output[0]) * norm
    cells, max_error, max_identity, max_counterfactual = [], 0.0, 0.0, 0.0
    for cell in a["cells"]:
        g = {k: cell[k] for k in ("block", "assignment", "target", "reverse", "schema")}
        key = prior.digest(g)
        r = native.read_record(audit.RUN / "qwen15/records" / f"{key}.json")["record"]
        p = audit.RUN / "qwen15/states" / f"{key}.npz"
        assert native.hashed(p) == r["states_sha256"]
        with np.load(p, allow_pickle=False) as z:
            nbar = float(z["shared_N_final"][-1, 0])
            decompositions, counterfactuals = {}, {}
            for cut in ("U", "NU", "WU", "N", "W") if args.experiment == 189 else audit.CUTS:
                values = {}
                for arm in ("paired", "even"):
                    for bit in range(2):
                        h = z[f"{cut}_{arm}_{bit}_final"][-1].astype(np.float64)
                        projection = float(direction @ h)
                        if args.experiment == 190:
                            scale = float(z[f"{cut}_{arm}_{bit}_N_final"][-1, 0])
                        else:
                            scale = (
                                nbar
                                if "N" in cut
                                else 1 / math.sqrt(float(np.mean(h * h)) + cfg.rms_norm_eps)
                            )
                        expected = next(
                            q["margin"]
                            for q in r["patches"]
                            if (q["cut"], q["arm"], q["bit"]) == (cut, arm, bit)
                        )
                        scores = output @ (h * scale * norm)
                        max_error = max(
                            max_error,
                            abs(float(scores[0]) - expected["false_score"]),
                            abs(float(scores[1]) - expected["true_score"]),
                            abs(scale * projection - expected["log_odds"]),
                        )
                        values[(arm, bit)] = {
                            "hidden": h,
                            "projection": projection,
                            "scale": scale,
                            "margin": scale * projection,
                            "fixed_scale_margin": nbar * projection,
                        }
                bit_terms = []
                for bit in range(2):
                    p0, p1 = values[("paired", bit)], values[("even", bit)]
                    pt = (p1["scale"] + p0["scale"]) / 2 * (p1["projection"] - p0["projection"])
                    nt = (p1["scale"] - p0["scale"]) * (p1["projection"] + p0["projection"]) / 2
                    max_identity = max(max_identity, abs(pt + nt - (p1["margin"] - p0["margin"])))
                    bit_terms.append(
                        {
                            "bit": bit,
                            "projection_term": pt,
                            "scale_term": nt,
                            "total": pt + nt,
                            "radial_geometry": radial_diagnostic(
                                p0["hidden"],
                                p1["hidden"],
                                direction,
                                cfg.rms_norm_eps,
                                nbar
                                if (cut in ("FU", "NU") if args.experiment == 190 else "N" in cut)
                                else None,
                            ),
                        }
                    )
                pk = bit_terms[1]["projection_term"] - bit_terms[0]["projection_term"]
                nk = bit_terms[1]["scale_term"] - bit_terms[0]["scale_term"]
                kf = (
                    values[("even", 1)]["fixed_scale_margin"]
                    - values[("even", 0)]["fixed_scale_margin"]
                ) - (
                    values[("paired", 1)]["fixed_scale_margin"]
                    - values[("paired", 0)]["fixed_scale_margin"]
                )
                decompositions[cut] = {
                    "projection_kappa": pk,
                    "scale_kappa": nk,
                    "total_kappa": pk + nk,
                    "public_kappa": cell["kappa"][cut],
                    "terms_oppose": pk * nk < 0,
                    "bit_terms": bit_terms,
                }
                counterfactuals[cut] = {
                    "kappa": kf,
                    "pairs": {
                        arm: [values[(arm, bit)]["fixed_scale_margin"] for bit in range(2)]
                        for arm in ("paired", "even")
                    },
                }
            if args.experiment == 190:
                for source, target in (("U", "FU"), ("IU", "NU")):
                    max_counterfactual = max(
                        max_counterfactual,
                        max(
                            abs(
                                counterfactuals[source]["pairs"][arm][bit]
                                - cell["margins"][target][arm][bit]
                            )
                            for arm in ("paired", "even")
                            for bit in range(2)
                        ),
                    )
            cells.append(
                {
                    **g,
                    "decomposition": decompositions,
                    "fixed_final_counterfactual": counterfactuals,
                }
            )
    assert (
        len(cells) == 64
        and max_error <= 0.005
        and max_identity <= 1e-10
        and max_counterfactual <= 0.005
    )
    result = {
        "fingerprint": a["fingerprint"],
        "experiment": args.experiment,
        "posthoc_diagnostic": True,
        "target_model_forwards": 0,
        "source_sha256": native.hashed(Path(__file__)),
        "audit_sha256": native.hashed(audit.OUT),
        "selected_weight_sha256": prior.digest(
            {"output": native.array_hash(output), "norm": native.array_hash(norm)}
        ),
        "maximum_public_score_reconstruction_error": max_error,
        "maximum_finite_product_identity_error": max_identity,
        "maximum190_fixed_final_counterfactual_error": max_counterfactual,
        "cells": cells,
        "scope": "Exact finite scale/projection arithmetic on final residuals with pinned tied embeddings;0full-model forwards. Opposing terms are ONE normalization operation, not competing learned mechanisms. Reference-based radial/remainder paths are geometric, not unique causal attribution. Counterfactual changes finalnorm ONLY.189 comparisons are posthoc;190 checks actual final-only forward interventions. Neither explains how upstream residual displacement is generated.",
    }
    write_json(ROOT / f"docs/analysis/{args.experiment}-norm-readout-cancellation.json", result)
    print(json.dumps({k: v for k, v in result.items() if k != "cells"}, indent=2))
    for schema in ("generic", "descriptive"):
        rs = [c for c in cells if c["schema"] == schema]
        print(
            schema,
            "U projection mean",
            np.mean([c["decomposition"]["U"]["projection_kappa"] for c in rs]),
            "U scale mean",
            np.mean([c["decomposition"]["U"]["scale_kappa"] for c in rs]),
            "U fixedF vsNU maxerr",
            max(
                abs(
                    c["fixed_final_counterfactual"]["U"]["kappa"]
                    - c["decomposition"]["NU"]["public_kappa"]
                )
                for c in rs
            ),
        )


if __name__ == "__main__":
    main()
