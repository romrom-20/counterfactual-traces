"""Source versus propagated displacement atlas; measured differences are not forecasts."""

import json
from pathlib import Path

import audit_fresh_norm_split_190 as audit
import numpy as np

from latent_decisions.evidence_policy import digest, write_json

ROOT = Path(__file__).resolve().parents[1]


def cosine(a, b):
    den = float(np.linalg.norm(a) * np.linalg.norm(b))
    return float(np.sum(a * b) / den) if den else None


def main():
    a = json.loads(audit.OUT.read_text())
    assert a["numerical_qualified"] and all(a["controls"].values())
    rows = []
    first_source_error = first_bit_difference = 0.0
    for c in a["cells"]:
        g = {k: c[k] for k in ("block", "assignment", "target", "reverse", "schema")}
        key = digest(g)
        r = audit.native.read_record(audit.RUN / "qwen15/records" / f"{key}.json")["record"]
        p = audit.RUN / "qwen15/states" / f"{key}.npz"
        assert audit.native.hashed(p) == r["states_sha256"]
        with np.load(p, allow_pickle=False) as z:
            shifts = {}
            for cut in ("U", "IU"):
                for layer in range(1, 29):
                    source = z[f"C_source_{layer}"].astype(np.float64)
                    ds = [
                        z[f"{cut}_even_{bit}_R_{layer}_output"].astype(np.float64)
                        - z[f"{cut}_paired_{bit}_R_{layer}_output"]
                        for bit in range(2)
                    ]
                    common = (ds[0] + ds[1]) / 2
                    difference = ds[1] - ds[0]
                    shifts[(cut, layer)] = (common, difference)
                    mlp = [
                        z[f"{cut}_even_{bit}_R_{layer}_mlp"].astype(np.float64)
                        - z[f"{cut}_paired_{bit}_R_{layer}_mlp"]
                        for bit in range(2)
                    ]
                    attention = [
                        z[f"{cut}_even_{bit}_R_{layer}_attention"].astype(np.float64)
                        - z[f"{cut}_paired_{bit}_R_{layer}_attention"]
                        for bit in range(2)
                    ]
                    if layer == 1:
                        first_source_error = max(
                            first_source_error, max(float(np.max(abs(v - source))) for v in ds)
                        )
                        first_bit_difference = max(
                            first_bit_difference, float(np.max(abs(difference)))
                        )
                    rows.append(
                        {
                            **g,
                            "cut": cut,
                            "layer": layer,
                            "source_norm": float(np.linalg.norm(source)),
                            "last_token_source_norm": float(np.linalg.norm(source[-1])),
                            "last_token_common_shift_norm": float(np.linalg.norm(common[-1])),
                            "last_token_bit_differential_shift_norm": float(
                                np.linalg.norm(difference[-1])
                            ),
                            "last_token_source_cosine_to_common_shift": cosine(
                                source[-1], common[-1]
                            ),
                            "false_shift_norm": float(np.linalg.norm(ds[0])),
                            "true_shift_norm": float(np.linalg.norm(ds[1])),
                            "common_shift_norm": float(np.linalg.norm(common)),
                            "bit_differential_shift_norm": float(np.linalg.norm(difference)),
                            "source_cosine_to_common_shift": cosine(source, common),
                            "source_cosine_to_false_shift": cosine(source, ds[0]),
                            "source_cosine_to_true_shift": cosine(source, ds[1]),
                            "mlp_differential_norm": float(np.linalg.norm(mlp[1] - mlp[0])),
                            "attention_differential_norm": float(
                                np.linalg.norm(attention[1] - attention[0])
                            ),
                            "mlp_false_propagated_input_response_norm": float(
                                np.linalg.norm(mlp[0] - source)
                            ),
                            "mlp_true_propagated_input_response_norm": float(
                                np.linalg.norm(mlp[1] - source)
                            ),
                        }
                    )
            for row in rows[-56:]:
                if row["cut"] == "U":
                    u, du = shifts[("U", row["layer"])]
                    i, di = shifts[("IU", row["layer"])]
                    row["common_displacement_cosine_internal_norm_free_vs_fixed"] = cosine(u, i)
                    row["differential_displacement_cosine_internal_norm_free_vs_fixed"] = cosine(
                        du, di
                    )
                    row["common_shift_change_from_internal_norm_cut"] = float(np.linalg.norm(i - u))
                    row["differential_shift_change_from_internal_norm_cut"] = float(
                        np.linalg.norm(di - du)
                    )
                    row["last_token_common_displacement_cosine_internal_norm_free_vs_fixed"] = (
                        cosine(u[-1], i[-1])
                    )
                    row[
                        "last_token_differential_displacement_cosine_internal_norm_free_vs_fixed"
                    ] = cosine(du[-1], di[-1])
                    row["last_token_differential_shift_change_from_internal_norm_cut"] = float(
                        np.linalg.norm(di[-1] - du[-1])
                    )
    assert len(rows) == 3584
    result = {
        "fingerprint": a["fingerprint"],
        "source_sha256": audit.native.hashed(Path(__file__)),
        "audit_sha256": audit.native.hashed(audit.OUT),
        "target_model_forwards": 0,
        "posthoc_diagnostic": True,
        "first_layer_source_vs_observed_max_error": first_source_error,
        "first_layer_bit_differential_max_error": first_bit_difference,
        "rows": rows,
        "scope": "All receiving positions,28layers,64contexts. SourceS=D(C*meanUP)common acrossbits/cuts. Layerwise even-minus-paired shifts MEASURED; source angle/norm and propagated-input responses descriptive, not independent predictions or unique learned features. Internal norm cut changes propagation with the source fixed. Finalnorm cannot generate these earlier shifts.",
    }
    write_json(ROOT / "docs/analysis/190-residual-source-atlas.json", result)
    print(json.dumps({k: v for k, v in result.items() if k != "rows"}, indent=2))


if __name__ == "__main__":
    main()
