"""Independent reconstruction of160–161; does not import its runner."""

import hashlib
import itertools
import json
import math
from pathlib import Path

import numpy as np
import run_counterbalanced_binding_155 as ancestor
import torch
from audit_counterbalanced_binding_155 import source
from audit_order_competence_151 import expected_choices, expected_messages
from transformers import AutoConfig, AutoTokenizer

from latent_decisions.evidence_policy import digest, token_sequences, write_json

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / "runs/binding-carrier-partition-160-161"
OUT = ROOT / "docs/analysis/160-161-independent-audit.json"
LITERALS = [
    ("amber", "160", "amber", "violet", "Wednesday", "Friday", "day_0"),
    ("coral", "160", "coral", "indigo", "Friday", "Monday", "day_4"),
    ("azure", "160", "azure", "ochre", "Tuesday", "Sunday", None),
    ("elm", "160", "elm", "ash", "Saturday", "Wednesday", None),
    ("jade", "161", "jade", "ruby", "Thursday", "Tuesday", None),
    ("chalk", "161", "chalk", "slate", "Monday", "Friday", None),
    ("navy", "161", "navy", "pearl", "Tuesday", "Thursday", None),
    ("beech", "161", "beech", "fir", "Friday", "Sunday", None),
]
ARMS = ("identity", "token", "suffix", "both")
ACCOUNTS = (
    "metadata_only",
    "suffix_only",
    "both_single_parts_sufficient",
    "additive_partition_response",
)


def blocks():
    return [
        {"id": bid, "stage": stage, "subjects": [a, b], "days": [x, y], "old_block": old}
        for bid, stage, a, b, x, y, old in LITERALS
    ]


def group(block, assignment, target, reverse, schema):
    return {
        "block": block["id"],
        "assignment": assignment,
        "target": target,
        "reverse": reverse,
        "schema": schema,
    }


def job(g, bit):
    return {
        "kind": "evidence",
        "order": "metadata_first",
        "candidate": 1,
        **{k: g[k] for k in ("assignment", "target", "reverse", "schema")},
        "clamp": bool(bit),
    }


def reconstruct(tok, block, j):
    data, facts = source(block, j)
    messages = expected_messages(data, {**j, "supported": facts["supported"]})
    choices = expected_choices(j)
    seqs = token_sequences(tok, choices)
    assert len(seqs[0]) == len(seqs[1])
    differences = [i for i, (x, y) in enumerate(zip(*seqs)) if x != y]
    assert len(differences) == 1
    free = differences[0]
    prefix = tok.apply_chat_template(messages, tokenize=True, add_generation_prompt=True)
    return {
        "job": j,
        "messages": messages,
        "prompt_ids": prefix,
        "choices": choices,
        "sequences": seqs,
        "free_index": free,
        "free_input_ids": prefix + seqs[0][:free],
        "false_token": seqs[0][free],
        "true_token": seqs[1][free],
        "facts": facts,
    }


def target_span(states, recipient, arm, bit):
    # Defined independently of runner's slicing helper.
    end = len(states[recipient])
    if arm == "identity":
        return bit, end, states[recipient][np.arange(bit, end)]
    donor = states[1 - recipient]
    start, end = (
        (bit, bit + 1) if arm == "token" else (bit + 1, end) if arm == "suffix" else (bit, end)
    )
    assert arm in ARMS
    return start, end, donor[np.arange(start, end)]


def estimands(records):
    panels = []
    for block, schema, reverse, bit in itertools.product(
        blocks(), ("generic", "descriptive"), range(2), range(2)
    ):
        cells = [
            r
            for r in records
            if r["block"] == block["id"] and r["schema"] == schema and r["reverse"] == reverse
        ]
        if len(cells) != 4:
            continue
        assert {(r["assignment"], r["target"]) for r in cells} == set(
            itertools.product(range(2), repeat=2)
        )

        def contrast(get_score):
            # Signed sum, unlike155's separate means.
            return (
                sum(
                    (1 if r["baselines"][0]["facts"]["supported"] else -1) * get_score(r)
                    for r in cells
                )
                / 2
            )

        native = contrast(lambda r: r["baselines"][bit]["margin"]["log_odds"])
        donor = contrast(lambda r: r["baselines"][1 - bit]["margin"]["log_odds"])
        patched = {
            arm: contrast(
                lambda r: next(
                    p["margin"]["log_odds"]
                    for p in r["patches"]
                    if p["recipient"] == bit and p["arm"] == arm
                )
            )
            for arm in ARMS
        }
        t, s, a = (patched[x] for x in ("token", "suffix", "both"))
        panels.append(
            {
                "block": block["id"],
                "stage": block["stage"],
                "schema": schema,
                "reverse": reverse,
                "recipient": bit,
                "native": native,
                "donor": donor,
                **patched,
                "donor_gap": donor - native,
                "token_donor_error": t - donor,
                "token_native_error": t - native,
                "suffix_donor_error": s - donor,
                "suffix_native_error": s - native,
                "interaction": a - t - s + native,
            }
        )
    return panels


def qualify(panels, controls, complete):
    tol, floor, dominance = 0.1, 0.2, 0.75
    gaps, strata = [], []
    for stage, schema, reverse in itertools.product(
        ("160", "161"), ("generic", "descriptive"), range(2)
    ):
        rows = [
            r
            for r in panels
            if r["stage"] == stage
            and r["schema"] == schema
            and r["reverse"] == reverse
            and r["recipient"] == 0
        ]
        good = sum(abs(r["donor_gap"]) > floor for r in rows)
        gaps.append(
            {
                "stage": stage,
                "schema": schema,
                "reverse": reverse,
                "panels": len(rows),
                "qualifying": good,
                "passed": len(rows) == 4 and good / 4 >= dominance,
            }
        )
        for bit in range(2):
            rs = [
                r
                for r in panels
                if r["stage"] == stage
                and r["schema"] == schema
                and r["reverse"] == reverse
                and r["recipient"] == bit
            ]
            counts = {
                "metadata_only": sum(
                    abs(r["token_donor_error"]) <= tol and abs(r["suffix_native_error"]) <= tol
                    for r in rs
                ),
                "suffix_only": sum(
                    abs(r["suffix_donor_error"]) <= tol and abs(r["token_native_error"]) <= tol
                    for r in rs
                ),
                "both_single_parts_sufficient": sum(
                    abs(r["token_donor_error"]) <= tol and abs(r["suffix_donor_error"]) <= tol
                    for r in rs
                ),
                "additive_partition_response": sum(abs(r["interaction"]) <= tol for r in rs),
            }
            strata.append(
                {
                    "stage": stage,
                    "schema": schema,
                    "reverse": reverse,
                    "recipient": bit,
                    "panels": len(rs),
                    "compatible": counts,
                    "passed": {k: len(rs) == 4 and v / 4 >= dominance for k, v in counts.items()},
                }
            )
    coverage = (
        complete
        and len(panels) == 64
        and all(
            len({r["block"] for r in panels if r["stage"] == stage}) == 4
            for stage in ("160", "161")
        )
    )
    raw = {k: coverage and all(s["passed"][k] for s in strata) for k in ACCOUNTS}
    effect = coverage and all(g["passed"] for g in gaps)
    return {
        "coverage": coverage,
        "effect_qualified": effect,
        "gap_strata": gaps,
        "account_strata": strata,
        "raw_compatible": raw,
        "qualified": {k: v and effect and all(controls.values()) for k, v in raw.items()},
    }


def audit_model(name, bundle):
    spec = bundle["design"]["models"][name]
    tok = AutoTokenizer.from_pretrained(
        spec["model"], revision=spec["revision"], local_files_only=True, trust_remote_code=False
    )
    rt = json.loads((RUN / name / "runtime.json").read_text())
    assert rt == json.loads((ancestor.DEFAULT / name / "runtime.json").read_text())
    config = AutoConfig.from_pretrained(
        spec["model"], revision=spec["revision"], local_files_only=True, trust_remote_code=False
    )
    # Reconstruct the loader's explicit float32 override of checkpoint bfloat16.
    config.dtype = torch.float32
    assert (
        digest(config.to_dict()) == rt["config_hash"]
        and digest(tok.get_vocab()) == rt["tokenizer_hash"]
    )
    n, middle = (28, 14) if name == "qwen15" else (40, 20)
    assert config.num_hidden_layers == n

    controls = {
        k: True
        for k in (
            "runtime",
            "record_integrity",
            "exact_token_paths",
            "full_crossing",
            "causal_prefix_identity",
            "state_shape_and_finiteness",
            "exact_patch_spans",
            "identity_replay",
            "both_donor_replay",
            "complementary_hybrid_replay",
            "old155_replay",
            "last_layer_negative",
            "selected_numerical_recheck",
        )
    }
    files = list((RUN / name / "records").glob("*.json"))
    assert len(files) == 128
    records = []
    for block, assignment, target, reverse, schema in itertools.product(
        blocks(), range(2), range(2), range(2), ("generic", "descriptive")
    ):
        g = group(block, assignment, target, reverse, schema)
        key = digest(g)
        e = json.loads((RUN / name / "records" / f"{key}.json").read_text())
        r = e["record"]
        assert (
            digest(r) == e["sha256"]
            and r["fingerprint"] == bundle["fingerprint"]
            and r["runtime_hash"] == digest(rt)
        )
        assert all(r[k] == v for k, v in g.items()) and r["stage"] == block["stage"]
        assert (r["middle_layer"], r["last_layer"]) == (middle, n)
        for bit in range(2):
            b = r["baselines"][bit]
            expected = reconstruct(tok, block, job(g, bit))
            assert all(b[k] == v for k, v in expected.items())
            m = b["margin"]
            assert (
                all(math.isfinite(v) for v in m.values())
                and m["log_odds"] == m["true_score"] - m["false_score"]
            )
            if block["stage"] == "160":
                prior_key = digest([block["id"], b["job"]])
                old = json.loads(
                    (ancestor.DEFAULT / name / "records" / f"{prior_key}.json").read_text()
                )
                assert old["record"]["block"] == block["id"] and old["record"]["job"] == b["job"]
                assert digest(old["record"]) == old["sha256"] == b["old_record_sha256"]
                assert (
                    old["record"]["margin"] == m
                    and old["record"]["fingerprint"] == bundle["design"]["parent_fingerprint"]
                )
                assert all(
                    old["record"][k] == b[k] for k in ("messages", "free_input_ids", "sequences")
                )
        paths = [b["free_input_ids"] for b in r["baselines"]]
        changes = [i for i, (x, y) in enumerate(zip(*paths)) if x != y]
        assert len(paths[0]) == len(paths[1]) and changes == [r["bit_position"]]
        bitpos = changes[0]
        assert len(r["baselines"][0]["prompt_ids"]) < bitpos < len(paths[0]) - 1
        assert r["baselines"][0]["prompt_ids"] == r["baselines"][1]["prompt_ids"]
        vp = RUN / name / "states" / f"{key}.npz"
        assert hashlib.sha256(vp.read_bytes()).hexdigest() == r["states_sha256"]
        with np.load(vp, allow_pickle=False) as archive:
            assert set(archive.files) == {"0_middle", "1_middle", "0_last_bit", "1_last_bit"}
            states = [archive[f"{b}_middle"] for b in range(2)]
            for b in range(2):
                assert (
                    states[b].dtype == np.float32
                    and states[b].ndim == 2
                    and states[b].shape == (len(paths[b]), config.hidden_size)
                )
                assert np.isfinite(states[b]).all() and np.isfinite(archive[f"{b}_last_bit"]).all()
                assert archive[f"{b}_last_bit"].dtype == np.float32 and archive[
                    f"{b}_last_bit"
                ].shape == (states[b].shape[1],)
            assert (
                states[0].shape == states[1].shape
                and np.array_equal(states[0][:bitpos], states[1][:bitpos])
                and r["prefix_states_identical"]
            )
            assert len(r["patches"]) == 8 and {
                (p["recipient"], p["arm"]) for p in r["patches"]
            } == set(itertools.product(range(2), ARMS))
            for p in r["patches"]:
                recipient, arm = p["recipient"], p["arm"]
                start, end, value = target_span(states, recipient, arm, bitpos)
                hybrid = np.concatenate(
                    (states[recipient][:start], value, states[recipient][end:]), axis=0
                )
                assert np.array_equal(hybrid[:start], states[recipient][:start]) and np.array_equal(
                    hybrid[end:], states[recipient][end:]
                )
                assert p["trace"] == [
                    {
                        "layer": middle,
                        "start": start,
                        "stop": end,
                        "applied": 1,
                        "other_positions_identical": True,
                        "target_installed_exactly": True,
                    }
                ]
                if arm in ("identity", "both"):
                    endpoint = recipient if arm == "identity" else 1 - recipient
                    assert (
                        np.array_equal(hybrid, states[endpoint])
                        and p["margin"] == r["baselines"][endpoint]["margin"]
                    )
                m = p["margin"]
                assert (
                    all(math.isfinite(v) for v in m.values())
                    and m["log_odds"] == m["true_score"] - m["false_score"]
                )
            for arm, complementary in (("token", "suffix"), ("suffix", "token")):
                first = next(
                    p["margin"] for p in r["patches"] if p["recipient"] == 0 and p["arm"] == arm
                )
                second = next(
                    p["margin"]
                    for p in r["patches"]
                    if p["recipient"] == 1 and p["arm"] == complementary
                )
                assert first == second
            selected = block["id"] in ("amber", "jade") and (assignment, target, reverse) == (
                0,
                0,
                0,
            )
            assert len(r["negative_controls"]) == (2 if selected else 0)
            for p in r["negative_controls"]:
                assert p["margin"] == r["baselines"][p["recipient"]]["margin"]
                assert p["trace"] == [
                    {
                        "layer": n,
                        "start": bitpos,
                        "stop": bitpos + 1,
                        "applied": 1,
                        "other_positions_identical": True,
                        "target_installed_exactly": True,
                    }
                ]
        records.append(r)
    panels = estimands(records)
    return {
        "controls": controls,
        "record_pairs": len(records),
        "baseline_forwards": 256,
        "middle_patch_forwards": 1024,
        "negative_patch_forwards": 8,
        "panels": panels,
        "qualification": qualify(panels, controls, True),
    }


def main():
    bundle = json.loads((RUN / "design.json").read_text())
    assert digest(bundle["design"]) == bundle["fingerprint"]
    sh = digest(
        {
            "runner": (ROOT / "scripts/run_binding_carrier_partition_160.py").read_text(),
            "protocol": (
                ROOT / "docs/experiments/160-161-binding-carrier-partition.md"
            ).read_text(),
            "parent": ancestor.source_hash(),
        }
    )
    assert sh == bundle["design"]["source_hash"] and bundle["design"]["blocks"] == blocks()
    status = json.loads((RUN / "pipeline-status.json").read_text())
    assert status["status"] == "complete" and status["fingerprint"] == bundle["fingerprint"]
    numerical = json.loads((ROOT / "docs/analysis/160-161-numerical-recheck.json").read_text())
    assert numerical["passed"] and numerical["fingerprint"] == bundle["fingerprint"]
    assert (
        numerical["source_sha256"]
        == hashlib.sha256(
            (ROOT / "scripts/recheck_binding_carrier_partition_160.py").read_bytes()
        ).hexdigest()
    )
    result = {
        "fingerprint": bundle["fingerprint"],
        "auditor_source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "complete": True,
        "models": {name: audit_model(name, bundle) for name in bundle["design"]["models"]},
        "boundary": "Separate-code artifact reconstruction and selected numerical rerun, not an independent research team or all-score replication.",
    }
    write_json(OUT, result)
    print(json.dumps({name: r["qualification"] for name, r in result["models"].items()}, indent=2))


if __name__ == "__main__":
    main()
