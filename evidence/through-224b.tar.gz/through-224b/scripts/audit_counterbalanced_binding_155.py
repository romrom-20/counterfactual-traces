"""Separate reconstruction of source crossings, execution provenance and estimands."""

import itertools
import json
import math
from pathlib import Path

import run_order_competence_151 as ancestor
from audit_order_competence_151 import expected_choices, expected_messages
from transformers import AutoTokenizer

from latent_decisions.evidence_policy import digest

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / "runs/counterbalanced-binding-155-156"
OUT = ROOT / "docs/analysis/155-156-independent-audit.json"
LITERALS = [
    ("amber", "155", "amber", "violet", "Wednesday", "Friday", "day_0"),
    ("coral", "155", "coral", "indigo", "Friday", "Monday", "day_4"),
    ("azure", "156", "azure", "ochre", "Tuesday", "Sunday", None),
    ("elm", "156", "elm", "ash", "Saturday", "Wednesday", None),
]
CONDITIONS = ["singleton", "verdict_first", "metadata_false", "metadata_true"]


def blocks():
    return [
        {"id": id_, "stage": stage, "subjects": [a, b], "days": [x, y], "old_block": old}
        for id_, stage, a, b, x, y, old in LITERALS
    ]


def source(block, job):
    pairs = list(zip(block["subjects"], block["days"]))
    if job["assignment"]:
        pairs = [(pairs[0][0], block["days"][1]), (pairs[1][0], block["days"][0])]
    if job["reverse"]:
        pairs = pairs[::-1]
    sentences = [f"The {subject} exhibit opened on {day}." for subject, day in pairs]
    answer = block["days"][job["candidate"]]
    requested = block["subjects"][job["target"]]
    truth = dict(pairs)[requested] == answer
    last = pairs[-1][1] == answer
    data = {
        "contexts": [" ".join(sentences)] * 2,
        "candidate": answer,
        "questions": [f"On which day did the {requested} exhibit open?"],
    }
    return data, {"supported": truth, "candidate_last": last}


def jobs(block):
    result = []
    for assignment, target, candidate, reverse, schema in itertools.product(
        range(2), range(2), range(2), range(2), ("generic", "descriptive")
    ):
        j = {
            "assignment": assignment,
            "target": target,
            "candidate": candidate,
            "reverse": reverse,
            "schema": schema,
        }
        result.append({**j, "kind": "singleton"})
        for order, bit in itertools.product(("metadata_first", "verdict_first"), (False, True)):
            result.append({**j, "kind": "evidence", "order": order, "clamp": bit})
    if block["id"] == "amber":
        for support, schema, order, bit in itertools.product(
            (False, True),
            ("generic", "descriptive"),
            ("metadata_first", "verdict_first"),
            (False, True),
        ):
            result.append(
                {
                    "kind": "given",
                    "supported": support,
                    "schema": schema,
                    "order": order,
                    "clamp": bit,
                }
            )
    return sorted(result, key=digest)


def public_selected(j):
    return j["kind"] == "given" or (
        (j["assignment"], j["target"], j["candidate"], j["reverse"]) == (0, 0, 1, 0)
        and (j["kind"] == "singleton" or j["order"] == "metadata_first" or j["clamp"] is False)
    )


def condition(j):
    if j["kind"] == "singleton":
        return "singleton"
    if j["order"] == "verdict_first":
        return "verdict_first"
    return "metadata_true" if j["clamp"] else "metadata_false"


def mean(values):
    return sum(values) / len(values)


def estimands(records):
    # Future true copies are excluded from analyses; their identity is an execution check.
    main = [
        r
        for r in records
        if r["job"]["kind"] != "given"
        and not (r["job"].get("order") == "verdict_first" and r["job"]["clamp"])
    ]
    binding, position, accuracies = [], [], []
    for block, candidate, schema, cond in itertools.product(
        blocks(), range(2), ("generic", "descriptive"), CONDITIONS
    ):
        selected = [
            r
            for r in main
            if r["block"] == block["id"]
            and r["job"]["candidate"] == candidate
            and r["job"]["schema"] == schema
            and condition(r["job"]) == cond
        ]
        if len(selected) != 8:
            continue
        position.append(
            {
                "block": block["id"],
                "stage": block["stage"],
                "candidate": candidate,
                "schema": schema,
                "condition": cond,
                "position_effect": mean(
                    [r["margin"]["log_odds"] for r in selected if r["facts"]["candidate_last"]]
                )
                - mean(
                    [r["margin"]["log_odds"] for r in selected if not r["facts"]["candidate_last"]]
                ),
            }
        )
        for reverse in (0, 1):
            cells = [r for r in selected if r["job"]["reverse"] == reverse]
            supported = [r["margin"]["log_odds"] for r in cells if r["facts"]["supported"]]
            unsupported = [r["margin"]["log_odds"] for r in cells if not r["facts"]["supported"]]
            assert len(cells) == 4 and len(supported) == len(unsupported) == 2
            binding.append(
                {
                    "block": block["id"],
                    "stage": block["stage"],
                    "candidate": candidate,
                    "schema": schema,
                    "condition": cond,
                    "reverse": reverse,
                    "binding_effect": mean(supported) - mean(unsupported),
                    "supported_mean": mean(supported),
                    "unsupported_mean": mean(unsupported),
                    "target_specific_responses": [
                        mean(
                            [
                                r["margin"]["log_odds"]
                                for r in cells
                                if r["job"]["target"] == target and r["facts"]["supported"]
                            ]
                        )
                        - mean(
                            [
                                r["margin"]["log_odds"]
                                for r in cells
                                if r["job"]["target"] == target and not r["facts"]["supported"]
                            ]
                        )
                        for target in (0, 1)
                    ],
                    "correct": sum(r["forward_choice"] == r["facts"]["supported"] for r in cells),
                    "queries": 4,
                    "cells": [
                        {
                            "assignment": r["job"]["assignment"],
                            "target": r["job"]["target"],
                            "margin": r["margin"]["log_odds"],
                            "supported": r["facts"]["supported"],
                            "candidate_last": r["facts"]["candidate_last"],
                            "verdict": r["forward_choice"],
                        }
                        for r in cells
                    ],
                }
            )
    differences = []
    for b in [r for r in binding if r["condition"] == "metadata_false"]:
        t = next(
            r
            for r in binding
            if r["condition"] == "metadata_true"
            and all(r[k] == b[k] for k in ("block", "candidate", "schema", "reverse"))
        )
        differences.append(
            {
                **{k: b[k] for k in ("block", "stage", "candidate", "schema", "reverse")},
                "binding_false": b["binding_effect"],
                "binding_true": t["binding_effect"],
                "difference": t["binding_effect"] - b["binding_effect"],
            }
        )
    for stage, schema, cond in itertools.product(
        ("155", "156"), ("generic", "descriptive"), CONDITIONS
    ):
        subset = [
            r
            for r in binding
            if r["stage"] == stage and r["schema"] == schema and r["condition"] == cond
        ]
        accuracies.append(
            {
                "stage": stage,
                "schema": schema,
                "condition": cond,
                "correct": sum(r["correct"] for r in subset),
                "queries": sum(r["queries"] for r in subset),
            }
        )
    return binding, position, differences, accuracies


def qualify(binding, position, differences, controls, complete):
    prerequisites = (
        complete
        and all(controls.values())
        and (len(binding), len(position), len(differences)) == (128, 64, 32)
    )
    bs, ps, ds = [], [], []
    for stage, schema, cond, reverse in itertools.product(
        ("155", "156"), ("generic", "descriptive"), CONDITIONS, (0, 1)
    ):
        selected = [
            r
            for r in binding
            if (r["stage"], r["schema"], r["condition"], r["reverse"])
            == (stage, schema, cond, reverse)
        ]
        positive = sum(r["binding_effect"] > 0.25 for r in selected)
        additive = sum(abs(r["binding_effect"]) <= 0.25 for r in selected)
        bs.append(
            {
                "stage": stage,
                "schema": schema,
                "condition": cond,
                "reverse": reverse,
                "panels": len(selected),
                "positive": positive,
                "additive": additive,
                "positive_passed": len(selected) == 4 and positive >= 3,
                "additive_passed": len(selected) == 4 and additive >= 3,
            }
        )
    for stage, schema, cond in itertools.product(
        ("155", "156"), ("generic", "descriptive"), CONDITIONS
    ):
        selected = [
            r
            for r in position
            if (r["stage"], r["schema"], r["condition"]) == (stage, schema, cond)
        ]
        positive = sum(r["position_effect"] > 0.25 for r in selected)
        ps.append(
            {
                "stage": stage,
                "schema": schema,
                "condition": cond,
                "panels": len(selected),
                "positive": positive,
                "passed": len(selected) == 4 and positive >= 3,
            }
        )
    for stage, schema, reverse in itertools.product(
        ("155", "156"), ("generic", "descriptive"), (0, 1)
    ):
        selected = [
            r
            for r in differences
            if (r["stage"], r["schema"], r["reverse"]) == (stage, schema, reverse)
        ]
        compatible = sum(abs(r["difference"]) <= 0.25 for r in selected)
        ds.append(
            {
                "stage": stage,
                "schema": schema,
                "reverse": reverse,
                "panels": len(selected),
                "compatible": compatible,
                "passed": len(selected) == 4 and compatible >= 3,
            }
        )
    whole = {
        "positive_binding": prerequisites and all(s["positive_passed"] for s in bs),
        "query_additive": prerequisites and all(s["additive_passed"] for s in bs),
        "last_sentence_preference": prerequisites and all(s["passed"] for s in ps),
        "bit_baseline_at_binding_level": prerequisites and all(s["passed"] for s in ds),
    }
    whole["recency_only"] = whole["query_additive"] and whole["last_sentence_preference"]
    per_condition = {
        cond: {
            "positive_binding": prerequisites
            and all(s["positive_passed"] for s in bs if s["condition"] == cond),
            "query_additive": prerequisites
            and all(s["additive_passed"] for s in bs if s["condition"] == cond),
        }
        for cond in CONDITIONS
    }
    return {
        "qualified": whole,
        "prerequisites": prerequisites,
        "per_condition": per_condition,
        "binding_strata": bs,
        "position_strata": ps,
        "bit_strata": ds,
    }


def audit():
    bundle = json.loads((RUN / "design.json").read_text())
    d = bundle["design"]
    assert digest(d) == bundle["fingerprint"] and d["blocks"] == blocks()
    assert (d["effect_tolerance"], d["dominance"]) == (0.25, 0.75)
    sh = digest(
        {
            "runner": (ROOT / "scripts/run_counterbalanced_binding_155.py").read_text(),
            "protocol": (ROOT / "docs/experiments/155-156-counterbalanced-binding.md").read_text(),
            "dependencies": ancestor.source_hash(),
        }
    )
    assert sh == d["source_hash"]
    pa = json.loads((ROOT / "docs/analysis/151-152-independent-audit.json").read_text())
    assert pa["complete"] and pa["fingerprint"] == d["parent_fingerprint"]
    report = {"fingerprint": bundle["fingerprint"], "complete": True, "models": {}}
    for name, cfg in d["models"].items():
        rt = json.loads((RUN / name / "runtime.json").read_text())
        assert rt == json.loads((ancestor.DEFAULT / name / "runtime.json").read_text())
        tok = AutoTokenizer.from_pretrained(
            cfg["model"], revision=cfg["revision"], local_files_only=True
        )
        if tok.pad_token_id is None:
            tok.pad_token = tok.eos_token
        assert (
            digest(tok.get_vocab()) == rt["tokenizer_hash"]
            and tok.chat_template == rt["chat_template"]
        )
        old = {}
        for path in (ancestor.DEFAULT / name / "records").glob("*.json"):
            e = json.loads(path.read_text())
            r = e["record"]
            assert digest(r) == e["sha256"] and r["fingerprint"] == d["parent_fingerprint"]
            old[r["block"], digest(r["job"])] = r
        saved, cache, errors, future, prompt, public_count, replays = {}, {}, [], [], [], 0, 0
        for block in blocks():
            for j in jobs(block):
                rid = digest([block["id"], j])
                path = RUN / name / "records" / f"{rid}.json"
                if not path.exists():
                    continue
                e = json.loads(path.read_text())
                r = e["record"]
                assert (
                    digest(r) == e["sha256"]
                    and r["fingerprint"] == bundle["fingerprint"]
                    and r["runtime_hash"] == digest(rt)
                )
                assert r["block"] == block["id"] and r["stage"] == block["stage"] and r["job"] == j
                if j["kind"] == "given":
                    fake = {}
                    facts = {"supported": j["supported"]}
                    pj = j
                else:
                    fake, facts = source(block, j)
                    pj = {**j, "supported": facts["supported"]}
                assert (
                    r["facts"] == facts
                    and r["messages"] == expected_messages(fake, pj)
                    and r["choices"] == expected_choices(j)
                )
                prefix = tok.apply_chat_template(
                    r["messages"], tokenize=True, add_generation_prompt=True
                )
                seqs = [
                    tok.encode(c[0], add_special_tokens=False) + [tok.eos_token_id]
                    for c in r["choices"]
                ]
                assert (
                    len(prefix) <= 2048
                    and r["prompt_ids"] == prefix
                    and r["sequences"] == seqs
                    and len(seqs[0]) == len(seqs[1])
                )
                index = [i for i, (f, t) in enumerate(zip(*seqs)) if f != t]
                assert len(index) == 1 and index[0] == r["free_index"]
                f, t = seqs[0][index[0]], seqs[1][index[0]]
                inputs = prefix + seqs[0][: index[0]]
                assert (
                    r["false_token"] == f and r["true_token"] == t and r["free_input_ids"] == inputs
                )
                ck = digest([inputs, f, t])
                assert ck == r["cache_key"]
                if ck in cache:
                    assert not r["forward_executed"] and cache[ck] == (
                        r["first_forward_record"],
                        r["margin"],
                    )
                else:
                    assert r["forward_executed"] and r["first_forward_record"] == rid
                    cache[ck] = (rid, r["margin"])
                m = r["margin"]
                assert (
                    all(math.isfinite(v) for v in m.values())
                    and m["log_odds"] == m["true_score"] - m["false_score"]
                )
                winning = sorted(
                    [(m["false_score"], f, False), (m["true_score"], t, True)],
                    key=lambda x: (-x[0], x[1]),
                )[0][2]
                assert (
                    r["forward_choice"] == winning
                    and r["derived_ids"] == seqs[int(winning)]
                    and r["derived_raw"] == tok.decode(r["derived_ids"], skip_special_tokens=True)
                )
                assert (r["public_generation"] is not None) == public_selected(j)
                if r["public_generation"] is not None:
                    pub = r["public_generation"]
                    gm = pub["margin"]
                    public_count += 1
                    assert (
                        pub["ids"] == r["derived_ids"]
                        and pub["raw"] == r["derived_raw"]
                        and gm["free_index"] == index[0]
                    )
                    assert (
                        gm["false_token"] == f
                        and gm["true_token"] == t
                        and sorted(gm["finite_token_ids"]) == sorted([f, t])
                    )
                    assert (
                        gm["log_odds"] == gm["true_score"] - gm["false_score"]
                        and gm["selected_token"] == seqs[int(winning)][index[0]]
                    )
                    assert (gm["true_score"] if winning else gm["false_score"]) == max(
                        gm["true_score"], gm["false_score"]
                    )
                    errors.extend(abs(gm[k] - m[k]) for k in m)
                old_expected = (
                    block["old_block"] is not None
                    and j["kind"] != "given"
                    and (j["target"], j["candidate"], j["reverse"]) == (0, 1, 0)
                )
                assert (r["old_replay"] is not None) == old_expected
                if old_expected:
                    oj = {
                        "kind": j["kind"],
                        "supported": bool(j["assignment"]),
                        "schema": j["schema"],
                    }
                    if j["kind"] != "singleton":
                        oj.update(order=j["order"], clamp=j["clamp"])
                    o = old[block["old_block"], digest(oj)]
                    assert r["old_replay"] == {
                        "block": block["old_block"],
                        "job": oj,
                        "record_sha256": digest(o),
                    }
                    assert (
                        r["messages"] == o["messages"]
                        and inputs == o["free_input_ids"]
                        and m == o["forward_margin"]
                    )
                    replays += 1
                saved[rid] = r
        given = [r for r in saved.values() if r["job"]["kind"] == "given"]
        for r in saved.values():
            j = r["job"]
            if (
                j["kind"] == "given"
                or j["kind"] == "singleton"
                or j["order"] != "verdict_first"
                or j["clamp"]
            ):
                continue
            other = saved.get(digest([r["block"], {**j, "clamp": True}]))
            if other:
                future.append(
                    other["margin"] == r["margin"]
                    and other["free_input_ids"] == r["free_input_ids"]
                    and other["forward_choice"] == r["forward_choice"]
                )
        for r in saved.values():
            j = r["job"]
            if (
                j["kind"] == "given"
                or j["kind"] == "singleton"
                or j["order"] != "metadata_first"
                or j["clamp"]
            ):
                continue
            same = [
                saved.get(digest([r["block"], {**j, "order": order, "clamp": bit}]))
                for order, bit in itertools.product(
                    ("metadata_first", "verdict_first"), (False, True)
                )
            ]
            if all(x is not None for x in same):
                prompt.append(all(x["prompt_ids"] == r["prompt_ids"] for x in same))
        complete = (len(saved), len(cache), public_count, replays) == (656, 524, 48, 40)
        controls = {
            "direct_status": len(given) == 16
            and all(r["forward_choice"] == r["facts"]["supported"] for r in given),
            "generation_bridge": len(errors) == 144 and max(errors) <= 0.05,
            "future_clamp": len(future) == 128 and all(future),
            "identical_twofield_prompt": len(prompt) == 128 and all(prompt),
            "old_replays_exact": replays == 40,
            "forward_provenance": len(cache) == 524,
        }
        binding, position, diffs, accuracy = estimands(list(saved.values()))
        report["models"][name] = {
            "complete": complete,
            "records": len(saved),
            "physical_forwards": len(cache),
            "public_generations": public_count,
            "old_replays": replays,
            "controls": controls,
            "max_generation_bridge_error": max(errors) if errors else None,
            "signatures": qualify(binding, position, diffs, controls, complete),
            "binding_panels": binding,
            "position_panels": position,
            "bit_binding_differences": diffs,
            "accuracies": accuracy,
        }
        report["complete"] = report["complete"] and complete
    return report


if __name__ == "__main__":
    value = audit()
    OUT.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")
    print(
        json.dumps(
            {
                "complete": value["complete"],
                "models": {
                    n: {
                        "controls": m["controls"],
                        "counts": [m["records"], m["physical_forwards"], m["public_generations"]],
                        "qualified": m["signatures"]["qualified"],
                        "per_condition": m["signatures"]["per_condition"],
                        "max_generation_bridge_error": m["max_generation_bridge_error"],
                    }
                    for n, m in value["models"].items()
                },
            },
            indent=2,
        )
    )
