"""Independent complete crossing, operator targets and shared-C transmission tests."""

import itertools
import json
from pathlib import Path

import audit_shared_signed_curvature_187 as parent
import numpy as np
from transformers import AutoTokenizer

from latent_decisions.evidence_policy import digest, write_json

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / "runs/curvature-multiplication-188"
OUT = ROOT / "docs/analysis/188-independent-audit.json"
CUTS = ("live", "NW", "NWU")


def source_hash():
    return digest(
        {
            "runner": (ROOT / "scripts/run_curvature_multiplication_188.py").read_text(),
            "protocol": (
                ROOT / "docs/experiments/188-shared-curvature-multiplication.md"
            ).read_text(),
            "parent": parent.source_hash(),
        }
    )


def accounts(cells, qualified):
    panels = []
    for block, schema, rev in itertools.product(
        parent.parent.blocks(), ("generic", "descriptive"), range(2)
    ):
        rows = [
            c
            for c in cells
            if (c["block"], c["schema"], c["reverse"]) == (block["id"], schema, rev)
        ]
        assert len(rows) == 4
        eligible = all(abs(c["kappa"]["live"]) >= 0.2 for c in rows)
        survival = eligible and all(
            c["kappa"]["live"] * c["kappa"]["NW"] > 0
            and abs(c["kappa"]["NW"]) >= 0.5 * abs(c["kappa"]["live"])
            for c in rows
        )
        panels.append(
            {
                "block": block["id"],
                "schema": schema,
                "reverse": rev,
                "eligible": eligible,
                "survival": survival,
            }
        )
    strata = {
        f"{s}_{r}": sum(p["survival"] for p in panels if (p["schema"], p["reverse"]) == (s, r))
        for s, r in itertools.product(("generic", "descriptive"), range(2))
    }
    null_score = max(abs(c["kappa"]["NWU"]) for c in cells)
    null_state = max(c["state_shift_interaction"]["NWU"] for c in cells)
    return {
        "panels": panels,
        "survival_account": {
            "eligible_panels": sum(p["eligible"] for p in panels),
            "compatible_panels": sum(p["survival"] for p in panels),
            "strata": strata,
            "whole_passed": qualified and all(v >= 3 for v in strata.values()),
        },
        "architectural_null": {
            "maximum_score_interaction": null_score,
            "maximum_state_shift_interaction": null_state,
            "score_tolerance": 0.005,
            "state_shift_tolerance": 0.005,
            "all64_score_cells_passed": all(abs(c["kappa"]["NWU"]) <= 0.005 for c in cells),
            "all64_state_cells_passed": all(
                c["state_shift_interaction"]["NWU"] <= 0.005 for c in cells
            ),
            "passed": qualified and null_score <= 0.005 and null_state <= 0.005,
        },
    }


def trace_ok(q, z, prefix, targets, ups, pos, length, raw_caps, activation=False):
    native = parent.parent.native
    ct, ut = q["class_trace"], q["up_trace"]
    assert len(ct) == 141 and {v["site"] for v in ct} == native.sites()
    assert len(ut) == 28 and [v["site"] for v in ut] == list(range(1, 29))
    result = all(
        v["fixed"] == (v["site"] in targets)
        and v["other_rows_identical"]
        and (v["start"], v["end"]) == ((pos, pos + 1) if v["site"][0] == "V" else (pos + 1, length))
        and (
            v["site"] not in targets or v["applied_sha256"] == native.array_hash(targets[v["site"]])
        )
        and (v["site"][0] != "V" or v["applied_sha256"] == native.array_hash(raw_caps[v["site"]]))
        and (
            not activation
            or v["site"][0] != "G"
            or v["applied_sha256"]
            == native.array_hash(z[f"{prefix}_{v['site'].split('_')[1]}_output"])
        )
        for v in ct
    )
    result &= all(
        v["fixed"] == (ups is not None)
        and v["other_rows_identical"]
        and (v["start"], v["end"]) == (pos + 1, length)
        and (ups is None or v["output_sha256"] == native.array_hash(ups[v["site"]]))
        and (
            not activation or v["output_sha256"] == native.array_hash(z[f"{prefix}_U_{v['site']}"])
        )
        for v in ut
    )
    return result


def main():
    native = parent.parent.native
    b = json.loads((RUN / "design.json").read_text())
    status = json.loads((RUN / "pipeline-status.json").read_text())
    pa = json.loads(parent.OUT.read_text())
    assert digest(b["design"]) == b["fingerprint"] and b["design"]["source_hash"] == source_hash()
    assert status["status"] == "complete" and status["completed_forwards"] == 1024
    assert pa["complete"] and all(pa["controls"].values()) and pa["numerical_qualified"]
    assert pa["fingerprint"] == b["design"]["parent_fingerprint"]
    cfg = b["design"]["models"]["qwen15"]
    tok = AutoTokenizer.from_pretrained(
        cfg["model"], revision=cfg["revision"], local_files_only=True
    )
    rt = json.loads((RUN / "qwen15/runtime.json").read_text())
    assert (
        rt == json.loads((parent.RUN / "qwen15/runtime.json").read_text())
        and digest(tok.get_vocab()) == rt["tokenizer_hash"]
    )
    checks = {
        k: True
        for k in (
            "immutable_parent_sources_runtime",
            "complete1024_crossing",
            "natural_single_token_inputs",
            "raw_all141_factors_28_up_shapes_hashes",
            "all64_pair_mean_targets",
            "all128_exact_own_NWU_identities",
            "all256_exact187_live_replays",
            "all_receiving_clamp_targets_spans",
            "all28_paired_even_activation_formulas",
            "metadata_V_and_earlier_rows_native_exact",
            "public_score_arithmetic",
        )
    }
    cells, formula_error = [], 0.0
    for block, a, t, rev, schema in itertools.product(
        parent.parent.blocks(), range(2), range(2), range(2), ("generic", "descriptive")
    ):
        g = native.fixture.group(block, a, t, rev, schema)
        key = digest(g)
        e = native.read_record(RUN / "qwen15/records" / f"{key}.json")
        pe = native.read_record(parent.RUN / "qwen15/records" / f"{key}.json")
        r, pr = e["record"], pe["record"]
        assert r["fingerprint"] == b["fingerprint"] and r["parent_record_sha256"] == pe["sha256"]
        assert all(r[k] == pr[k] == v for k, v in g.items())
        p, pp = RUN / "qwen15/states" / f"{key}.npz", parent.RUN / "qwen15/states" / f"{key}.npz"
        assert native.hashed(p) == r["states_sha256"] and native.hashed(pp) == pr["states_sha256"]
        bases = [
            native.fixture.reconstruct(tok, block, native.fixture.job(g, bit)) for bit in range(2)
        ]
        pos, length = r["position"], len(bases[0]["free_input_ids"])
        checks["natural_single_token_inputs"] &= (
            bases == [v["base"] for v in r["raw"]]
            and length == len(bases[1]["free_input_ids"])
            and [
                i
                for i, (x, y) in enumerate(
                    zip(bases[0]["free_input_ids"], bases[1]["free_input_ids"])
                )
                if x != y
            ]
            == [pos]
        )
        assert len(r["raw"]) == len(r["identities"]) == 2 and len(r["patches"]) == 12
        assert {(q["cut"], q["arm"], q["bit"]) for q in r["patches"]} == set(
            itertools.product(CUTS, ("paired", "even"), range(2))
        )
        with np.load(p, allow_pickle=False) as z, np.load(pp, allow_pickle=False) as pz:
            caps = [{name: z[f"raw_{bit}_{name}"] for name in native.sites()} for bit in range(2)]
            raw_u = [{site: z[f"raw_{bit}_U_{site}"] for site in range(1, 29)} for bit in range(2)]
            shared = {
                name: native.midpoint(caps[0][name], caps[1][name])
                for name in native.sites()
                if name[0] in "NW"
            }
            shared_u = {
                site: native.midpoint(raw_u[0][site], raw_u[1][site]) for site in range(1, 29)
            }
            checks["all64_pair_mean_targets"] &= all(
                np.array_equal(v, z[f"shared_{name}"]) for name, v in shared.items()
            ) and all(np.array_equal(v, z[f"shared_U_{site}"]) for site, v in shared_u.items())
            for bit in range(2):
                h = z[f"raw_{bit}_final"]
                expected = next(
                    q["margin"] for q in pr["patches"] if (q["arm"], q["bit"]) == ("both", bit)
                )
                checks["all256_exact187_live_replays"] &= r["raw"][bit][
                    "margin"
                ] == expected and np.array_equal(h, pz[f"both_{bit}_final"])
                checks["raw_all141_factors_28_up_shapes_hashes"] &= h.shape == (length, 1536)
                q = r["raw"][bit]
                checks["raw_all141_factors_28_up_shapes_hashes"] &= (
                    trace_ok(q, z, "", {}, None, pos, length, caps[bit])
                    and all(
                        v["applied_sha256"] == native.array_hash(caps[bit][v["site"]])
                        for v in q["class_trace"]
                    )
                    and all(
                        v["output_sha256"] == native.array_hash(raw_u[bit][v["site"]])
                        for v in q["up_trace"]
                    )
                )
                for name, v in {
                    **caps[bit],
                    **{f"U_{s}": u for s, u in raw_u[bit].items()},
                }.items():
                    shape = (
                        (length - pos - 1, 1)
                        if name[0] == "N"
                        else (12, length - pos - 1, length)
                        if name[0] == "W"
                        else (length - pos - 1, 8960)
                        if name[0] in "GU"
                        else (256,)
                    )
                    checks["raw_all141_factors_28_up_shapes_hashes"] &= (
                        v.shape == shape and v.dtype == np.float32 and np.isfinite(v).all()
                    )
                    if name[0] == "N":
                        checks["raw_all141_factors_28_up_shapes_hashes"] &= (v > 0).all()
                    if name[0] == "W":
                        checks["raw_all141_factors_28_up_shapes_hashes"] &= (
                            (v >= 0).all()
                            and np.max(abs(v.astype(np.float64).sum(-1) - 1)) <= 1e-6
                            and all(
                                np.count_nonzero(v[:, row, pos + 2 + row :]) == 0
                                for row in range(length - pos - 1)
                            )
                        )
                q = r["identities"][bit]
                own = {name: v for name, v in caps[bit].items() if name[0] in "NW"}
                checks["all128_exact_own_NWU_identities"] &= (
                    q["bit"] == bit
                    and q["margin"] == r["raw"][bit]["margin"]
                    and np.array_equal(z[f"own_{bit}_final"], h)
                    and trace_ok(q, z, "", own, raw_u[bit], pos, length, caps[bit])
                )
            pairs = {cut: {} for cut in CUTS}
            shifts = {}
            for q in r["patches"]:
                cut, arm, bit = q["cut"], q["arm"], q["bit"]
                prefix = f"{cut}_{arm}_{bit}"
                h = z[f"{prefix}_final"]
                targets = shared if cut != "live" else {}
                ups = shared_u if cut == "NWU" else None
                checks["all_receiving_clamp_targets_spans"] &= trace_ok(
                    q, z, prefix, targets, ups, pos, length, caps[bit], True
                )
                checks["metadata_V_and_earlier_rows_native_exact"] &= h.shape == (
                    length,
                    1536,
                ) and np.array_equal(h[: pos + 1], z[f"raw_{bit}_final"][: pos + 1])
                at = q["activation_trace"]
                checks["all28_paired_even_activation_formulas"] &= (
                    len(at) == 28
                    and [v["site"] for v in at] == list(range(1, 29))
                    and all(
                        v["arm"] == arm
                        and v["bit"] == bit
                        and not v["endpoint_correction"]
                        and v["other_rows_identical"]
                        and (v["start"], v["end"]) == (pos + 1, length)
                        and v["input_sha256"] == native.array_hash(z[f"{prefix}_{v['site']}_input"])
                        and v["output_sha256"]
                        == native.array_hash(z[f"{prefix}_{v['site']}_output"])
                        for v in at
                    )
                )
                for site in range(1, 29):
                    x, y = z[f"{prefix}_{site}_input"], z[f"{prefix}_{site}_output"]
                    m = {
                        name: pz[f"map_{site}_{name}"]
                        for name in ("center", "intercept", "slope", "even")
                    }
                    pred = m["intercept"] + m["slope"] * (x - m["center"])
                    if arm == "even":
                        pred = pred + m["even"]
                    formula_error = max(formula_error, float(np.max(abs(y - pred))))
                    checks["all28_paired_even_activation_formulas"] &= (
                        x.shape == y.shape == (length - pos - 1, 8960)
                        and np.isfinite(x).all()
                        and np.isfinite(y).all()
                    )
                if cut == "live":
                    expected = next(
                        v["margin"] for v in pr["patches"] if (v["arm"], v["bit"]) == (arm, bit)
                    )
                    checks["all256_exact187_live_replays"] &= q[
                        "margin"
                    ] == expected and np.array_equal(h, pz[f"{arm}_{bit}_final"])
                pairs[cut][(arm, bit)] = q["margin"]["log_odds"]
            for cut in CUTS:
                shifts[cut] = float(
                    np.max(
                        abs(
                            (
                                z[f"{cut}_even_1_final"][pos + 1 :].astype(np.float64)
                                - z[f"{cut}_paired_1_final"][pos + 1 :]
                            )
                            - (
                                z[f"{cut}_even_0_final"][pos + 1 :].astype(np.float64)
                                - z[f"{cut}_paired_0_final"][pos + 1 :]
                            )
                        )
                    )
                )
            ds = {
                cut: {
                    arm: pairs[cut][(arm, 1)] - pairs[cut][(arm, 0)] for arm in ("paired", "even")
                }
                for cut in CUTS
            }
            cells.append(
                {
                    **g,
                    "supported": bases[0]["facts"]["supported"],
                    "margins": {
                        cut: {
                            arm: [pairs[cut][(arm, bit)] for bit in range(2)]
                            for arm in ("paired", "even")
                        }
                        for cut in CUTS
                    },
                    "deltas": ds,
                    "kappa": {cut: ds[cut]["even"] - ds[cut]["paired"] for cut in CUTS},
                    "state_shift_interaction": shifts,
                }
            )
            checks["public_score_arithmetic"] &= all(
                native.margin_valid(q["margin"]) for q in r["raw"] + r["identities"] + r["patches"]
            )
    checks["complete1024_crossing"] &= (
        len(cells) == len(list((RUN / "qwen15/records").glob("*.json"))) == 64
    )
    checks["all28_paired_even_activation_formulas"] &= formula_error <= 1e-5
    numerical = False
    p = ROOT / "docs/analysis/188-numerical-recheck.json"
    if p.exists():
        n = json.loads(p.read_text())
        paths = {
            "source_sha256": ROOT / "scripts/recheck_curvature_multiplication_188.py",
            "audit_sha256": Path(__file__),
            "public_helper_sha256": ROOT / "scripts/recheck_natural_bit_shared_reader_181.py",
            "activation_helper_sha256": ROOT / "scripts/recheck_shared_signed_curvature_187.py",
            "component_helper_sha256": Path(parent.__file__),
        }
        numerical = (
            n["passed"]
            and n["fingerprint"] == b["fingerprint"]
            and n["forwards"] == 64
            and all(n[k] == native.hashed(v) for k, v in paths.items())
        )
    result = {
        "complete": True,
        "fingerprint": b["fingerprint"],
        "main_forwards": 1024,
        "controls": {k: bool(v) for k, v in checks.items()},
        "maximum_activation_formula_error": formula_error,
        "numerical_qualified": numerical,
        "cells": cells,
        **accounts(cells, numerical and all(checks.values())),
        "scope": "Conditional transmission under paired dense operator cuts. Architectural null is distinct from survival; neither identifies a unique native mechanism or constitutes a preference forecast.",
    }
    write_json(OUT, result)
    print(json.dumps({k: v for k, v in result.items() if k not in ("cells", "panels")}, indent=2))


if __name__ == "__main__":
    main()
