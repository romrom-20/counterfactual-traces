"""Reconstruct discovery-only selections and every heldout native-response account."""

import hashlib
import itertools
import json
from pathlib import Path

import audit_layerwise_nonlinear_remainder_199 as parent
import numpy as np
from audit_one_sided_gain_forecast_186 import ordered
from transformers import AutoTokenizer

from latent_decisions.evidence_policy import digest, write_json

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / "runs/discovery-ranked-repair-200"
OUT = ROOT / "docs/analysis/200-independent-audit.json"
ARMS = (
    "source_linear",
    "exact_readout",
    "residual_blocks",
    "margin_blocks",
    "union_blocks",
    "control_blocks",
)
FILES = (
    "scripts/run_discovery_ranked_repair_200.py",
    "scripts/audit_discovery_ranked_repair_200.py",
    "scripts/recheck_discovery_ranked_repair_200.py",
    "scripts/ranked_block_response_200.py",
    "scripts/public_ranked_block_response_200.py",
    "docs/experiments/200-discovery-ranked-finite-block-repair.md",
)
LITERALS = (
    ("cobalt", "indium", "Tuesday", "Sunday"),
    ("pebble", "stone", "Wednesday", "Friday"),
    ("fresco", "stencil", "Monday", "Thursday"),
    ("reef", "shoal", "Saturday", "Tuesday"),
)
native = parent.parent.native


def blocks():
    return [
        {"id": a, "stage": "200", "subjects": [a, b], "days": [x, y], "old_block": None}
        for a, b, x, y in LITERALS
    ]


def hashed(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def source_hash():
    return digest(
        {"files": {p: (ROOT / p).read_text() for p in FILES}, "parent": parent.source_hash()}
    )


def selections(discovery):
    scores = []
    for block in range(2, 29):
        residual = (
            sum(
                abs(r["rows"][block - 2]["error_direction_contribution"])
                / r["budget"]["observed_final_error_norm"]
                for r in discovery["records"]
            )
            / 64
        )
        margin = (
            sum(
                abs(r["rows"][block - 2]["margin_contribution"])
                / max(abs(r["budget"]["actual_margin_error"]), 0.1)
                for r in discovery["records"]
            )
            / 64
        )
        scores.append({"block": block, "residual_score": residual, "margin_score": margin})
    rs = sorted(scores, key=lambda r: (-r["residual_score"], r["block"]))
    ms = sorted(scores, key=lambda r: (-r["margin_score"], r["block"]))
    residual, margin = sorted(r["block"] for r in rs[:2]), sorted(r["block"] for r in ms[:2])
    union = sorted(set(residual + margin))
    rr, mr = {r["block"]: i for i, r in enumerate(rs)}, {r["block"]: i for i, r in enumerate(ms)}
    controls = sorted(
        (b for b in range(2, 29) if b not in union), key=lambda b: (-(rr[b] + mr[b]), b)
    )[: len(union)]
    return {
        "residual": residual,
        "margin": margin,
        "union": union,
        "control": sorted(controls),
        "scores": scores,
        "discovery_fingerprint": discovery["fingerprint"],
    }


def measure(actual, prediction):
    norm, pn = float(np.linalg.norm(actual)), float(np.linalg.norm(prediction))
    return {
        "norm": norm,
        "relative_error": float(np.linalg.norm(actual - prediction) / norm) if norm else None,
        "cosine": float(np.dot(actual.ravel(), prediction.ravel()) / (norm * pn))
        if norm and pn
        else None,
    }


def matched(value):
    return (
        value["norm"] >= 0.001
        and value["relative_error"] is not None
        and value["relative_error"] <= 0.05
        and value["cosine"] is not None
        and value["cosine"] >= 0.99
    )


def main():
    bundle = json.loads((RUN / "design.json").read_text())
    status = json.loads((RUN / "pipeline-status.json").read_text())
    pa = json.loads(parent.OUT.read_text())
    assert pa["numerical_qualified"] and all(pa["controls"].values())
    assert pa["fingerprint"] == bundle["design"]["parent_fingerprint"]
    assert (
        bundle["fingerprint"] == digest(bundle["design"])
        and bundle["design"]["source_hash"] == source_hash()
    )
    assert hashed(parent.OUT) == bundle["design"]["parent_audit_sha256"]
    actual_sel, declared = selections(pa), bundle["design"]["selection"]
    assert all(actual_sel[k] == declared[k] for k in actual_sel if k != "scores")
    selection_error = max(
        abs(a[k] - b[k])
        for a, b in zip(actual_sel["scores"], declared["scores"])
        for k in ("residual_score", "margin_score")
    )
    assert selection_error <= 1e-12 and digest(declared) == bundle["design"]["selection_sha256"]
    assert status["status"] == "complete" and all(
        status[k] == v for k, v in bundle["design"].items() if k in status and isinstance(v, int)
    )
    spec = bundle["design"]["models"]["qwen15"]
    tok = AutoTokenizer.from_pretrained(
        spec["model"], revision=spec["revision"], local_files_only=True
    )
    rt = json.loads((RUN / "runtime.json").read_text())
    assert (
        rt == json.loads((parent.RUN / "runtime.json").read_text())
        and digest(tok.get_vocab()) == rt["tokenizer_hash"]
    )
    manifest = json.loads((RUN / "forecast-manifest.json").read_text())
    assert (
        digest(manifest["manifest"]) == manifest["sha256"]
        and manifest["ordinary_false_model_invocations"] == 64
    )
    bykey = {r["key"]: r for r in manifest["manifest"]}
    controls = {
        k: True
        for k in (
            "immutable_source_runtime_qualified_parent",
            "predeclared_discovery_selection_reconstructed",
            "all64single_token_prefix_pairs",
            "global_all_forecasts_before_any_true",
            "finite_all_rows_scores_shapes",
            "all_local_false_primal_bounds",
            "all_head_anchor_bounds",
            "firstblock_source_matches_native_true",
            "complete64pairs_128ordinary_localcounts",
        )
    }
    cells, before, after = [], [], []
    max_source_error = 0.0
    for block, a, t, rev, schema in itertools.product(
        blocks(), range(2), range(2), range(2), ("generic", "descriptive")
    ):
        g = native.fixture.group(block, a, t, rev, schema)
        key = digest(g)
        fp, op = RUN / "forecasts" / f"{key}.npz", RUN / "observations" / f"{key}.npz"
        f, o = (
            native.read_record(fp.with_suffix(".json")),
            native.read_record(op.with_suffix(".json")),
        )
        fr, obs = f["record"], o["record"]
        assert fr["fingerprint"] == obs["fingerprint"] == bundle["fingerprint"]
        assert obs["forecast_record_sha256"] == f["sha256"]
        assert hashed(fp) == fr["states_sha256"] and hashed(op) == obs["states_sha256"]
        assert bykey[key] == {
            "key": key,
            "record_sha256": f["sha256"],
            "states_sha256": fr["states_sha256"],
        }
        bases = [
            native.fixture.reconstruct(tok, block, native.fixture.job(g, bit)) for bit in range(2)
        ]
        pos, length = fr["position"], len(bases[0]["free_input_ids"])
        controls["all64single_token_prefix_pairs"] &= (
            bases == fr["bases"]
            and len(bases[1]["free_input_ids"]) == length
            and [
                i
                for i, (x, y) in enumerate(
                    zip(bases[0]["free_input_ids"], bases[1]["free_input_ids"])
                )
                if x != y
            ]
            == [pos]
        )
        before.append(fr["completed_utc"])
        after.append(obs["started_utc"])
        controls["all_head_anchor_bounds"] &= fr["head_anchor_error"] <= 0.005
        with np.load(fp, allow_pickle=False) as z, np.load(op, allow_pickle=False) as oz:
            controls["finite_all_rows_scores_shapes"] &= all(
                np.isfinite(v).all() for table in (z, oz) for v in table.values()
            ) and z["false_rows"].shape == oz["true_rows"].shape == (28, 2, 1536)
            actual = oz["true_rows"].astype(np.float64) - z["false_rows"].astype(np.float64)
            source_actual = oz["true_first"].astype(np.float64) - z["false_first"].astype(
                np.float64
            )
            source_error = float(np.max(abs(source_actual - z["source_first_delta"])))
            max_source_error = max(max_source_error, source_error)
            controls["firstblock_source_matches_native_true"] &= (
                source_error <= 1e-4
                and np.count_nonzero(source_actual[:pos])
                == np.count_nonzero(z["source_first_delta"][:pos])
                == 0
            )
            sf, st = z["false_scores"].astype(np.float64), oz["true_scores"].astype(np.float64)
            dm = float((st[1] - st[0]) - (sf[1] - sf[0]))
            for arm in ARMS:
                finite = (
                    []
                    if arm in ("source_linear", "exact_readout")
                    else declared[
                        {
                            "residual_blocks": "residual",
                            "margin_blocks": "margin",
                            "union_blocks": "union",
                            "control_blocks": "control",
                        }[arm]
                    ]
                )
                metadata = fr["arms"][arm]
                assert metadata["finite_blocks"] == sorted({1, *finite}) and metadata[
                    "finite_head"
                ] == (arm != "source_linear")
                assert metadata["local_finite_block_calls"] == len(finite) and metadata[
                    "local_block_ad_calls"
                ] == 27 - len(finite)
                controls["all_local_false_primal_bounds"] &= (
                    metadata["maximum_primal_error"] <= 1e-4
                )
                pred, ds = (
                    z[f"{arm}_delta_rows"].astype(np.float64),
                    z[f"{arm}_delta_scores"].astype(np.float64),
                )
                controls["finite_all_rows_scores_shapes"] &= pred.shape == (
                    28,
                    2,
                    1536,
                ) and ds.shape == (2,)
                cells.append(
                    {
                        **g,
                        "arm": arm,
                        "supported": bases[0]["facts"]["supported"],
                        "source": measure(actual[0, 0], pred[0, 0]),
                        "final": measure(actual[-1, -1], pred[-1, -1]),
                        "actual_delta_margin": dm,
                        "predicted_delta_margin": float(ds[1] - ds[0]),
                        "margin_error": float(ds[1] - ds[0]) - dm,
                        "all28_verdict_relative_errors": [
                            measure(actual[i, -1], pred[i, -1])["relative_error"] for i in range(28)
                        ],
                    }
                )
    controls["global_all_forecasts_before_any_true"] &= ordered(
        before, manifest["completed_utc"], after
    )
    controls["complete64pairs_128ordinary_localcounts"] &= (
        len(bykey)
        == len(before)
        == len(after)
        == len(list((RUN / "forecasts").glob("*.json")))
        == len(list((RUN / "observations").glob("*.json")))
        == 64
        and len(cells) == 384
    )
    numerical = False
    npath = ROOT / "docs/analysis/200-numerical-recheck.json"
    if npath.exists():
        n = json.loads(npath.read_text())
        numerical = (
            n["passed"]
            and n["fingerprint"] == bundle["fingerprint"]
            and n["source_sha256"]
            == hashed(ROOT / "scripts/recheck_discovery_ranked_repair_200.py")
            and n["audit_sha256"] == hashed(Path(__file__))
            and n["public_helper_sha256"]
            == hashed(ROOT / "scripts/public_ranked_block_response_200.py")
            and n["ordinary_model_invocations"] == 16
            and n["forward_false_model_invocations"] == 48
            and n["reverse_false_model_invocations"] == 8
        )
    panels = []
    for block, schema, rev, arm in itertools.product(
        blocks(), ("generic", "descriptive"), range(2), ARMS
    ):
        rs = [
            c
            for c in cells
            if (c["block"], c["schema"], c["reverse"], c["arm"]) == (block["id"], schema, rev, arm)
        ]
        base = {
            (c["assignment"], c["target"]): c
            for c in cells
            if (c["block"], c["schema"], c["reverse"], c["arm"])
            == (block["id"], schema, rev, "source_linear")
        }
        assert len(rs) == len(base) == 4
        progress = all(
            c["final"]["relative_error"]
            <= 0.5 * base[(c["assignment"], c["target"])]["final"]["relative_error"]
            and abs(c["margin_error"])
            <= 0.5 * abs(base[(c["assignment"], c["target"])]["margin_error"])
            for c in rs
        )
        balanced = sum((1 if c["supported"] else -1) * c["margin_error"] for c in rs) / 2
        panels.append(
            {
                "block": block["id"],
                "schema": schema,
                "reverse": rev,
                "arm": arm,
                "source_matching": all(matched(c["source"]) for c in rs),
                "individual_matching": all(abs(c["margin_error"]) <= 0.1 for c in rs),
                "residual_matching": all(matched(c["final"]) for c in rs),
                "prospective_progress": progress,
                "balanced_matching": abs(balanced) <= 0.1,
                "balanced_error": balanced,
            }
        )
    accounts = {}
    for metric in (
        "source_matching",
        "individual_matching",
        "residual_matching",
        "prospective_progress",
        "balanced_matching",
    ):
        accounts[metric] = {}
        for arm in ARMS:
            rs = [p for p in panels if p["arm"] == arm]
            strata = {
                f"{s}_{r}": sum(p[metric] for p in rs if (p["schema"], p["reverse"]) == (s, r))
                for s, r in itertools.product(("generic", "descriptive"), range(2))
            }
            accounts[metric][arm] = {
                "compatible_panels": sum(p[metric] for p in rs),
                "strata": strata,
                "whole_passed": numerical
                and all(controls.values())
                and all(v >= 3 for v in strata.values()),
            }
    result = {
        "fingerprint": bundle["fingerprint"],
        "controls": {k: bool(v) for k, v in controls.items()},
        "numerical_qualified": numerical,
        "selection": declared,
        "selection_reconstruction_error": selection_error,
        "maximum_source_coordinate_error": max_source_error,
        "cells": cells,
        "panels": panels,
        "accounts": accounts,
        "scope": "Genuinely newFalse-only coefficient/knownedit/component-function forecasts; discoveryTrue used only forpredeclaredblockIDranking. Up to4finiteblocks includingSource, remainingFalseJ; fullknownfunctions stillcomputed/notcheap learnedcircuit. Macroblockprediction improvement notuniqueprimitivecausality/priority/competence; onecheckpoint/dependenttemplates/groundingfailures. Original196primitive reverse-over-reverse discrepancy unresolved.",
    }
    write_json(OUT, result)
    print(json.dumps({k: v for k, v in result.items() if k not in ("cells", "panels")}, indent=2))


if __name__ == "__main__":
    main()
