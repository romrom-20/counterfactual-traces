"""Separately labeled198 mixed-validation accounts; preserve the failed196audit."""

import json
from pathlib import Path

import audit_first_block_primitive_repair_196 as original

from latent_decisions.evidence_policy import write_json

ROOT = Path(__file__).resolve().parents[1]


def main():
    a = json.loads(original.OUT.read_text())
    n = json.loads((ROOT / "docs/analysis/198-dual-primitive-recheck.json").read_text())
    design = json.loads((original.RUN / "design.json").read_text())
    assert original.source_hash() == design["design"]["source_hash"]
    assert a["fingerprint"] == n["fingerprint"] == design["fingerprint"]
    assert not a["numerical_qualified"] and all(a["controls"].values())
    assert n["source_sha256"] == original.hashed(
        ROOT / "scripts/check_dual_primitive_reconstruction_198.py"
    )
    assert n["protocol_sha256"] == original.hashed(
        ROOT / "docs/experiments/198-dual-revalidation.md"
    )
    assert n["original_numerical_sha256"] == original.hashed(
        ROOT / "docs/analysis/196-numerical-recheck.json"
    )
    for arm_accounts in a["accounts"].values():
        for account in arm_accounts.values():
            account["whole_passed"] = n["passed"] and all(
                v >= 3 for v in account["strata"].values()
            )
    a.update(
        validation_stage=198,
        numerical_qualified=n["passed"],
        original196_numerical_qualified=False,
        qualification_scope=n["scope"],
        original_audit_sha256=original.hashed(original.OUT),
        revalidation_sha256=original.hashed(ROOT / "docs/analysis/198-dual-primitive-recheck.json"),
    )
    write_json(ROOT / "docs/analysis/198-revalidated-196-audit.json", a)
    print(
        json.dumps(
            {
                "qualified": n["passed"],
                "maximum_local_coordinate_error": n["maximum_direction_error"],
                "original196qualification_preserved": False,
                "accounts": a["accounts"],
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
