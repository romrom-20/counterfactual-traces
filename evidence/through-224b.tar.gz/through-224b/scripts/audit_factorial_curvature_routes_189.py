"""Complete conditional N/W/U factorial with parent references explicitly counted."""

import itertools
import json
import math
from pathlib import Path

import audit_curvature_multiplication_188 as parent
import numpy as np
from transformers import AutoTokenizer

from latent_decisions.evidence_policy import digest, write_json

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / "runs/factorial-curvature-routes-189"
OUT = ROOT / "docs/analysis/189-independent-audit.json"
NEW = ("U", "N", "W", "NU", "WU")
CUTS = ("live", "N", "W", "U", "NW", "NU", "WU", "NWU")
native = parent.parent.parent.native


def blocks():
    return parent.parent.parent.blocks()


def source_hash():
    return digest(
        {
            "runner": (ROOT / "scripts/run_factorial_curvature_routes_189.py").read_text(),
            "protocol": (ROOT / "docs/experiments/189-factorial-curvature-routes.md").read_text(),
            "parent": parent.source_hash(),
        }
    )


def accounts(cells, valid):
    panels = []
    for block, schema, rev in itertools.product(blocks(), ("generic", "descriptive"), range(2)):
        rows = [
            c
            for c in cells
            if (c["block"], c["schema"], c["reverse"]) == (block["id"], schema, rev)
        ]
        assert len(rows) == 4
        eligible = all(abs(c["kappa"]["live"]) >= 0.2 for c in rows)
        feedback_eligible = all(abs(c["kappa"]["U"]) >= 0.2 for c in rows)
        matches = {
            "up_bottleneck": eligible and all(abs(c["kappa"]["U"]) <= 0.1 for c in rows),
            "feedback_restoration": eligible
            and all(
                c["kappa"]["live"] * c["kappa"]["U"] > 0
                and abs(c["kappa"]["U"]) >= 0.5 * abs(c["kappa"]["live"])
                for c in rows
            ),
            **{
                name: feedback_eligible
                and all(
                    abs(c["kappa"][cut] - c["kappa"]["U"]) <= 0.1
                    and c["kappa"][cut] * c["kappa"]["U"] > 0
                    and abs(c["kappa"][cut]) >= 0.5 * abs(c["kappa"]["U"])
                    for c in rows
                )
                for name, cut in (
                    ("norm_only_conditional", "WU"),
                    ("attention_only_conditional", "NU"),
                )
            },
        }
        panels.append(
            {
                "block": block["id"],
                "schema": schema,
                "reverse": rev,
                "live_eligible": eligible,
                "feedback_eligible": feedback_eligible,
                "matches": matches,
                "mean_up_fraction": math.fsum(
                    abs(c["kappa"]["U"] / c["kappa"]["live"]) for c in rows
                )
                / 4,
                "all_up_signs_retained": all(
                    c["kappa"]["U"] * c["kappa"]["live"] > 0 for c in rows
                ),
            }
        )
    outcomes = {}
    for name in panels[0]["matches"]:
        strata = {
            f"{s}_{r}": sum(
                p["matches"][name] for p in panels if (p["schema"], p["reverse"]) == (s, r)
            )
            for s, r in itertools.product(("generic", "descriptive"), range(2))
        }
        outcomes[name] = {
            "compatible_panels": sum(p["matches"][name] for p in panels),
            "eligible_panels": sum(
                p["feedback_eligible" if name.endswith("conditional") else "live_eligible"]
                for p in panels
            ),
            "strata": strata,
            "whole_passed": valid and all(v >= 3 for v in strata.values()),
        }
    comparisons = []
    for block, rev in itertools.product(blocks(), range(2)):
        g, d = [
            next(
                p
                for p in panels
                if (p["block"], p["schema"], p["reverse"]) == (block["id"], schema, rev)
            )
            for schema in ("generic", "descriptive")
        ]
        difference = g["mean_up_fraction"] - d["mean_up_fraction"]
        comparisons.append(
            {
                "block": block["id"],
                "reverse": rev,
                "generic_fraction": g["mean_up_fraction"],
                "descriptive_fraction": d["mean_up_fraction"],
                "difference": difference,
                "matching": g["all_up_signs_retained"]
                and g["live_eligible"]
                and d["live_eligible"]
                and difference >= 0.1,
            }
        )
    strata = {
        str(rev): sum(c["matching"] for c in comparisons if c["reverse"] == rev) for rev in range(2)
    }
    outcomes["generic_preferential_feedback_fraction"] = {
        "compatible_comparisons": sum(c["matching"] for c in comparisons),
        "strata": strata,
        "whole_passed": valid and all(v >= 3 for v in strata.values()),
    }
    return {"panels": panels, "schema_comparisons": comparisons, "accounts": outcomes}


def main():
    b = json.loads((RUN / "design.json").read_text())
    status = json.loads((RUN / "pipeline-status.json").read_text())
    pa = json.loads(parent.OUT.read_text())
    assert digest(b["design"]) == b["fingerprint"] and b["design"]["source_hash"] == source_hash()
    assert status["status"] == "complete" and status["completed_forwards"] == 1536
    assert (
        pa["complete"]
        and pa["numerical_qualified"]
        and all(pa["controls"].values())
        and pa["fingerprint"] == b["design"]["parent_fingerprint"]
    )
    cfg = b["design"]["models"]["qwen15"]
    tok = AutoTokenizer.from_pretrained(
        cfg["model"], revision=cfg["revision"], local_files_only=True
    )
    rt = json.loads((RUN / "qwen15/runtime.json").read_text())
    assert (
        rt == json.loads((parent.RUN / "qwen15/runtime.json").read_text())
        and digest(tok.get_vocab()) == rt["tokenizer_hash"]
    )
    checks = {
        name: True
        for name in (
            "immutable_parent_map_sources_runtime",
            "complete1536_new_crossing",
            "all64_natural_single_token_pairs",
            "all141_factors_28_up_shapes_hashes",
            "all128_exact_raw_full_capture_replays",
            "all128_exact_own_NWU_identities",
            "all64_exact_parent_means",
            "all_clamp_targets_spans",
            "all28_paired_even_formulas",
            "metadata_V_prefix_native_exact",
            "parent_reference_provenance_not_new_executions",
            "public_score_arithmetic",
        )
    }
    cells, formula_error = [], 0.0
    parent_cells = {
        (c["block"], c["assignment"], c["target"], c["reverse"], c["schema"]): c
        for c in pa["cells"]
    }
    for block, a, t, rev, schema in itertools.product(
        blocks(), range(2), range(2), range(2), ("generic", "descriptive")
    ):
        g = native.fixture.group(block, a, t, rev, schema)
        key = digest(g)
        e = native.read_record(RUN / "qwen15/records" / f"{key}.json")
        pe = native.read_record(parent.RUN / "qwen15/records" / f"{key}.json")
        me = native.read_record(parent.parent.RUN / "qwen15/records" / f"{key}.json")
        r, pr, mr = e["record"], pe["record"], me["record"]
        assert (
            r["fingerprint"] == b["fingerprint"]
            and r["parent_record_sha256"] == pe["sha256"]
            and r["map_record_sha256"] == pr["parent_record_sha256"] == me["sha256"]
        )
        assert all(r[k] == pr[k] == mr[k] == v for k, v in g.items())
        p, pp, mp = (
            base / "qwen15/states" / f"{key}.npz" for base in (RUN, parent.RUN, parent.parent.RUN)
        )
        assert (
            native.hashed(p) == r["states_sha256"]
            and native.hashed(pp) == pr["states_sha256"]
            and native.hashed(mp) == mr["states_sha256"]
        )
        bases = [
            native.fixture.reconstruct(tok, block, native.fixture.job(g, bit)) for bit in range(2)
        ]
        pos, length = r["position"], len(bases[0]["free_input_ids"])
        checks["all64_natural_single_token_pairs"] &= (
            bases == [q["base"] for q in r["raw"]]
            and length == len(bases[1]["free_input_ids"])
            and [
                i
                for i, (x, y) in enumerate(
                    zip(bases[0]["free_input_ids"], bases[1]["free_input_ids"])
                )
                if x != y
            ]
            == [pos]
        )
        assert len(r["raw"]) == len(r["identities"]) == 2 and len(r["patches"]) == 20
        assert {(q["cut"], q["arm"], q["bit"]) for q in r["patches"]} == set(
            itertools.product(NEW, ("paired", "even"), range(2))
        )
        with (
            np.load(p, allow_pickle=False) as z,
            np.load(pp, allow_pickle=False) as pz,
            np.load(mp, allow_pickle=False) as mz,
        ):
            caps = [{name: z[f"raw_{bit}_{name}"] for name in native.sites()} for bit in range(2)]
            ups = [{site: z[f"raw_{bit}_U_{site}"] for site in range(1, 29)} for bit in range(2)]
            means = {
                name: native.midpoint(caps[0][name], caps[1][name])
                for name in native.sites()
                if name[0] in "NW"
            }
            mean_u = {site: native.midpoint(ups[0][site], ups[1][site]) for site in range(1, 29)}
            checks["all64_exact_parent_means"] &= all(
                np.array_equal(v, z[f"shared_{name}"]) and np.array_equal(v, pz[f"shared_{name}"])
                for name, v in means.items()
            ) and all(
                np.array_equal(v, z[f"shared_U_{site}"])
                and np.array_equal(v, pz[f"shared_U_{site}"])
                for site, v in mean_u.items()
            )
            for bit in range(2):
                raw, own = r["raw"][bit], r["identities"][bit]
                h = z[f"raw_{bit}_final"]
                all_cap = {**caps[bit], **{f"U_{site}": v for site, v in ups[bit].items()}}
                checks["all128_exact_raw_full_capture_replays"] &= (
                    raw["margin"] == pr["raw"][bit]["margin"]
                    and np.array_equal(h, pz[f"raw_{bit}_final"])
                    and all(
                        np.array_equal(v, pz[f"raw_{bit}_{name}"]) for name, v in all_cap.items()
                    )
                )
                checks["all141_factors_28_up_shapes_hashes"] &= (
                    parent.trace_ok(raw, z, "", {}, None, pos, length, caps[bit])
                    and all(
                        v["applied_sha256"] == native.array_hash(caps[bit][v["site"]])
                        for v in raw["class_trace"]
                    )
                    and all(
                        v["output_sha256"] == native.array_hash(ups[bit][v["site"]])
                        for v in raw["up_trace"]
                    )
                )
                for name, v in all_cap.items():
                    shape = (
                        (length - pos - 1, 1)
                        if name[0] == "N"
                        else (12, length - pos - 1, length)
                        if name[0] == "W"
                        else (length - pos - 1, 8960)
                        if name[0] in "GU"
                        else (256,)
                    )
                    checks["all141_factors_28_up_shapes_hashes"] &= (
                        v.shape == shape and v.dtype == np.float32 and np.isfinite(v).all()
                    )
                    if name[0] == "N":
                        checks["all141_factors_28_up_shapes_hashes"] &= (v > 0).all()
                    if name[0] == "W":
                        checks["all141_factors_28_up_shapes_hashes"] &= (
                            (v >= 0).all()
                            and np.max(abs(v.astype(np.float64).sum(-1) - 1)) <= 1e-6
                            and all(
                                np.count_nonzero(v[:, row, pos + 2 + row :]) == 0
                                for row in range(length - pos - 1)
                            )
                        )
                checks["all128_exact_own_NWU_identities"] &= (
                    own["bit"] == bit
                    and own["margin"] == raw["margin"]
                    and np.array_equal(z[f"own_{bit}_final"], h)
                    and parent.trace_ok(
                        own,
                        z,
                        "",
                        {name: v for name, v in caps[bit].items() if name[0] in "NW"},
                        ups[bit],
                        pos,
                        length,
                        caps[bit],
                    )
                )
            cparent = parent_cells[(g["block"], a, t, rev, schema)]
            pairs = {cut: cparent["margins"][cut] for cut in ("live", "NW", "NWU")}
            for cut in pairs:
                checks["parent_reference_provenance_not_new_executions"] &= all(
                    next(
                        q["margin"]["log_odds"]
                        for q in pr["patches"]
                        if (q["cut"], q["arm"], q["bit"]) == (cut, arm, bit)
                    )
                    == pairs[cut][arm][bit]
                    for arm, bit in itertools.product(("paired", "even"), range(2))
                )
            for cut in NEW:
                pairs[cut] = {
                    arm: [
                        next(
                            q["margin"]["log_odds"]
                            for q in r["patches"]
                            if (q["cut"], q["arm"], q["bit"]) == (cut, arm, bit)
                        )
                        for bit in range(2)
                    ]
                    for arm in ("paired", "even")
                }
            for q in r["patches"]:
                cut, arm, bit = q["cut"], q["arm"], q["bit"]
                prefix = f"{cut}_{arm}_{bit}"
                targets = {name: v for name, v in means.items() if name[0] in cut}
                fixed_u = mean_u if "U" in cut else None
                h = z[f"{prefix}_final"]
                checks["all_clamp_targets_spans"] &= parent.trace_ok(
                    q, z, prefix, targets, fixed_u, pos, length, caps[bit], True
                )
                checks["metadata_V_prefix_native_exact"] &= h.shape == (
                    length,
                    1536,
                ) and np.array_equal(h[: pos + 1], z[f"raw_{bit}_final"][: pos + 1])
                at = q["activation_trace"]
                checks["all28_paired_even_formulas"] &= (
                    len(at) == 28
                    and [v["site"] for v in at] == list(range(1, 29))
                    and all(
                        v["arm"] == arm
                        and v["bit"] == bit
                        and not v["endpoint_correction"]
                        and v["other_rows_identical"]
                        and (v["start"], v["end"]) == (pos + 1, length)
                        and v["input_sha256"] == native.array_hash(z[f"{prefix}_{v['site']}_input"])
                        and v["output_sha256"]
                        == native.array_hash(z[f"{prefix}_{v['site']}_output"])
                        for v in at
                    )
                )
                for site in range(1, 29):
                    x, y = z[f"{prefix}_{site}_input"], z[f"{prefix}_{site}_output"]
                    pred = mz[f"map_{site}_intercept"] + mz[f"map_{site}_slope"] * (
                        x - mz[f"map_{site}_center"]
                    )
                    if arm == "even":
                        pred = pred + mz[f"map_{site}_even"]
                    formula_error = max(formula_error, float(np.max(abs(y - pred))))
                    checks["all28_paired_even_formulas"] &= (
                        x.shape == y.shape == (length - pos - 1, 8960)
                        and np.isfinite(x).all()
                        and np.isfinite(y).all()
                    )
            ds = {
                cut: {arm: pair[1] - pair[0] for arm, pair in arms.items()}
                for cut, arms in pairs.items()
            }
            kappa = {cut: d["even"] - d["paired"] for cut, d in ds.items()}
            cells.append(
                {
                    **g,
                    "supported": bases[0]["facts"]["supported"],
                    "margins": pairs,
                    "deltas": ds,
                    "kappa": kappa,
                    "up_fixed_NW_interaction": kappa["U"]
                    - kappa["NU"]
                    - kappa["WU"]
                    + kappa["NWU"],
                    "parent_reference_cuts": ["live", "NW", "NWU"],
                }
            )
            checks["public_score_arithmetic"] &= all(
                native.margin_valid(q["margin"]) for q in r["raw"] + r["identities"] + r["patches"]
            )
    checks["complete1536_new_crossing"] &= (
        len(cells) == len(list((RUN / "qwen15/records").glob("*.json"))) == 64
    )
    checks["all28_paired_even_formulas"] &= formula_error <= 1e-5
    numerical = False
    p = ROOT / "docs/analysis/189-numerical-recheck.json"
    if p.exists():
        n = json.loads(p.read_text())
        paths = {
            "source_sha256": ROOT / "scripts/recheck_factorial_curvature_routes_189.py",
            "audit_sha256": Path(__file__),
            "public_helper_sha256": ROOT / "scripts/recheck_natural_bit_shared_reader_181.py",
            "activation_helper_sha256": ROOT / "scripts/recheck_shared_signed_curvature_187.py",
            "up_helper_sha256": ROOT / "scripts/recheck_curvature_multiplication_188.py",
            "component_helper_sha256": Path(parent.parent.__file__),
        }
        numerical = (
            n["passed"]
            and n["forwards"] == 192
            and n["fingerprint"] == b["fingerprint"]
            and all(n[k] == native.hashed(v) for k, v in paths.items())
        )
    result = {
        "complete": True,
        "fingerprint": b["fingerprint"],
        "main_forwards": 1536,
        "parent_reference_patch_rows": 768,
        "controls": {k: bool(v) for k, v in checks.items()},
        "maximum_activation_formula_error": formula_error,
        "numerical_qualified": numerical,
        "cells": cells,
        **accounts(cells, numerical and all(checks.values())),
        "scope": "Complete paired N/W/U operation factorial on reused contexts;768parent patch rows are references, not new executions/replications. Conditional cut-specific effects, not unique native decomposition or forecasts.",
    }
    write_json(OUT, result)
    print(
        json.dumps(
            {k: v for k, v in result.items() if k not in ("cells", "panels", "schema_comparisons")},
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
