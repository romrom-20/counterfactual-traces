"""Independent artifact reconstruction and every registered195 account, including failures."""

import hashlib
import itertools
import json
from pathlib import Path

import audit_single_state_native_response_193 as parent
import numpy as np
from audit_one_sided_gain_forecast_186 import ordered
from transformers import AutoTokenizer

from latent_decisions.evidence_policy import digest, write_json

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / "runs/first-block-primitive-repair-195"
OUT = ROOT / "docs/analysis/195-independent-audit.json"
FACTORS = ("input_rms", "qk_product", "softmax", "weight_value", "post_rms", "silu", "gate_up")
ARMS = ("linear", *FACTORS, "exact_block", "exact_source")
LITERALS = (
    ("velvet", "satin", "Tuesday", "Friday"),
    ("harbor", "inlet", "Monday", "Saturday"),
    ("mosaic", "mural", "Wednesday", "Sunday"),
    ("glacier", "tundra", "Thursday", "Monday"),
)
FILES = (
    "scripts/run_first_block_primitive_repair_195.py",
    "scripts/first_block_response_195.py",
    "scripts/audit_first_block_primitive_repair_195.py",
    "scripts/recheck_first_block_primitive_repair_195.py",
    "docs/experiments/195-first-block-primitive-repair.md",
)
native = parent.native


def hashed(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def blocks():
    return [
        {"id": a, "stage": "195", "subjects": [a, b], "days": [x, y], "old_block": None}
        for a, b, x, y in LITERALS
    ]


def source_hash():
    return digest(
        {"files": {p: (ROOT / p).read_text() for p in FILES}, "parent": parent.source_hash()}
    )


def vector(actual, predicted):
    actual, predicted = actual.astype(np.float64), predicted.astype(np.float64)
    norm, pn = float(np.linalg.norm(actual)), float(np.linalg.norm(predicted))
    return {
        "norm": norm,
        "relative_error": float(np.linalg.norm(actual - predicted) / norm) if norm else None,
        "cosine": float(np.dot(actual.ravel(), predicted.ravel()) / (norm * pn))
        if norm and pn
        else None,
    }


def matching(value):
    return (
        value["norm"] >= 0.001
        and value["relative_error"] is not None
        and value["relative_error"] <= 0.05
        and value["cosine"] is not None
        and value["cosine"] >= 0.99
    )


def main():
    bundle = json.loads((RUN / "design.json").read_text())
    status = json.loads((RUN / "pipeline-status.json").read_text())
    pa = json.loads(parent.OUT.read_text())
    assert (
        bundle["fingerprint"] == digest(bundle["design"])
        and bundle["design"]["source_hash"] == source_hash()
    )
    assert (
        pa["numerical_qualified"]
        and all(pa["controls"].values())
        and pa["fingerprint"] == bundle["design"]["parent_fingerprint"]
    )
    assert status["status"] == "complete"
    assert all(
        status[k] == n == bundle["design"][k]
        for k, n in (
            ("ordinary_model_invocations", 128),
            ("false_tail_ad_invocations", 640),
            ("local_first_ad_invocations", 64),
            ("local_analytical_responses", 576),
        )
    )
    rt = json.loads((RUN / "qwen15/runtime.json").read_text())
    assert rt == json.loads((parent.RUN / "qwen15/runtime.json").read_text())
    spec = bundle["design"]["models"]["qwen15"]
    tok = AutoTokenizer.from_pretrained(
        spec["model"], revision=spec["revision"], local_files_only=True
    )
    assert digest(tok.get_vocab()) == rt["tokenizer_hash"]
    manifest = json.loads((RUN / "forecast-manifest.json").read_text())
    assert digest(manifest["manifest"]) == manifest["manifest_sha256"]
    assert (
        manifest["ordinary_model_invocations"] == 64
        and manifest["false_tail_ad_invocations"] == 640
    )
    entries = {r["key"]: r for r in manifest["manifest"]}
    controls = {
        k: True
        for k in (
            "immutable_source_runtime_parent",
            "complete64pairs_128ordinary_640ad",
            "all_single_token_prefix_reconstructions",
            "global_forecasts_before_true",
            "finite_shapes_all_saved_rows",
            "all64local_linear_derivative_checks",
            "all640false_tail_primals",
            "causal_prefix_zero_firstblock",
            "source_row_splice_rule",
            "firstblock_rows_tail_identity",
            "exact_firstblock_control_against_native_true",
        )
    }
    cells, diagnostics, before, after = [], [], [], []
    max_exact_error = 0.0
    for block, a, t, rev, schema in itertools.product(
        blocks(), range(2), range(2), range(2), ("generic", "descriptive")
    ):
        g = native.fixture.group(block, a, t, rev, schema)
        key = digest(g)
        f, o = (
            native.read_record(RUN / "qwen15/forecasts" / f"{key}.json"),
            native.read_record(RUN / "qwen15/observations" / f"{key}.json"),
        )
        fr, obs = f["record"], o["record"]
        fp, op = RUN / "qwen15/forecasts" / f"{key}.npz", RUN / "qwen15/observations" / f"{key}.npz"
        assert fr["fingerprint"] == obs["fingerprint"] == bundle["fingerprint"]
        assert obs["forecast_record_sha256"] == f["sha256"]
        assert hashed(fp) == fr["states_sha256"] and hashed(op) == obs["states_sha256"]
        assert entries[key] == {
            "key": key,
            "record_sha256": f["sha256"],
            "states_sha256": fr["states_sha256"],
        }
        bases = [
            native.fixture.reconstruct(tok, block, native.fixture.job(g, bit)) for bit in range(2)
        ]
        pos, length = fr["position"], len(bases[0]["free_input_ids"])
        controls["all_single_token_prefix_reconstructions"] &= (
            bases == fr["bases"]
            and len(bases[1]["free_input_ids"]) == length
            and [
                i
                for i, (x, y) in enumerate(
                    zip(bases[0]["free_input_ids"], bases[1]["free_input_ids"])
                )
                if x != y
            ]
            == [pos]
        )
        controls["all64local_linear_derivative_checks"] &= fr["local_ad_error"] <= 1e-4
        controls["all640false_tail_primals"] &= fr["tail_primal_error"] <= 1e-4
        before.append(fr["completed_utc"])
        after.append(obs["started_utc"])
        with np.load(fp, allow_pickle=False) as z, np.load(op, allow_pickle=False) as oz:
            controls["finite_shapes_all_saved_rows"] &= (
                all(np.isfinite(v).all() for table in (z, oz) for v in table.values())
                and z["false_rows"].shape == oz["true_rows"].shape == (28, 2, 1536)
                and z["false_first"].shape == oz["true_first"].shape == (length, 1536)
            )
            actual = oz["true_rows"].astype(np.float64) - z["false_rows"].astype(np.float64)
            first = oz["true_first"].astype(np.float64) - z["false_first"].astype(np.float64)
            fs, ts = z["false_scores"].astype(np.float64), oz["true_scores"].astype(np.float64)
            dm = float((ts[1] - ts[0]) - (fs[1] - fs[0]))
            exact_error = float(
                np.max(abs(z["exact_block_first_delta"].astype(np.float64) - first))
            )
            max_exact_error = max(max_exact_error, exact_error)
            controls["exact_firstblock_control_against_native_true"] &= exact_error <= 1e-4
            other = np.arange(length) != pos
            controls["source_row_splice_rule"] &= np.array_equal(
                z["exact_source_first_delta"][other], z["linear_first_delta"][other]
            ) and np.array_equal(
                z["exact_source_first_delta"][pos], z["exact_block_first_delta"][pos]
            )
            for arm in ARMS:
                ph, ps = (
                    z[f"{arm}_delta_rows"].astype(np.float64),
                    z[f"{arm}_delta_scores"].astype(np.float64),
                )
                controls["finite_shapes_all_saved_rows"] &= (
                    ph.shape == (28, 2, 1536)
                    and ps.shape == (2,)
                    and z[f"{arm}_first_delta"].shape == (length, 1536)
                )
                controls["firstblock_rows_tail_identity"] &= (
                    np.max(abs(ph[0] - z[f"{arm}_first_delta"][[pos, -1]])) <= 1e-4
                )
                controls["causal_prefix_zero_firstblock"] &= (
                    np.count_nonzero(z[f"{arm}_first_delta"][:pos]) == 0
                    and np.count_nonzero(first[:pos]) == 0
                )
                cells.append(
                    {
                        **g,
                        "arm": arm,
                        "control_arm": arm.startswith("exact_"),
                        "supported": bases[0]["facts"]["supported"],
                        "source": vector(first[pos], z[f"{arm}_first_delta"][pos]),
                        "first_receivers": vector(
                            first[pos + 1 :], z[f"{arm}_first_delta"][pos + 1 :]
                        ),
                        "final": vector(actual[-1, -1], ph[-1, -1]),
                        "actual_delta_margin": dm,
                        "predicted_delta_margin": float(ps[1] - ps[0]),
                        "margin_error": float(ps[1] - ps[0]) - dm,
                        "all28_source": [vector(actual[k, 0], ph[k, 0]) for k in range(28)],
                        "all28_verdict": [vector(actual[k, 1], ph[k, 1]) for k in range(28)],
                    }
                )
            diagnostics.append(
                {
                    **g,
                    "post_observation_only": True,
                    "linear_component_error": {
                        name: {
                            "source": vector(
                                oz[f"native_{name}"][0] - z[f"base_{name}"][0],
                                z[f"base_{name}_delta"][0],
                            ),
                            "verdict": vector(
                                oz[f"native_{name}"][1] - z[f"base_{name}"][1],
                                z[f"base_{name}_delta"][1],
                            ),
                        }
                        for name in (
                            "norm_input",
                            "attention",
                            "mid",
                            "norm_post",
                            "gate",
                            "up",
                            "phi",
                            "mlp",
                        )
                    },
                }
            )
    controls["global_forecasts_before_true"] &= ordered(before, manifest["completed_utc"], after)
    controls["complete64pairs_128ordinary_640ad"] &= (
        len(entries) == len(before) == len(after) == 64
        and len(cells) == 640
        and len(list((RUN / "qwen15/forecasts").glob("*.json")))
        == len(list((RUN / "qwen15/observations").glob("*.json")))
        == 64
    )
    numerical = False
    npth = ROOT / "docs/analysis/195-numerical-recheck.json"
    if npth.exists():
        n = json.loads(npth.read_text())
        numerical = (
            n["passed"]
            and n["fingerprint"] == bundle["fingerprint"]
            and n["source_sha256"]
            == hashed(ROOT / "scripts/recheck_first_block_primitive_repair_195.py")
            and n["audit_sha256"] == hashed(Path(__file__))
            and n["ordinary_model_invocations"] == 16
            and n["reverse_tail_ad_invocations"] == 80
        )
    panels = []
    for block, schema, rev, arm in itertools.product(
        blocks(), ("generic", "descriptive"), range(2), ARMS
    ):
        rs = [
            c
            for c in cells
            if (c["block"], c["schema"], c["reverse"], c["arm"]) == (block["id"], schema, rev, arm)
        ]
        bs = [
            c
            for c in cells
            if (c["block"], c["schema"], c["reverse"], c["arm"])
            == (block["id"], schema, rev, "linear")
        ]
        assert len(rs) == len(bs) == 4
        lookup = {(c["assignment"], c["target"]): c for c in bs}
        progress = []
        for c in rs:
            base = lookup[(c["assignment"], c["target"])]
            progress.append(
                c["source"]["relative_error"] <= 0.5 * base["source"]["relative_error"]
                and (
                    c["final"]["relative_error"] <= 0.5 * base["final"]["relative_error"]
                    or abs(c["margin_error"]) <= 0.5 * abs(base["margin_error"])
                )
            )
        balanced = sum((1 if c["supported"] else -1) * c["margin_error"] for c in rs) / 2
        panels.append(
            {
                "block": block["id"],
                "schema": schema,
                "reverse": rev,
                "arm": arm,
                "source_matching": all(matching(c["source"]) for c in rs),
                "individual_matching": all(abs(c["margin_error"]) <= 0.1 for c in rs),
                "residual_matching": all(matching(c["final"]) for c in rs),
                "prospective_progress": all(progress),
                "balanced_matching": abs(balanced) <= 0.1,
                "balanced_error": balanced,
            }
        )
    accounts = {}
    for metric in (
        "source_matching",
        "individual_matching",
        "residual_matching",
        "prospective_progress",
        "balanced_matching",
    ):
        accounts[metric] = {}
        for arm in ARMS:
            rs = [p for p in panels if p["arm"] == arm]
            strata = {
                f"{s}_{r}": sum(p[metric] for p in rs if (p["schema"], p["reverse"]) == (s, r))
                for s, r in itertools.product(("generic", "descriptive"), range(2))
            }
            accounts[metric][arm] = {
                "compatible_panels": sum(p[metric] for p in rs),
                "strata": strata,
                "whole_passed": numerical
                and all(controls.values())
                and all(v >= 3 for v in strata.values()),
                "mechanistic_progress_candidate": metric == "prospective_progress"
                and arm in FACTORS,
                "control_arm": arm.startswith("exact_"),
            }
    result = {
        "complete": True,
        "fingerprint": bundle["fingerprint"],
        "controls": {k: bool(v) for k, v in controls.items()},
        "numerical_qualified": numerical,
        "maximum_exact_firstblock_error": max_exact_error,
        "cells": cells,
        "panels": panels,
        "accounts": accounts,
        "post_observation_diagnostics": diagnostics,
        "scope": "False-calibrated finite selected first-block operations and false-tail FIRST derivative. Exact block/source are computation controls, not identified mechanisms. NativeTrue used only after sealing for evaluation/diagnostics. Individual/residual native accounts remain primary; dependent templates, one smallcheckpoint, grounding failures, no uniqueness/priority claim.",
    }
    write_json(OUT, result)
    print(
        json.dumps(
            {
                k: v
                for k, v in result.items()
                if k not in ("cells", "panels", "post_observation_diagnostics")
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
