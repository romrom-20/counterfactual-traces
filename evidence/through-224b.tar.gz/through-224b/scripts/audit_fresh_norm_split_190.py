"""Fresh paired controls, exact final-state identities and frozen norm-split accounts."""

import itertools
import json
from pathlib import Path

import audit_factorial_curvature_routes_189 as parent
import numpy as np
from transformers import AutoTokenizer

from latent_decisions.evidence_policy import digest, write_json

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / "runs/fresh-norm-split-190"
OUT = ROOT / "docs/analysis/190-independent-audit.json"
CUTS = ("live", "U", "FU", "IU", "NU")
LITERALS = (
    ("beryl", "turquoise", "Tuesday", "Thursday"),
    ("meadow", "prairie", "Wednesday", "Sunday"),
    ("axiom", "lemma", "Friday", "Monday"),
    ("lantern", "beacon", "Saturday", "Wednesday"),
)
native = parent.native


def blocks():
    return [
        {"id": a, "stage": "190", "subjects": [a, b], "days": [x, y], "old_block": None}
        for a, b, x, y in LITERALS
    ]


def norm_targets(means, cut):
    names = (
        {"N_final"}
        if cut == "FU"
        else {n for n in means if n != "N_final"}
        if cut == "IU"
        else set(means)
        if cut == "NU"
        else set()
    )
    return {name: means[name] for name in names}


def source_hash():
    return digest(
        {
            "runner": (ROOT / "scripts/run_fresh_norm_split_190.py").read_text(),
            "protocol": (
                ROOT / "docs/experiments/190-fresh-final-versus-internal-norm.md"
            ).read_text(),
            "parent": parent.source_hash(),
            "capture_helper": (ROOT / "scripts/run_natural_silu_tangent_183.py").read_text(),
            "transport_helper": (ROOT / "scripts/curvature_residual_transport_190.py").read_text(),
        }
    )


def accounts(cells, valid):
    panels = []
    for block, schema, rev in itertools.product(blocks(), ("generic", "descriptive"), range(2)):
        rows = [
            c
            for c in cells
            if (c["block"], c["schema"], c["reverse"]) == (block["id"], schema, rev)
        ]
        assert len(rows) == 4
        live_eligible = all(abs(c["kappa"]["live"]) >= 0.2 for c in rows)
        norm_eligible = all(abs(c["kappa"]["NU"]) >= 0.2 for c in rows)
        matches = {
            "up_bottleneck_replication": live_eligible
            and all(abs(c["kappa"]["U"]) <= 0.1 for c in rows),
            "norm_conditioned_sign_reversal": live_eligible
            and norm_eligible
            and all(c["kappa"]["live"] * c["kappa"]["NU"] < 0 for c in rows),
            **{
                name: norm_eligible
                and all(
                    abs(c["kappa"][cut] - c["kappa"]["NU"]) <= 0.1
                    and c["kappa"][cut] * c["kappa"]["NU"] > 0
                    and abs(c["kappa"][cut]) >= 0.5 * abs(c["kappa"]["NU"])
                    for c in rows
                )
                for name, cut in (
                    ("final_readout_explanation", "FU"),
                    ("internal_norm_explanation", "IU"),
                )
            },
        }
        panels.append(
            {
                "block": block["id"],
                "schema": schema,
                "reverse": rev,
                "live_eligible": live_eligible,
                "norm_eligible": norm_eligible,
                "matches": matches,
            }
        )
    outcomes = {}
    for name in panels[0]["matches"]:
        strata = {
            f"{schema}_{rev}": sum(
                p["matches"][name] for p in panels if (p["schema"], p["reverse"]) == (schema, rev)
            )
            for schema, rev in itertools.product(("generic", "descriptive"), range(2))
        }
        outcomes[name] = {
            "compatible_panels": sum(p["matches"][name] for p in panels),
            "strata": strata,
            "whole_passed": valid and all(v >= 3 for v in strata.values()),
        }
    return {"panels": panels, "accounts": outcomes}


def main():
    b = json.loads((RUN / "design.json").read_text())
    s = json.loads((RUN / "pipeline-status.json").read_text())
    pa = json.loads(parent.OUT.read_text())
    assert b["fingerprint"] == digest(b["design"]) and b["design"]["source_hash"] == source_hash()
    assert s["status"] == "complete" and s["completed_forwards"] == 1536
    assert (
        pa["numerical_qualified"]
        and all(pa["controls"].values())
        and pa["fingerprint"] == b["design"]["parent_fingerprint"]
    )
    cfg = b["design"]["models"]["qwen15"]
    tok = AutoTokenizer.from_pretrained(
        cfg["model"], revision=cfg["revision"], local_files_only=True
    )
    rt = json.loads((RUN / "qwen15/runtime.json").read_text())
    assert rt == json.loads((parent.RUN / "qwen15/runtime.json").read_text()) and rt[
        "tokenizer_hash"
    ] == digest(tok.get_vocab())
    checks = {
        name: True
        for name in (
            "immutable_sources_parent_runtime",
            "complete1536_fresh_crossing",
            "all64_fresh_natural_single_token_pairs",
            "raw_all141_factors_28_up_shapes_hashes",
            "all28_native_SiLU_component_formulas",
            "all64_norm_up_means_targets",
            "all128_exact_own_NWU_identities",
            "all_receiving_targets_spans",
            "all28_paired_even_activation_formulas",
            "all256_exact_final_only_state_identities",
            "metadata_V_prefix_native_exact",
            "effective_final_scale_hashes",
            "public_score_arithmetic",
            "all28_residual_trajectory_spans_additions",
            "all28_residual_source_shapes",
        )
    }
    cells, component_error, formula_error, native_phi_error = [], 0.0, 0.0, 0.0
    for block, a, t, rev, schema in itertools.product(
        blocks(), range(2), range(2), range(2), ("generic", "descriptive")
    ):
        g = native.fixture.group(block, a, t, rev, schema)
        key = digest(g)
        r = native.read_record(RUN / "qwen15/records" / f"{key}.json")["record"]
        assert r["fingerprint"] == b["fingerprint"] and all(r[k] == v for k, v in g.items())
        p = RUN / "qwen15/states" / f"{key}.npz"
        assert native.hashed(p) == r["states_sha256"]
        bases = [
            native.fixture.reconstruct(tok, block, native.fixture.job(g, bit)) for bit in range(2)
        ]
        pos, length = r["position"], len(bases[0]["free_input_ids"])
        checks["all64_fresh_natural_single_token_pairs"] &= (
            bases == [q["base"] for q in r["raw"]]
            and len(bases[1]["free_input_ids"]) == length
            and [
                i
                for i, (x, y) in enumerate(
                    zip(bases[0]["free_input_ids"], bases[1]["free_input_ids"])
                )
                if x != y
            ]
            == [pos]
        )
        assert len(r["raw"]) == len(r["identities"]) == 2 and len(r["patches"]) == 20
        assert {(q["cut"], q["arm"], q["bit"]) for q in r["patches"]} == set(
            itertools.product(CUTS, ("paired", "even"), range(2))
        )
        with np.load(p, allow_pickle=False) as z:
            caps = [{n: z[f"raw_{bit}_{n}"] for n in native.sites()} for bit in range(2)]
            ups = [{site: z[f"raw_{bit}_U_{site}"] for site in range(1, 29)} for bit in range(2)]
            means = {
                n: native.midpoint(caps[0][n], caps[1][n]) for n in native.sites() if n[0] == "N"
            }
            mean_u = {site: native.midpoint(ups[0][site], ups[1][site]) for site in range(1, 29)}
            checks["all64_norm_up_means_targets"] &= all(
                np.array_equal(v, z[f"shared_{n}"]) for n, v in means.items()
            ) and all(np.array_equal(v, z[f"shared_U_{site}"]) for site, v in mean_u.items())
            for site in range(1, 29):
                expected = parent.parent.parent.components(
                    z[f"raw_phi_0_{site}_input"],
                    z[f"raw_phi_1_{site}_input"],
                    z[f"raw_phi_0_{site}_output"],
                    z[f"raw_phi_1_{site}_output"],
                )
                component_error = max(
                    component_error,
                    max(float(np.max(abs(v - z[f"map_{site}_{n}"]))) for n, v in expected.items()),
                )
            for bit in range(2):
                q = r["raw"][bit]
                own = r["identities"][bit]
                checks["raw_all141_factors_28_up_shapes_hashes"] &= (
                    parent.parent.trace_ok(q, z, "", {}, None, pos, length, caps[bit])
                    and all(
                        v["applied_sha256"] == native.array_hash(caps[bit][v["site"]])
                        for v in q["class_trace"]
                    )
                    and all(
                        v["output_sha256"] == native.array_hash(ups[bit][v["site"]])
                        for v in q["up_trace"]
                    )
                )
                for n, v in {**caps[bit], **{f"U_{s}": u for s, u in ups[bit].items()}}.items():
                    shape = (
                        (length - pos - 1, 1)
                        if n[0] == "N"
                        else (12, length - pos - 1, length)
                        if n[0] == "W"
                        else (length - pos - 1, 8960)
                        if n[0] in "GU"
                        else (256,)
                    )
                    checks["raw_all141_factors_28_up_shapes_hashes"] &= (
                        v.shape == shape and v.dtype == np.float32 and np.isfinite(v).all()
                    )
                    if n[0] == "N":
                        checks["raw_all141_factors_28_up_shapes_hashes"] &= (v > 0).all()
                    if n[0] == "W":
                        checks["raw_all141_factors_28_up_shapes_hashes"] &= (
                            (v >= 0).all()
                            and np.max(abs(v.astype(np.float64).sum(-1) - 1)) <= 1e-6
                            and all(
                                np.count_nonzero(v[:, row, pos + 2 + row :]) == 0
                                for row in range(length - pos - 1)
                            )
                        )
                trace = q["activation_trace"]
                checks["all28_native_SiLU_component_formulas"] &= (
                    len(trace) == 28
                    and [v["site"] for v in trace] == list(range(1, 29))
                    and all(
                        not v["tangent"]
                        and v["other_rows_identical"]
                        and (v["start"], v["end"]) == (pos + 1, length)
                        and v["input_sha256"]
                        == native.array_hash(z[f"raw_phi_{bit}_{v['site']}_input"])
                        and v["output_sha256"]
                        == native.array_hash(z[f"raw_phi_{bit}_{v['site']}_output"])
                        for v in trace
                    )
                )
                for site in range(1, 29):
                    x = z[f"raw_phi_{bit}_{site}_input"].astype(np.float64)
                    y = z[f"raw_phi_{bit}_{site}_output"]
                    native_phi_error = max(
                        native_phi_error, float(np.max(abs(y - x * np.exp(-np.logaddexp(0, -x)))))
                    )
                    checks["all28_native_SiLU_component_formulas"] &= np.array_equal(
                        y, caps[bit][f"G_{site}"]
                    )
                checks["all128_exact_own_NWU_identities"] &= (
                    own["margin"] == q["margin"]
                    and np.array_equal(z[f"own_{bit}_final"], z[f"raw_{bit}_final"])
                    and parent.parent.trace_ok(
                        own,
                        z,
                        "",
                        {n: v for n, v in caps[bit].items() if n[0] in "NW"},
                        ups[bit],
                        pos,
                        length,
                        caps[bit],
                    )
                )
            for q in r["patches"]:
                cut, arm, bit = q["cut"], q["arm"], q["bit"]
                prefix = f"{cut}_{arm}_{bit}"
                targets = norm_targets(means, cut)
                fu = mean_u if cut != "live" else None
                h = z[f"{prefix}_final"]
                rtrace = q["residual_trace"]
                checks["all28_residual_trajectory_spans_additions"] &= (
                    len(rtrace) == 112
                    and {(v["site"], v["kind"]) for v in rtrace}
                    == set(itertools.product(range(1, 29), ("input", "attention", "mlp", "output")))
                    and all((v["start"], v["end"]) == (pos + 1, length) for v in rtrace)
                )
                for layer in range(1, 29):
                    fields = {
                        kind: z[f"{prefix}_R_{layer}_{kind}"]
                        for kind in ("input", "attention", "mlp", "output")
                    }
                    checks["all28_residual_trajectory_spans_additions"] &= (
                        all(
                            v.shape == (length - pos - 1, 1536)
                            and v.dtype == np.float32
                            and np.isfinite(v).all()
                            for v in fields.values()
                        )
                        and float(
                            np.max(
                                abs(
                                    fields["output"]
                                    - ((fields["input"] + fields["attention"]) + fields["mlp"])
                                )
                            )
                        )
                        <= 0.005
                    )
                    if layer < 28:
                        checks["all28_residual_trajectory_spans_additions"] &= np.array_equal(
                            fields["output"], z[f"{prefix}_R_{layer + 1}_input"]
                        )
                    else:
                        checks["all28_residual_trajectory_spans_additions"] &= np.array_equal(
                            fields["output"], h[pos + 1 :]
                        )
                    source = z[f"C_source_{layer}"]
                    checks["all28_residual_source_shapes"] &= (
                        source.shape == (length - pos - 1, 1536)
                        and source.dtype == np.float32
                        and np.isfinite(source).all()
                    )
                checks["all_receiving_targets_spans"] &= parent.parent.trace_ok(
                    q, z, prefix, targets, fu, pos, length, caps[bit], True
                )
                checks["metadata_V_prefix_native_exact"] &= h.shape == (
                    length,
                    1536,
                ) and np.array_equal(h[: pos + 1], z[f"raw_{bit}_final"][: pos + 1])
                trace = q["activation_trace"]
                checks["all28_paired_even_activation_formulas"] &= (
                    len(trace) == 28
                    and [v["site"] for v in trace] == list(range(1, 29))
                    and all(
                        v["arm"] == arm
                        and v["bit"] == bit
                        and not v["endpoint_correction"]
                        and v["other_rows_identical"]
                        and (v["start"], v["end"]) == (pos + 1, length)
                        and v["input_sha256"] == native.array_hash(z[f"{prefix}_{v['site']}_input"])
                        and v["output_sha256"]
                        == native.array_hash(z[f"{prefix}_{v['site']}_output"])
                        for v in trace
                    )
                )
                for site in range(1, 29):
                    x, y = z[f"{prefix}_{site}_input"], z[f"{prefix}_{site}_output"]
                    prediction = z[f"map_{site}_intercept"] + z[f"map_{site}_slope"] * (
                        x - z[f"map_{site}_center"]
                    )
                    if arm == "even":
                        prediction = prediction + z[f"map_{site}_even"]
                    formula_error = max(formula_error, float(np.max(abs(y - prediction))))
                    checks["all28_paired_even_activation_formulas"] &= (
                        x.shape == y.shape == (length - pos - 1, 8960)
                        and np.isfinite(x).all()
                        and np.isfinite(y).all()
                    )
                nf = z[f"{prefix}_N_final"]
                checks["effective_final_scale_hashes"] &= (
                    nf.shape == (length - pos - 1, 1)
                    and np.isfinite(nf).all()
                    and (nf > 0).all()
                    and next(
                        v["applied_sha256"] for v in q["class_trace"] if v["site"] == "N_final"
                    )
                    == native.array_hash(nf)
                )
                if cut in ("FU", "NU"):
                    checks["effective_final_scale_hashes"] &= np.array_equal(nf, means["N_final"])
            for arm, bit in itertools.product(("paired", "even"), range(2)):
                checks["all256_exact_final_only_state_identities"] &= np.array_equal(
                    z[f"FU_{arm}_{bit}_final"], z[f"U_{arm}_{bit}_final"]
                ) and np.array_equal(z[f"NU_{arm}_{bit}_final"], z[f"IU_{arm}_{bit}_final"])
            pairs = {
                cut: {
                    arm: [
                        next(
                            q["margin"]["log_odds"]
                            for q in r["patches"]
                            if (q["cut"], q["arm"], q["bit"]) == (cut, arm, bit)
                        )
                        for bit in range(2)
                    ]
                    for arm in ("paired", "even")
                }
                for cut in CUTS
            }
            ds = {cut: {arm: p[1] - p[0] for arm, p in arms.items()} for cut, arms in pairs.items()}
            cells.append(
                {
                    **g,
                    "supported": bases[0]["facts"]["supported"],
                    "margins": pairs,
                    "deltas": ds,
                    "kappa": {cut: d["even"] - d["paired"] for cut, d in ds.items()},
                }
            )
            checks["public_score_arithmetic"] &= all(
                native.margin_valid(q["margin"]) for q in r["raw"] + r["identities"] + r["patches"]
            )
    checks["complete1536_fresh_crossing"] &= (
        len(cells) == len(list((RUN / "qwen15/records").glob("*.json"))) == 64
    )
    checks["all28_native_SiLU_component_formulas"] &= (
        component_error <= 1e-5 and native_phi_error <= 1e-5
    )
    checks["all28_paired_even_activation_formulas"] &= formula_error <= 1e-5
    numerical = False
    p = ROOT / "docs/analysis/190-numerical-recheck.json"
    if p.exists():
        n = json.loads(p.read_text())
        paths = {
            "source_sha256": ROOT / "scripts/recheck_fresh_norm_split_190.py",
            "audit_sha256": Path(__file__),
            "public_helper_sha256": ROOT / "scripts/recheck_natural_bit_shared_reader_181.py",
            "activation_helper_sha256": ROOT / "scripts/recheck_shared_signed_curvature_187.py",
            "up_helper_sha256": ROOT / "scripts/recheck_curvature_multiplication_188.py",
            "component_helper_sha256": Path(parent.parent.parent.__file__),
        }
        numerical = (
            n["passed"]
            and n["component_matrix_computations"] == 224
            and n["forwards"] == 192
            and n["fingerprint"] == b["fingerprint"]
            and all(n[k] == native.hashed(v) for k, v in paths.items())
        )
    result = {
        "complete": True,
        "fingerprint": b["fingerprint"],
        "main_forwards": 1536,
        "controls": {k: bool(v) for k, v in checks.items()},
        "maximum_component_error": component_error,
        "maximum_native_phi_error": native_phi_error,
        "maximum_activation_formula_error": formula_error,
        "numerical_qualified": numerical,
        "cells": cells,
        **accounts(cells, numerical and all(checks.values())),
        "scope": "Four new dependent day blocks. Dense local paired-state calibration; held out of hypothesis specification, not false-only prediction or independent tasks/team. Final-only scale cuts leave full block28 states EXACT; scientific accounts distinct from arithmetic identities.",
    }
    write_json(OUT, result)
    print(json.dumps({k: v for k, v in result.items() if k not in ("cells", "panels")}, indent=2))


if __name__ == "__main__":
    main()
