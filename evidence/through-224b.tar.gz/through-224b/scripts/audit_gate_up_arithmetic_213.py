"""Read-only saved-vector audit of213 arithmetic and immutable bindings."""
import hashlib,json
from pathlib import Path
import numpy as np
R=Path(__file__).resolve().parents[1];RUN=R/'runs/gate-up-arithmetic-213';OUT=R/'docs/analysis/213-gate-up-arithmetic-audit.json'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 assert not OUT.exists();d=json.loads((RUN/'design.json').read_text());p=json.loads((R/'docs/analysis/213-gate-up-arithmetic.json').read_text());assert p['cases']==256
 assert all(sha(R/f)==h for f,h in d['source_hashes'].items());assert sha(R/'runs/genuine-oracle-continuation-204-full/runtime.json')==d['runtime_sha256']
 rows=[]
 for file in sorted((RUN/'pairs').glob('*.npz')):
  rec=json.loads(file.with_suffix('.json').read_text());assert sha(file)==rec['arrays_sha256']
  with np.load(file) as z:
   assert all(np.isfinite(a).all() for a in z.values())
   for row in rec['rows']:
    for label,path in [('parent209c_sha256',R/'runs/two-block-factorial-209c/pairs'/file.name),('parent204_sha256',R/'runs/genuine-oracle-continuation-204-full/pairs'/file.name)]:
     assert sha(path)==row[label];other=json.loads(path.with_suffix('.json').read_text());assert sha(path)==other['arrays_sha256']
    pre=row['branch']+'_'+row['post_rms']+'_';v={name:z[pre+name] for name in ['gate_branch','up_branch','mixed','product_rounding','down_rounding','residual_rounding','finite_effect','mixed_discrepancy']}
    closure=float(np.max(abs(v['finite_effect']-v['mixed']-v['product_rounding']-v['down_rounding']-v['residual_rounding'])));assert closure<=1e-4
    stats={}
    for region,s in [('source',slice(0,1)),('receivers',slice(1,None)),('verdict',slice(-1,None)),('causal_suffix',slice(None))]:
     effect=v['finite_effect'][s].ravel();en=np.linalg.norm(effect);stats[region]={}
     for name,value in v.items():
      a=value[s].ravel();stats[region][name]=dict(norm=float(np.linalg.norm(a)),maximum_coordinate=float(np.max(abs(a))),signed_projection_toward_finite_effect=float(a@effect/en) if en else None)
    rows.append(dict(key=row['key'],branch=row['branch'],post_rms=row['post_rms'],saved_vector_closure_error=closure,strict_receiver_mixed_coordinate_agreement=float(np.max(abs(v['mixed_discrepancy'][1:])))<=1e-4,regions=stats))
 assert len(rows)==256
 out=dict(cases=len(rows),source_hashes_unchanged=True,parent_bindings_verified=True,arithmetic_qualified=p['arithmetic_qualified'],original_wholeblock_jacobian_qualified=False,strict_mixed_agreement=p['strict_mixed_agreement'],maximum_saved_vector_closure_error=max(r['saved_vector_closure_error'] for r in rows),rows=rows,auditor_sha256=sha(Path(__file__)),target_loader_sha256=sha(R/'src/latent_decisions/target.py'),parent_runtime_sha256=d['runtime_sha256'],report_sha256=sha(R/'docs/analysis/213-gate-up-arithmetic.json'))
 OUT.write_text(json.dumps(out,indent=2));print({k:v for k,v in out.items() if k!='rows'})
if __name__=='__main__':main()
