"""Independent saved-vector arithmetic, lineage and reset-account audit; no model calls."""

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--scope", choices=["sample", "full"], required=True)
    args = parser.parse_args()
    run = ROOT / f"runs/genuine-oracle-continuation-204-{args.scope}"
    out = ROOT / f"docs/analysis/204-{args.scope}-oracle-vector-audit.json"
    assert not out.exists(), "Do not overwrite an executed numerical audit"
    status = json.loads((run / "status.json").read_text())
    bundle = json.loads((run / "design.json").read_text())
    design = bundle["design"]
    assert status["status"] == "complete" and status["reset_qualified"]
    for f, expected in design["source_hashes"].items():
        assert sha(ROOT / f) == expected
    parent = ROOT / "runs/discovery-ranked-repair-201"
    original = json.loads((ROOT / "docs/analysis/202-replacement-metric-audit.json").read_text())
    for f, expected in original["preserved_replacement_hashes"].items():
        assert sha(ROOT / f) == expected
    maximum = {
        "native_delta_reconstruction": 0.0,
        "reset_boundary": 0.0,
        "saved_error_vector": 0.0,
        "saved_native_remainder": 0.0,
        "represented_transport": 0.0,
        "two_jvp_identity": 0.0,
        "direct_je_identity": 0.0,
    }
    direct_checks, direct_failures, count = 0, 0, 0
    direct_by_position = {
        k: {"maximum_coordinate_error": 0.0, "failed_transitions": 0}
        for k in ("source", "receivers", "verdict")
    }
    direct_by_block = {str(k): 0 for k in range(1, 29)}
    outcomes, layerwise, checks = [], [], []
    for key in design["keys"]:
        record = json.loads((run / "pairs" / f"{key}.json").read_text())
        npz = run / "pairs" / f"{key}.npz"
        assert sha(npz) == record["arrays_sha256"]
        assert sha(parent / "forecasts" / f"{key}.npz") == record["parent_forecast_sha256"]
        assert sha(parent / "observations" / f"{key}.npz") == record["parent_observation_sha256"]
        assert all(c["passed"] for c in record["checks"] if c.get("required_for_reset", True))
        checks.extend(record["checks"])
        group = record["group"]
        with np.load(npz, allow_pickle=False) as z:
            pos = int(z["source_position"])
            actual = z["native_delta_suffix"].astype(np.float64)
            reconstructed = z["native_true_suffix"].astype(np.float64) - z["false_boundaries"][
                :, pos:
            ].astype(np.float64)
            maximum["native_delta_reconstruction"] = max(
                maximum["native_delta_reconstruction"], float(np.max(abs(reconstructed - actual)))
            )
            jn = z["native_j_delta_suffix"].astype(np.float64)
            for arm in ("source_linear", "union_blocks"):
                finite = {1, 16, 18, 21} if arm == "union_blocks" else {1}
                for k in (None, 1, 3, 8, 11, 16, 21, 27):
                    label, b = ("ordinary", 0) if k is None else (f"before{k}", k - 1)
                    pred = z[f"{label}_{arm}_delta_suffix"].astype(np.float64)
                    terms = z[f"{label}_{arm}_budget_suffix"]
                    assert pred.shape == actual[b:].shape and terms.shape == (
                        28 - b,
                        5,
                        *actual.shape[1:],
                    )
                    if k is not None:
                        maximum["reset_boundary"] = max(
                            maximum["reset_boundary"], float(np.max(abs(pred[0] - actual[b])))
                        )
                    for offset, index in enumerate(range(b, 28)):
                        je, rn, rp, en, represented = terms[offset]
                        expected_error = actual[index + 1] - pred[offset + 1]
                        expected_rn = actual[index + 1] - jn[index]
                        jp = pred[offset + 1] - rp if index + 1 in finite else pred[offset + 1]
                        expected_rep = jn[index] - jp
                        for name, diff in [
                            ("saved_error_vector", en - expected_error),
                            ("saved_native_remainder", rn - expected_rn),
                            ("represented_transport", represented - expected_rep),
                            ("two_jvp_identity", en - represented - rn + rp),
                        ]:
                            maximum[name] = max(maximum[name], float(np.max(abs(diff))))
                        if index + 1 not in finite:
                            assert np.count_nonzero(rp) == 0
                        diff = en - je - rn + rp
                        direct_error = float(np.max(abs(diff)))
                        for label, part in [
                            ("source", diff[:1]),
                            ("receivers", diff[1:]),
                            ("verdict", diff[-1:]),
                        ]:
                            value = float(np.max(abs(part)))
                            direct_by_position[label]["maximum_coordinate_error"] = max(
                                direct_by_position[label]["maximum_coordinate_error"], value
                            )
                            direct_by_position[label]["failed_transitions"] += value > 1e-4
                        direct_by_block[str(index + 1)] += direct_error > 1e-4
                        maximum["direct_je_identity"] = max(
                            maximum["direct_je_identity"], direct_error
                        )
                        direct_checks += 1
                        direct_failures += direct_error > 1e-4
                        count += 1
            for outcome in record["outcomes"]:
                outcomes.append(dict(key=key, **group, **outcome))
            for row in record["budgets"]:
                layerwise.append(dict(key=key, **group, **row))
    expected = 8 if args.scope == "sample" else 64
    assert len(design["keys"]) == expected and len(outcomes) == expected * 14
    assert direct_checks == expected * (2 * 28 + 2 * sum(29 - k for k in [1, 3, 8, 11, 16, 21, 27]))
    numerical_accounting = all(v <= 1e-4 for k, v in maximum.items() if k != "direct_je_identity")
    assert numerical_accounting
    assert (direct_failures == 0) == status["direct_identity_qualified"]
    summary = []
    for arm in ("source_linear", "union_blocks"):
        for k in [1, 3, 8, 11, 16, 21, 27]:
            rows = [r for r in outcomes if r["arm"] == arm and r["next_block"] == k]
            strata = []
            for group in sorted({(r["block"], r["schema"], r["reverse"]) for r in rows}):
                rs = [r for r in rows if (r["block"], r["schema"], r["reverse"]) == group]
                strata.append(
                    dict(
                        block=group[0],
                        schema=group[1],
                        reverse=group[2],
                        count=len(rs),
                        median_final_relative_error=float(
                            np.median([r["final"]["verdict"]["relative_error"] for r in rs])
                        ),
                        median_absolute_margin_error=float(
                            np.median([abs(r["reset_margin_error"]) for r in rs])
                        ),
                    )
                )
            summary.append(
                dict(
                    arm=arm,
                    next_block=k,
                    completed_blocks=k - 1,
                    count=len(rows),
                    median_relative_error=float(
                        np.median([r["final"]["verdict"]["relative_error"] for r in rows])
                    ),
                    median_cosine=float(np.median([r["final"]["verdict"]["cosine"] for r in rows])),
                    median_absolute_margin_error=float(
                        np.median([abs(r["reset_margin_error"]) for r in rows])
                    ),
                    residual_improved_count=sum(
                        r["final"]["verdict"]["relative_error"]
                        < r["ordinary_final"]["verdict"]["relative_error"]
                        for r in rows
                    ),
                    margin_improved_count=sum(
                        abs(r["reset_margin_error"]) < abs(r["ordinary_margin_error"]) for r in rows
                    ),
                    strata=strata,
                )
            )
    result = dict(
        scope=args.scope,
        reset_qualified=True,
        direct_identity_qualified=direct_failures == 0,
        direct_identity_checks=direct_checks,
        direct_identity_failures=direct_failures,
        direct_by_position=direct_by_position,
        direct_failures_by_block=direct_by_block,
        algebraic_accounting_qualified=numerical_accounting,
        maximum_errors=maximum,
        transition_vectors=count,
        counts=status["counts"],
        summary=summary,
        outcomes=outcomes,
        layerwise=layerwise,
        controls_summary={
            kind: dict(
                count=sum(c["kind"] == kind for c in checks),
                failed=sum(c["kind"] == kind and not c["passed"] for c in checks),
                maximum_coordinate_error=max(
                    c["maximum_coordinate_error"] for c in checks if c["kind"] == kind
                ),
                maximum_score_error=max(
                    c["maximum_score_error"] for c in checks if c["kind"] == kind
                ),
            )
            for kind in sorted({c["kind"] for c in checks})
        },
        source_hash=sha(Path(__file__)),
        design_fingerprint=bundle["fingerprint"],
        scope_limits="Retrospective oracle computation. Direct J(error) coordinate identity fails if any recorded violation; algebraic closure is not independent derivative validation. Public hooks share forwardAD backend. No196reconciliation, unique operation, prospective success or QuestionBsolution.",
    )
    out.write_text(json.dumps(result, indent=2))
    print(
        json.dumps(
            {k: v for k, v in result.items() if k not in ("outcomes", "layerwise", "summary")},
            indent=2,
        )
    )
    print(json.dumps([{k: v for k, v in r.items() if k != "strata"} for r in summary], indent=2))


if __name__ == "__main__":
    main()
