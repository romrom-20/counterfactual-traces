"""Every paired remainder budget, fixed-tolerance duality check and immutable input."""

import hashlib
import itertools
import json
from pathlib import Path

import audit_single_state_native_response_193 as parent
import numpy as np

from latent_decisions.evidence_policy import digest, write_json

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / "runs/layerwise-nonlinear-remainder-199"
OUT = ROOT / "docs/analysis/199-independent-audit.json"
FILES = (
    "scripts/run_layerwise_nonlinear_remainder_199.py",
    "scripts/audit_layerwise_nonlinear_remainder_199.py",
    "docs/experiments/199-layerwise-nonlinear-remainder.md",
)


def hashed(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def source_hash():
    return digest(
        {
            "files": {p: (ROOT / p).read_text() for p in FILES},
            "parent": parent.source_hash(),
            "transport_helper": (ROOT / "scripts/first_block_response_196.py").read_text(),
        }
    )


def close(a, b):
    return abs(a - b) <= 0.001 + 0.0001 * abs(b)


def main():
    bundle = json.loads((RUN / "design.json").read_text())
    status = json.loads((RUN / "pipeline-status.json").read_text())
    pa = json.loads(parent.OUT.read_text())
    assert (
        pa["numerical_qualified"]
        and all(pa["controls"].values())
        and pa["fingerprint"] == bundle["design"]["parent_fingerprint"]
    )
    assert (
        bundle["fingerprint"] == digest(bundle["design"])
        and bundle["design"]["source_hash"] == source_hash()
    )
    assert status["status"] == "complete"
    assert all(
        status[k] == n == bundle["design"][k]
        for k, n in (
            ("ordinary_false_model_invocations", 64),
            ("forward_false_model_invocations", 64),
            ("reverse_false_model_invocations", 64),
            ("local_block_forward_ad_invocations", 1728),
        )
    )
    assert json.loads((RUN / "runtime.json").read_text()) == json.loads(
        (parent.RUN / "qwen15/runtime.json").read_text()
    )
    manifest = json.loads((RUN / "manifest.json").read_text())
    assert digest(manifest["manifest"]) == manifest["sha256"]
    bykey = {r["key"]: r for r in manifest["manifest"]}
    controls = {
        k: True
        for k in (
            "immutable_sources_runtime_parent",
            "complete64pairs_1728blocks",
            "all64parent_raw_hashes",
            "all64native_false_replays",
            "local_block_false_primals",
            "all_saved_arrays_finite",
            "zero_initial_error",
            "all3456local_forward_reverse_contractions",
            "all64margin_error_budgets",
            "all64residual_projection_budgets",
        )
    }
    records = []
    for block, a, t, rev, schema in itertools.product(
        parent.blocks(), range(2), range(2), range(2), ("generic", "descriptive")
    ):
        g = parent.native.fixture.group(block, a, t, rev, schema)
        key = digest(g)
        p = RUN / "records" / f"{key}.npz"
        wrapped = parent.native.read_record(p.with_suffix(".json"))
        r = wrapped["record"]
        assert all(r[k] == v for k, v in g.items()) and r["fingerprint"] == bundle["fingerprint"]
        assert hashed(p) == r["states_sha256"] and bykey[key] == {
            "key": key,
            "record_sha256": wrapped["sha256"],
            "states_sha256": r["states_sha256"],
        }
        fp, op = (
            parent.RUN / "qwen15/forecasts" / f"{key}.npz",
            parent.RUN / "qwen15/observations" / f"{key}.npz",
        )
        controls["all64parent_raw_hashes"] &= (
            hashed(fp) == r["forecast_parent_sha256"]
            and hashed(op) == r["observation_parent_sha256"]
        )
        controls["all64native_false_replays"] &= (
            r["replay_state_error"] <= 1e-4 and r["replay_score_error"] <= 0.005
        )
        assert len(r["rows"]) == 27 and [v["block"] for v in r["rows"]] == list(range(2, 29))
        budget = r["budget"]
        margin_sum = sum(v["margin_contribution"] for v in r["rows"]) + budget["readout_remainder"]
        residual_sum = sum(v["error_direction_contribution"] for v in r["rows"])
        controls["all64margin_error_budgets"] &= (
            close(margin_sum, budget["actual_margin_error"])
            and budget["margin_passed"]
            and abs(margin_sum - budget["reconstructed_margin_error"]) <= 1e-12
        )
        controls["all64residual_projection_budgets"] &= (
            close(residual_sum, budget["observed_final_error_norm"])
            and budget["residual_passed"]
            and abs(residual_sum - budget["reconstructed_final_error_projection"]) <= 1e-12
        )
        with np.load(p, allow_pickle=False) as z:
            controls["all_saved_arrays_finite"] &= (
                len(z.files) == 29
                and all(
                    v.shape == (2, 1536) and np.isfinite(v).all()
                    for k, v in z.items()
                    if k.startswith("remainder")
                )
                and z["actual_delta_rows"].shape == z["predicted_delta_rows"].shape == (28, 2, 1536)
                and all(np.isfinite(v).all() for v in z.values())
            )
            controls["zero_initial_error"] &= np.array_equal(
                z["actual_delta_rows"][0], z["predicted_delta_rows"][0]
            )
            error_norm = float(
                np.linalg.norm(
                    z["actual_delta_rows"][-1, -1].astype(np.float64)
                    - z["predicted_delta_rows"][-1, -1].astype(np.float64)
                )
            )
            controls["all64residual_projection_budgets"] &= close(residual_sum, error_norm)
        for row in r["rows"]:
            controls["local_block_false_primals"] &= row["local_primal_error"] <= 1e-4
            assert len(row["duality"]) == 2
            for d in row["duality"]:
                controls["all3456local_forward_reverse_contractions"] &= (
                    d["passed"]
                    and close(d["forward"], d["reverse"])
                    and abs(abs(d["forward"] - d["reverse"]) - d["absolute_error"]) <= 1e-12
                )
        records.append(r)
    controls["complete64pairs_1728blocks"] &= (
        len(records) == len(bykey) == len(list((RUN / "records").glob("*.json"))) == 64
    )
    result = {
        "fingerprint": bundle["fingerprint"],
        "controls": {k: bool(v) for k, v in controls.items()},
        "numerical_qualified": all(controls.values()),
        "ordinary_false_model_invocations": 64,
        "forward_false_model_invocations": 64,
        "reverse_false_model_invocations": 64,
        "local_block_forward_ad_invocations": 1728,
        "records": records,
        "scope": "Paired193discovery-only fullstate nonlinearremainders and False-adjoint projectedgain. Oracle initial displacement/error-direction/actualremainders, not prospective prediction or unique causal contribution. Standard first-order reverse contractions+telescoping bounds; does not reconcile196primitive reverse-over-reverse failure. No independent AD backend for localforward maps or independent research team.",
    }
    write_json(OUT, result)
    print(json.dumps({k: v for k, v in result.items() if k != "records"}, indent=2))


if __name__ == "__main__":
    main()
