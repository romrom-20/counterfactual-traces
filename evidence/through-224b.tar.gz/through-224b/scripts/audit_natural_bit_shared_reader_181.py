"""Independent artifacts, natural input reconstruction and all-layer cut accounting."""

import hashlib
import itertools
import json
import math
from pathlib import Path

import audit_binding_carrier_partition_160 as fixture
import numpy as np
from transformers import AutoConfig, AutoTokenizer
from transformers.models.qwen2 import modeling_qwen2 as impl

from latent_decisions.evidence_policy import digest, write_json

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / "runs/natural-bit-shared-reader-181"
OUT = ROOT / "docs/analysis/181-independent-audit.json"
ARMS = ("native", "own", "N", "W", "G", "NW", "NG", "WG", "NWG", "neutral", "canonical")
LITERALS = (
    ("bronze", "nickel", "Monday", "Thursday"),
    ("willow", "cedar", "Tuesday", "Friday"),
    ("orbit", "comet", "Wednesday", "Saturday"),
    ("saffron", "ochre", "Friday", "Sunday"),
)


def blocks():
    return [
        {"id": a, "stage": "181", "subjects": [a, b], "days": [x, y], "old_block": None}
        for a, b, x, y in LITERALS
    ]


def source_hash():
    return digest(
        {
            "runner": (ROOT / "scripts/run_natural_bit_shared_reader_181.py").read_text(),
            "protocol": (ROOT / "docs/experiments/181-natural-bit-shared-reader.md").read_text(),
            "fixture": Path(fixture.__file__).read_text(),
            "fixture_source": (ROOT / "scripts/audit_counterbalanced_binding_155.py").read_text(),
            "fixture_messages": (ROOT / "scripts/audit_order_competence_151.py").read_text(),
            "runtime_helper": (ROOT / "scripts/run_order_competence_151.py").read_text(),
            "evidence_policy": (ROOT / "src/latent_decisions/evidence_policy.py").read_text(),
            "target": (ROOT / "src/latent_decisions/target.py").read_text(),
            "implementation": Path(impl.__file__).read_text(),
        }
    )


def hashed(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def array_hash(v):
    return hashlib.sha256(v.tobytes()).hexdigest()


def native_caps(z, bit):
    return {
        name[len(f"native_{bit}_") :]: z[name].copy()
        for name in z.files
        if name.startswith(f"native_{bit}_") and name != f"native_{bit}_final"
    }


def midpoint(a, b):
    return ((a.astype(np.float64) + b.astype(np.float64)) / 2).astype(np.float32)


def sites():
    return (
        {f"N_{layer}_{kind}" for layer, kind in itertools.product(range(1, 29), ("pre", "post"))}
        | {"N_final"}
        | {f"{kind}_{layer}" for kind, layer in itertools.product(("W", "G", "V"), range(1, 29))}
    )


def read_record(path):
    e = json.loads(path.read_text())
    assert digest(e["record"]) == e["sha256"]
    return e


def margin_valid(m):
    return (
        set(m) == {"false_score", "true_score", "log_odds"}
        and all(math.isfinite(v) for v in m.values())
        and m["log_odds"] == m["true_score"] - m["false_score"]
    )


def summarize(records, qualified):
    cells, panels = [], []
    for r in records:
        m = {
            "native": [n["margin"] for n in r["natives"]],
            **{
                arm: [
                    next(p["margin"] for p in r["patches"] if (p["arm"], p["bit"]) == (arm, bit))
                    for bit in range(2)
                ]
                for arm in ARMS[1:]
            },
        }
        deltas = {arm: pair[1]["log_odds"] - pair[0]["log_odds"] for arm, pair in m.items()}
        native = deltas["native"]
        cells.append(
            {
                **{k: r[k] for k in ("block", "schema", "reverse", "assignment", "target")},
                "supported": r["natives"][0]["base"]["facts"]["supported"],
                "margins": m,
                "delta": deltas,
                "native_eligible": abs(native) >= 0.5,
                "matching": {arm: abs(value - native) <= 0.1 for arm, value in deltas.items()},
                "retention": {
                    arm: abs(native) >= 0.5
                    and native * value > 0
                    and abs(value) >= 0.5 * abs(native)
                    for arm, value in deltas.items()
                },
            }
        )
    for block, schema, rev in itertools.product(blocks(), ("generic", "descriptive"), range(2)):
        rows = [
            c
            for c in cells
            if (c["block"], c["schema"], c["reverse"]) == (block["id"], schema, rev)
        ]
        assert len(rows) == 4 and sorted(c["supported"] for c in rows) == [False, False, True, True]
        b = {
            arm: [
                math.fsum(
                    (1 if c["supported"] else -1) * c["margins"][arm][bit]["log_odds"] for c in rows
                )
                / 2
                for bit in range(2)
            ]
            for arm in ARMS
        }
        d = {arm: pair[1] - pair[0] for arm, pair in b.items()}
        native = d["native"]
        panels.append(
            {
                "block": block["id"],
                "schema": schema,
                "reverse": rev,
                "B": b,
                "delta_B": d,
                "individual_eligible": all(c["native_eligible"] for c in rows),
                "balanced_eligible": abs(native) >= 0.2,
                "individual_matching": {arm: all(c["matching"][arm] for c in rows) for arm in ARMS},
                "individual_retention": {
                    arm: all(c["retention"][arm] for c in rows) for arm in ARMS
                },
                "balanced_matching": {arm: abs(value - native) <= 0.1 for arm, value in d.items()},
                "balanced_retention": {
                    arm: abs(native) >= 0.2
                    and native * value > 0
                    and abs(value) >= 0.5 * abs(native)
                    for arm, value in d.items()
                },
                "maximum_individual_effect_error": {
                    arm: max(abs(c["delta"][arm] - c["delta"]["native"]) for c in rows)
                    for arm in ARMS
                },
            }
        )
    accounts = {}
    for metric in (
        "individual_matching",
        "balanced_matching",
        "individual_retention",
        "balanced_retention",
    ):
        accounts[metric] = {
            arm: {
                "compatible_panels": sum(p[metric][arm] for p in panels),
                "strata": {
                    f"{schema}_{rev}": sum(
                        p[metric][arm]
                        for p in panels
                        if p["schema"] == schema and p["reverse"] == rev
                    )
                    for schema, rev in itertools.product(("generic", "descriptive"), range(2))
                },
                "whole_passed": qualified
                and all(
                    sum(
                        p[metric][arm]
                        for p in panels
                        if p["schema"] == schema and p["reverse"] == rev
                    )
                    >= 3
                    for schema, rev in itertools.product(("generic", "descriptive"), range(2))
                ),
            }
            for arm in ARMS
        }
    # Descriptive exact factorial decomposition, no fitting or feature interpretation.
    interactions = []
    for c in cells:
        entry = {k: c[k] for k in ("block", "schema", "reverse", "assignment", "target")}
        entry["native_delta"] = c["delta"]["native"]
        entry["terms"] = {}
        for size in range(1, 4):
            for subset in itertools.combinations("NWG", size):
                label = "".join(subset)
                terms = []
                for subsize in range(size + 1):
                    for sub in itertools.combinations(subset, subsize):
                        name = "".join(sub) if sub else "native"
                        terms.append((-1) ** (size - subsize) * c["delta"][name])
                entry["terms"][label] = math.fsum(terms)
        entry["reconstruction_error"] = (
            math.fsum([entry["native_delta"], *entry["terms"].values()]) - c["delta"]["NWG"]
        )
        interactions.append(entry)
    return {
        "cells": cells,
        "panels": panels,
        "accounts": accounts,
        "factorial_interactions": interactions,
    }


def main():
    b = json.loads((RUN / "design.json").read_text())
    status = json.loads((RUN / "pipeline-status.json").read_text())
    assert digest(b["design"]) == b["fingerprint"] and b["design"]["source_hash"] == source_hash()
    assert (
        status["status"] == "complete"
        and status["completed_forwards"] == 1408
        and status["fingerprint"] == b["fingerprint"]
    )
    cfg = b["design"]["models"]["qwen15"]
    tok = AutoTokenizer.from_pretrained(
        cfg["model"], revision=cfg["revision"], local_files_only=True
    )
    config = AutoConfig.from_pretrained(
        cfg["model"], revision=cfg["revision"], local_files_only=True
    )
    rt = json.loads((RUN / "qwen15/runtime.json").read_text())
    runtime_ok = (
        digest(tok.get_vocab()) == rt["tokenizer_hash"]
        and config.num_hidden_layers == 28
        and config.hidden_size == 1536
        and rt
        == json.loads((ROOT / "runs/layer-curvature-atlas-179/qwen15/runtime.json").read_text())
    )
    cp = RUN / "qwen15/canonical-directions.npz"
    provenance = json.loads((RUN / "qwen15/canonical-provenance.json").read_text())
    assert provenance["sha256"] == hashed(cp) and provenance["completed_forwards"] == 128
    with np.load(cp, allow_pickle=False) as z:
        canon = {name: z[name].copy() for name in z.files}
    checks = {
        name: True
        for name in (
            "immutable_design_runtime",
            "all64_natural_single_token_pairs",
            "all28_layers_57_norms_capture_shapes",
            "native_factor_hashes_and_causal_weights",
            "all_shared_means_targets_and_spans",
            "all128_exact_own_factor_identities",
            "unclamped_metadata_encoder_identity",
            "neutral_exact_zero_bit_response",
            "neutral_shared_reader_affinity",
            "canonical_query_blind_directions",
            "complete_1408_forward_crossing",
            "public_score_arithmetic",
        )
    }
    checks["immutable_design_runtime"] = runtime_ok
    records, affinity = [], []
    for block, a, t, rev, schema in itertools.product(
        blocks(), range(2), range(2), range(2), ("generic", "descriptive")
    ):
        g = fixture.group(block, a, t, rev, schema)
        key = digest(g)
        ne = read_record(RUN / "qwen15/native" / f"{key}.json")
        e = read_record(RUN / "qwen15/records" / f"{key}.json")
        nr, r = ne["record"], e["record"]
        assert (
            r["native_sha256"] == ne["sha256"]
            and r["fingerprint"] == nr["fingerprint"] == b["fingerprint"]
        )
        assert all(r[k] == nr[k] == v for k, v in g.items())
        npth, p = RUN / "qwen15/native" / f"{key}.npz", RUN / "qwen15/states" / f"{key}.npz"
        assert nr["states_sha256"] == hashed(npth) and r["states_sha256"] == hashed(p)
        bases = [fixture.reconstruct(tok, block, fixture.job(g, bit)) for bit in range(2)]
        pos, length = r["position"], len(bases[0]["free_input_ids"])
        nrecv = length - pos - 1
        assert nrecv > 0 and len(bases[1]["free_input_ids"]) == length
        checks["all64_natural_single_token_pairs"] &= (
            [
                i
                for i, (x, y) in enumerate(
                    zip(bases[0]["free_input_ids"], bases[1]["free_input_ids"])
                )
                if x != y
            ]
            == [pos]
            and bases == [n["base"] for n in nr["natives"]]
            and bases[0]["messages"] == bases[1]["messages"]
            and bases[0]["facts"] == bases[1]["facts"]
        )
        with np.load(npth, allow_pickle=False) as nz, np.load(p, allow_pickle=False) as z:
            caps = [native_caps(nz, bit) for bit in range(2)]
            means = {name: midpoint(caps[0][name], caps[1][name]) for name in sites()}
            checks["all_shared_means_targets_and_spans"] &= all(
                np.array_equal(z[f"mean_{name}"], value) for name, value in means.items()
            )
            for bit in range(2):
                checks["all28_layers_57_norms_capture_shapes"] &= set(caps[bit]) == sites() and nz[
                    f"native_{bit}_final"
                ].shape == (length, 1536)
                for name, value in caps[bit].items():
                    shape = (
                        (nrecv, 1)
                        if name[0] == "N"
                        else (config.num_attention_heads, nrecv, length)
                        if name[0] == "W"
                        else (nrecv, config.intermediate_size)
                        if name[0] == "G"
                        else (
                            config.num_key_value_heads
                            * (config.hidden_size // config.num_attention_heads),
                        )
                    )
                    checks["all28_layers_57_norms_capture_shapes"] &= (
                        value.shape == shape
                        and value.dtype == np.float32
                        and np.isfinite(value).all()
                    )
                    if name[0] == "N":
                        checks["native_factor_hashes_and_causal_weights"] &= (value > 0).all()
                    elif name[0] == "W":
                        checks["native_factor_hashes_and_causal_weights"] &= (
                            (value >= 0).all()
                            and np.max(abs(value.astype(np.float64).sum(-1) - 1)) <= 1e-6
                            and all(
                                np.count_nonzero(value[:, row, pos + 2 + row :]) == 0
                                for row in range(nrecv)
                            )
                        )
                trace = nr["natives"][bit]["trace"]
                checks["native_factor_hashes_and_causal_weights"] &= (
                    len(trace) == 141
                    and {x["site"] for x in trace} == sites()
                    and all(
                        not x["fixed"]
                        and x["applied_sha256"] == array_hash(caps[bit][x["site"]])
                        and x["other_rows_identical"]
                        and (x["start"], x["end"])
                        == ((pos, pos + 1) if x["site"][0] == "V" else (pos + 1, length))
                        for x in trace
                    )
                )
                checks["public_score_arithmetic"] &= margin_valid(nr["natives"][bit]["margin"])
            assert len(r["patches"]) == 20 and {(q["arm"], q["bit"]) for q in r["patches"]} == set(
                itertools.product(ARMS[1:], range(2))
            )
            for q in r["patches"]:
                arm, bit = q["arm"], q["bit"]
                h, baseline = z[f"{arm}_{bit}_final"], nz[f"native_{bit}_final"]
                selected = "NWG" if arm in ("own", "NWG", "neutral", "canonical") else arm
                target_factors = caps[bit] if arm == "own" else means
                targets = {name: v for name, v in target_factors.items() if name[0] in selected}
                if arm == "neutral":
                    targets.update({name: v for name, v in means.items() if name[0] == "V"})
                if arm == "canonical":
                    targets.update(
                        {
                            f"V_{site}": (
                                means[f"V_{site}"].astype(np.float64)
                                + (bit - 0.5) * canon[f"{schema}_{rev}_V_{site}"].astype(np.float64)
                            ).astype(np.float32)
                            for site in range(1, 29)
                        }
                    )
                trace = q["trace"]
                checks["all_shared_means_targets_and_spans"] &= (
                    len(trace) == 141
                    and {x["site"] for x in trace} == sites()
                    and all(
                        x["other_rows_identical"]
                        and x["fixed"] == (x["site"] in targets)
                        and (x["start"], x["end"])
                        == ((pos, pos + 1) if x["site"][0] == "V" else (pos + 1, length))
                        and (
                            x["site"] not in targets
                            or x["applied_sha256"] == array_hash(targets[x["site"]])
                        )
                        for x in trace
                    )
                    and h.shape == baseline.shape
                    and np.array_equal(h[:pos], baseline[:pos])
                )
                checks["public_score_arithmetic"] &= margin_valid(q["margin"])
                if arm == "own":
                    checks["all128_exact_own_factor_identities"] &= q["margin"] == nr["natives"][
                        bit
                    ]["margin"] and np.array_equal(h, baseline)
                if arm not in ("neutral", "canonical"):
                    checks["unclamped_metadata_encoder_identity"] &= np.array_equal(
                        h[: pos + 1], baseline[: pos + 1]
                    ) and all(
                        np.array_equal(z[f"{arm}_{bit}_V_{site}"], caps[bit][f"V_{site}"])
                        for site in range(1, 29)
                    )
                else:
                    checks["all_shared_means_targets_and_spans"] &= all(
                        np.array_equal(z[f"{arm}_{bit}_V_{site}"], targets[f"V_{site}"])
                        for site in range(1, 29)
                    )
            neutral = [
                next(q["margin"] for q in r["patches"] if (q["arm"], q["bit"]) == ("neutral", bit))
                for bit in range(2)
            ]
            shared = [
                next(q["margin"] for q in r["patches"] if (q["arm"], q["bit"]) == ("NWG", bit))
                for bit in range(2)
            ]
            nonmeta = np.r_[np.arange(pos), np.arange(pos + 1, length)]
            checks["neutral_exact_zero_bit_response"] &= neutral[0] == neutral[
                1
            ] and np.array_equal(z["neutral_0_final"][nonmeta], z["neutral_1_final"][nonmeta])
            score_error = max(
                abs(neutral[0][name] - (shared[0][name] + shared[1][name]) / 2)
                for name in neutral[0]
            )
            state_error = float(
                np.max(
                    abs(
                        z["neutral_0_final"][pos + 1 :].astype(np.float64)
                        - (
                            z["NWG_0_final"][pos + 1 :].astype(np.float64)
                            + z["NWG_1_final"][pos + 1 :].astype(np.float64)
                        )
                        / 2
                    )
                )
            )
            checks["neutral_shared_reader_affinity"] &= (
                score_error <= 0.005 and state_error <= 0.005
            )
            affinity.append({**g, "score_error": score_error, "state_error": state_error})
            if block["id"] == "bronze" and a == t == 0:
                checks["canonical_query_blind_directions"] &= all(
                    np.array_equal(
                        canon[f"{schema}_{rev}_V_{site}"],
                        caps[1][f"V_{site}"] - caps[0][f"V_{site}"],
                    )
                    for site in range(1, 29)
                )
        records.append({**r, "natives": nr["natives"]})
    checks["complete_1408_forward_crossing"] = (
        len(records) == 64
        and len(list((RUN / "qwen15/records").glob("*.json")))
        == len(list((RUN / "qwen15/native").glob("*.json")))
        == 64
    )
    nump = ROOT / "docs/analysis/181-numerical-recheck.json"
    numerical = False
    if nump.exists():
        n = json.loads(nump.read_text())
        numerical = (
            n["passed"]
            and n["fingerprint"] == b["fingerprint"]
            and n["forwards"] == 88
            and n["source_sha256"]
            == hashed(ROOT / "scripts/recheck_natural_bit_shared_reader_181.py")
            and n["audit_sha256"] == hashed(Path(__file__))
        )
    valid = all(checks.values()) and numerical
    report = {
        "complete": True,
        "fingerprint": b["fingerprint"],
        "main_forwards": 1408,
        "controls": {k: bool(v) for k, v in checks.items()},
        "numerical_qualified": bool(numerical),
        "affinity": affinity,
        **summarize(records, valid),
        "scope": "One pinned checkpoint, four reused dependent synthetic sources. Per-pair shared factors are calibrated counterfactuals, not universal features; selected88-forward independent replay. No grounding/deployment/priority claim.",
    }
    write_json(OUT, report)
    print(
        json.dumps(
            {
                "complete": True,
                "controls": report["controls"],
                "numerical_qualified": numerical,
                "maximum_affinity_score_error": max(x["score_error"] for x in affinity),
                "maximum_affinity_state_error": max(x["state_error"] for x in affinity),
                "accounts": report["accounts"],
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
