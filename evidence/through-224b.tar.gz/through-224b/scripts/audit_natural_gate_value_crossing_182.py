"""Independent gate/value target grid, token-path controls and effect accounting."""

import itertools
import json
import math
from pathlib import Path

import audit_natural_bit_shared_reader_181 as parent
import numpy as np

from latent_decisions.evidence_policy import digest, write_json

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / "runs/natural-gate-value-crossing-182"
OUT = ROOT / "docs/analysis/182-independent-audit.json"
EFFECTS = ("native", "own", "gate_only", "value_only", "joint", "canonical_gate")


def source_hash():
    return digest(
        {
            "runner": (ROOT / "scripts/run_natural_gate_value_crossing_182.py").read_text(),
            "protocol": (ROOT / "docs/experiments/182-natural-gate-value-crossing.md").read_text(),
            "parent": parent.source_hash(),
        }
    )


def blend(a, b, i):
    return a.copy() if i == 0 else b.copy() if i == 2 else parent.midpoint(a, b)


def surface_effects(f):
    gate = f(2, 1) - f(0, 1)
    value = f(1, 2) - f(1, 0)
    joint = f(2, 2) - f(0, 0)
    gate_shapley = ((f(2, 2) - f(0, 2)) + (f(2, 0) - f(0, 0))) / 2
    value_shapley = ((f(2, 2) - f(2, 0)) + (f(0, 2) - f(0, 0))) / 2
    return {
        "gate_only": gate,
        "value_only": value,
        "joint": joint,
        "gate_shapley": gate_shapley,
        "value_shapley": value_shapley,
        "rectangle_interaction": f(2, 2) - f(2, 0) - f(0, 2) + f(0, 0),
        "shapley_sum_error": gate_shapley + value_shapley - joint,
        "gate_midpoint_affinity_error": gate - gate_shapley,
    }


def estimands(records, valid):
    cells = []
    for r in records:

        def m(label):
            return next(p["margin"]["log_odds"] for p in r["patches"] if p["label"] == label)

        surface = surface_effects(lambda gi, vi: m(f"grid_{gi}_{vi}"))
        native = r["natives"][1]["margin"]["log_odds"] - r["natives"][0]["margin"]["log_odds"]
        delta = {
            "native": native,
            "own": m("own_1") - m("own_0"),
            **{name: surface[name] for name in ("gate_only", "value_only", "joint")},
            "canonical_gate": m("canonical_1") - m("canonical_0"),
        }
        cells.append(
            {
                **{k: r[k] for k in ("block", "schema", "reverse", "assignment", "target")},
                "supported": r["natives"][0]["base"]["facts"]["supported"],
                "delta": delta,
                "surface": {
                    f"{gi}_{vi}": m(f"grid_{gi}_{vi}")
                    for gi, vi in itertools.product(range(3), repeat=2)
                },
                "decomposition": surface,
                "eligible": abs(native) >= 0.5,
                "matching": {arm: abs(d - native) <= 0.1 for arm, d in delta.items()},
                "retention": {
                    arm: abs(native) >= 0.5 and native * d > 0 and abs(d) >= 0.5 * abs(native)
                    for arm, d in delta.items()
                },
            }
        )
    panels = []
    for block, schema, rev in itertools.product(
        parent.blocks(), ("generic", "descriptive"), range(2)
    ):
        rows = [
            c
            for c in cells
            if (c["block"], c["schema"], c["reverse"]) == (block["id"], schema, rev)
        ]
        assert len(rows) == 4 and sorted(c["supported"] for c in rows) == [False, False, True, True]
        balanced = {
            arm: math.fsum((1 if c["supported"] else -1) * c["delta"][arm] for c in rows) / 2
            for arm in EFFECTS
        }
        native = balanced["native"]
        panels.append(
            {
                "block": block["id"],
                "schema": schema,
                "reverse": rev,
                "delta_B": balanced,
                "common_delta_M": {
                    arm: math.fsum(c["delta"][arm] for c in rows) / 4 for arm in EFFECTS
                },
                "maximum_individual_effect_error": {
                    arm: max(abs(c["delta"][arm] - c["delta"]["native"]) for c in rows)
                    for arm in EFFECTS
                },
                "individual_matching": {
                    arm: all(c["matching"][arm] for c in rows) for arm in EFFECTS
                },
                "individual_retention": {
                    arm: all(c["retention"][arm] for c in rows) for arm in EFFECTS
                },
                "balanced_matching": {arm: abs(d - native) <= 0.1 for arm, d in balanced.items()},
                "balanced_retention": {
                    arm: abs(native) >= 0.2 and native * d > 0 and abs(d) >= 0.5 * abs(native)
                    for arm, d in balanced.items()
                },
                "individual_eligible": all(c["eligible"] for c in rows),
                "balanced_eligible": abs(native) >= 0.2,
                "decomposition_B": {
                    name: math.fsum(
                        (1 if c["supported"] else -1) * c["decomposition"][name] for c in rows
                    )
                    / 2
                    for name in rows[0]["decomposition"]
                },
            }
        )
    accounts = {
        metric: {
            arm: {
                "compatible_panels": sum(p[metric][arm] for p in panels),
                "strata": {
                    f"{schema}_{rev}": sum(
                        p[metric][arm]
                        for p in panels
                        if (p["schema"], p["reverse"]) == (schema, rev)
                    )
                    for schema, rev in itertools.product(("generic", "descriptive"), range(2))
                },
                "whole_passed": valid
                and all(
                    sum(
                        p[metric][arm]
                        for p in panels
                        if (p["schema"], p["reverse"]) == (schema, rev)
                    )
                    >= 3
                    for schema, rev in itertools.product(("generic", "descriptive"), range(2))
                ),
            }
            for arm in EFFECTS
        }
        for metric in (
            "individual_matching",
            "balanced_matching",
            "individual_retention",
            "balanced_retention",
        )
    }
    return {"cells": cells, "panels": panels, "accounts": accounts}


def main():
    b = json.loads((RUN / "design.json").read_text())
    status = json.loads((RUN / "pipeline-status.json").read_text())
    assert digest(b["design"]) == b["fingerprint"] and b["design"]["source_hash"] == source_hash()
    assert (
        status["status"] == "complete"
        and status["fingerprint"] == b["fingerprint"]
        and status["completed_forwards"] == 832
    )
    pa = json.loads(parent.OUT.read_text())
    assert (
        pa["fingerprint"] == b["design"]["parent_fingerprint"]
        and pa["numerical_qualified"]
        and all(pa["controls"].values())
    )
    rt = json.loads((RUN / "qwen15/runtime.json").read_text())
    assert rt == json.loads((parent.RUN / "qwen15/runtime.json").read_text())
    canonp = RUN / "canonical-gate-directions.npz"
    provenance = json.loads((RUN / "canonical-provenance.json").read_text())
    assert provenance["sha256"] == parent.hashed(canonp) and provenance["before182_forwards"]
    with np.load(canonp, allow_pickle=False) as z:
        canon = {name: z[name].copy() for name in z.files}
    checks = {
        name: True
        for name in (
            "immutable_sources_runtime_parent",
            "complete832_crossed_forward_accounting",
            "all141_target_hashes_and_spans",
            "all128_own_factor_value_exact_identities",
            "all192_shared_parent_replays",
            "same_input_grid_earlier_rows",
            "canonical_query_blind_gate_targets",
            "all192_value_affinity_controls",
            "public_score_arithmetic",
            "shapley_algebra",
        )
    }
    records, affinity, direction_norms = [], [], []
    for block, a, t, rev, schema in itertools.product(
        parent.blocks(), range(2), range(2), range(2), ("generic", "descriptive")
    ):
        g = parent.fixture.group(block, a, t, rev, schema)
        key = digest(g)
        ne = parent.read_record(parent.RUN / "qwen15/native" / f"{key}.json")
        pe = parent.read_record(parent.RUN / "qwen15/records" / f"{key}.json")
        e = parent.read_record(RUN / "qwen15/records" / f"{key}.json")
        nr, pr, r = ne["record"], pe["record"], e["record"]
        assert (
            r["fingerprint"] == b["fingerprint"]
            and r["native_sha256"] == ne["sha256"]
            and r["parent_record_sha256"] == pe["sha256"]
            and all(r[k] == nr[k] == v for k, v in g.items())
        )
        npth, ppth, p = (
            parent.RUN / "qwen15/native" / f"{key}.npz",
            parent.RUN / "qwen15/states" / f"{key}.npz",
            RUN / "qwen15/states" / f"{key}.npz",
        )
        assert (
            parent.hashed(npth) == nr["states_sha256"]
            and parent.hashed(ppth) == pr["states_sha256"]
            and parent.hashed(p) == r["states_sha256"]
        )
        pos, length = r["position"], len(nr["natives"][0]["base"]["free_input_ids"])
        nonmeta = np.r_[np.arange(pos), np.arange(pos + 1, length)]
        assert len(r["patches"]) == len({q["label"] for q in r["patches"]}) == 13 and {
            q["label"] for q in r["patches"]
        } == {f"own_{bit}" for bit in range(2)} | {f"canonical_{bit}" for bit in range(2)} | {
            f"grid_{gi}_{vi}" for gi, vi in itertools.product(range(3), repeat=2)
        }
        with (
            np.load(npth, allow_pickle=False) as nz,
            np.load(ppth, allow_pickle=False) as pz,
            np.load(p, allow_pickle=False) as z,
        ):
            caps = [parent.native_caps(nz, bit) for bit in range(2)]
            means = {name: parent.midpoint(caps[0][name], caps[1][name]) for name in parent.sites()}
            for q in r["patches"]:
                label, family, bit = q["label"], q["family"], q["bit"]
                if family == "own":
                    targets = caps[bit]
                    checks["all128_own_factor_value_exact_identities"] &= q["margin"] == nr[
                        "natives"
                    ][bit]["margin"] and np.array_equal(
                        z[f"{label}_final"], nz[f"native_{bit}_final"]
                    )
                else:
                    targets = {name: v for name, v in means.items() if name[0] in "NW"}
                    if family == "grid":
                        gi, vi = q["gamma"], q["alpha"]
                        assert (
                            gi in range(3)
                            and vi in range(3)
                            and bit is None
                            and label == f"grid_{gi}_{vi}"
                        )
                        targets.update(
                            {
                                f"G_{site}": blend(caps[0][f"G_{site}"], caps[1][f"G_{site}"], gi)
                                for site in range(1, 29)
                            }
                        )
                        targets.update(
                            {
                                f"V_{site}": blend(caps[0][f"V_{site}"], caps[1][f"V_{site}"], vi)
                                for site in range(1, 29)
                            }
                        )
                        if gi == 1:
                            arm, refbit = ("neutral", 0) if vi == 1 else ("NWG", vi // 2)
                            expected = next(
                                p["margin"]
                                for p in pr["patches"]
                                if (p["arm"], p["bit"]) == (arm, refbit)
                            )
                            checks["all192_shared_parent_replays"] &= q[
                                "margin"
                            ] == expected and np.array_equal(
                                z[f"{label}_final"][nonmeta], pz[f"{arm}_{refbit}_final"][nonmeta]
                            )
                    else:
                        assert (
                            family == "canonical"
                            and bit in range(2)
                            and label == f"canonical_{bit}"
                        )
                        targets.update({name: v for name, v in means.items() if name[0] == "V"})
                        targets.update(
                            {
                                f"G_{site}": (
                                    means[f"G_{site}"].astype(np.float64)
                                    + (bit - 0.5)
                                    * canon[f"{schema}_{rev}_G_{site}"].astype(np.float64)
                                ).astype(np.float32)
                                for site in range(1, 29)
                            }
                        )
                    checks["same_input_grid_earlier_rows"] &= np.array_equal(
                        z[f"{label}_final"][:pos], nz["native_0_final"][:pos]
                    )
                trace = q["trace"]
                checks["all141_target_hashes_and_spans"] &= (
                    set(targets) == parent.sites()
                    and len(trace) == 141
                    and {x["site"] for x in trace} == parent.sites()
                    and all(
                        x["fixed"]
                        and x["other_rows_identical"]
                        and x["applied_sha256"] == parent.array_hash(targets[x["site"]])
                        and (x["start"], x["end"])
                        == ((pos, pos + 1) if x["site"][0] == "V" else (pos + 1, length))
                        for x in trace
                    )
                    and z[f"{label}_final"].shape == (length, 1536)
                )
                checks["public_score_arithmetic"] &= parent.margin_valid(q["margin"])
            for gi in range(3):
                scores = [
                    next(q["margin"] for q in r["patches"] if q["label"] == f"grid_{gi}_{vi}")
                    for vi in range(3)
                ]
                score_error = max(
                    abs(scores[1][name] - (scores[0][name] + scores[2][name]) / 2)
                    for name in scores[1]
                )
                state_error = float(
                    np.max(
                        abs(
                            z[f"grid_{gi}_1_final"][pos + 1 :].astype(np.float64)
                            - (
                                z[f"grid_{gi}_0_final"][pos + 1 :].astype(np.float64)
                                + z[f"grid_{gi}_2_final"][pos + 1 :].astype(np.float64)
                            )
                            / 2
                        )
                    )
                )
                checks["all192_value_affinity_controls"] &= (
                    score_error <= 0.005 and state_error <= 0.005
                )
                affinity.append(
                    {**g, "gamma": gi, "score_error": score_error, "state_error": state_error}
                )
            if block["id"] == "bronze" and a == t == 0:
                checks["canonical_query_blind_gate_targets"] &= provenance["sources"][
                    f"{schema}_{rev}"
                ] == {"record_sha256": ne["sha256"], "state_sha256": nr["states_sha256"]} and all(
                    np.array_equal(
                        canon[f"{schema}_{rev}_G_{site}"],
                        caps[1][f"G_{site}"] - caps[0][f"G_{site}"],
                    )
                    for site in range(1, 29)
                )
            local_norm = math.sqrt(
                sum(
                    float(
                        np.square(
                            (caps[1][f"G_{site}"] - caps[0][f"G_{site}"]).astype(np.float64)
                        ).sum()
                    )
                    for site in range(1, 29)
                )
            )
            canonical_norm = math.sqrt(
                sum(
                    float(np.square(canon[f"{schema}_{rev}_G_{site}"].astype(np.float64)).sum())
                    for site in range(1, 29)
                )
            )
            direction_norms.append(
                {
                    **g,
                    "local_gate_difference_norm": local_norm,
                    "canonical_gate_difference_norm": canonical_norm,
                    "norm_ratio": canonical_norm / local_norm,
                }
            )
        records.append({**r, "natives": nr["natives"]})
    checks["complete832_crossed_forward_accounting"] &= (
        len(records) == len(list((RUN / "qwen15/records").glob("*.json"))) == 64
    )
    results = estimands(records, False)
    checks["shapley_algebra"] &= all(
        abs(c["decomposition"]["shapley_sum_error"]) < 1e-10
        and abs(c["decomposition"]["gate_midpoint_affinity_error"]) <= 0.01
        for c in results["cells"]
    )
    npth = ROOT / "docs/analysis/182-numerical-recheck.json"
    numerical = False
    if npth.exists():
        n = json.loads(npth.read_text())
        numerical = (
            n["passed"]
            and n["fingerprint"] == b["fingerprint"]
            and n["forwards"] == 60
            and n["source_sha256"]
            == parent.hashed(ROOT / "scripts/recheck_natural_gate_value_crossing_182.py")
            and n["audit_sha256"] == parent.hashed(Path(__file__))
            and n["helper_sha256"]
            == parent.hashed(ROOT / "scripts/recheck_natural_bit_shared_reader_181.py")
        )
    result = {
        "complete": True,
        "fingerprint": b["fingerprint"],
        "controls": {k: bool(v) for k, v in checks.items()},
        "numerical_qualified": numerical,
        "main_forwards": 832,
        "affinity": affinity,
        "direction_norms": direction_norms,
        **estimands(records, numerical and all(checks.values())),
        "scope": "Natural-capture trajectory sufficiency under shared N/W, not a minimal learned circuit or natural-path equivalence. Single checkpoint/reused sources; selected60-forward independent replay.",
    }
    write_json(OUT, result)
    print(
        json.dumps(
            {
                "controls": result["controls"],
                "numerical_qualified": numerical,
                "accounts": result["accounts"],
                "maximum_affinity_score_error": max(x["score_error"] for x in affinity),
                "maximum_affinity_state_error": max(x["state_error"] for x in affinity),
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
