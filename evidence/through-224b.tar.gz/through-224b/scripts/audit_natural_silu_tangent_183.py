"""Independent analytic tangent maps, native replays and endpoint/effect separation."""

import itertools
import json
import math
from pathlib import Path

import audit_natural_bit_shared_reader_181 as native
import audit_natural_gate_value_crossing_182 as parent
import numpy as np

from latent_decisions.evidence_policy import digest, write_json

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / "runs/natural-silu-tangent-183"
OUT = ROOT / "docs/analysis/183-independent-audit.json"
MODES = ("raw", "native_NW", "tangent_free", "tangent_NW")


def source_hash():
    return digest(
        {
            "runner": (ROOT / "scripts/run_natural_silu_tangent_183.py").read_text(),
            "protocol": (ROOT / "docs/experiments/183-natural-silu-tangent.md").read_text(),
            "parent": parent.source_hash(),
        }
    )


def anchor(x0, x1):
    c = 0.5 * (x0.astype(np.float64) + x1.astype(np.float64))
    # Stable sign-separated sigmoid, independent of the runner's logaddexp expression.
    s = np.empty_like(c)
    positive = c >= 0
    s[positive] = 1 / (1 + np.exp(-c[positive]))
    ec = np.exp(c[~positive])
    s[~positive] = ec / (1 + ec)
    return {
        "center": c.astype(np.float32),
        "intercept": (c * s).astype(np.float32),
        "slope": (s * (1 + c * (1 - s))).astype(np.float32),
    }


def estimands(records, valid):
    cells = []
    for r in records:
        margins = {
            mode: [
                next(
                    p["margin"]["log_odds"]
                    for p in r["patches"]
                    if (p["mode"], p["bit"]) == (mode, bit)
                )
                for bit in range(2)
            ]
            for mode in MODES
        }
        effects = {mode: m[1] - m[0] for mode, m in margins.items()}
        cells.append(
            {
                **{k: r[k] for k in ("block", "schema", "reverse", "assignment", "target")},
                "supported": r["natives"][0]["base"]["facts"]["supported"],
                "margins": margins,
                "delta": effects,
            }
        )
    panels = []
    for block, schema, rev, mode in itertools.product(
        native.blocks(), ("generic", "descriptive"), range(2), ("tangent_free", "tangent_NW")
    ):
        rows = [
            c
            for c in cells
            if (c["block"], c["schema"], c["reverse"]) == (block["id"], schema, rev)
        ]
        assert len(rows) == 4 and sorted(c["supported"] for c in rows) == [False, False, True, True]
        base = "raw" if mode == "tangent_free" else "native_NW"
        b = {
            label: [
                math.fsum((1 if c["supported"] else -1) * c["margins"][label][bit] for c in rows)
                / 2
                for bit in range(2)
            ]
            for label in MODES
        }
        db = {label: m[1] - m[0] for label, m in b.items()}
        e = [
            {
                "assignment": c["assignment"],
                "target": c["target"],
                "bit": bit,
                "error": c["margins"][mode][bit] - c["margins"][base][bit],
            }
            for c in rows
            for bit in range(2)
        ]
        de = [
            {
                "assignment": c["assignment"],
                "target": c["target"],
                "error": c["delta"][mode] - c["delta"][base],
                "native_delta": c["delta"][base],
                "tested_delta": c["delta"][mode],
            }
            for c in rows
        ]
        be = [b[mode][bit] - b[base][bit] for bit in range(2)]
        panels.append(
            {
                "block": block["id"],
                "schema": schema,
                "reverse": rev,
                "mode": mode,
                "baseline": base,
                "B": b,
                "delta_B": db,
                "individual_endpoint_errors": e,
                "individual_effect_errors": de,
                "balanced_endpoint_errors": be,
                "balanced_effect_error": db[mode] - db[base],
                "maximum_individual_endpoint_error": max(abs(v["error"]) for v in e),
                "maximum_individual_effect_error": max(abs(v["error"]) for v in de),
                "individual_endpoint_matching": all(abs(v["error"]) <= 0.1 for v in e),
                "individual_effect_matching": all(abs(v["error"]) <= 0.1 for v in de),
                "balanced_endpoint_matching": all(abs(v) <= 0.1 for v in be),
                "balanced_effect_matching": abs(db[mode] - db[base]) <= 0.1,
                "individual_retention": all(
                    abs(c["delta"][base]) >= 0.5
                    and c["delta"][base] * c["delta"][mode] > 0
                    and abs(c["delta"][mode]) >= 0.5 * abs(c["delta"][base])
                    for c in rows
                ),
                "balanced_retention": abs(db[base]) >= 0.2
                and db[base] * db[mode] > 0
                and abs(db[mode]) >= 0.5 * abs(db[base]),
            }
        )
    accounts = {}
    for metric in (
        "individual_endpoint_matching",
        "individual_effect_matching",
        "balanced_endpoint_matching",
        "balanced_effect_matching",
        "individual_retention",
        "balanced_retention",
    ):
        accounts[metric] = {
            mode: {
                "compatible_panels": sum(p[metric] for p in panels if p["mode"] == mode),
                "strata": {
                    f"{schema}_{rev}": sum(
                        p[metric]
                        for p in panels
                        if (p["mode"], p["schema"], p["reverse"]) == (mode, schema, rev)
                    )
                    for schema, rev in itertools.product(("generic", "descriptive"), range(2))
                },
                "whole_passed": valid
                and all(
                    sum(
                        p[metric]
                        for p in panels
                        if (p["mode"], p["schema"], p["reverse"]) == (mode, schema, rev)
                    )
                    >= 3
                    for schema, rev in itertools.product(("generic", "descriptive"), range(2))
                ),
            }
            for mode in ("tangent_free", "tangent_NW")
        }
    return {"cells": cells, "panels": panels, "accounts": accounts}


def main():
    b = json.loads((RUN / "design.json").read_text())
    status = json.loads((RUN / "pipeline-status.json").read_text())
    assert digest(b["design"]) == b["fingerprint"] and b["design"]["source_hash"] == source_hash()
    assert (
        status["status"] == "complete"
        and status["completed_forwards"] == 512
        and status["fingerprint"] == b["fingerprint"]
    )
    assert json.loads((RUN / "qwen15/runtime.json").read_text()) == json.loads(
        (native.RUN / "qwen15/runtime.json").read_text()
    )
    pa = json.loads(parent.OUT.read_text())
    assert (
        pa["fingerprint"] == b["design"]["parent_fingerprint"]
        and pa["numerical_qualified"]
        and all(pa["controls"].values())
    )
    controls = {
        name: True
        for name in (
            "immutable_runtime_sources_parent",
            "complete512_crossing",
            "all128_native_and128_NW_exact_replays",
            "all28_analytic_means_and_derivatives",
            "all28_actual_input_output_formulas",
            "receiver_clamp_targets_gate_value_hashes",
            "all_activation_spans_and_hashes",
            "earlier_metadata_rows_unchanged",
            "public_score_arithmetic",
        )
    }
    records, max_anchor_error, max_formula_error = [], 0.0, 0.0
    for block, a, t, rev, schema in itertools.product(
        native.blocks(), range(2), range(2), range(2), ("generic", "descriptive")
    ):
        g = native.fixture.group(block, a, t, rev, schema)
        key = digest(g)
        ne = native.read_record(native.RUN / "qwen15/native" / f"{key}.json")
        pe = native.read_record(native.RUN / "qwen15/records" / f"{key}.json")
        e = native.read_record(RUN / "qwen15/records" / f"{key}.json")
        nr, pr, r = ne["record"], pe["record"], e["record"]
        assert (
            r["native_sha256"] == ne["sha256"]
            and r["parent_record_sha256"] == pe["sha256"]
            and r["fingerprint"] == b["fingerprint"]
            and all(r[k] == nr[k] == v for k, v in g.items())
        )
        npth, ppth, path = (
            native.RUN / "qwen15/native" / f"{key}.npz",
            native.RUN / "qwen15/states" / f"{key}.npz",
            RUN / "qwen15/states" / f"{key}.npz",
        )
        assert (
            native.hashed(npth) == nr["states_sha256"]
            and native.hashed(ppth) == pr["states_sha256"]
            and native.hashed(path) == r["states_sha256"]
        )
        pos, length = r["position"], len(nr["natives"][0]["base"]["free_input_ids"])
        assert {(q["mode"], q["bit"]) for q in r["patches"]} == set(
            itertools.product(MODES, range(2))
        ) and len(r["patches"]) == 8
        with (
            np.load(npth, allow_pickle=False) as nz,
            np.load(ppth, allow_pickle=False) as pz,
            np.load(path, allow_pickle=False) as z,
        ):
            for site in range(1, 29):
                expected = anchor(z[f"raw_0_{site}_input"], z[f"raw_1_{site}_input"])
                max_anchor_error = max(
                    max_anchor_error,
                    max(
                        float(np.max(abs(v - z[f"anchor_{site}_{name}"])))
                        for name, v in expected.items()
                    ),
                )
            for q in r["patches"]:
                mode, bit = q["mode"], q["bit"]
                prefix = f"{mode}_{bit}"
                h = z[f"{prefix}_final"]
                controls["earlier_metadata_rows_unchanged"] &= h.shape == (
                    length,
                    1536,
                ) and np.array_equal(h[: pos + 1], nz[f"native_{bit}_final"][: pos + 1])
                controls["public_score_arithmetic"] &= native.margin_valid(q["margin"])
                if mode == "raw":
                    controls["all128_native_and128_NW_exact_replays"] &= q["margin"] == nr[
                        "natives"
                    ][bit]["margin"] and np.array_equal(h, nz[f"native_{bit}_final"])
                if mode == "native_NW":
                    expected = next(
                        p["margin"] for p in pr["patches"] if (p["arm"], p["bit"]) == ("NW", bit)
                    )
                    controls["all128_native_and128_NW_exact_replays"] &= q[
                        "margin"
                    ] == expected and np.array_equal(h, pz[f"NW_{bit}_final"])
                trace, at = q["trace"], q["activation_trace"]
                fixed = (
                    {
                        name.removeprefix("mean_"): pz[name]
                        for name in pz.files
                        if name.startswith("mean_") and name.removeprefix("mean_")[0] in "NW"
                    }
                    if mode in ("native_NW", "tangent_NW")
                    else {}
                )
                controls["receiver_clamp_targets_gate_value_hashes"] &= (
                    len(trace) == 141
                    and {x["site"] for x in trace} == native.sites()
                    and all(
                        x["other_rows_identical"]
                        and x["fixed"] == (x["site"] in fixed)
                        and (x["start"], x["end"])
                        == ((pos, pos + 1) if x["site"][0] == "V" else (pos + 1, length))
                        and (
                            x["site"] not in fixed
                            or x["applied_sha256"] == native.array_hash(fixed[x["site"]])
                        )
                        and (
                            x["site"][0] != "V"
                            or x["applied_sha256"]
                            == native.array_hash(nz[f"native_{bit}_{x['site']}"])
                        )
                        for x in trace
                    )
                )
                controls["all_activation_spans_and_hashes"] &= (
                    len(at) == 28
                    and [x["site"] for x in at] == list(range(1, 29))
                    and all(
                        x["other_rows_identical"]
                        and x["tangent"] == (mode.startswith("tangent"))
                        and (x["start"], x["end"]) == (pos + 1, length)
                        and x["input_sha256"] == native.array_hash(z[f"{prefix}_{x['site']}_input"])
                        and x["output_sha256"]
                        == native.array_hash(z[f"{prefix}_{x['site']}_output"])
                        for x in at
                    )
                )
                for site in range(1, 29):
                    x, y = z[f"{prefix}_{site}_input"], z[f"{prefix}_{site}_output"]
                    controls["all28_actual_input_output_formulas"] &= (
                        x.shape == y.shape == (length - pos - 1, 8960)
                        and x.dtype == y.dtype == np.float32
                        and np.isfinite(x).all()
                        and np.isfinite(y).all()
                    )
                    if mode.startswith("tangent"):
                        expected = z[f"anchor_{site}_intercept"] + z[f"anchor_{site}_slope"] * (
                            x - z[f"anchor_{site}_center"]
                        )
                    else:
                        expected = (
                            x.astype(np.float64) * np.exp(-np.logaddexp(0, -x.astype(np.float64)))
                        ).astype(np.float32)
                    max_formula_error = max(max_formula_error, float(np.max(abs(y - expected))))
                    controls["receiver_clamp_targets_gate_value_hashes"] &= next(
                        v["applied_sha256"] for v in trace if v["site"] == f"G_{site}"
                    ) == native.array_hash(y)
                    if mode == "raw":
                        controls["all128_native_and128_NW_exact_replays"] &= np.array_equal(
                            y, nz[f"native_{bit}_G_{site}"]
                        )
                if mode == "raw":
                    controls["all128_native_and128_NW_exact_replays"] &= all(
                        x["applied_sha256"] == native.array_hash(nz[f"native_{bit}_{x['site']}"])
                        for x in trace
                    )
        records.append({**r, "natives": nr["natives"]})
    controls["all28_analytic_means_and_derivatives"] &= max_anchor_error <= 1e-5
    controls["all28_actual_input_output_formulas"] &= max_formula_error <= 1e-5
    controls["complete512_crossing"] &= (
        len(records) == len(list((RUN / "qwen15/records").glob("*.json"))) == 64
    )
    npth = ROOT / "docs/analysis/183-numerical-recheck.json"
    numerical = False
    if npth.exists():
        n = json.loads(npth.read_text())
        numerical = (
            n["passed"]
            and n["fingerprint"] == b["fingerprint"]
            and n["forwards"] == 32
            and n["source_sha256"]
            == native.hashed(ROOT / "scripts/recheck_natural_silu_tangent_183.py")
            and n["audit_sha256"] == native.hashed(Path(__file__))
            and n["helper_sha256"]
            == native.hashed(ROOT / "scripts/recheck_natural_bit_shared_reader_181.py")
        )
    result = {
        "complete": True,
        "fingerprint": b["fingerprint"],
        "main_forwards": 512,
        "controls": {k: bool(v) for k, v in controls.items()},
        "maximum_anchor_error": max_anchor_error,
        "maximum_activation_formula_error": max_formula_error,
        "numerical_qualified": numerical,
        **estimands(records, numerical and all(controls.values())),
        "scope": "Per-pair local pointwise derivative maps; no endpoint preservation. Native attention/normalization free in primary. Reused dependent templates, one checkpoint; selected numerical replay. No global linearity or semantic/training-origin claim.",
    }
    write_json(OUT, result)
    print(
        json.dumps(
            {
                "controls": result["controls"],
                "numerical_qualified": numerical,
                "maximum_anchor_error": max_anchor_error,
                "maximum_activation_formula_error": max_formula_error,
                "accounts": result["accounts"],
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
