"""Independent false-only derivatives, polynomial captures and strict forecast ordering."""

import itertools
import json
import math
from pathlib import Path

import audit_fresh_norm_split_190 as parent
import audit_one_sided_gain_forecast_186 as timing
import numpy as np
from transformers import AutoTokenizer

from latent_decisions.evidence_policy import digest, write_json

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / "runs/one-sided-curvature-forecast-191"
OUT = ROOT / "docs/analysis/191-independent-audit.json"
native = parent.native
ARMS = ("T1", "Q2", "C3")
LITERALS = (
    ("cypress", "larch", "Monday", "Friday"),
    ("quartz", "agate", "Tuesday", "Sunday"),
    ("meridian", "zenith", "Thursday", "Saturday"),
    ("tundra", "taiga", "Wednesday", "Monday"),
)


def blocks():
    return [
        {"id": a, "stage": "191", "subjects": [a, b], "days": [x, y], "old_block": None}
        for a, b, x, y in LITERALS
    ]


def source_hash():
    return digest(
        {
            "runner": (ROOT / "scripts/run_one_sided_curvature_forecast_191.py").read_text(),
            "protocol": (ROOT / "docs/experiments/191-one-sided-curvature-forecast.md").read_text(),
            "parent": parent.source_hash(),
        }
    )


def coefficients(x, y):
    v = x.astype(np.float64)
    s = np.empty_like(v)
    mask = v >= 0
    s[mask] = 1 / (1 + np.exp(-v[mask]))
    e = np.exp(v[~mask])
    s[~mask] = e / (1 + e)
    q = s * (1 - s)
    t = 1 - 2 * s
    return {
        "center": x.copy(),
        "intercept": y.copy(),
        "slope": (s * (1 + v * (1 - s))).astype(np.float32),
        "second": (q * (2 + v * t) / 2).astype(np.float32),
        "third": (q * (3 * t + v * (t * t - 2 * q)) / 6).astype(np.float32),
    }


def estimands(records, valid):
    cells = []
    for r in records:
        actual = [r["native_false"]["margin"]["log_odds"], r["native_true"]["margin"]["log_odds"]]
        forecasts = {
            arm: [
                next(
                    q["margin"]["log_odds"]
                    for q in r["patches"]
                    if (q["arm"], q["bit"]) == (arm, bit)
                )
                for bit in range(2)
            ]
            for arm in ARMS
        }
        cells.append(
            {
                **{k: r[k] for k in ("block", "schema", "reverse", "assignment", "target")},
                "supported": r["bases"][0]["facts"]["supported"],
                "native": actual,
                "forecasts": forecasts,
                "native_delta": actual[1] - actual[0],
                "errors": {arm: p[1] - actual[1] for arm, p in forecasts.items()},
                "deltas": {arm: p[1] - p[0] for arm, p in forecasts.items()},
            }
        )
    panels = []
    for block, schema, rev in itertools.product(blocks(), ("generic", "descriptive"), range(2)):
        rows = [
            c
            for c in cells
            if (c["block"], c["schema"], c["reverse"]) == (block["id"], schema, rev)
        ]
        assert len(rows) == 4 and sorted(c["supported"] for c in rows) == [False, False, True, True]
        b = [
            math.fsum((1 if c["supported"] else -1) * c["native"][bit] for c in rows) / 2
            for bit in range(2)
        ]
        predicted = {
            arm: [
                math.fsum((1 if c["supported"] else -1) * c["forecasts"][arm][bit] for c in rows)
                / 2
                for bit in range(2)
            ]
            for arm in ARMS
        }
        d = b[1] - b[0]
        panels.append(
            {
                "block": block["id"],
                "schema": schema,
                "reverse": rev,
                "B_native": b,
                "B_forecasts": predicted,
                "native_delta_B": d,
                "individual_true_errors": {
                    arm: [
                        {
                            "assignment": c["assignment"],
                            "target": c["target"],
                            "error": c["errors"][arm],
                        }
                        for c in rows
                    ]
                    for arm in ARMS
                },
                "balanced_true_errors": {arm: p[1] - b[1] for arm, p in predicted.items()},
                "maximum_individual_error": {
                    arm: max(abs(c["errors"][arm]) for c in rows) for arm in ARMS
                },
                "common_true_error": {
                    arm: math.fsum(c["errors"][arm] for c in rows) / 4 for arm in ARMS
                },
                "individual_matching": {
                    arm: all(abs(c["errors"][arm]) <= 0.1 for c in rows) for arm in ARMS
                },
                "balanced_matching": {arm: abs(p[1] - b[1]) <= 0.1 for arm, p in predicted.items()},
                "individual_retention": {
                    arm: all(
                        abs(c["native_delta"]) >= 0.5
                        and c["native_delta"] * c["deltas"][arm] > 0
                        and abs(c["deltas"][arm]) >= 0.5 * abs(c["native_delta"])
                        for c in rows
                    )
                    for arm in ARMS
                },
                "balanced_retention": {
                    arm: abs(d) >= 0.2
                    and d * (p[1] - p[0]) > 0
                    and abs(p[1] - p[0]) >= 0.5 * abs(d)
                    for arm, p in predicted.items()
                },
            }
        )
    accounts = {
        metric: {
            arm: {
                "compatible_panels": sum(p[metric][arm] for p in panels),
                "strata": {
                    f"{schema}_{rev}": sum(
                        p[metric][arm]
                        for p in panels
                        if (p["schema"], p["reverse"]) == (schema, rev)
                    )
                    for schema, rev in itertools.product(("generic", "descriptive"), range(2))
                },
                "whole_passed": valid
                and all(
                    sum(
                        p[metric][arm]
                        for p in panels
                        if (p["schema"], p["reverse"]) == (schema, rev)
                    )
                    >= 3
                    for schema, rev in itertools.product(("generic", "descriptive"), range(2))
                ),
                "prospective": True,
            }
            for arm in ARMS
        }
        for metric in (
            "individual_matching",
            "balanced_matching",
            "individual_retention",
            "balanced_retention",
        )
    }
    return {"cells": cells, "panels": panels, "accounts": accounts}


def main():
    b = json.loads((RUN / "design.json").read_text())
    status = json.loads((RUN / "pipeline-status.json").read_text())
    pa = json.loads(parent.OUT.read_text())
    assert (
        b["fingerprint"] == digest(b["design"])
        and b["design"]["source_hash"] == source_hash()
        and status["status"] == "complete"
        and status["completed_forwards"] == 512
    )
    assert (
        pa["numerical_qualified"]
        and all(pa["controls"].values())
        and pa["fingerprint"] == b["design"]["parent_fingerprint"]
    )
    rt = json.loads((RUN / "qwen15/runtime.json").read_text())
    assert rt == json.loads((parent.RUN / "qwen15/runtime.json").read_text())
    spec = b["design"]["models"]["qwen15"]
    tok = AutoTokenizer.from_pretrained(
        spec["model"], revision=spec["revision"], local_files_only=True
    )
    assert digest(tok.get_vocab()) == rt["tokenizer_hash"]
    manifest = json.loads((RUN / "forecast-manifest.json").read_text())
    assert (
        manifest["completed_forwards"] == 448
        and digest(manifest["manifest"]) == manifest["manifest_sha256"]
        and len(manifest["manifest"]) == 64
    )
    entries = {v["key"]: v for v in manifest["manifest"]}
    controls = {
        k: True
        for k in (
            "immutable_source_runtime_parent",
            "complete512_crossing",
            "all64_new_single_token_pairs",
            "global_forecast_before_native_true",
            "all28_false_only_derivatives",
            "all28_actual_polynomial_spans_formulas",
            "all192_exact_false_state_identities",
            "prefix_metadata_rows_native_exact",
            "public_margin_arithmetic",
            "native_phi_captures_formulas",
        )
    }
    records = []
    ce = fe = 0.0
    before = []
    after = []
    for block, a, t, rev, schema in itertools.product(
        blocks(), range(2), range(2), range(2), ("generic", "descriptive")
    ):
        g = native.fixture.group(block, a, t, rev, schema)
        key = digest(g)
        f = native.read_record(RUN / "qwen15/forecasts" / f"{key}.json")
        p = native.read_record(RUN / "qwen15/records" / f"{key}.json")
        fr, pr = f["record"], p["record"]
        assert (
            fr["fingerprint"] == pr["fingerprint"] == b["fingerprint"]
            and pr["forecast_record_sha256"] == f["sha256"]
        )
        assert (
            all(fr[k] == pr[k] == v for k, v in g.items())
            and entries[key]["record_sha256"] == f["sha256"]
            and entries[key]["states_sha256"] == fr["states_sha256"]
        )
        fp, pp = RUN / "qwen15/forecasts" / f"{key}.npz", RUN / "qwen15/states" / f"{key}.npz"
        assert native.hashed(fp) == fr["states_sha256"] and native.hashed(pp) == pr["states_sha256"]
        bases = [
            native.fixture.reconstruct(tok, block, native.fixture.job(g, bit)) for bit in range(2)
        ]
        pos = fr["position"]
        length = len(bases[0]["free_input_ids"])
        controls["all64_new_single_token_pairs"] &= (
            bases == fr["bases"]
            and length == len(bases[1]["free_input_ids"])
            and [
                i
                for i, (x, y) in enumerate(
                    zip(bases[0]["free_input_ids"], bases[1]["free_input_ids"])
                )
                if x != y
            ]
            == [pos]
        )
        assert (
            len(fr["patches"]) == 6
            and {(v["arm"], v["bit"]) for v in fr["patches"]}
            == set(itertools.product(ARMS, range(2)))
            and pr["patches"] == []
        )
        before.extend(
            [fr["native_false"]["completed_utc"]] + [q["completed_utc"] for q in fr["patches"]]
        )
        after.append(pr["native_true"]["started_utc"])
        with np.load(fp, allow_pickle=False) as z, np.load(pp, allow_pickle=False) as tz:
            for table, record, label in (
                (z, fr["native_false"], "native_false"),
                (tz, pr["native_true"], "native_true"),
            ):
                trace = record["activation_trace"]
                controls["native_phi_captures_formulas"] &= (
                    len(trace) == 28
                    and [v["site"] for v in trace] == list(range(1, 29))
                    and all(
                        not v["tangent"]
                        and v["other_rows_identical"]
                        and (v["start"], v["end"]) == (pos + 1, length)
                        and v["input_sha256"]
                        == native.array_hash(table[f"{label}_{v['site']}_input"])
                        and v["output_sha256"]
                        == native.array_hash(table[f"{label}_{v['site']}_output"])
                        for v in trace
                    )
                )
                for site in range(1, 29):
                    x = table[f"{label}_{site}_input"].astype(np.float64)
                    y = table[f"{label}_{site}_output"]
                    controls["native_phi_captures_formulas"] &= (
                        x.shape == y.shape == (length - pos - 1, 8960)
                        and np.isfinite(x).all()
                        and np.isfinite(y).all()
                        and float(np.max(abs(y - x * np.exp(-np.logaddexp(0, -x))))) <= 1e-5
                    )
            for site in range(1, 29):
                expected = coefficients(
                    z[f"native_false_{site}_input"], z[f"native_false_{site}_output"]
                )
                for arm in ARMS:
                    ce = max(
                        ce,
                        max(
                            float(np.max(abs(v - z[f"map_{arm}_{site}_{name}"])))
                            for name, v in expected.items()
                        ),
                    )
            for q in fr["patches"]:
                arm, bit = q["arm"], q["bit"]
                prefix = f"{arm}_{bit}"
                h = z[f"{prefix}_final"]
                raw = z["native_false_final"] if bit == 0 else tz["native_true_final"]
                controls["prefix_metadata_rows_native_exact"] &= h.shape == (
                    length,
                    1536,
                ) and np.array_equal(h[: pos + 1], raw[: pos + 1])
                trace = q["activation_trace"]
                controls["all28_actual_polynomial_spans_formulas"] &= (
                    len(trace) == 28
                    and [v["site"] for v in trace] == list(range(1, 29))
                    and all(
                        v["arm"] == arm
                        and v["other_rows_identical"]
                        and (v["start"], v["end"]) == (pos + 1, length)
                        and v["input_sha256"] == native.array_hash(z[f"{prefix}_{v['site']}_input"])
                        and v["output_sha256"]
                        == native.array_hash(z[f"{prefix}_{v['site']}_output"])
                        for v in trace
                    )
                )
                for site in range(1, 29):
                    x, y = z[f"{prefix}_{site}_input"], z[f"{prefix}_{site}_output"]
                    delta = x - z[f"map_{arm}_{site}_center"]
                    prediction = (
                        z[f"map_{arm}_{site}_intercept"] + z[f"map_{arm}_{site}_slope"] * delta
                    )
                    if arm in ("Q2", "C3"):
                        prediction = prediction + z[f"map_{arm}_{site}_second"] * (delta * delta)
                    if arm == "C3":
                        prediction = prediction + z[f"map_{arm}_{site}_third"] * (
                            (delta * delta) * delta
                        )
                    fe = max(fe, float(np.max(abs(y - prediction))))
                    controls["all28_actual_polynomial_spans_formulas"] &= (
                        x.shape == y.shape == (length - pos - 1, 8960)
                        and np.isfinite(x).all()
                        and np.isfinite(y).all()
                    )
                    if bit == 0:
                        controls["all192_exact_false_state_identities"] &= np.array_equal(
                            x, z[f"native_false_{site}_input"]
                        ) and np.array_equal(y, z[f"native_false_{site}_output"])
                if bit == 0:
                    controls["all192_exact_false_state_identities"] &= q["margin"] == fr[
                        "native_false"
                    ]["margin"] and np.array_equal(h, z["native_false_final"])
                controls["public_margin_arithmetic"] &= native.margin_valid(q["margin"])
            controls["public_margin_arithmetic"] &= native.margin_valid(
                fr["native_false"]["margin"]
            ) and native.margin_valid(pr["native_true"]["margin"])
        records.append({**fr, "native_true": pr["native_true"]})
    controls["global_forecast_before_native_true"] &= timing.ordered(
        before, manifest["completed_utc"], after
    )
    controls["complete512_crossing"] &= (
        len(records)
        == len(list((RUN / "qwen15/records").glob("*.json")))
        == len(list((RUN / "qwen15/forecasts").glob("*.json")))
        == 64
    )
    controls["all28_false_only_derivatives"] &= ce <= 1e-5
    controls["all28_actual_polynomial_spans_formulas"] &= fe <= 1e-5
    numerical = False
    npath = ROOT / "docs/analysis/191-numerical-recheck.json"
    if npath.exists():
        n = json.loads(npath.read_text())
        paths = {
            "source_sha256": ROOT / "scripts/recheck_one_sided_curvature_forecast_191.py",
            "audit_sha256": Path(__file__),
            "public_helper_sha256": ROOT / "scripts/recheck_natural_bit_shared_reader_181.py",
        }
        numerical = (
            n["passed"]
            and n["forwards"] == 64
            and n["fingerprint"] == b["fingerprint"]
            and all(n[k] == native.hashed(v) for k, v in paths.items())
        )
    result = {
        "complete": True,
        "fingerprint": b["fingerprint"],
        "main_forwards": 512,
        "controls": {k: bool(v) for k, v in controls.items()},
        "maximum_coefficient_error": ce,
        "maximum_activation_formula_error": fe,
        "numerical_qualified": numerical,
        **estimands(records, numerical and all(controls.values())),
        "scope": "Prospective false-only analytic curvature on new dependent prompts. True endpoint and bit-effect errors identical because false anchors EXACT; no double counting. No fitted/refined/oracle correction or native true calibration.",
    }
    write_json(OUT, result)
    print(json.dumps({k: v for k, v in result.items() if k not in ("cells", "panels")}, indent=2))


if __name__ == "__main__":
    main()
