"""Independent one-sided/refined gain formulas and strict target-measurement ordering."""

import itertools
import json
import math
from datetime import datetime
from pathlib import Path

import audit_natural_bit_shared_reader_181 as native
import audit_tangent_offset_slope_crossing_185 as parent
import numpy as np
from transformers import AutoTokenizer

from latent_decisions.evidence_policy import digest, write_json

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / "runs/one-sided-gain-forecast-186"
OUT = ROOT / "docs/analysis/186-independent-audit.json"
ARMS = ("J0", "J1", "J2", "oracle")
LITERALS = (
    ("tamarind", "acacia", "Tuesday", "Saturday"),
    ("moraine", "delta", "Thursday", "Sunday"),
    ("paprika", "cumin", "Wednesday", "Friday"),
    ("fresco", "mosaic", "Monday", "Thursday"),
)


def blocks():
    return [
        {"id": a, "stage": "186", "subjects": [a, b], "days": [x, y], "old_block": None}
        for a, b, x, y in LITERALS
    ]


def source_hash():
    return digest(
        {
            "runner": (ROOT / "scripts/run_one_sided_gain_forecast_186.py").read_text(),
            "protocol": (ROOT / "docs/experiments/186-one-sided-gain-forecast.md").read_text(),
            "parent": parent.source_hash(),
        }
    )


def slope_at(x):
    c = x.astype(np.float64)
    s = np.empty_like(c)
    positive = c >= 0
    s[positive] = 1 / (1 + np.exp(-c[positive]))
    e = np.exp(c[~positive])
    s[~positive] = e / (1 + e)
    return (s * (1 + c * (1 - s))).astype(np.float32)


def ordered(before, frozen, after):
    return bool(before and after) and max(
        map(datetime.fromisoformat, before)
    ) <= datetime.fromisoformat(frozen) <= min(map(datetime.fromisoformat, after))


def estimands(records, valid):
    cells = []
    for r in records:
        actual = [r["native_false"]["margin"]["log_odds"], r["native_true"]["margin"]["log_odds"]]
        forecasts = {
            arm: [
                next(
                    q["margin"]["log_odds"]
                    for q in r["patches"]
                    if (q["arm"], q["bit"]) == (arm, bit)
                )
                for bit in range(2)
            ]
            for arm in ARMS
        }
        cells.append(
            {
                **{k: r[k] for k in ("block", "schema", "reverse", "assignment", "target")},
                "supported": r["bases"][0]["facts"]["supported"],
                "native": actual,
                "forecasts": forecasts,
                "native_delta": actual[1] - actual[0],
                "errors": {arm: p[1] - actual[1] for arm, p in forecasts.items()},
                "deltas": {arm: p[1] - p[0] for arm, p in forecasts.items()},
            }
        )
    panels = []
    for block, schema, rev in itertools.product(blocks(), ("generic", "descriptive"), range(2)):
        rows = [
            c
            for c in cells
            if (c["block"], c["schema"], c["reverse"]) == (block["id"], schema, rev)
        ]
        assert len(rows) == 4 and sorted(c["supported"] for c in rows) == [False, False, True, True]
        b = [
            math.fsum((1 if c["supported"] else -1) * c["native"][bit] for c in rows) / 2
            for bit in range(2)
        ]
        predicted = {
            arm: [
                math.fsum((1 if c["supported"] else -1) * c["forecasts"][arm][bit] for c in rows)
                / 2
                for bit in range(2)
            ]
            for arm in ARMS
        }
        d = b[1] - b[0]
        panels.append(
            {
                "block": block["id"],
                "schema": schema,
                "reverse": rev,
                "B_native": b,
                "B_forecasts": predicted,
                "native_delta_B": d,
                "individual_true_errors": {
                    arm: [
                        {
                            "assignment": c["assignment"],
                            "target": c["target"],
                            "error": c["errors"][arm],
                        }
                        for c in rows
                    ]
                    for arm in ARMS
                },
                "balanced_true_errors": {arm: p[1] - b[1] for arm, p in predicted.items()},
                "maximum_individual_error": {
                    arm: max(abs(c["errors"][arm]) for c in rows) for arm in ARMS
                },
                "common_true_error": {
                    arm: math.fsum(c["errors"][arm] for c in rows) / 4 for arm in ARMS
                },
                "individual_matching": {
                    arm: all(abs(c["errors"][arm]) <= 0.1 for c in rows) for arm in ARMS
                },
                "balanced_matching": {arm: abs(p[1] - b[1]) <= 0.1 for arm, p in predicted.items()},
                "individual_retention": {
                    arm: all(
                        abs(c["native_delta"]) >= 0.5
                        and c["native_delta"] * c["deltas"][arm] > 0
                        and abs(c["deltas"][arm]) >= 0.5 * abs(c["native_delta"])
                        for c in rows
                    )
                    for arm in ARMS
                },
                "balanced_retention": {
                    arm: abs(d) >= 0.2
                    and d * (p[1] - p[0]) > 0
                    and abs(p[1] - p[0]) >= 0.5 * abs(d)
                    for arm, p in predicted.items()
                },
            }
        )
    accounts = {
        metric: {
            arm: {
                "compatible_panels": sum(p[metric][arm] for p in panels),
                "strata": {
                    f"{schema}_{rev}": sum(
                        p[metric][arm]
                        for p in panels
                        if (p["schema"], p["reverse"]) == (schema, rev)
                    )
                    for schema, rev in itertools.product(("generic", "descriptive"), range(2))
                },
                "whole_passed": valid
                and all(
                    sum(
                        p[metric][arm]
                        for p in panels
                        if (p["schema"], p["reverse"]) == (schema, rev)
                    )
                    >= 3
                    for schema, rev in itertools.product(("generic", "descriptive"), range(2))
                ),
                "prospective": arm != "oracle",
            }
            for arm in ARMS
        }
        for metric in (
            "individual_matching",
            "balanced_matching",
            "individual_retention",
            "balanced_retention",
        )
    }
    return {"cells": cells, "panels": panels, "accounts": accounts}


def main():
    b = json.loads((RUN / "design.json").read_text())
    status = json.loads((RUN / "pipeline-status.json").read_text())
    assert (
        digest(b["design"]) == b["fingerprint"]
        and b["design"]["source_hash"] == source_hash()
        and status["status"] == "complete"
        and status["completed_forwards"] == 640
    )
    pa = json.loads(parent.OUT.read_text())
    assert (
        pa["numerical_qualified"]
        and all(pa["controls"].values())
        and pa["fingerprint"] == b["design"]["parent_fingerprint"]
    )
    rt = json.loads((RUN / "qwen15/runtime.json").read_text())
    assert rt == json.loads((parent.RUN / "qwen15/runtime.json").read_text())
    cfg = b["design"]["models"]["qwen15"]
    tok = AutoTokenizer.from_pretrained(
        cfg["model"], revision=cfg["revision"], local_files_only=True
    )
    assert digest(tok.get_vocab()) == rt["tokenizer_hash"]
    manifest = json.loads((RUN / "forecast-manifest.json").read_text())
    assert (
        manifest["completed_forwards"] == 448
        and digest(manifest["manifest"]) == manifest["manifest_sha256"]
        and len(manifest["manifest"]) == 64
    )
    bykey = {e["key"]: e for e in manifest["manifest"]}
    controls = {
        name: True
        for name in (
            "immutable_runtime_sources_parent",
            "all64_single_token_reconstructions",
            "complete640_forward_crossing",
            "all_manifest_hashes",
            "all28_false_anchored_gain_update_formulas",
            "all28_actual_activation_formulas_spans",
            "all256_exact_false_identities",
            "earlier_metadata_rows_native_exact",
            "all448_calibration_forecasts_before_any_native_true",
            "oracle_after_native_true",
            "public_score_arithmetic",
        )
    }
    records, before, after = [], [], []
    map_error = formula_error = 0.0
    for block, a, t, rev, schema in itertools.product(
        blocks(), range(2), range(2), range(2), ("generic", "descriptive")
    ):
        g = native.fixture.group(block, a, t, rev, schema)
        key = digest(g)
        fe = native.read_record(RUN / "qwen15/forecasts" / f"{key}.json")
        e = native.read_record(RUN / "qwen15/records" / f"{key}.json")
        fr, r = fe["record"], e["record"]
        assert (
            fr["fingerprint"] == r["fingerprint"] == b["fingerprint"]
            and r["forecast_record_sha256"] == fe["sha256"]
            and all(fr[k] == r[k] == v for k, v in g.items())
        )
        fp, p = RUN / "qwen15/forecasts" / f"{key}.npz", RUN / "qwen15/states" / f"{key}.npz"
        controls["all_manifest_hashes"] &= (
            native.hashed(fp) == fr["states_sha256"]
            and native.hashed(p) == r["states_sha256"]
            and bykey[key]
            == {"key": key, "record_sha256": fe["sha256"], "states_sha256": fr["states_sha256"]}
        )
        bases = [
            native.fixture.reconstruct(tok, block, native.fixture.job(g, bit)) for bit in range(2)
        ]
        pos, length = r["position"], len(bases[0]["free_input_ids"])
        controls["all64_single_token_reconstructions"] &= (
            bases == fr["bases"]
            and pos == fr["position"]
            and len(bases[1]["free_input_ids"]) == length
            and [
                i
                for i, (x, y) in enumerate(
                    zip(bases[0]["free_input_ids"], bases[1]["free_input_ids"])
                )
                if x != y
            ]
            == [pos]
        )
        assert (
            len(fr["patches"]) == 6
            and {(q["arm"], q["bit"]) for q in fr["patches"]}
            == set(itertools.product(ARMS[:3], range(2)))
            and [(q["arm"], q["bit"]) for q in r["patches"]] == [("oracle", 0), ("oracle", 1)]
        )
        before.append(fr["native_false"]["completed_utc"])
        before.extend(q["completed_utc"] for q in fr["patches"])
        after.append(r["native_true"]["started_utc"])
        controls["oracle_after_native_true"] &= all(
            datetime.fromisoformat(q["started_utc"])
            >= datetime.fromisoformat(r["native_true"]["completed_utc"])
            for q in r["patches"]
        )
        with np.load(fp, allow_pickle=False) as fz, np.load(p, allow_pickle=False) as z:
            for arm in ARMS:
                table = z if arm == "oracle" else fz
                for site in range(1, 29):
                    xf = fz[f"native_false_{site}_input"]
                    yf = fz[f"native_false_{site}_output"]
                    xt = (
                        None
                        if arm == "J0"
                        else fz[f"J{int(arm[1]) - 1}_1_{site}_input"]
                        if arm != "oracle"
                        else z[f"native_true_{site}_input"]
                    )
                    c = (
                        xf.astype(np.float64)
                        if xt is None
                        else (xf.astype(np.float64) + xt.astype(np.float64)) / 2
                    )
                    slope = slope_at(c)
                    map_error = max(
                        map_error, float(np.max(abs(slope - table[f"map_{arm}_{site}_slope"])))
                    )
                    controls["all28_false_anchored_gain_update_formulas"] &= np.array_equal(
                        table[f"map_{arm}_{site}_center"], xf
                    ) and np.array_equal(table[f"map_{arm}_{site}_intercept"], yf)
            for family, table, patches in (
                ("native_false", fz, [fr["native_false"]]),
                ("native_true", z, [r["native_true"]]),
                ("forecasts", fz, fr["patches"]),
                ("oracle", z, r["patches"]),
            ):
                for q in patches:
                    transformed = family in ("forecasts", "oracle")
                    arm, bit = (
                        (q["arm"], q["bit"])
                        if transformed
                        else (None, 0 if family == "native_false" else 1)
                    )
                    prefix = f"{arm}_{bit}" if transformed else family
                    controls["public_score_arithmetic"] &= native.margin_valid(q["margin"])
                    h = table[f"{prefix}_final"]
                    reference = fz["native_false_final"] if bit == 0 else z["native_true_final"]
                    controls["earlier_metadata_rows_native_exact"] &= (
                        h.shape == reference.shape == (length, 1536)
                        and np.array_equal(h[: pos + 1], reference[: pos + 1])
                    )
                    trace = q["activation_trace"]
                    controls["all28_actual_activation_formulas_spans"] &= (
                        len(trace) == 28
                        and [v["site"] for v in trace] == list(range(1, 29))
                        and all(
                            v["other_rows_identical"]
                            and v["tangent"] == transformed
                            and (v["start"], v["end"]) == (pos + 1, length)
                            and v["input_sha256"]
                            == native.array_hash(table[f"{prefix}_{v['site']}_input"])
                            and v["output_sha256"]
                            == native.array_hash(table[f"{prefix}_{v['site']}_output"])
                            for v in trace
                        )
                    )
                    if transformed and bit == 0:
                        controls["all256_exact_false_identities"] &= q["margin"] == fr[
                            "native_false"
                        ]["margin"] and np.array_equal(h, fz["native_false_final"])
                    for site in range(1, 29):
                        x, y = table[f"{prefix}_{site}_input"], table[f"{prefix}_{site}_output"]
                        controls["all28_actual_activation_formulas_spans"] &= (
                            x.shape == y.shape == (length - pos - 1, 8960)
                            and x.dtype == y.dtype == np.float32
                            and np.isfinite(x).all()
                            and np.isfinite(y).all()
                        )
                        expected = (
                            table[f"map_{arm}_{site}_intercept"]
                            + table[f"map_{arm}_{site}_slope"]
                            * (x - table[f"map_{arm}_{site}_center"])
                            if transformed
                            else (
                                x.astype(np.float64)
                                * np.exp(-np.logaddexp(0, -x.astype(np.float64)))
                            ).astype(np.float32)
                        )
                        formula_error = max(formula_error, float(np.max(abs(y - expected))))
                        if transformed and bit == 0:
                            controls["all256_exact_false_identities"] &= np.array_equal(
                                x, fz[f"native_false_{site}_input"]
                            ) and np.array_equal(y, fz[f"native_false_{site}_output"])
        records.append(
            {
                **r,
                "bases": bases,
                "native_false": fr["native_false"],
                "patches": fr["patches"] + r["patches"],
            }
        )
    controls["all448_calibration_forecasts_before_any_native_true"] = ordered(
        before, manifest["completed_utc"], after
    )
    controls["complete640_forward_crossing"] &= (
        len(records)
        == len(bykey)
        == len(list((RUN / "qwen15/records").glob("*.json")))
        == len(list((RUN / "qwen15/forecasts").glob("*.json")))
        == 64
        and len(before) == 448
        and len(after) == 64
    )
    controls["all28_false_anchored_gain_update_formulas"] &= map_error <= 1e-5
    controls["all28_actual_activation_formulas_spans"] &= formula_error <= 1e-5
    numerical = False
    p = ROOT / "docs/analysis/186-numerical-recheck.json"
    if p.exists():
        n = json.loads(p.read_text())
        numerical = (
            n["passed"]
            and n["fingerprint"] == b["fingerprint"]
            and n["forwards"] == 40
            and n["source_sha256"]
            == native.hashed(ROOT / "scripts/recheck_one_sided_gain_forecast_186.py")
            and n["audit_sha256"] == native.hashed(Path(__file__))
            and n["activation_helper_sha256"]
            == native.hashed(ROOT / "scripts/recheck_natural_silu_tangent_183.py")
            and n["public_helper_sha256"]
            == native.hashed(ROOT / "scripts/recheck_natural_bit_shared_reader_181.py")
        )
    result = {
        "complete": True,
        "fingerprint": b["fingerprint"],
        "main_forwards": 640,
        "controls": {k: bool(v) for k, v in controls.items()},
        "maximum_map_error": map_error,
        "maximum_activation_formula_error": formula_error,
        "numerical_qualified": numerical,
        **estimands(records, numerical and all(controls.values())),
        "scope": "Prospective native-true response forecasts from measured native-false state and preceding modified-network forecasts. Oracle uses native-true inputs after measurement and is diagnostic only. False endpoint/delta success redundant, no extra independent account. Single checkpoint/dependent new templates; selected numerical subset.",
    }
    write_json(OUT, result)
    print(
        json.dumps(
            {
                "controls": result["controls"],
                "numerical_qualified": numerical,
                "accounts": result["accounts"],
                "maximum_map_error": map_error,
                "maximum_activation_formula_error": formula_error,
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
