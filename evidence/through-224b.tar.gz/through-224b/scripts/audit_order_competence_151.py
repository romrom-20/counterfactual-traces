"""Separate-code reconstruction and competence qualification; no151 runner import."""

import itertools
import json
import math
from pathlib import Path

import run_metadata_evidence_135 as ancestor
import run_metadata_token_margin_141 as score_ancestor
from transformers import AutoTokenizer

from latent_decisions.evidence_policy import digest

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / "runs/order-competence-151-152"
OUT = ROOT / "docs/analysis/151-152-independent-audit.json"
SCHEMAS = {"generic": ["first_value", "second_value"], "descriptive": ["record_flag", "supported"]}
LITERALS = [
    ("151", "amber", "violet", "Wednesday", "Friday"),
    ("151", "silver", "bronze", "Thursday", "Sunday"),
    ("151", "birch", "willow", "Saturday", "Tuesday"),
    ("151", "north", "south", "Monday", "Thursday"),
    ("152", "coral", "indigo", "Friday", "Monday"),
    ("152", "oak", "pine", "Sunday", "Wednesday"),
    ("152", "east", "west", "Tuesday", "Saturday"),
    ("152", "copper", "ivory", "Thursday", "Friday"),
]


def blocks():
    result = []
    for i, (stage, a, b, day_a, day_b) in enumerate(LITERALS):
        result.append(
            {
                "id": f"day_{i}",
                "stage": stage,
                "candidate": day_b,
                "contexts": [
                    f"The {a} exhibit opened on {x}. The {b} exhibit opened on {y}."
                    for x, y in [(day_a, day_b), (day_b, day_a)]
                ],
                "questions": [f"On which day did the {a} exhibit open?"],
            }
        )
    return result


def expected_messages(block, j):
    flag, verdict = SCHEMAS[j["schema"]]
    if j["kind"] == "singleton":
        instruction = f'Return only a JSON object with a boolean value for key "{verdict}". For "{verdict}", true means the proposed answer is supported and false means it is unsupported.'
    else:
        instruction = (
            f'Return only a JSON object with boolean values for keys "{flag}" and "{verdict}". '
            f'"{flag}" is an arbitrary metadata bit with no meaning about the passage, question or answer correctness. Either true or false is permitted. '
            f'For "{verdict}", true means the proposed answer is supported and false means it is unsupported.'
        )
    if j["kind"] == "given":
        text = "The answer support status is already given. Do not reassess it. Encode the given status. "
        data = {"answer_is_supported": j["supported"]}
    else:
        text = (
            "Use only the passage to judge whether proposed_answer is directly supported as an answer to question. "
            "An occurrence of the proposed answer in an unrelated fact is not sufficient. Do not use outside knowledge. "
        )
        data = {
            "passage": block["contexts"][int(j["supported"])],
            "proposed_answer": block["candidate"],
            "question": block["questions"][0],
        }
    return [
        {"role": "system", "content": text + instruction},
        {"role": "user", "content": json.dumps(data, ensure_ascii=False)},
    ]


def expected_choices(j):
    flag, verdict = SCHEMAS[j["schema"]]
    out = []
    for value in (False, True):
        if j["kind"] == "singleton":
            data = {verdict: value}
        elif j["order"] == "verdict_first":
            data = {verdict: value, flag: j["clamp"]}
        else:
            data = {flag: j["clamp"], verdict: value}
        out.append([json.dumps(data), [value]])
    return out


def jobs(block):
    result = [
        {"kind": kind, "supported": support, "schema": schema, "order": order, "clamp": bit}
        for kind in (["evidence", "given"] if block["id"] == "day_0" else ["evidence"])
        for support, schema, order, bit in itertools.product(
            (False, True), SCHEMAS, ("metadata_first", "verdict_first"), (False, True)
        )
    ]
    result += [
        {"kind": "singleton", "supported": support, "schema": schema}
        for support, schema in itertools.product((False, True), SCHEMAS)
    ]
    return result


def qualify(rows, controls, complete):
    result = {}
    for schema in SCHEMAS:
        selected = [r for r in rows if r["schema"] == schema]
        full = len(selected) == 16
        correct = sum(
            all(v == r["supported"] for v in r["verdict_first"]["verdicts"]) for r in selected
        )
        singleton = sum(r["singleton"]["verdict"] == r["supported"] for r in selected)
        qualified = complete and full and all(controls.values()) and correct == 16
        strata = []
        for stage in ("151", "152"):
            rs = [r for r in selected if r["stage"] == stage]
            ids = {r["block"] for r in rs}
            bit = sum(
                any(
                    r["metadata_first"]["verdicts"][0] != r["metadata_first"]["verdicts"][1]
                    for r in rs
                    if r["block"] == block
                )
                for block in ids
            )
            order = sum(
                any(
                    any(v != r["supported"] for v in r["metadata_first"]["verdicts"])
                    for r in rs
                    if r["block"] == block
                )
                for block in ids
            )
            strata.append(
                {
                    "stage": stage,
                    "blocks": len(ids),
                    "bit_disrupted_blocks": bit,
                    "order_disrupted_blocks": order,
                    "bit_passed": len(ids) == 4 and bit / 4 >= 0.25,
                    "order_passed": len(ids) == 4 and order / 4 >= 0.25,
                }
            )
        result[schema] = {
            "qualified": qualified,
            "verdict_first_correct_queries": correct,
            "required_queries": 16,
            "singleton_correct_queries": singleton,
            "singleton_all_correct": full and singleton == 16,
            "bit_disruption_passed": qualified and all(r["bit_passed"] for r in strata),
            "order_disruption_passed": qualified and all(r["order_passed"] for r in strata),
            "strata": strata,
        }
    return result


def audit():
    bundle = json.loads((RUN / "design.json").read_text())
    design = bundle["design"]
    assert digest(design) == bundle["fingerprint"] and design["blocks"] == blocks()
    assert (
        design["schemas"] == SCHEMAS
        and design["competence_minimum"] == 1.0
        and design["disruption_minimum"] == 0.25
    )
    source_hash = digest(
        {
            "runner": (ROOT / "scripts/run_order_competence_151.py").read_text(),
            "protocol": (ROOT / "docs/experiments/151-152-order-competence.md").read_text(),
            "dependencies": [
                ancestor.source_hash(),
                score_ancestor.source_hash(),
                digest((ROOT / "src/latent_decisions/target.py").read_text()),
            ],
        }
    )
    assert source_hash == design["source_hash"]
    report = {"fingerprint": bundle["fingerprint"], "models": {}, "complete": True}
    for name, cfg in design["models"].items():
        rt = json.loads((RUN / name / "runtime.json").read_text())
        assert rt == json.loads((score_ancestor.DEFAULT / name / "runtime.json").read_text())
        tok = AutoTokenizer.from_pretrained(
            cfg["model"], revision=cfg["revision"], local_files_only=True
        )
        if tok.pad_token_id is None:
            tok.pad_token = tok.eos_token
        assert (
            digest(tok.get_vocab()) == rt["tokenizer_hash"]
            and tok.chat_template == rt["chat_template"]
        )
        expected = {(b["id"], digest(j)): (b, j) for b in blocks() for j in jobs(b)}
        records, errors = {}, []
        for path in (RUN / name / "records").glob("*.json"):
            e = json.loads(path.read_text())
            r = e["record"]
            assert digest(r) == e["sha256"] and r["fingerprint"] == bundle["fingerprint"]
            assert r["runtime_hash"] == digest(rt)
            key = r["block"], digest(r["job"])
            assert key in expected and key not in records
            b, j = expected[key]
            assert r["stage"] == b["stage"] and r["messages"] == expected_messages(b, j)
            assert r["choices"] == expected_choices(j)
            prefix = tok.apply_chat_template(
                r["messages"], tokenize=True, add_generation_prompt=True
            )
            seqs = [
                tok.encode(c[0], add_special_tokens=False) + [tok.eos_token_id]
                for c in r["choices"]
            ]
            assert r["prompt_ids"] == prefix and r["sequences"] == seqs and len(prefix) <= 2048
            assert len(seqs[0]) == len(seqs[1])
            free = [i for i, pair in enumerate(zip(*seqs)) if pair[0] != pair[1]]
            assert len(free) == 1
            gm, fm = r["generation_margin"], r["forward_margin"]
            assert (
                gm["free_index"] == free[0]
                and gm["false_token"] == seqs[0][free[0]]
                and gm["true_token"] == seqs[1][free[0]]
            )
            assert r["free_input_ids"] == prefix + seqs[0][: free[0]]
            assert r["ids"] in seqs and r["raw"] == tok.decode(r["ids"], skip_special_tokens=True)
            choice = seqs.index(r["ids"])
            assert r["verdict"] == bool(choice) and r["raw"] == r["choices"][choice][0]
            assert gm["selected_token"] == r["ids"][free[0]] and sorted(
                gm["finite_token_ids"]
            ) == sorted([gm["false_token"], gm["true_token"]])
            assert (gm["true_score"] if choice else gm["false_score"]) == max(
                gm["false_score"], gm["true_score"]
            )
            for m in (gm, fm):
                assert all(math.isfinite(m[k]) for k in ("false_score", "true_score", "log_odds"))
                assert m["log_odds"] == m["true_score"] - m["false_score"]
            errors += [abs(gm[k] - fm[k]) for k in fm]
            records[key] = r
        complete = len(records) == 176
        rows, future, same_prompt = [], [], []
        for b in blocks():
            for support, schema in itertools.product((False, True), SCHEMAS):
                row = {
                    "block": b["id"],
                    "stage": b["stage"],
                    "supported": support,
                    "schema": schema,
                }
                prompts = []
                for order in ("metadata_first", "verdict_first"):
                    pair = [
                        records.get(
                            (
                                b["id"],
                                digest(
                                    {
                                        "kind": "evidence",
                                        "supported": support,
                                        "schema": schema,
                                        "order": order,
                                        "clamp": bit,
                                    }
                                ),
                            )
                        )
                        for bit in (False, True)
                    ]
                    if any(r is None for r in pair):
                        complete = False
                        continue
                    prompts += [r["prompt_ids"] for r in pair]
                    margins = [r["generation_margin"]["log_odds"] for r in pair]
                    row[order] = {
                        "verdicts": [r["verdict"] for r in pair],
                        "margins": margins,
                        "delta": margins[1] - margins[0],
                    }
                    if order == "verdict_first":
                        future.append(
                            pair[0]["free_input_ids"] == pair[1]["free_input_ids"]
                            and pair[0]["generation_margin"] == pair[1]["generation_margin"]
                            and pair[0]["verdict"] == pair[1]["verdict"]
                        )
                single = records.get(
                    (b["id"], digest({"kind": "singleton", "supported": support, "schema": schema}))
                )
                if len(prompts) != 4 or single is None:
                    complete = False
                    continue
                same_prompt.append(all(p == prompts[0] for p in prompts))
                row["singleton"] = {
                    "verdict": single["verdict"],
                    "margin": single["generation_margin"]["log_odds"],
                }
                rows.append(row)
        given = [r for r in records.values() if r["job"]["kind"] == "given"]
        controls = {
            "same_prompt": len(same_prompt) == 32 and all(same_prompt),
            "future_clamp_exact": len(future) == 32 and all(future),
            "direct_status": len(given) == 16
            and all(r["verdict"] == r["job"]["supported"] for r in given),
            "public_score_bridge": len(errors) == 528 and max(errors) <= 0.05,
        }
        evidence_responses = []
        for b in blocks():
            for schema in SCHEMAS:
                paired = [
                    next(
                        (
                            r
                            for r in rows
                            if r["block"] == b["id"]
                            and r["schema"] == schema
                            and r["supported"] == support
                        ),
                        None,
                    )
                    for support in (False, True)
                ]
                if any(r is None for r in paired):
                    continue
                evidence_responses.append(
                    {
                        "block": b["id"],
                        "stage": b["stage"],
                        "schema": schema,
                        "verdict_first": [
                            paired[1]["verdict_first"]["margins"][bit]
                            - paired[0]["verdict_first"]["margins"][bit]
                            for bit in (0, 1)
                        ],
                        "metadata_first": [
                            paired[1]["metadata_first"]["margins"][bit]
                            - paired[0]["metadata_first"]["margins"][bit]
                            for bit in (0, 1)
                        ],
                        "singleton": paired[1]["singleton"]["margin"]
                        - paired[0]["singleton"]["margin"],
                    }
                )
        report["models"][name] = {
            "complete": complete,
            "generations": len(records),
            "forward_bridges": len(records),
            "controls": controls,
            "max_bridge_error": max(errors) if errors else None,
            "signatures": qualify(rows, controls, complete),
            "outcomes": rows,
            "evidence_responses": evidence_responses,
        }
        report["complete"] = report["complete"] and complete
    return report


if __name__ == "__main__":
    value = audit()
    OUT.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")
    print(
        json.dumps(
            {
                "complete": value["complete"],
                "models": {
                    n: {k: v[k] for k in ("controls", "signatures", "max_bridge_error")}
                    for n, v in value["models"].items()
                },
            },
            indent=2,
        )
    )
