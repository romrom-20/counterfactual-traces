"""Read-only reconstruction of 201 metrics and audit of replacement-agent claims."""

import hashlib
import json
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / "runs/discovery-ranked-repair-201"
OUT = ROOT / "docs/analysis/202-replacement-metric-audit.json"
ARMS = ("source_linear", "exact_readout", "residual_blocks", "margin_blocks",
        "union_blocks", "control_blocks")


def measure(actual, predicted):
    a, p = actual.astype(np.float64), predicted.astype(np.float64)
    an, pn = np.linalg.norm(a), np.linalg.norm(p)
    en = np.linalg.norm(a - p)
    q = float(en / an) if an else None
    cosine = float(np.vdot(a, p) / (an * pn)) if an and pn else None
    bound = float(np.sqrt(max(0, 1 - q * q))) if q is not None and q <= 1 else None
    return dict(native_norm=float(an), prediction_norm=float(pn), absolute_error=float(en),
                relative_error=q, cosine=cosine, same_vector_lower_bound=bound,
                consistent=bound is None or cosine is None or cosine >= bound - 1e-10)


def main():
    assert not OUT.exists(), "Preserve executed audit; use a new name for corrections"
    original = json.loads((ROOT / "docs/analysis/201-independent-audit.json").read_text())
    assert original["numerical_qualified"] and all(original["controls"].values())
    rows, maximum_source = [], 0.0
    for p in sorted((RUN / "forecasts").glob("*.npz")):
        record = json.loads(p.with_suffix(".json").read_text())["record"]
        with np.load(p, allow_pickle=False) as f, np.load(RUN / "observations" / p.name,
                                                       allow_pickle=False) as t:
            actual = t["true_rows"].astype(np.float64) - f["false_rows"].astype(np.float64)
            source = t["true_first"].astype(np.float64) - f["false_first"].astype(np.float64)
            maximum_source = max(maximum_source, float(np.max(abs(source - f["source_first_delta"]))))
            scores = t["true_scores"].astype(np.float64) - f["false_scores"].astype(np.float64)
            dm = float(scores[1] - scores[0])
            for arm in (*ARMS, "zero_displacement"):
                pred = np.zeros_like(actual) if arm == "zero_displacement" else f[f"{arm}_delta_rows"]
                ds = np.zeros(2) if arm == "zero_displacement" else f[f"{arm}_delta_scores"]
                rows.append(dict(key=p.stem, block=record["block"], schema=record["schema"],
                                 reverse=record["reverse"], assignment=record["assignment"],
                                 target=record["target"], arm=arm,
                                 source_first=measure(actual[0, 0], pred[0, 0]),
                                 verdict_first=measure(actual[0, 1], pred[0, 1]),
                                 final=measure(actual[-1, 1], pred[-1, 1]),
                                 absolute_margin_error=abs(float(ds[1] - ds[0]) - dm),
                                 source_layers=[measure(a[0], b[0]) for a, b in zip(actual, pred)],
                                 verdict_layers=[measure(a[1], b[1]) for a, b in zip(actual, pred)]))
    assert len(rows) == 64 * 7
    summary = {}
    for arm in (*ARMS, "zero_displacement"):
        group = [r for r in rows if r["arm"] == arm]
        summary[arm] = dict(median_final_relative_error=float(np.median([r["final"]["relative_error"] for r in group])),
                            median_absolute_margin_error=float(np.median([r["absolute_margin_error"] for r in group])),
                            maximum_first_source_relative_error=max(r["source_first"]["relative_error"] for r in group))
    checks = [m["consistent"] for r in rows for k in ("source_layers", "verdict_layers") for m in r[k]]
    assert all(checks) and maximum_source <= 1e-4
    files = ["scripts/stage1_error_decomposition_201.py", "scripts/stage2_oracle_reset_201.py",
             "scripts/stage2_real_reset_start_201.py", "scripts/run_oracle_reset_201.py",
             ".context/audit_oracle_reset_201.md", ".context/stage1_identity_verified.json",
             ".context/stage2_real_attempt.json", ".context/checkpoint_recovered.json",
             ".context/oracle_reset_201_result.json"]
    preserved = {f: hashlib.sha256((ROOT / f).read_bytes()).hexdigest() for f in files}
    result = dict(summary=summary, rows=rows, maximum_full_first_block_coordinate_error=maximum_source,
                  same_vector_checks=len(checks), same_vector_checks_passed=all(checks),
                  original201_fingerprint=original["fingerprint"], preserved_replacement_hashes=preserved,
                  audit_findings=[
                      "Replacement false_rows/true_rows are absolute native block OUTPUTS, not forecasts or displacement vectors.",
                      "Their difference is native displacement, not prediction error. The reported 42% block1 error does not measure forecast error.",
                      "source_first_delta is a full first-block DISPLACEMENT; true_first is an absolute native first-block state. Comparing these directly is invalid.",
                      "Original 201 source control checks FULL first-block vector coordinates AND per-example source vector relative error/cosine, not merely scores.",
                      "Stage1 projection uses absolute native displacement and false depth steps, no model Jacobian. local_disc is defined by subtraction; reconstruction_err is its norm, not an identity residual.",
                      "stage1_identity_verified.json is a status assertion without quantitative model-JVP verification.",
                      "run_oracle_reset_201.py subtracts two norms and never executes a continuation; no causal reset result exists.",
                      "stage2_real_reset_start_201.py loads a model and tensor, then executes pass. first_embedding_consumed=True is unsupported by a model forward.",
                      "Checkpoint metadata is a claim to recheck against loaded original runtime; no genuine reset result exists yet."
                  ],
                  definitions={"native_displacement": "true_rows - false_rows, same row/block",
                               "forecast_displacement": "{arm}_delta_rows",
                               "error": "native_displacement - forecast_displacement",
                               "q": "norm(error)/norm(native_displacement)",
                               "source_row": "saved row0 at Boolean token", "receiver_row": "saved row1 at last prompt token",
                               "depth": "row index+1 completed public blocks; pre-final-norm coordinates",
                               "zero": "zero predicted displacement and zero predicted margin change; cosine undefined"})
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(result, indent=2))
    print(json.dumps({k: v for k, v in result.items() if k not in ("rows", "preserved_replacement_hashes")}, indent=2))


if __name__ == "__main__":
    main()
