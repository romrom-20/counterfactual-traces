"""Independent shared/signed component reconstruction, identities and full margins."""

import itertools
import json
import math
from pathlib import Path

import audit_one_sided_gain_forecast_186 as parent
import numpy as np

from latent_decisions.evidence_policy import digest, write_json

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / "runs/shared-signed-curvature-187"
OUT = ROOT / "docs/analysis/187-independent-audit.json"
ARMS = ("paired", "even", "odd", "both", "false_anchor")


def source_hash():
    return digest(
        {
            "runner": (ROOT / "scripts/run_shared_signed_curvature_187.py").read_text(),
            "protocol": (
                ROOT / "docs/experiments/187-shared-versus-signed-curvature.md"
            ).read_text(),
            "parent": parent.source_hash(),
        }
    )


def components(xf, xt, yf, yt):
    x0, x1, y0, y1 = (v.astype(np.float64) for v in (xf, xt, yf, yt))
    c = (x0 + x1) * 0.5
    h = (x1 - x0) * 0.5
    s = np.empty_like(c)
    p = c >= 0
    s[p] = 1 / (1 + np.exp(-c[p]))
    e = np.exp(c[~p])
    s[~p] = e / (1 + e)
    a = c * s
    d = s * (1 + c * (1 - s))
    return {
        "center": c.astype(np.float32),
        "intercept": a.astype(np.float32),
        "slope": d.astype(np.float32),
        "even": ((y0 + y1) * 0.5 - a).astype(np.float32),
        "odd": ((y1 - y0) * 0.5 - d * h).astype(np.float32),
        "xf": xf.copy(),
        "xt": xt.copy(),
        "yf": yf.copy(),
        "yt": yt.copy(),
    }


def estimands(records, valid):
    cells = []
    for r in records:
        actual = [r["native_false"]["margin"]["log_odds"], r["native_true"]["margin"]["log_odds"]]
        pairs = {
            arm: [
                next(
                    q["margin"]["log_odds"]
                    for q in r["patches"]
                    if (q["arm"], q["bit"]) == (arm, bit)
                )
                for bit in range(2)
            ]
            for arm in ARMS
        }
        ds = {arm: v[1] - v[0] for arm, v in pairs.items()}
        cells.append(
            {
                **{k: r[k] for k in ("block", "schema", "reverse", "assignment", "target")},
                "supported": r["bases"][0]["facts"]["supported"],
                "native": actual,
                "pairs": pairs,
                "native_delta": actual[1] - actual[0],
                "deltas": ds,
                "curvature_delta_interaction": ds["both"] - ds["even"] - ds["odd"] + ds["paired"],
            }
        )
    panels = []
    for block, schema, rev in itertools.product(
        parent.blocks(), ("generic", "descriptive"), range(2)
    ):
        rows = [
            c
            for c in cells
            if (c["block"], c["schema"], c["reverse"]) == (block["id"], schema, rev)
        ]
        assert len(rows) == 4 and sorted(c["supported"] for c in rows) == [False, False, True, True]
        b = [
            math.fsum((1 if c["supported"] else -1) * c["native"][bit] for c in rows) / 2
            for bit in range(2)
        ]
        pb = {
            arm: [
                math.fsum((1 if c["supported"] else -1) * c["pairs"][arm][bit] for c in rows) / 2
                for bit in range(2)
            ]
            for arm in ARMS
        }
        db = b[1] - b[0]
        errors = {
            arm: [
                {
                    "assignment": c["assignment"],
                    "target": c["target"],
                    "bit": bit,
                    "error": c["pairs"][arm][bit] - c["native"][bit],
                }
                for c in rows
                for bit in range(2)
            ]
            for arm in ARMS
        }
        de = {
            arm: [
                {
                    "assignment": c["assignment"],
                    "target": c["target"],
                    "error": c["deltas"][arm] - c["native_delta"],
                }
                for c in rows
            ]
            for arm in ARMS
        }
        be = {arm: [v[bit] - b[bit] for bit in range(2)] for arm, v in pb.items()}
        panels.append(
            {
                "block": block["id"],
                "schema": schema,
                "reverse": rev,
                "B_native": b,
                "B_patched": pb,
                "native_delta_B": db,
                "individual_errors": errors,
                "individual_effect_errors": de,
                "balanced_errors": be,
                "balanced_effect_errors": {arm: (v[1] - v[0]) - db for arm, v in pb.items()},
                "maximum_individual_error": {
                    arm: max(abs(e["error"]) for e in es) for arm, es in errors.items()
                },
                "maximum_individual_effect_error": {
                    arm: max(abs(e["error"]) for e in es) for arm, es in de.items()
                },
                "common_margin_errors": {
                    arm: [
                        math.fsum(e["error"] for e in es if e["bit"] == bit) / 4 for bit in range(2)
                    ]
                    for arm, es in errors.items()
                },
                "individual_matching": {
                    arm: all(abs(e["error"]) <= 0.1 for e in es) for arm, es in errors.items()
                },
                "individual_effect_matching": {
                    arm: all(abs(e["error"]) <= 0.1 for e in es) for arm, es in de.items()
                },
                "balanced_matching": {
                    arm: all(abs(e) <= 0.1 for e in es) for arm, es in be.items()
                },
                "balanced_effect_matching": {
                    arm: abs((v[1] - v[0]) - db) <= 0.1 for arm, v in pb.items()
                },
                "individual_retention": {
                    arm: all(
                        abs(c["native_delta"]) >= 0.5
                        and c["native_delta"] * c["deltas"][arm] > 0
                        and abs(c["deltas"][arm]) >= 0.5 * abs(c["native_delta"])
                        for c in rows
                    )
                    for arm in ARMS
                },
                "balanced_retention": {
                    arm: abs(db) >= 0.2
                    and db * (v[1] - v[0]) > 0
                    and abs(v[1] - v[0]) >= 0.5 * abs(db)
                    for arm, v in pb.items()
                },
            }
        )
    accounts = {
        metric: {
            arm: {
                "compatible_panels": sum(p[metric][arm] for p in panels),
                "strata": {
                    f"{schema}_{rev}": sum(
                        p[metric][arm]
                        for p in panels
                        if (p["schema"], p["reverse"]) == (schema, rev)
                    )
                    for schema, rev in itertools.product(("generic", "descriptive"), range(2))
                },
                "whole_passed": valid
                and arm != "both"
                and all(
                    sum(
                        p[metric][arm]
                        for p in panels
                        if (p["schema"], p["reverse"]) == (schema, rev)
                    )
                    >= 3
                    for schema, rev in itertools.product(("generic", "descriptive"), range(2))
                ),
                "identity_control": arm == "both",
            }
            for arm in ARMS
        }
        for metric in (
            "individual_matching",
            "individual_effect_matching",
            "balanced_matching",
            "balanced_effect_matching",
            "individual_retention",
            "balanced_retention",
        )
    }
    return {"cells": cells, "panels": panels, "accounts": accounts}


def main():
    native = parent.native
    b = json.loads((RUN / "design.json").read_text())
    status = json.loads((RUN / "pipeline-status.json").read_text())
    assert (
        digest(b["design"]) == b["fingerprint"]
        and b["design"]["source_hash"] == source_hash()
        and status["status"] == "complete"
        and status["completed_forwards"] == 640
    )
    pa = json.loads(parent.OUT.read_text())
    assert (
        pa["numerical_qualified"]
        and all(pa["controls"].values())
        and pa["fingerprint"] == b["design"]["parent_fingerprint"]
    )
    assert json.loads((RUN / "qwen15/runtime.json").read_text()) == json.loads(
        (parent.RUN / "qwen15/runtime.json").read_text()
    )
    checks = {
        name: True
        for name in (
            "immutable_runtime_sources_parent",
            "complete640_component_crossing",
            "all28_shared_signed_component_formulas",
            "all28_actual_activation_formulas_spans",
            "all128_exact_native_combined_identities",
            "all128_exact186_false_anchor_replays",
            "earlier_metadata_rows_native_exact",
            "public_score_arithmetic",
        )
    }
    records = []
    map_error = formula_error = 0.0
    for block, a, t, rev, schema in itertools.product(
        parent.blocks(), range(2), range(2), range(2), ("generic", "descriptive")
    ):
        g = native.fixture.group(block, a, t, rev, schema)
        key = digest(g)
        fe = native.read_record(parent.RUN / "qwen15/forecasts" / f"{key}.json")
        pe = native.read_record(parent.RUN / "qwen15/records" / f"{key}.json")
        e = native.read_record(RUN / "qwen15/records" / f"{key}.json")
        fr, pr, r = fe["record"], pe["record"], e["record"]
        assert (
            r["forecast_record_sha256"] == fe["sha256"]
            and r["native_record_sha256"] == pe["sha256"]
            and r["fingerprint"] == b["fingerprint"]
            and all(r[k] == pr[k] == v for k, v in g.items())
        )
        fp, pp, p = (
            parent.RUN / "qwen15/forecasts" / f"{key}.npz",
            parent.RUN / "qwen15/states" / f"{key}.npz",
            RUN / "qwen15/states" / f"{key}.npz",
        )
        assert (
            native.hashed(fp) == fr["states_sha256"]
            and native.hashed(pp) == pr["states_sha256"]
            and native.hashed(p) == r["states_sha256"]
        )
        assert len(r["patches"]) == 10 and {(q["arm"], q["bit"]) for q in r["patches"]} == set(
            itertools.product(ARMS, range(2))
        )
        pos, length = r["position"], len(fr["bases"][0]["free_input_ids"])
        with (
            np.load(fp, allow_pickle=False) as fz,
            np.load(pp, allow_pickle=False) as pz,
            np.load(p, allow_pickle=False) as z,
        ):
            for site in range(1, 29):
                expected = components(
                    fz[f"native_false_{site}_input"],
                    pz[f"native_true_{site}_input"],
                    fz[f"native_false_{site}_output"],
                    pz[f"native_true_{site}_output"],
                )
                map_error = max(
                    map_error,
                    max(
                        float(np.max(abs(v - z[f"map_{site}_{name}"])))
                        for name, v in expected.items()
                    ),
                )
            for q in r["patches"]:
                arm, bit = q["arm"], q["bit"]
                prefix = f"{arm}_{bit}"
                h = z[f"{prefix}_final"]
                raw_table = fz if bit == 0 else pz
                raw_label = "native_false" if bit == 0 else "native_true"
                expected_margin = (
                    fr["native_false"]["margin"] if bit == 0 else pr["native_true"]["margin"]
                )
                checks["earlier_metadata_rows_native_exact"] &= h.shape == (
                    length,
                    1536,
                ) and np.array_equal(h[: pos + 1], raw_table[f"{raw_label}_final"][: pos + 1])
                checks["public_score_arithmetic"] &= native.margin_valid(q["margin"])
                if arm == "both":
                    checks["all128_exact_native_combined_identities"] &= q[
                        "margin"
                    ] == expected_margin and np.array_equal(h, raw_table[f"{raw_label}_final"])
                if arm == "false_anchor":
                    checks["all128_exact186_false_anchor_replays"] &= q["margin"] == next(
                        v["margin"] for v in pr["patches"] if v["bit"] == bit
                    ) and np.array_equal(h, pz[f"oracle_{bit}_final"])
                trace = q["activation_trace"]
                checks["all28_actual_activation_formulas_spans"] &= (
                    len(trace) == 28
                    and [v["site"] for v in trace] == list(range(1, 29))
                    and all(
                        v["arm"] == arm
                        and v["bit"] == bit
                        and v["other_rows_identical"]
                        and v["endpoint_correction"] == (arm == "both")
                        and (v["start"], v["end"]) == (pos + 1, length)
                        and v["input_sha256"] == native.array_hash(z[f"{prefix}_{v['site']}_input"])
                        and v["output_sha256"]
                        == native.array_hash(z[f"{prefix}_{v['site']}_output"])
                        for v in trace
                    )
                )
                for site in range(1, 29):
                    m = {
                        name: z[f"map_{site}_{name}"]
                        for name in (
                            "center",
                            "intercept",
                            "slope",
                            "even",
                            "odd",
                            "xf",
                            "xt",
                            "yf",
                            "yt",
                        )
                    }
                    x, y = z[f"{prefix}_{site}_input"], z[f"{prefix}_{site}_output"]
                    checks["all28_actual_activation_formulas_spans"] &= (
                        x.shape == y.shape == (length - pos - 1, 8960)
                        and x.dtype == y.dtype == np.float32
                        and np.isfinite(x).all()
                        and np.isfinite(y).all()
                    )
                    if arm == "false_anchor":
                        pred = m["yf"] + m["slope"] * (x - m["xf"])
                    else:
                        pred = m["intercept"] + m["slope"] * (x - m["center"])
                        if arm in ("even", "both"):
                            pred = pred + m["even"]
                        if arm in ("odd", "both"):
                            pred = pred + (2 * bit - 1) * m["odd"]
                        if arm == "both":
                            pred = np.where(x == m["xf"], m["yf"], pred)
                            pred = np.where(x == m["xt"], m["yt"], pred)
                    formula_error = max(formula_error, float(np.max(abs(y - pred))))
                    if arm == "both":
                        checks["all128_exact_native_combined_identities"] &= np.array_equal(
                            x, raw_table[f"{raw_label}_{site}_input"]
                        ) and np.array_equal(y, raw_table[f"{raw_label}_{site}_output"])
        records.append(
            {
                **r,
                "bases": fr["bases"],
                "native_false": fr["native_false"],
                "native_true": pr["native_true"],
            }
        )
    checks["complete640_component_crossing"] &= (
        len(records) == len(list((RUN / "qwen15/records").glob("*.json"))) == 64
    )
    checks["all28_shared_signed_component_formulas"] &= map_error <= 1e-5
    checks["all28_actual_activation_formulas_spans"] &= formula_error <= 1e-5
    numerical = False
    p = ROOT / "docs/analysis/187-numerical-recheck.json"
    if p.exists():
        n = json.loads(p.read_text())
        numerical = (
            n["passed"]
            and n["fingerprint"] == b["fingerprint"]
            and n["forwards"] == 48
            and n["source_sha256"]
            == native.hashed(ROOT / "scripts/recheck_shared_signed_curvature_187.py")
            and n["audit_sha256"] == native.hashed(Path(__file__))
            and n["public_helper_sha256"]
            == native.hashed(ROOT / "scripts/recheck_natural_bit_shared_reader_181.py")
        )
    result = {
        "complete": True,
        "fingerprint": b["fingerprint"],
        "main_forwards": 640,
        "controls": {k: bool(v) for k, v in checks.items()},
        "maximum_map_error": map_error,
        "maximum_activation_formula_error": formula_error,
        "numerical_qualified": numerical,
        **estimands(records, numerical and all(checks.values())),
        "scope": "Paired native activation decomposition under native dynamics. Both is endpoint-preserving identity only, excluded from predictive whole accounts; other arms uncorrected. Shared correction fixes derivative maps but can alter live activation differences. Reused186 dependent cohort; selected numerical replay.",
    }
    write_json(OUT, result)
    print(
        json.dumps(
            {
                "controls": result["controls"],
                "numerical_qualified": numerical,
                "accounts": result["accounts"],
                "maximum_map_error": map_error,
                "maximum_activation_formula_error": formula_error,
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
