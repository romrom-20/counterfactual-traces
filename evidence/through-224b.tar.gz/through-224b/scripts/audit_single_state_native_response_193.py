"""All single-state forecasts, native-response failures, and global prospective proof."""

import itertools
import json
from pathlib import Path

import audit_one_sided_curvature_forecast_191 as parent
import numpy as np
from audit_one_sided_gain_forecast_186 import ordered
from transformers import AutoTokenizer

from latent_decisions.evidence_policy import digest, write_json

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / "runs/single-state-native-response-193"
OUT = ROOT / "docs/analysis/193-independent-audit.json"
native = parent.native
DOSES = (0.125, 0.25, 0.5, 1.0)
LITERALS = (
    ("sylvan", "woodland", "Tuesday", "Saturday"),
    ("topaz", "beryl", "Monday", "Thursday"),
    ("planet", "orbit", "Wednesday", "Friday"),
    ("fjord", "cove", "Thursday", "Tuesday"),
)


def blocks():
    return [
        {"id": a, "stage": "193", "subjects": [a, b], "days": [x, y], "old_block": None}
        for a, b, x, y in LITERALS
    ]


def source_hash():
    return digest(
        {
            "runner": (ROOT / "scripts/run_single_state_native_response_193.py").read_text(),
            "helper": (ROOT / "scripts/false_state_response_192.py").read_text(),
            "protocol": (ROOT / "docs/experiments/193-first-order-native-response.md").read_text(),
            "parent": parent.source_hash(),
        }
    )


def main():
    b = json.loads((RUN / "design.json").read_text())
    status = json.loads((RUN / "pipeline-status.json").read_text())
    pa = json.loads(parent.OUT.read_text())
    assert b["fingerprint"] == digest(b["design"]) and b["design"]["source_hash"] == source_hash()
    assert pa["numerical_qualified"] and all(pa["controls"].values())
    assert pa["fingerprint"] == b["design"]["parent_fingerprint"]
    assert (
        status["status"] == "complete"
        and status["ordinary_model_invocations"] == 320
        and status["differentiated_false_invocations"] == 64
    )
    rt = json.loads((RUN / "qwen15/runtime.json").read_text())
    assert rt == json.loads((parent.RUN / "qwen15/runtime.json").read_text())
    spec = b["design"]["models"]["qwen15"]
    tok = AutoTokenizer.from_pretrained(
        spec["model"], revision=spec["revision"], local_files_only=True
    )
    assert digest(tok.get_vocab()) == rt["tokenizer_hash"]
    manifest = json.loads((RUN / "forecast-manifest.json").read_text())
    assert digest(manifest["manifest"]) == manifest["manifest_sha256"]
    assert (
        manifest["ordinary_model_invocations"] == manifest["differentiated_false_invocations"] == 64
    )
    entries = {v["key"]: v for v in manifest["manifest"]}
    controls = {
        k: True
        for k in (
            "immutable_source_runtime_parent",
            "complete320ordinary64differentiated",
            "all64_new_single_token_pairs",
            "global_false_forecasts_before_any_observation",
            "all28_states_scores_derivatives_finite",
            "false_primal_all28_trajectories",
            "causal_prefix_derivatives_exact_zero",
            "observed_prefix_states_native_exact",
            "public_score_arrays_arithmetic",
            "embedding_closure_bound",
        )
    }
    cells, before, after = [], [], []
    for block, a, t, rev, schema in itertools.product(
        blocks(), range(2), range(2), range(2), ("generic", "descriptive")
    ):
        g = native.fixture.group(block, a, t, rev, schema)
        key = digest(g)
        f = native.read_record(RUN / "qwen15/forecasts" / f"{key}.json")
        o = native.read_record(RUN / "qwen15/observations" / f"{key}.json")
        fr, obs = f["record"], o["record"]
        assert (
            fr["fingerprint"] == obs["fingerprint"] == b["fingerprint"]
            and obs["forecast_record_sha256"] == f["sha256"]
        )
        assert (
            entries[key]["record_sha256"] == f["sha256"]
            and entries[key]["states_sha256"] == fr["states_sha256"]
        )
        fp, op = RUN / "qwen15/forecasts" / f"{key}.npz", RUN / "qwen15/observations" / f"{key}.npz"
        assert (
            native.hashed(fp) == fr["states_sha256"] and native.hashed(op) == obs["states_sha256"]
        )
        bases = [
            native.fixture.reconstruct(tok, block, native.fixture.job(g, bit)) for bit in range(2)
        ]
        pos = fr["position"]
        length = len(bases[0]["free_input_ids"])
        controls["all64_new_single_token_pairs"] &= (
            bases == fr["bases"]
            and len(bases[1]["free_input_ids"]) == length
            and [
                i
                for i, (x, y) in enumerate(
                    zip(bases[0]["free_input_ids"], bases[1]["free_input_ids"])
                )
                if x != y
            ]
            == [pos]
        )
        before.append(fr["completed_utc"])
        after.append(obs["started_utc"])
        controls["embedding_closure_bound"] &= 0 <= fr["embedding_closure_error"] <= 1e-5
        with np.load(fp, allow_pickle=False) as z, np.load(op, allow_pickle=False) as oz:
            shape = (28, length, 1536)
            controls["all28_states_scores_derivatives_finite"] &= (
                all(np.isfinite(v).all() for table in (z, oz) for v in table.values())
                and all(z[f"{k}_states"].shape == shape for k in ("native_false", "primal", "d1"))
                and all(oz[f"actual_{dose}_states"].shape == shape for dose in DOSES)
            )
            controls["false_primal_all28_trajectories"] &= (
                float(np.max(abs(z["primal_states"] - z["native_false_states"]))) <= 1e-4
                and float(np.max(abs(z["primal_scores"] - z["native_false_scores"]))) <= 0.005
            )
            controls["causal_prefix_derivatives_exact_zero"] &= all(
                np.count_nonzero(z[f"{k}_states"][:, :pos]) == 0 for k in ("d1",)
            )
            fs = z["native_false_scores"].astype(np.float64)
            h0 = z["native_false_states"].astype(np.float64)
            controls["public_score_arrays_arithmetic"] &= np.array_equal(
                fs, np.array([fr["native_false"]["false_score"], fr["native_false"]["true_score"]])
            ) and native.margin_valid(fr["native_false"])
            for dose in DOSES:
                hs = oz[f"actual_{dose}_states"].astype(np.float64)
                scores = oz[f"actual_{dose}_scores"].astype(np.float64)
                controls["observed_prefix_states_native_exact"] &= np.array_equal(
                    hs[:, :pos], h0[:, :pos]
                )
                m = obs["margins"][str(dose)]
                controls["public_score_arrays_arithmetic"] &= native.margin_valid(
                    m
                ) and np.array_equal(scores, np.array([m["false_score"], m["true_score"]]))
                delta_h = hs - h0
                delta_m = float((scores[1] - scores[0]) - (fs[1] - fs[0]))
                for order in (1,):
                    pred_h = dose * z["d1_states"].astype(np.float64)
                    pred_s = dose * z["d1_scores"].astype(np.float64)
                    pred_m = float(pred_s[1] - pred_s[0])
                    norm = float(np.linalg.norm(delta_h[-1, -1]))
                    pn = float(np.linalg.norm(pred_h[-1, -1]))
                    cosine = (
                        float(np.dot(delta_h[-1, -1], pred_h[-1, -1]) / (norm * pn))
                        if norm and pn
                        else None
                    )
                    relative = (
                        float(np.linalg.norm(pred_h[-1, -1] - delta_h[-1, -1]) / norm)
                        if norm
                        else None
                    )
                    cells.append(
                        {
                            **g,
                            "supported": bases[0]["facts"]["supported"],
                            "dose": dose,
                            "order": order,
                            "native_false_margin": float(fs[1] - fs[0]),
                            "actual_delta_margin": delta_m,
                            "predicted_delta_margin": pred_m,
                            "margin_error": pred_m - delta_m,
                            "last_displacement_norm": norm,
                            "last_relative_error": relative,
                            "last_cosine": cosine,
                            "all28_last_relative_errors": [
                                float(
                                    np.linalg.norm(pred_h[layer, -1] - delta_h[layer, -1])
                                    / np.linalg.norm(delta_h[layer, -1])
                                )
                                if np.linalg.norm(delta_h[layer, -1])
                                else None
                                for layer in range(28)
                            ],
                            "all28_last_actual_displacement_norms": [
                                float(np.linalg.norm(delta_h[layer, -1])) for layer in range(28)
                            ],
                        }
                    )
    controls["global_false_forecasts_before_any_observation"] &= ordered(
        before, manifest["completed_utc"], after
    )
    controls["complete320ordinary64differentiated"] &= (
        len(entries)
        == len(list((RUN / "qwen15/forecasts").glob("*.json")))
        == len(list((RUN / "qwen15/observations").glob("*.json")))
        == 64
    )
    numerical = False
    npth = ROOT / "docs/analysis/193-numerical-recheck.json"
    if npth.exists():
        n = json.loads(npth.read_text())
        numerical = (
            n["passed"]
            and n["ordinary_model_invocations"] == 16
            and n["reverse_differentiated_invocations"] == 8
            and n["fingerprint"] == b["fingerprint"]
            and n["source_sha256"]
            == native.hashed(ROOT / "scripts/recheck_single_state_native_response_193.py")
            and n["audit_sha256"] == native.hashed(Path(__file__))
            and n["public_helper_sha256"]
            == native.hashed(ROOT / "scripts/recheck_natural_bit_shared_reader_181.py")
        )
    panels = []
    for block, schema, rev, dose, order in itertools.product(
        blocks(), ("generic", "descriptive"), range(2), DOSES, (1,)
    ):
        rs = [
            c
            for c in cells
            if (c["block"], c["schema"], c["reverse"], c["dose"], c["order"])
            == (block["id"], schema, rev, dose, order)
        ]
        assert len(rs) == 4
        balanced = sum((1 if c["supported"] else -1) * c["margin_error"] for c in rs) / 2
        panels.append(
            {
                "block": block["id"],
                "schema": schema,
                "reverse": rev,
                "dose": dose,
                "order": order,
                "individual_matching": all(abs(c["margin_error"]) <= 0.1 for c in rs),
                "residual_matching": all(
                    c["last_displacement_norm"] >= 0.001
                    and c["last_relative_error"] <= 0.05
                    and c["last_cosine"] is not None
                    and c["last_cosine"] >= 0.99
                    for c in rs
                ),
                "balanced_matching": abs(balanced) <= 0.1,
                "balanced_error": balanced,
            }
        )
    accounts = {}
    for dose, order, metric in itertools.product(
        DOSES, (1,), ("individual_matching", "residual_matching", "balanced_matching")
    ):
        rs = [p for p in panels if (p["dose"], p["order"]) == (dose, order)]
        strata = {
            f"{s}_{r}": sum(p[metric] for p in rs if (p["schema"], p["reverse"]) == (s, r))
            for s, r in itertools.product(("generic", "descriptive"), range(2))
        }
        accounts[f"dose{dose}_order{order}_{metric}"] = {
            "compatible_panels": sum(p[metric] for p in rs),
            "strata": strata,
            "whole_passed": numerical
            and all(controls.values())
            and all(v >= 3 for v in strata.values()),
            "primary": dose == 1 and metric in ("individual_matching", "residual_matching"),
        }
    result = {
        "complete": True,
        "fingerprint": b["fingerprint"],
        "ordinary_model_invocations": 320,
        "differentiated_false_invocations": 64,
        "controls": {k: bool(v) for k, v in controls.items()},
        "numerical_qualified": numerical,
        "cells": cells,
        "panels": panels,
        "accounts": accounts,
        "scope": "Single-state white-box directional Taylor baseline; no true-state trajectory calibration or live target computation in prediction. Small doses diagnostic. Known input change and weights available; no learned mechanism/priority/competence claim. Numerical derivative projection checks do not certify coordinatewise equality of the entire derivative tensor.",
    }
    write_json(OUT, result)
    print(json.dumps({k: v for k, v in result.items() if k not in ("cells", "panels")}, indent=2))


if __name__ == "__main__":
    main()
