"""Separate affine offset/slope reconstruction and unchanged matching criteria."""

import itertools
import json
from pathlib import Path

import audit_transferred_silu_tangent_184 as parent
import numpy as np

from latent_decisions.evidence_policy import digest, write_json

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / "runs/tangent-offset-slope-crossing-185"
OUT = ROOT / "docs/analysis/185-independent-audit.json"
ARMS = ("original_local", "LL", "LD", "DL", "DD")


def source_hash():
    return digest(
        {
            "runner": (ROOT / "scripts/run_tangent_offset_slope_crossing_185.py").read_text(),
            "protocol": (
                ROOT / "docs/experiments/185-tangent-offset-slope-crossing.md"
            ).read_text(),
            "parent": parent.source_hash(),
        }
    )


def coefficients(x0, x1):
    c = (x0.astype(np.float64) + x1.astype(np.float64)) * 0.5
    s = np.empty_like(c)
    pos = c >= 0
    s[pos] = 1 / (1 + np.exp(-c[pos]))
    e = np.exp(c[~pos])
    s[~pos] = e / (1 + e)
    return {
        "slope": (s * (1 + c * (1 - s))).astype(np.float32),
        "offset": (-c * c * s * (1 - s)).astype(np.float32),
    }


def estimands(records, valid):
    cells, panels, accounts = [], [], {}
    for arm in ARMS:
        rs = []
        for r in records:
            rs.append(
                {
                    **r,
                    "transferred": [
                        next(q for q in r["patches"] if (q["arm"], q["bit"]) == (arm, bit))
                        for bit in range(2)
                    ],
                }
            )
        result = parent.estimands(rs, valid)
        cells.extend({**c, "arm": arm} for c in result["cells"])
        panels.extend({**p, "arm": arm} for p in result["panels"])
        for metric, rows in result["accounts"].items():
            accounts.setdefault(metric, {})[arm] = rows["transferred"]
    return {"cells": cells, "panels": panels, "accounts": accounts}


def main():
    native = parent.parent.native
    b = json.loads((RUN / "design.json").read_text())
    status = json.loads((RUN / "pipeline-status.json").read_text())
    assert (
        digest(b["design"]) == b["fingerprint"]
        and b["design"]["source_hash"] == source_hash()
        and status["status"] == "complete"
        and status["completed_forwards"] == 640
    )
    pa = json.loads(parent.OUT.read_text())
    assert (
        pa["numerical_qualified"]
        and all(pa["controls"].values())
        and pa["fingerprint"] == b["design"]["parent_fingerprint"]
    )
    assert json.loads((RUN / "qwen15/runtime.json").read_text()) == json.loads(
        (parent.RUN / "qwen15/runtime.json").read_text()
    )
    checks = {
        name: True
        for name in (
            "immutable_runtime_sources_parent",
            "all640_crossed_conditions",
            "all28_local_donor_offset_slope_formulas",
            "all28_activation_formula_spans_hashes",
            "earlier_metadata_rows_native_exact",
            "diagonal_representation_controls",
            "public_score_arithmetic",
        )
    }
    donor = {}
    prov = json.loads((RUN / "donor-provenance.json").read_text())
    max_map_error = max_formula_error = 0.0
    for schema, rev in itertools.product(("generic", "descriptive"), range(2)):
        g = native.fixture.group(native.blocks()[0], 0, 0, rev, schema)
        key = digest(g)
        e = native.read_record(parent.parent.RUN / "qwen15/records" / f"{key}.json")
        p = parent.parent.RUN / "qwen15/states" / f"{key}.npz"
        assert native.hashed(p) == e["record"]["states_sha256"] and prov[f"{schema}_{rev}"] == {
            "record_sha256": e["sha256"],
            "state_sha256": e["record"]["states_sha256"],
        }
        with np.load(p, allow_pickle=False) as z:
            donor[f"{schema}_{rev}"] = {
                site: coefficients(z[f"raw_0_{site}_input"], z[f"raw_1_{site}_input"])
                for site in range(1, 29)
            }
    records, diagonals = [], []
    for block, a, t, rev, schema in itertools.product(
        parent.blocks(), range(2), range(2), range(2), ("generic", "descriptive")
    ):
        g = native.fixture.group(block, a, t, rev, schema)
        key = digest(g)
        pe = native.read_record(parent.RUN / "qwen15/records" / f"{key}.json")
        fe = native.read_record(parent.RUN / "qwen15/forecasts" / f"{key}.json")
        e = native.read_record(RUN / "qwen15/records" / f"{key}.json")
        pr, fr, r = pe["record"], fe["record"], e["record"]
        assert (
            r["native_record_sha256"] == pe["sha256"]
            and r["forecast_record_sha256"] == fe["sha256"]
            and r["fingerprint"] == b["fingerprint"]
            and all(r[k] == pr[k] == v for k, v in g.items())
        )
        p, pp, fp = (
            RUN / "qwen15/states" / f"{key}.npz",
            parent.RUN / "qwen15/states" / f"{key}.npz",
            parent.RUN / "qwen15/forecasts" / f"{key}.npz",
        )
        assert (
            native.hashed(p) == r["states_sha256"]
            and native.hashed(pp) == pr["states_sha256"]
            and native.hashed(fp) == fr["states_sha256"]
        )
        assert len(r["patches"]) == 10 and {(q["arm"], q["bit"]) for q in r["patches"]} == set(
            itertools.product(ARMS, range(2))
        )
        pos, length = r["position"], len(fr["bases"][0]["free_input_ids"])
        with (
            np.load(p, allow_pickle=False) as z,
            np.load(pp, allow_pickle=False) as pz,
            np.load(fp, allow_pickle=False) as fz,
        ):
            local = {
                site: coefficients(pz[f"native_0_{site}_input"], pz[f"native_1_{site}_input"])
                for site in range(1, 29)
            }
            original = {
                site: parent.parent.anchor(
                    pz[f"native_0_{site}_input"], pz[f"native_1_{site}_input"]
                )
                for site in range(1, 29)
            }
            refs = {"L": local, "D": donor[f"{schema}_{rev}"]}
            for q in r["patches"]:
                arm, bit = q["arm"], q["bit"]
                prefix = f"{arm}_{bit}"
                h = z[f"{prefix}_final"]
                checks["earlier_metadata_rows_native_exact"] &= h.shape == (
                    length,
                    1536,
                ) and np.array_equal(h[: pos + 1], pz[f"native_{bit}_final"][: pos + 1])
                checks["public_score_arithmetic"] &= native.margin_valid(q["margin"])
                trace = q["activation_trace"]
                checks["all28_activation_formula_spans_hashes"] &= (
                    len(trace) == 28
                    and [v["site"] for v in trace] == list(range(1, 29))
                    and all(
                        v["tangent"]
                        and v["other_rows_identical"]
                        and (v["start"], v["end"]) == (pos + 1, length)
                        and v["input_sha256"] == native.array_hash(z[f"{prefix}_{v['site']}_input"])
                        and v["output_sha256"]
                        == native.array_hash(z[f"{prefix}_{v['site']}_output"])
                        for v in trace
                    )
                )
                for site in range(1, 29):
                    expected = (
                        original[site]
                        if arm == "original_local"
                        else {
                            "center": np.zeros_like(local[site]["slope"]),
                            "intercept": refs[arm[0]][site]["offset"],
                            "slope": refs[arm[1]][site]["slope"],
                        }
                    )
                    max_map_error = max(
                        max_map_error,
                        max(
                            float(np.max(abs(v - z[f"map_{arm}_{site}_{name}"])))
                            for name, v in expected.items()
                        ),
                    )
                    x, y = z[f"{prefix}_{site}_input"], z[f"{prefix}_{site}_output"]
                    checks["all28_activation_formula_spans_hashes"] &= (
                        x.shape == y.shape == (length - pos - 1, 8960)
                        and x.dtype == y.dtype == np.float32
                        and np.isfinite(x).all()
                        and np.isfinite(y).all()
                    )
                    pred = z[f"map_{arm}_{site}_intercept"] + z[f"map_{arm}_{site}_slope"] * (
                        x - z[f"map_{arm}_{site}_center"]
                    )
                    max_formula_error = max(max_formula_error, float(np.max(abs(y - pred))))
            for bit in range(2):
                for arm, reference, expected in (
                    (
                        "LL",
                        z[f"original_local_{bit}_final"],
                        next(
                            q["margin"]
                            for q in r["patches"]
                            if (q["arm"], q["bit"]) == ("original_local", bit)
                        ),
                    ),
                    ("DD", fz[f"forecast_{bit}_final"], fr["patches"][bit]["margin"]),
                ):
                    actual = next(
                        q["margin"] for q in r["patches"] if (q["arm"], q["bit"]) == (arm, bit)
                    )
                    se = max(abs(actual[k] - expected[k]) for k in actual)
                    he = float(np.max(abs(z[f"{arm}_{bit}_final"] - reference)))
                    checks["diagonal_representation_controls"] &= se <= 0.005 and he <= 0.001
                    diagonals.append(
                        {**g, "arm": arm, "bit": bit, "score_error": se, "state_error": he}
                    )
        records.append({**r, "bases": fr["bases"], "native": pr["natives"]})
    checks["all640_crossed_conditions"] &= (
        len(records) == len(list((RUN / "qwen15/records").glob("*.json"))) == 64
    )
    checks["all28_local_donor_offset_slope_formulas"] &= max_map_error <= 1e-5
    checks["all28_activation_formula_spans_hashes"] &= max_formula_error <= 1e-5
    numerical = False
    p = ROOT / "docs/analysis/185-numerical-recheck.json"
    if p.exists():
        n = json.loads(p.read_text())
        numerical = (
            n["passed"]
            and n["fingerprint"] == b["fingerprint"]
            and n["forwards"] == 48
            and n["source_sha256"]
            == native.hashed(ROOT / "scripts/recheck_tangent_offset_slope_crossing_185.py")
            and n["audit_sha256"] == native.hashed(Path(__file__))
            and n["activation_helper_sha256"]
            == native.hashed(ROOT / "scripts/recheck_natural_silu_tangent_183.py")
            and n["public_helper_sha256"]
            == native.hashed(ROOT / "scripts/recheck_natural_bit_shared_reader_181.py")
        )
    result = {
        "complete": True,
        "fingerprint": b["fingerprint"],
        "main_forwards": 640,
        "controls": {k: bool(v) for k, v in checks.items()},
        "maximum_map_error": max_map_error,
        "maximum_activation_formula_error": max_formula_error,
        "diagonal_controls": diagonals,
        "numerical_qualified": numerical,
        **estimands(records, numerical and all(checks.values())),
        "scope": "Posthoc184 target cohort; per-pair local affine coefficients crossed with fixed donor coefficients. Operation-level sufficiency under native dynamics, not learned semantic/training-origin/grounding explanation.",
    }
    offset = (
        result["accounts"]["balanced_endpoint_matching"]["LD"]["whole_passed"]
        and result["accounts"]["balanced_effect_matching"]["LD"]["whole_passed"]
    )
    slope = (
        result["accounts"]["balanced_endpoint_matching"]["DL"]["whole_passed"]
        and result["accounts"]["balanced_effect_matching"]["DL"]["whole_passed"]
    )
    result["mixed_evidence_accounts"] = {
        "local_offset_donor_slope": offset,
        "donor_offset_local_slope": slope,
        "offset_only_passes": offset and not slope,
        "slope_only_passes": slope and not offset,
    }
    write_json(OUT, result)
    print(
        json.dumps(
            {
                "controls": result["controls"],
                "numerical_qualified": numerical,
                "accounts": result["accounts"],
                "mixed_evidence_accounts": result["mixed_evidence_accounts"],
                "maximum_diagonal_score_error": max(x["score_error"] for x in diagonals),
                "maximum_diagonal_state_error": max(x["state_error"] for x in diagonals),
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
