"""Fixed donor maps and all-forecast-before-any-measurement audit."""

import itertools
import json
import math
from datetime import datetime
from pathlib import Path

import audit_natural_silu_tangent_183 as parent
import numpy as np
from transformers import AutoTokenizer

from latent_decisions.evidence_policy import digest, write_json

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / "runs/transferred-silu-tangent-184"
OUT = ROOT / "docs/analysis/184-independent-audit.json"
LITERALS = (
    ("juniper", "magnolia", "Monday", "Sunday"),
    ("zircon", "topaz", "Thursday", "Saturday"),
    ("horizon", "solstice", "Wednesday", "Monday"),
    ("cobalt", "umber", "Saturday", "Tuesday"),
)


def blocks():
    return [
        {"id": a, "stage": "184", "subjects": [a, b], "days": [x, y], "old_block": None}
        for a, b, x, y in LITERALS
    ]


def source_hash():
    return digest(
        {
            "runner": (ROOT / "scripts/run_transferred_silu_tangent_184.py").read_text(),
            "protocol": (ROOT / "docs/experiments/184-transferred-silu-tangent.md").read_text(),
            "parent": parent.source_hash(),
        }
    )


def forecast_order(forecast_times, frozen_time, measurement_times):
    return bool(forecast_times and measurement_times) and max(
        map(datetime.fromisoformat, forecast_times)
    ) <= datetime.fromisoformat(frozen_time) <= min(map(datetime.fromisoformat, measurement_times))


def estimands(records, valid):
    cells = []
    for r in records:
        margins = {
            mode: [r[mode][bit]["margin"]["log_odds"] for bit in range(2)]
            for mode in ("native", "transferred")
        }
        cells.append(
            {
                **{k: r[k] for k in ("block", "schema", "reverse", "assignment", "target")},
                "supported": r["bases"][0]["facts"]["supported"],
                "margins": margins,
                "delta": {mode: m[1] - m[0] for mode, m in margins.items()},
            }
        )
    panels = []
    for block, schema, rev in itertools.product(blocks(), ("generic", "descriptive"), range(2)):
        rows = [
            c
            for c in cells
            if (c["block"], c["schema"], c["reverse"]) == (block["id"], schema, rev)
        ]
        assert len(rows) == 4 and sorted(c["supported"] for c in rows) == [False, False, True, True]
        b = {
            mode: [
                math.fsum((1 if c["supported"] else -1) * c["margins"][mode][bit] for c in rows) / 2
                for bit in range(2)
            ]
            for mode in ("native", "transferred")
        }
        db = {mode: v[1] - v[0] for mode, v in b.items()}
        errors = [
            {
                "assignment": c["assignment"],
                "target": c["target"],
                "bit": bit,
                "error": c["margins"]["transferred"][bit] - c["margins"]["native"][bit],
            }
            for c in rows
            for bit in range(2)
        ]
        de = [
            {
                "assignment": c["assignment"],
                "target": c["target"],
                "error": c["delta"]["transferred"] - c["delta"]["native"],
            }
            for c in rows
        ]
        be = [b["transferred"][bit] - b["native"][bit] for bit in range(2)]
        panels.append(
            {
                "block": block["id"],
                "schema": schema,
                "reverse": rev,
                "B": b,
                "delta_B": db,
                "individual_endpoint_errors": errors,
                "individual_effect_errors": de,
                "balanced_endpoint_errors": be,
                "balanced_effect_error": db["transferred"] - db["native"],
                "individual_endpoint_matching": all(abs(e["error"]) <= 0.1 for e in errors),
                "individual_effect_matching": all(abs(e["error"]) <= 0.1 for e in de),
                "balanced_endpoint_matching": all(abs(e) <= 0.1 for e in be),
                "balanced_effect_matching": abs(db["transferred"] - db["native"]) <= 0.1,
                "individual_retention": all(
                    abs(c["delta"]["native"]) >= 0.5
                    and c["delta"]["native"] * c["delta"]["transferred"] > 0
                    and abs(c["delta"]["transferred"]) >= 0.5 * abs(c["delta"]["native"])
                    for c in rows
                ),
                "balanced_retention": abs(db["native"]) >= 0.2
                and db["native"] * db["transferred"] > 0
                and abs(db["transferred"]) >= 0.5 * abs(db["native"]),
            }
        )
    accounts = {
        metric: {
            "transferred": {
                "compatible_panels": sum(p[metric] for p in panels),
                "strata": {
                    f"{schema}_{rev}": sum(
                        p[metric] for p in panels if (p["schema"], p["reverse"]) == (schema, rev)
                    )
                    for schema, rev in itertools.product(("generic", "descriptive"), range(2))
                },
                "whole_passed": valid
                and all(
                    sum(p[metric] for p in panels if (p["schema"], p["reverse"]) == (schema, rev))
                    >= 3
                    for schema, rev in itertools.product(("generic", "descriptive"), range(2))
                ),
            }
        }
        for metric in (
            "individual_endpoint_matching",
            "individual_effect_matching",
            "balanced_endpoint_matching",
            "balanced_effect_matching",
            "individual_retention",
            "balanced_retention",
        )
    }
    return {"cells": cells, "panels": panels, "accounts": accounts}


def main():
    native = parent.native
    bundle = json.loads((RUN / "design.json").read_text())
    status = json.loads((RUN / "pipeline-status.json").read_text())
    assert (
        digest(bundle["design"]) == bundle["fingerprint"]
        and bundle["design"]["source_hash"] == source_hash()
    )
    assert (
        status["status"] == "complete"
        and status["fingerprint"] == bundle["fingerprint"]
        and status["completed_forwards"] == 256
    )
    pa = json.loads(parent.OUT.read_text())
    assert (
        pa["fingerprint"] == bundle["design"]["parent_fingerprint"]
        and pa["numerical_qualified"]
        and all(pa["controls"].values())
    )
    rt = json.loads((RUN / "qwen15/runtime.json").read_text())
    assert rt == json.loads((parent.RUN / "qwen15/runtime.json").read_text())
    cfg = bundle["design"]["models"]["qwen15"]
    tok = AutoTokenizer.from_pretrained(
        cfg["model"], revision=cfg["revision"], local_files_only=True
    )
    assert digest(tok.get_vocab()) == rt["tokenizer_hash"]
    manifest = json.loads((RUN / "forecast-manifest.json").read_text())
    assert (
        manifest["completed_forwards"] == 128
        and digest(manifest["manifest"]) == manifest["manifest_sha256"]
        and len(manifest["manifest"]) == 64
    )
    bykey = {e["key"]: e for e in manifest["manifest"]}
    provenance = json.loads((RUN / "donor-provenance.json").read_text())
    mp = RUN / "donor-maps.npz"
    assert provenance["maps_sha256"] == native.hashed(mp) and provenance["before_target_forwards"]
    with np.load(mp, allow_pickle=False) as z:
        maps = {key: z[key].copy() for key in z.files}
    controls = {
        name: True
        for name in (
            "immutable_runtime_source_parent",
            "all64_reconstructed_single_token_pairs",
            "fixed_four_donor_maps_analytic_provenance",
            "all128_forecasts_before_any_target_native",
            "all_manifest_record_state_hashes",
            "all28_activation_formulas_shapes_spans",
            "all_earlier_metadata_final_rows_identical",
            "complete256_physical_crossing",
            "public_score_arithmetic",
        )
    }
    anchor_error = 0.0
    for schema, rev in itertools.product(("generic", "descriptive"), range(2)):
        donor = native.fixture.group(native.blocks()[0], 0, 0, rev, schema)
        key = digest(donor)
        e = native.read_record(parent.RUN / "qwen15/records" / f"{key}.json")
        p = parent.RUN / "qwen15/states" / f"{key}.npz"
        assert native.hashed(p) == e["record"]["states_sha256"]
        controls["fixed_four_donor_maps_analytic_provenance"] &= provenance["donors"][
            f"{schema}_{rev}"
        ] == {
            "donor": donor,
            "record_sha256": e["sha256"],
            "states_sha256": e["record"]["states_sha256"],
        }
        with np.load(p, allow_pickle=False) as z:
            for site in range(1, 29):
                a = parent.anchor(z[f"raw_0_{site}_input"], z[f"raw_1_{site}_input"])
                anchor_error = max(
                    anchor_error,
                    max(
                        float(np.max(abs(v - maps[f"{schema}_{rev}_{site}_{name}"])))
                        for name, v in a.items()
                    ),
                )
                controls["fixed_four_donor_maps_analytic_provenance"] &= all(
                    np.array_equal(
                        maps[f"{schema}_{rev}_{site}_{name}"], z[f"anchor_{site}_{name}"]
                    )
                    for name in a
                )
    controls["fixed_four_donor_maps_analytic_provenance"] &= anchor_error <= 1e-5
    records, forecast_times, measurement_times = [], [], []
    formula_error = 0.0
    for block, a, t, rev, schema in itertools.product(
        blocks(), range(2), range(2), range(2), ("generic", "descriptive")
    ):
        g = native.fixture.group(block, a, t, rev, schema)
        key = digest(g)
        fe = native.read_record(RUN / "qwen15/forecasts" / f"{key}.json")
        e = native.read_record(RUN / "qwen15/records" / f"{key}.json")
        fr, r = fe["record"], e["record"]
        assert (
            fr["fingerprint"] == r["fingerprint"] == bundle["fingerprint"]
            and all(fr[k] == r[k] == v for k, v in g.items())
            and r["forecast_record_sha256"] == fe["sha256"]
        )
        fp, p = RUN / "qwen15/forecasts" / f"{key}.npz", RUN / "qwen15/states" / f"{key}.npz"
        controls["all_manifest_record_state_hashes"] &= (
            native.hashed(fp) == fr["states_sha256"]
            and native.hashed(p) == r["states_sha256"]
            and bykey[key]
            == {"key": key, "record_sha256": fe["sha256"], "states_sha256": fr["states_sha256"]}
        )
        bases = [
            native.fixture.reconstruct(tok, block, native.fixture.job(g, bit)) for bit in range(2)
        ]
        pos, length = r["position"], len(bases[0]["free_input_ids"])
        controls["all64_reconstructed_single_token_pairs"] &= (
            fr["bases"] == bases
            and pos == fr["position"]
            and len(bases[1]["free_input_ids"]) == length
            and [
                i
                for i, (x, y) in enumerate(
                    zip(bases[0]["free_input_ids"], bases[1]["free_input_ids"])
                )
                if x != y
            ]
            == [pos]
        )
        assert [q["bit"] for q in fr["patches"]] == [q["bit"] for q in r["natives"]] == [0, 1]
        with np.load(fp, allow_pickle=False) as fz, np.load(p, allow_pickle=False) as z:
            for bit in range(2):
                forecast_times.append(fr["patches"][bit]["completed_utc"])
                measurement_times.append(r["natives"][bit]["started_utc"])
                for family, table, patch in (
                    ("forecast", fz, fr["patches"][bit]),
                    ("native", z, r["natives"][bit]),
                ):
                    prefix = f"{family}_{bit}"
                    controls["public_score_arithmetic"] &= native.margin_valid(patch["margin"])
                    trace = patch["activation_trace"]
                    controls["all28_activation_formulas_shapes_spans"] &= (
                        len(trace) == 28
                        and [v["site"] for v in trace] == list(range(1, 29))
                        and all(
                            v["other_rows_identical"]
                            and v["tangent"] == (family == "forecast")
                            and (v["start"], v["end"]) == (pos + 1, length)
                            and v["input_sha256"]
                            == native.array_hash(table[f"{prefix}_{v['site']}_input"])
                            and v["output_sha256"]
                            == native.array_hash(table[f"{prefix}_{v['site']}_output"])
                            for v in trace
                        )
                    )
                    for site in range(1, 29):
                        x, y = table[f"{prefix}_{site}_input"], table[f"{prefix}_{site}_output"]
                        controls["all28_activation_formulas_shapes_spans"] &= (
                            x.shape == y.shape == (length - pos - 1, 8960)
                            and x.dtype == y.dtype == np.float32
                            and np.isfinite(x).all()
                            and np.isfinite(y).all()
                        )
                        expected = (
                            maps[f"{schema}_{rev}_{site}_intercept"]
                            + maps[f"{schema}_{rev}_{site}_slope"]
                            * (x - maps[f"{schema}_{rev}_{site}_center"])
                            if family == "forecast"
                            else (
                                x.astype(np.float64)
                                * np.exp(-np.logaddexp(0, -x.astype(np.float64)))
                            ).astype(np.float32)
                        )
                        formula_error = max(formula_error, float(np.max(abs(y - expected))))
                controls["all_earlier_metadata_final_rows_identical"] &= fz[
                    f"forecast_{bit}_final"
                ].shape == z[f"native_{bit}_final"].shape == (length, 1536) and np.array_equal(
                    fz[f"forecast_{bit}_final"][: pos + 1], z[f"native_{bit}_final"][: pos + 1]
                )
        records.append({**r, "bases": bases, "native": r["natives"], "transferred": fr["patches"]})
    controls["all128_forecasts_before_any_target_native"] = forecast_order(
        forecast_times, manifest["completed_utc"], measurement_times
    )
    controls["complete256_physical_crossing"] = (
        len(records)
        == len(bykey)
        == len(list((RUN / "qwen15/records").glob("*.json")))
        == len(list((RUN / "qwen15/forecasts").glob("*.json")))
        == 64
        and len(forecast_times) == len(measurement_times) == 128
    )
    controls["all28_activation_formulas_shapes_spans"] &= formula_error <= 1e-5
    numerical = False
    p = ROOT / "docs/analysis/184-numerical-recheck.json"
    if p.exists():
        n = json.loads(p.read_text())
        numerical = (
            n["passed"]
            and n["fingerprint"] == bundle["fingerprint"]
            and n["forwards"] == 16
            and n["source_sha256"]
            == native.hashed(ROOT / "scripts/recheck_transferred_silu_tangent_184.py")
            and n["audit_sha256"] == native.hashed(Path(__file__))
            and n["activation_helper_sha256"]
            == native.hashed(ROOT / "scripts/recheck_natural_silu_tangent_183.py")
            and n["public_helper_sha256"]
            == native.hashed(ROOT / "scripts/recheck_natural_bit_shared_reader_181.py")
        )
    result = {
        "complete": True,
        "fingerprint": bundle["fingerprint"],
        "main_forwards": 256,
        "controls": {k: bool(v) for k, v in controls.items()},
        "maximum_anchor_error": anchor_error,
        "maximum_activation_formula_error": formula_error,
        "numerical_qualified": numerical,
        **estimands(records, numerical and all(controls.values())),
        "scope": "Fresh blocks, fixed four donor maps, all forecasts frozen before any target native measurement. Same checkpoint/relation family; numerical replay selected first block/descriptive/order0. No target-pair calibration, universal semantic/training/grounding claim.",
    }
    write_json(OUT, result)
    print(
        json.dumps(
            {
                "controls": result["controls"],
                "numerical_qualified": numerical,
                "accounts": result["accounts"],
                "maximum_anchor_error": anchor_error,
                "maximum_activation_formula_error": formula_error,
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
