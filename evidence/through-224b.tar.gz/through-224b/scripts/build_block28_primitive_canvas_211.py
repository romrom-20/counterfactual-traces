"""Presentation only: actual signed vectors and finite interventions, offline."""

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MANAGED = Path(
    "/Users/samanseshadri/.cursor/projects/Users-samanseshadri-conductor-workspaces-training-jev-v1-bucharest/canvases/block28-primitive-211.canvas.tsx"
)


def main():
    result = json.loads((ROOT / "docs/analysis/211-block28-primitives.json").read_text())
    assert result["finite_interventions_qualified"]
    data = {k: v for k, v in result.items() if k != "strata"}
    data["summary"] = [r for r in result["strata"] if r["field"] is None]
    cross = json.loads((ROOT / "docs/analysis/211c-saved-vector-crosschecks.json").read_text())
    data["crosscheck"] = {
        k: cross[k]
        for k in ("failures", "maximum_coordinate_disagreement", "median_relative_l2_disagreement")
    }
    code = r"""import {H1,H2,Text,Table,Select,useState,useHostTheme} from "cursor/canvas";
const DATA=__DATA__;
const fmt=(v:number|null)=>v===null?"undefined":v.toPrecision(5);
const groups=["attention_norm_routing","value_output_interaction","mlp_input_rms","silu_curvature","gate_up_interaction"];
const budgetNames=["attention_norm_routing","weight_value","post_rms","silu","gate_up"];
const names=["Attention input RMS + QK + softmax","Attention weight–value product","MLP-input RMSNorm","SiLU gate curvature","Gate–up product"];
const primitives=["input_rms","qk_product","softmax","weight_value","post_rms","silu","gate_up","linear_rounding","reference_minus_public_jvp"];
export default function PrimitiveDiagnostic(){
 const t=useHostTheme();
 const [branch,setBranch]=useState("native");
 const [index,setIndex]=useState("0");
 const [kind,setKind]=useState("surgery_repair_");
 const cases=DATA.rows.filter(r=>r.branch===branch),item=cases[Number(index)];
 const summary=DATA.summary.find(r=>r.branch===branch)!;
 const endpoint=(key:string)=>item.endpoints[key];
 const outrow=(label:string,key:string)=>[label,fmt(endpoint(key).verdict.relative_l2),fmt(endpoint(key).absolute_margin_error),String(endpoint(key).both_improve_baseline),String(endpoint(key).primary_pass)];
 return <main style={{padding:24,maxWidth:1180,margin:"auto",background:t.bg.editor,color:t.text.primary}}>
 <H1>Block28 primitive diagnostic</H1>
 <p style={{fontSize:18}}><strong>Finite interventions qualified. The original MPS whole-block Jacobian remains unqualified.</strong></p>
 <Text>Source:211actual64old209ccontexts ×2incomingstates ·15October2026 · pinnedQwen1.5B · MPSFloat32/eager · alloracle/retrospective, no208extension</Text>
 <p>Both incoming states originate from the same native full-sequence reset before block27. Native means finite27output; linear27 means the originalFalse-Jacobian27output. All final readouts are finite. The complete causal prefix is computed; saved vectors contain the causal suffix after explicit prefix-zero checks.</p>
 <div style={{display:"flex",gap:14,flexWrap:"wrap",margin:"12px 0"}}>
 <label>Incoming state <Select value={branch} onChange={setBranch} options={[{value:"native",label:"Native after finite27"},{value:"linear27",label:"After False-linear27"}]}/></label>
 <label>Case <Select value={index} onChange={setIndex} options={cases.map((r,i)=>({value:String(i),label:r.group.block+" · "+r.group.schema+" · order"+r.group.reverse+" · "+r.group.assignment+"/"+r.group.target}))}/></label>
 </div>
 <H2>Signed receiving-position displacement effects</H2>
 <Table headers={["Local primitive / numerical term","Vector norm (residual units)","Signed projection toward native error","Signed projection toward local finite-minus-linear discrepancy"]} rows={primitives.map(k=>{
 const v=item.vectors["component_"+k].receivers;
 return [k,fmt(v.toward_native.norm),fmt(v.toward_native.signed_projection),fmt(v.toward_local.signed_projection)];
 })}/>
 <p>Each local finite remainder is transported through a fixedFalse CPU64 reference graph. The explicit reference/public mismatch includes tangent arithmetic AND originalFloat32input-subtraction differences. These signed vectors add to the measured local finite-minus-original-JVP discrepancy; their norms do not add. This accounting is not an exact attribution to the unqualified originalMPSJacobian.</p>
 <H2>Does correcting the discrepancy improve both endpoints?</H2>
 <label>Retrospective correction <Select value={kind} onChange={setKind} options={[{value:"surgery_repair_",label:"Insert measured finite surgery effect"},{value:"budget_repair_",label:"Insert frozen-reference remainder"}]}/></label>
 <Table headers={["Only receiving-row correction inserted","Median relative residual error","Median absolute margin error (nats)","Both improve /64","Original joint passes /64"]} rows={[
 ["Original209c JVP baseline",fmt(summary.endpoints.baseline.median_relative_l2),fmt(summary.endpoints.baseline.median_absolute_margin_error),"0/64",String(summary.endpoints.baseline.primary_passes)+"/64"],
 ...groups.map((g,i)=>{const s=summary.endpoints[kind+(kind==="budget_repair_"?budgetNames[i]:g)];return [names[i],fmt(s.median_relative_l2),fmt(s.median_absolute_margin_error),s.both_improve_baseline+"/64",s.primary_passes+"/64"];})
 ]}/>
 <p>Finite surgery effect = fullfiniteoutput − lesionedoutput. An actual intervention replaces just the named primitive/group with its False-anchored affine response, while allotheroperations recompute finitely. Its measured effect is then inserted at receiving rows of the originalJVPforecast. This is an oracle sufficiency diagnostic, not a prospective predictor or a unique additive decomposition.</p>
 <Table headers={["Selected case","Final relative residual error","Absolute margin error (nats)","Both improve baseline","Original joint pass"]} rows={[outrow("OriginalJVP","baseline"),outrow("Full finite","finite"),...groups.map((g,i)=>outrow(names[i],kind+(kind==="budget_repair_"?budgetNames[i]:g)))]}/>
 <H2>Necessity: remove each finite nonlinear response</H2>
 <Table headers={["Finite block with affine primitive lesion","Median relative residual error","Median margin error (nats)","Original joint passes /64"]} rows={groups.map((g,i)=>{const s=summary.endpoints["lesion_"+g];return [names[i],fmt(s.median_relative_l2),fmt(s.median_absolute_margin_error),s.primary_passes+"/64"];})}/>
 <Text>Lesions start at the selected native/linear27incomingstate. The unlesioned fullfinite reference may itself miss native output when the incoming state is inaccurate. Lesion effects therefore need not have the same sign in both contexts.</Text>
 <H2>Derivative-free attention routing × value pathway</H2>
 <Table headers={["Selected finite-path intervention","Final relative residual error","Absolute margin error (nats)","Both improve originalJVP","Original joint pass"]} rows={[
 outrow("Finite routing / finite values","finite"),outrow("False routing / finite values","lesion_clamp_routing"),outrow("Finite routing / False values","lesion_clamp_value"),outrow("False routing / False values","lesion_clamp_both")
 ]}/>
 <Text>Selected receiving-position fullblock routing/value interaction: norm {fmt(item.vectors.path_interaction.receivers.toward_native.norm)}; signed projection toward native error {fmt(item.vectors.path_interaction.receivers.toward_native.signed_projection)} residual units. The output projection and downstreamMLP are recomputed finitely in every arm.</Text>
 <H2>Qualification and boundaries</H2>
 <Table headers={["Check","Observed scope"]} rows={[
 ["211finite state/score controls",DATA.controls+"passed; maxcoordinate "+fmt(DATA.maximum_coordinate_control_error)+", maxscore "+fmt(DATA.maximum_score_control_error)],
 ["211local affine derivative rechecks",DATA.local_surgery_derivative_checks+"passed; max "+fmt(DATA.maximum_local_surgery_derivative_error)],
 ["211signed accounting closure","Maxcoordinate "+fmt(DATA.maximum_budget_closure_error)+"; algebraiccheck only"],
 ["210originalwholeblock compatibility","8/128native/linear direction failures; max1.43736e-4 vs1e-4bound"],
 ["210originalMPSadditivity","15/64failures; max1.99795e-4"],
 ["210cactualfinite-node localderivatives","896/896passed publicfirstAD andCPU64finite-difference checks"],
 ["211creference gate–up vs finite surgery vector",DATA.crosscheck.failures+"/128 coordinateagreement failures at1e-4; max "+fmt(DATA.crosscheck.maximum_coordinate_disagreement)+". Separate finite interventions remain directly measured."],
 ["204resetdiagnostic","Preservedqualifiedscope; original424/18432directidentityfailuresunresolved"]]}/>
 <p>Original bounds: coordinate1e-4,score.005; native accuracy relativeL2≤.05,cosine≥.99,nativenorm≥.001,marginerror≤.10nats. Related synthetic templates, fixed smallcheckpoint, retrospective native information. A finite primitive intervention effect does not identify a learned circuit, training origin, or general solution toQuestionB. No broader208claim, publication, push or browser use.</p>
 </main>;
}""".replace("__DATA__", json.dumps(data, separators=(",", ":")))
    MANAGED.write_text(code)
    target = ROOT / "results/block28-primitives-210-211/block28-primitive.canvas.tsx"
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(code)
    print(f"Embedded {len(result['rows'])}actual branch cases: {MANAGED}")


if __name__ == "__main__":
    main()
