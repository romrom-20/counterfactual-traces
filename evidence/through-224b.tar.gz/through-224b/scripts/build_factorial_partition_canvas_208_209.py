"""Presentation only: self-contained offline viewer of frozen actual outcomes."""

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MANAGED = Path(
    "/Users/samanseshadri/.cursor/projects/Users-samanseshadri-conductor-workspaces-training-jev-v1-bucharest/canvases/source-receiver-factorial-208-209.canvas.tsx"
)


def main():
    f = json.loads((ROOT / "docs/analysis/209c-two-block-factorial.json").read_text())
    p = json.loads((ROOT / "docs/analysis/208-source-receiver-partition.json").read_text())
    assert f["qualified"] and p["qualified"]
    data = dict(
        factorial={
            k: v for k, v in f.items() if k not in ("numerical_checks", "derivative_results")
        },
        partition=p,
    )
    code = r"""import {H1,H2,Text,Table,LineChart,Select,useState,useHostTheme} from "cursor/canvas";
const DATA=__DATA__;
const fmt=(x:number|null)=>x===null?"undefined":x.toPrecision(5);
const arms=["source_linear","source_linear_finite_head","source_receiver","full_finite_control","zero_displacement"];
const labels=["Source-linear","Same blocks / finite readout","Source–receiver","Full-finite control","Zero displacement"];
const fArms=["LL","FL","LF","FF"];
const caseLabel=(r:any)=>r.group.block+" · "+r.group.schema+" · order "+r.group.reverse+" · "+r.group.assignment+"/"+r.group.target;
export default function FactorialPartition(){
 const t=useHostTheme();
 const [fresh,setFresh]=useState("0");
 const [old,setOld]=useState("0");
 const [stratum,setStratum]=useState("0");
 const p=DATA.partition,f=DATA.factorial;
 const item=p.rows[Number(fresh)],fact=f.rows[Number(old)],group=p.strata[Number(stratum)];
 return <main style={{padding:24,maxWidth:1160,margin:"auto",background:t.bg.editor,color:t.text.primary}}>
 <H1>Counterfactual displacement: two controlled tests</H1>
 <p style={{fontSize:18}}><strong>{p.whole.source_receiver.primary_pass.passed?"Source–receiver prediction met the registered whole-account criterion.":"Source–receiver prediction did not meet the registered whole-account criterion."}</strong> Qualified source replay is a control; learned circuits and primitive causes remain unidentified.</p>
 <Text>Source: actual208 and209c run artifacts ·15October2026 · pinned Qwen2.5-1.5B-Instruct · MPS Float32/eager · no training</Text>
 <H2>209c: what remains after the exact native reset before block 27?</H2>
 <p>All64historicalcontexts share the verified native full-sequence input before block27. L uses the original False-state Jacobian; F uses the finite block. Every arm uses the same finite final readout. This is retrospective oracle diagnosis.</p>
 <Table headers={["Blocks27/28","Median final residual error (ratio)","Median margin error (nats)","Joint individual passes /64"]} rows={fArms.map(a=>[a,fmt(f.strata[0].arms[a].median_relative_l2),fmt(f.strata[0].arms[a].median_absolute_margin_error),String(f.strata[0].arms[a].passing_individuals)])}/>
 <label>Historical case <Select value={old} onChange={setOld} options={f.rows.map((r,i)=>({value:String(i),label:caseLabel(r)}))}/></label>
 <Table headers={["Final verdict correction vector","Norm (residual units)","Signed projection toward missing LL displacement"]} rows={["block27","block28","interaction"].map(k=>[k,fmt(fact.effects[k].verdict.norm),fmt(fact.effects[k].verdict.signed_projection_toward_LL_missing)])}/>
 <p>c27 = FL − LL; c28 = LF − LL; interaction = FF − FL − LF + LL. These vectors add to FF − LL. Their norms do not add and are not causal fractions. A negative projection does not establish learned compensation.</p>
 <Table headers={["Signed margin factorial quantity","Nats"]} rows={Object.entries(fact.margin_effects).map(([k,v])=>[k,fmt(v)])}/>
 <Text>The margin interaction is split using the synthetic additive endpoint FL+LF−LL: residual-interaction readout plus nonlinear readout combination. Algebraic separation, not two learned mechanisms.</Text>
 <H2>208: fresh False-only source–receiver prediction</H2>
 <p>At every depth, compute the finite response to the Boolean source INPUT row, then add False-linear transport of receiving-row changes. The finite term changes all output rows. Absolute source carry avoids subtract/add reconstruction at that row. No observed True activation supplies a forecast.</p>
 <Text>Global forecast seal: {p.sealed_utc}. First ordinary native True measurement: {p.first_true_utc}. All128new input sequences are absent from {p.historical_unique_sequences}historical sequences checked.</Text>
 <label>Stratum <Select value={stratum} onChange={setStratum} options={p.strata.map((r,i)=>({value:String(i),label:r.field===null?"All64freshcases":r.field+" = "+String(r.value)}))}/></label>
 <Table headers={["Frozen arm","Median relative residual error","Median absolute margin error (nats)","Individual joint passes", "Individual partial progress"]} rows={arms.map((a,i)=>[labels[i],fmt(group.arms[a].median_relative_l2),fmt(group.arms[a].median_absolute_margin_error),group.arms[a].passing_individuals+"/"+group.count,group.arms[a].partial_progress_individuals+"/"+group.count])}/>
 <p>Primary: relative error ≤0.05, cosine ≥0.99, native norm ≥0.001 and margin error ≤0.10nats in ALLfourcells per panel. Partial progress must halve BOTH errors versus source_linear in ALLfourcells. Whole account requires ≥3/4lexicalblocks in EVERYschema/order stratum. Pooled medians do not qualify an account.</p>
 <Table headers={["Schema","Order","Source–receiver primary panels /4","Partial-progress panels /4"]} rows={p.whole.source_receiver.primary_pass.strata.map((r,i)=>[r.schema,String(r.reverse),r.passed+"/4",p.whole.source_receiver.partial_progress_pass.strata[i].passed+"/4"])}/>
 <label>Fresh case <Select value={fresh} onChange={setFresh} options={p.rows.map((r,i)=>({value:String(i),label:caseLabel(r)}))}/></label>
 <LineChart categories={Array.from({length:28},(_,i)=>String(i+1))} height={270} series={[
 {name:"Source-linear verdict error",data:item.arms.source_linear.layers.map(l=>l.verdict.relative_l2),tone:"neutral"},
 {name:"Source–receiver verdict error",data:item.arms.source_receiver.layers.map(l=>l.verdict.relative_l2),tone:"info"},
 {name:"Full-finite control verdict error",data:item.arms.full_finite_control.layers.map(l=>l.verdict.relative_l2),tone:"success"}
 ]} referenceLines={[{value:1,label:"Zero-displacement error"},{value:.05,label:"Original residual bound"}]}/>
 <Text>Horizontal axis: completed blocks1–28. Vertical axis: individual verdict displacement relative L2 error (ratio), no smoothing. Finite-head baseline shares the source-linear residual trajectory.</Text>
 <Table headers={["Arm","Final relative error","Cosine","Signed margin error (nats)","Joint pass"]} rows={arms.map((a,i)=>[labels[i],fmt(item.arms[a].final.verdict.relative_l2),fmt(item.arms[a].final.verdict.cosine),fmt(item.arms[a].signed_margin_error),String(item.arms[a].primary_pass)])}/>
 <H2>Checks, cost, and remaining boundaries</H2>
 <Table headers={["Numerical check","Observed"]} rows={[
 ["209c state/score controls",f.checks+" passed"],["209c first-reverse projections",f.derivative_checks+" passed; max error "+fmt(f.maximum_derivative_projection_error)],
 ["208 state/score controls",p.numerical_controls+" passed; max coordinate "+fmt(p.maximum_coordinate_check_error)],
 ["208 first-reverse projections",p.derivative_projections+" passed; max error "+fmt(p.maximum_reverse_projection_error)],
 ["208 native source replay at all28depths", "Maximum coordinate error "+fmt(p.source_control_maximum)],
 ["Original204direct J(error) identity","424/18432 failed; still unresolved"],
 ["Original196primitive derivative disagreement","Still unresolved"]]}/>
 <p>Alternate whole-model hooks share the forward-AD backend: structural independence, not independent derivative certification. Standard first-reverse projections qualify only tested directions/projections. Full-finite control matching is expected and is not a mechanism discovery.</p>
 <p>Candidate cost per context:28whole finite block evaluations +27receiver JVPs, plus native False trajectory and finite readout. This can cost more than a native True forward. Contexts are dependent synthetic templates from four lexical blocks. Neither experiment identifies a learned circuit, normalization primitive, training origin, grounded-verifier failure or general solution to QuestionB.</p>
 <p>209stopped at0/64and209bat9/64on strict finite-native state controls. Both failed attempts remain immutable.209ccorrected absolute operands without changing thresholds.204is preserved as a qualified retrospective reset diagnostic; invalid replacement-agent conclusions remain invalid. No push or publication.</p>
 </main>;
}""".replace("__DATA__", json.dumps(data, separators=(",", ":")))
    MANAGED.write_text(code)
    target = ROOT / "results/source-receiver-factorial-208-209/source-receiver-factorial.canvas.tsx"
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(code)
    print(
        f"Embedded {len(f['rows'])}factorial cases and {len(p['rows'])}prospective cases in {MANAGED}"
    )


if __name__ == "__main__":
    main()
