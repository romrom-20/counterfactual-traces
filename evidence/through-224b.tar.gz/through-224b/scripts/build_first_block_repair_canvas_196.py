"""Offline viewer of all primitive repairs and their downstream failure or success."""

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def main():
    audit = json.loads((ROOT / "docs/analysis/198-revalidated-196-audit.json").read_text())
    summary = json.loads((ROOT / "docs/analysis/198-first-block-repair-summary.json").read_text())
    assert audit["fingerprint"] == summary["fingerprint"] and summary["qualified"]
    arms = list(summary["all_arms"])
    cases = [
        {
            **{k: v for k, v in c.items() if k not in ("all28_source", "all28_verdict")},
            "all28_verdict": [{"relative_error": v["relative_error"]} for v in c["all28_verdict"]],
        }
        for c in audit["cells"]
    ]
    data = {
        "fingerprint": audit["fingerprint"],
        "arms": arms,
        "summary": summary["all_arms"],
        "cases": cases,
        "accounts": audit["accounts"],
    }
    code = r"""import { H1, H2, Text, Select, Table, BarChart, LineChart, useState, useHostTheme } from "cursor/canvas";
const DATA = __DATA__;
const display = (x:number|null) => x === null ? "undefined" : x.toPrecision(5);
export default function FirstBlockRepair() {
  const theme = useHostTheme();
  const [schema, setSchema] = useState("generic");
  const [reverse, setReverse] = useState("0");
  const [arm, setArm] = useState("input_rms");
  const subset = DATA.cases.filter(c => c.schema === schema && String(c.reverse) === reverse);
  const chosenCases = subset.filter(c => c.arm === arm);
  const [index, setIndex] = useState("0");
  const item = chosenCases[Number(index)] || chosenCases[0];
  const baseline = subset.find(c => c.arm === "linear" && c.block === item.block && c.assignment === item.assignment && c.target === item.target)!;
  const rows = DATA.arms.map(a => [a.startsWith("exact_") ? a+" [control]" : a,
    DATA.accounts.source_matching[a].compatible_panels+"/16",
    DATA.accounts.individual_matching[a].compatible_panels+"/16",
    DATA.accounts.residual_matching[a].compatible_panels+"/16",
    DATA.accounts.prospective_progress[a].compatible_panels+"/16",
    DATA.accounts.prospective_progress[a].whole_passed ? "PASS" : "FAIL"]);
  return <main style={{padding:24, color:theme.text.primary, background:theme.bg.editor, maxWidth:1180, margin:"auto"}}>
    <H1>Can one first-block operation repair counterfactual prediction?</H1>
    <Text>Experiment196 forecasts · separate198 mixed-check revalidation · all64pairs and ten arms · 14October2026</Text>
    <p style={{color:theme.text.secondary}}>Original196 numerical qualification failed48/80 local primitive coordinate checks (maximum0.0002284, bound0.0001) and remains failed. Separate198 public first-block hook reconstruction passes the same bound (maximum0.00000596); retained reverse tail scalar checks/native replays pass. Local198 reconstruction shares the forward-AD backend: code-path independence only. The original primitive derivative disagreement remains unresolved.</p>
    <p style={{fontSize:16}}>Seven finite first-block operation repairs are followed by derivatives evaluated only at the false state. Exact block and exact source are local finite-computation controls. Their success would not itself identify a mechanism.</p>
    <H2>Registered panel accounts</H2>
    <Table headers={["Arm", "Source matching", "Individual preference", "Final residual", "Comparative progress", "Progress whole account"]} rows={rows}/>
    <Text>Each panel has four dependent cells. Whole account requires at least3/4blocks in every schema/order; preference error ≤0.10nats, vector relativeL2 ≤0.05 and cosine ≥0.99. Comparative progress halves source error and either final error; it does not replace native matching.</Text>
    <H2>Displacement prediction error across all64pairs</H2>
    <BarChart categories={DATA.arms} horizontal height={370} series={[
      {name:"First-block Boolean source: median relativeL2", data:DATA.arms.map(a=>DATA.summary[a].source_relative_error.median), tone:"neutral"},
      {name:"Block28 verdict: median relativeL2", data:DATA.arms.map(a=>DATA.summary[a].final_relative_error.median), tone:"info"}
    ]}/>
    <Text>Horizontal axis: relative displacement error (ratio); vertical axis: first-block repair/control. Medians of64dependent pairs, no uncertainty estimate. Source:196-independent-audit.json; denominator is native displacement norm.</Text>
    <H2>Follow a single prospective forecast through28blocks</H2>
    <div style={{display:"flex",gap:12,flexWrap:"wrap",margin:"12px 0"}}>
      <label>Schema <Select value={schema} onChange={setSchema} options={[{value:"generic",label:"Generic"},{value:"descriptive",label:"Descriptive"}]}/></label>
      <label>Order <Select value={reverse} onChange={setReverse} options={[{value:"0",label:"Original"},{value:"1",label:"Reversed"}]}/></label>
      <label>Repair <Select value={arm} onChange={setArm} options={DATA.arms.map(a=>({value:a,label:a}))}/></label>
      <label>Cell <Select value={index} onChange={setIndex} options={chosenCases.map((c,i)=>({value:String(i),label:c.block+" · assignment"+c.assignment+" · target"+c.target}))}/></label>
    </div>
    <LineChart categories={Array.from({length:28},(_,i)=>String(i+1))} height={300} series={[
      {name:"Linear baseline · verdict row",data:baseline.all28_verdict.map(v=>v.relative_error!),tone:"neutral"},
      {name:arm+" · verdict row",data:item.all28_verdict.map(v=>v.relative_error!),tone:"info"}
    ]} referenceLines={[{value:0.05,label:"Registered vector error bound"}]}/>
    <Text>Horizontal axis: transformer block (1–28). Vertical axis: verdict-row relative displacement error (ratio). Cosine and native norm are separate requirements. Source:196 saved false/true rows and sealed derivative forecasts;14October2026.</Text>
    <Table headers={["Quantity","Linear baseline","Selected repair"]} rows={[
      ["Boolean source relative error",display(baseline.source.relative_error),display(item.source.relative_error)],
      ["Final residual relative error",display(baseline.final.relative_error),display(item.final.relative_error)],
      ["Final cosine",display(baseline.final.cosine),display(item.final.cosine)],
      ["Predicted preference shift (nats)",display(baseline.predicted_delta_margin),display(item.predicted_delta_margin)],
      ["Observed preference shift (nats)",display(baseline.actual_delta_margin),display(item.actual_delta_margin)],
      ["Preference error (nats)",display(baseline.margin_error),display(item.margin_error)]
    ]}/>
    <p style={{color:theme.text.secondary}}>195 failed its local derivative check before any nativeTrue observation and remains preserved.197 raw dual execution hit MPS Linear support failure;198 uses the supported functional wrapper.196 uses primitive automatic differentiation, with unchanged bounds.198 validates/reanalyzes unchanged196 forecasts, not fresh held-out predictions. Single small Qwen checkpoint, dependent synthetic templates, supplied first Boolean; earlier grounding controls failed. No semantic feature, universal mechanism, reliable verifier failure, or novelty priority established. All data embedded; no network or browser required.</p>
    <Text>Fingerprint: {DATA.fingerprint}</Text>
  </main>;
}
""".replace("__DATA__", json.dumps(data, separators=(",", ":")))
    (ROOT / ".context/196-first-block-canvas-code.txt").write_text(code)
    (ROOT / ".context/196-first-block-canvas-data.json").write_text(json.dumps(data))
    print(f"196 viewer prepared: {len(data['cases'])}cases, {len(code)}characters")


if __name__ == "__main__":
    main()
