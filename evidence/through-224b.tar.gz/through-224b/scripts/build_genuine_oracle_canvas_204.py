"""Presentation only: embed frozen summaries in a local offline evidence viewer."""

import argparse
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MANAGED = Path(
    "/Users/samanseshadri/.cursor/projects/Users-samanseshadri-conductor-workspaces-training-jev-v1-bucharest/canvases/genuine-oracle-reset-204.canvas.tsx"
)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--scope", choices=["sample", "full"], required=True)
    scope = parser.parse_args().scope
    data = json.loads((ROOT / f"docs/analysis/204-{scope}-oracle-summary.json").read_text())
    data["measured_separation"] = json.loads(
        (ROOT / f"docs/analysis/205-{scope}-measured-reset-separation.json").read_text()
    )
    code = r"""import { H1,H2,Text,Table,LineChart,Select,useState,useHostTheme } from "cursor/canvas";
const DATA=__DATA__;
const fmt=(x:number|null)=>x===null?"undefined":x.toPrecision(5);
export default function OracleReset(){
 const theme=useHostTheme();
 const [arm,setArm]=useState("union_blocks");
 const [reset,setReset]=useState("16");
 const [cell,setCell]=useState("0");
 const filtered=DATA.cases.filter(c=>c.arm===arm&&c.next_block===Number(reset));
 const item=filtered[Number(cell)]||filtered[0];
 const ordinary=DATA.cases.find(c=>c.arm===arm&&c.key===item.key&&c.next_block===null)!;
 const outcome=DATA.outcomes.find(c=>c.arm===arm&&c.key===item.key&&c.next_block===Number(reset))!;
 const separation=DATA.measured_separation.rows.find(c=>c.arm===arm&&c.key===item.key&&c.next_block===Number(reset))!.components.verdict;
 const rows=DATA.reset_summary.filter(r=>r.arm===arm);
 const source=DATA.original201_layerwise.find(r=>r.arm==="source_linear")!;
 return <main style={{padding:24,maxWidth:1140,margin:"auto",background:theme.bg.editor,color:theme.text.primary}}>
  <H1>Genuine oracle-state resets</H1>
  <p style={{fontSize:18}}>The remaining transformer blocks actually execute after one full-sequence native-state replacement. <strong>Reset checks passed; direct derivative-additivity checks remain unqualified.</strong></p>
  <Text>Source: experiment204 {DATA.scope} scope ·15October2026 · pinned Qwen2.5-1.5B ·MPSfloat32/eager · all results retrospective</Text>
  <H2>Correction to the replacement-agent analysis</H2>
  <p>Absolute False/True states were mistaken for forecast displacements. The original first block was accurate: full-state coordinate discrepancy 1.19×10⁻⁷. The earlier norm-subtraction “reset” did not run a model and provides no causal evidence. Its Stage1 projection did not evaluate a Jacobian. All historical files remain preserved.</p>
  <LineChart categories={Array.from({length:28},(_,i)=>String(i+1))} height={230} series={[
   {name:"Boolean-source median error",data:source.source_median_q,tone:"neutral"},
   {name:"Verdict-position median error",data:source.verdict_median_q,tone:"info"}
  ]}/>
  <Text>Horizontal axis: completed blocks1–28. Vertical axis: relative displacement error (ratio). Corrected source_linear errors, medians over all64 original201pairs. Same native and predicted vectors at each block/position. Source:202read-only metric audit.</Text>
  <H2>Final response after genuine resets</H2>
  <label>Arm <Select value={arm} onChange={setArm} options={[{value:"source_linear",label:"Source finite / False-linear tail"},{value:"union_blocks",label:"Source +16/18/21finite"}]}/></label>
  <Table headers={["Reset BEFORE block k","Completed blocks","Median final relative error","Median cosine","Median absolute margin error (nats)","Residual improves / cases"]} rows={rows.map(r=>[
   String(r.next_block),String(r.completed_blocks),fmt(r.median_relative_error),fmt(r.median_cosine),fmt(r.median_absolute_margin_error),r.residual_improved_count+"/"+r.count
  ])}/>
  <p>At k1 the reset supplies the known embedding change and reproduces the original surrogate. All other resets supply native full-sequence states once. Later transitions retain the same arm's False Jacobians and finite selected blocks; no later native state is inserted. These are oracle interventions, not false-only forecasting successes.</p>
  <H2>Inspect an actual reset trajectory</H2>
  <div style={{display:"flex",gap:12,flexWrap:"wrap",margin:"12px 0"}}>
   <label>Reset before <Select value={reset} onChange={setReset} options={[1,3,8,11,16,21,27].map(k=>({value:String(k),label:"Public block "+k}))}/></label>
   <label>Case <Select value={cell} onChange={setCell} options={filtered.map((c,i)=>({value:String(i),label:c.block+" · "+c.schema+" · order"+c.reverse+" · "+c.assignment+"/"+c.target}))}/></label>
  </div>
  <LineChart categories={Array.from({length:item.verdict_relative_errors.length},(_,i)=>String(item.curve_start_completed_blocks+i))} height={260} series={[
   {name:"Ordinary forecast at the same depths",data:ordinary.verdict_relative_errors.slice(item.curve_start_completed_blocks-1),tone:"neutral"},
   {name:"After ONE oracle reset",data:item.verdict_relative_errors,tone:"info"}
  ]} referenceLines={[{value:1,label:"Zero displacement"},{value:0.05,label:"Original vector-error bound"}]}/>
  <Text>Horizontal axis: completed public blocks. Vertical axis: verdict-position relative displacement error (ratio). Individual observed native displacement versus computed surrogate; embedding boundary with zero native verdict displacement is omitted. No averaging or smoothing.</Text>
  <Table headers={["Quantity","Ordinary same case","Genuine reset"]} rows={[
   ["Final relative error",fmt(outcome.ordinary_final.verdict.relative_error),fmt(outcome.final.verdict.relative_error)],
   ["Final cosine",fmt(outcome.ordinary_final.verdict.cosine),fmt(outcome.final.verdict.cosine)],
   ["Margin error, predicted minus observed (nats)",fmt(outcome.ordinary_margin_error),fmt(outcome.reset_margin_error)]
  ]}/>
  <H2>Separate measured vectors, not subtracted error norms</H2>
  <p>For this case, Eordinary = Ereset + (reset prediction − ordinary prediction). Both predictions came from actual downstream executions. Signed projections onto Eordinary add to its norm; the separate component norms do not.</p>
  <Table headers={["Final verdict vector quantity","Hidden units"]} rows={[
   ["Ordinary error norm",fmt(separation.original_error_norm)],
   ["Remaining reset error norm",fmt(separation.remaining_reset_error_norm)],
   ["Change in prediction caused by reset: norm",fmt(separation.reset_effect_norm)],
   ["Remaining error: signed projection onto ordinary error",fmt(separation.signed_remaining_error_projection)],
   ["Reset effect: signed projection onto ordinary error",fmt(separation.signed_reset_effect_projection)]
  ]}/>
  <p>In source_linear the tail uses the tested False-linear transport. For union_blocks this measured reset effect also includes changes in finite-block computations at different predicted inputs. This is an intervention account within the surrogate, not a unique learned mechanism.</p>
  <H2>Qualification is separated from interpretation</H2>
  <Table headers={["Control","Checks","Failures","Maximum coordinate error","Maximum score error"]} rows={Object.entries(DATA.controls).map(([kind,r]:[string,any])=>[
   kind,String(r.count),String(r.failed),fmt(r.maximum_coordinate_error),fmt(r.maximum_score_error)
  ])}/>
  <p style={{color:theme.text.secondary}}>The standalone J(error) coordinate identity failed {DATA.direct_identity_failures}/{DATA.direct_identity_checks} checks at the unchanged10⁻⁴ bound. A two-evaluated-JVP algebraic budget closes, but closure is not independent derivative validation. Original196primitive reverse-over-reverse disagreement remains unresolved. Whole-model dual hooks provide structural checks using the same forward-AD backend. One checkpoint, dependent synthetic templates and failed earlier grounding controls limit generalization. No primitive cause, prospective success, solvedQuestionB, push or publication is claimed.</p>
 </main>;
}
""".replace("__DATA__", json.dumps(data, separators=(",", ":"), allow_nan=False))
    MANAGED.write_text(code)
    repo = ROOT / "results/genuine-oracle-202-204"
    repo.mkdir(parents=True, exist_ok=True)
    (repo / "genuine-oracle-reset.canvas.tsx").write_text(code)
    print(f"Canvas written: {len(data['cases'])} real trajectories; {len(code)} characters")


if __name__ == "__main__":
    main()
