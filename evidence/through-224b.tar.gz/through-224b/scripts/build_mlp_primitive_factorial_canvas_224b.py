"""Offline actual-node factorial viewer with every gate and signed case contrast."""
import json
from pathlib import Path
R=Path(__file__).resolve().parents[1]
DEST=Path('/Users/samanseshadri/.cursor/projects/Users-samanseshadri-conductor-workspaces-training-jev-v1-bucharest/canvases/mlp-primitive-factorial-224b.canvas.tsx')
def main():
    x=json.loads((R/'docs/analysis/224b-mlp-primitive-factorial.json').read_text());q=json.loads((R/'docs/analysis/224b-endpoint-qualification.json').read_text());assert x['qualified'] and q['qualified']
    p=json.loads((R/'docs/analysis/224b-silu-product-accounting.json').read_text())
    data=dict(result=x,qualification=q,product=p)
    template='''import {H1,H2,Text,Table,Select,useState,useHostTheme} from "cursor/canvas";
const D:any=__DATA__;const f=(v:number)=>Number.isFinite(v)?v.toPrecision(5):String(v);const modes=["LLL","LLF","LFL","LFF","FLL","FLF","FFL","FFF"];
const label=(r:any)=>r.kind==="random"?"Random "+r.purpose+" for "+r.target:r.mode;
export default function PrimitiveFactorial(){const t=useHostTheme();const x=D.result;const [key,setKey]=useState(x.rows[0].context);const [site,setSite]=useState("22");const [mode,setMode]=useState("FFL");
const rows=x.rows.filter((r:any)=>r.context===key&&r.site===Number(site));const a=rows.find((r:any)=>r.kind!=="random"&&r.mode===mode);const precision=x.composed_vs_composite.find((r:any)=>r.context===key&&r.site===Number(site));
const gates=x.gates.filter((g:any)=>g.site===Number(site));const edge=x.edges.filter((r:any)=>r.context===key&&r.site===Number(site));const interactions=x.interactions.filter((r:any)=>r.context===key&&r.site===Number(site));
return <main style={{padding:24,maxWidth:1280,margin:"auto",background:t.bg.editor,color:t.text.primary}}>
<H1>Which native MLP nonlinearities change the Boolean response?</H1>
<p style={{fontSize:18}}><strong>Cross RMSNorm, SiLU and gate–up multiplication at one native receiving site; continue the actual finite network.</strong></p>
<Text>Experiment224b · Qwen2.5-1.5B-Instruct · 32 old larch/marzipan contexts · retrospective public-node interventions · no fitting or selection on these outcomes</Text>
<p>223 showed that local nonlinear remainders matter. This factorial asks which specified primitives must remain finite to preserve the native residual and verdict margin. Native input is supplied as an oracle. A conditional result here is not a False-only forecast or a learned circuit.</p>
<p><strong>No partial subset preserves both endpoints in any context.</strong> At22, all three individual deletions pass the frozen material/specificity gate. At23, SiLU does; normalization and product fail the cross-stratum gate. A separate posthoc finding is sharper: the product background reverses the SiLU margin effect in64/64 site23 context/normalization pairs, versus0/64 at22.</p>
<section style={{background:t.fill.tertiary,padding:16,margin:"18px 0"}}>
<strong>Failed224 remains failed.</strong> Its composed all-linear endpoint differed from223’s composite affine intervention by1.6785e-4 in one final coordinate, exceeding the frozen1e-4 bound. No partial factorial ran under224. Separately registered224b tests the actual node graph against its own baseline, preserves all signed implementation contrasts, and adds a100× contrast guard for deletions. It does not recertify the old coordinate bridge or whole-block Jacobian.
</section>
<H2>Frozen gates at the selected site</H2>
<Select value={site} onChange={setSite} options={[{value:"22",label:"MLP22"},{value:"23",label:"MLP23"}]}/>
<Table headers={["Test","N/S/P setting","Eligible /32","Beats matched random /32","Precision guard /32","Combined /32","Whole gate"]} rows={gates.map((g:any)=>[g.purpose==="restore"?"Retain subset":"Remove one primitive",g.mode,String(g.totals.eligible),String(g.totals.beats_random),g.purpose==="delete"?String(g.totals.precision_clear):"Not a deletion",String(g.totals.combined),String(g.passed)])}/>
<p>F = finite; L = False-affine. N/S/P = input RMSNorm / SiLU / gate–up product. Retention must match native (relative verdict deviation≤.05, cosine≥.99, absolute margin change≤.10nats) and beat its restoration random on both errors. Deletion must change both endpoints materially, exceed its deletion random, and clear100× the measured composed/composite contrast. A whole gate requires≥24/32 and≥6/8 in every schema/order stratum.</p>
<Text>Minimal passing partial subsets: {x.minimal_subsets.map((r:any)=>"MLP"+r.site+": "+(r.modes.length?r.modes.join(", "):"none")).join("; ")}. Failure to find a subset does not prove universal necessity.</Text>
<H2>Inspect a receiving-state intervention</H2>
<Select value={key} onChange={setKey} options={[...new Set<string>(x.rows.map((r:any)=>r.context))].map((c:string)=>{const g=x.rows.find((r:any)=>r.context===c).group;return {value:c,label:g.block+" · "+g.schema+" · order "+g.reverse+" · assignment/target "+g.assignment+"/"+g.target};})}/>
<div style={{margin:"16px 0"}}><Select value={mode} onChange={setMode} options={modes.map(m=>({value:m,label:m+" · "+["N","S","P"].filter((_,i)=>m[i]==="F").join("+")+" finite"}))}/></div>
<svg viewBox="0 0 1100 160" role="img" aria-label="Actual RMSNorm, linear projections, SiLU and product intervention graph" style={{width:"100%",maxHeight:170}}>
<path d="M490 25 V15 H900 V25" fill="none" stroke={t.stroke.secondary}/><text x="690" y="11" textAnchor="middle" fill={t.text.secondary} fontSize="10">Up pathway bypasses SiLU</text>
{[{x:10,w:180,text:"Native mid-residual",sub:"fixed input",flag:"F"},{x:220,w:150,text:"RMSNorm",sub:mode[0]==="F"?"finite":"False-affine",flag:mode[0]},{x:400,w:180,text:"Gate / up projections",sub:"actual public modules",flag:"F"},{x:610,w:170,text:"SiLU gate",sub:mode[1]==="F"?"finite":"False-affine",flag:mode[1]},{x:810,w:180,text:"Gate × up product",sub:mode[2]==="F"?"finite":"False-affine",flag:mode[2]}].map((b:any,i:number)=><g key={b.x}><rect x={b.x} y="25" width={b.w} height="70" fill={b.flag==="F"?t.fill.tertiary:t.fill.secondary} stroke={t.stroke.secondary}/><text x={b.x+b.w/2} y="54" textAnchor="middle" fill={t.text.primary} fontSize="13">{b.text}</text><text x={b.x+b.w/2} y="77" textAnchor="middle" fill={t.text.secondary} fontSize="12">{b.sub}</text>{i<4?<text x={b.x+b.w+10} y="66" fill={t.text.secondary}>→</text>:null}</g>)}
<text x="530" y="128" textAnchor="middle" fill={t.text.secondary}>Actual down projection → add write → every remaining finite public block → finite final normalization/readout</text>
<text x="530" y="149" textAnchor="middle" fill={t.text.secondary}>Only receiving rows are edited. Later primitive parents are the actual outputs under earlier switches.</text>
</svg>
<div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:24,margin:"20px 0"}}>
<section><H2>Actual natural response</H2><p>Verdict relative deviation: <strong>{f(a.verdict_relative_deviation)}</strong><br/>All receiving rows: {f(a.receiver_relative_deviation)}<br/>Verdict displacement cosine: {f(a.cosine)}</p><p>Natural true−false margin: {f(a.natural_margin)}nats<br/>Native margin: {f(a.native_margin)}nats<br/>Signed intervention change: <strong>{f(a.margin_change)}nats</strong></p><Text>These are deviations from the native response, normalized by nativeTrue−False displacement; they are not predictive accuracy claims.</Text></section>
<section><H2>Composed/composite arithmetic contrast</H2><p>Largest local write-coordinate difference: {f(precision.maximum_local_coordinate)}<br/>Largest final-coordinate difference: {f(precision.maximum_final_coordinate)}<br/>Verdict relative difference: {f(precision.verdict_relative_deviation)}<br/>Absolute margin difference: {f(precision.absolute_margin_discrepancy)}nats</p><p>Signed write-accounting closure: {f(precision.rounding_closure)}; bound1e-9</p><Text>This measured contrast bounds a particular implementation comparison, not all numerical error. It does not turn failed224 into a successful coordinate replay.</Text></section>
</div>
<Table headers={["Actual arm","Verdict relative deviation","All receivers relative deviation","Signed natural margin change (nats)","Response preserved"]} rows={rows.map((r:any)=>[label(r),f(r.verdict_relative_deviation),f(r.receiver_relative_deviation),f(r.margin_change),String(r.response_preserved)])}/>
<H2>Signed local and downstream contrasts for this case</H2>
<Table headers={["Primitive toggle","Other switches fixed","Local write norm","Signed projection on223 remainder","Final verdict effect norm","Signed natural margin effect (nats)"]} rows={edge.map((r:any)=>[r.factor,r.low+" → "+r.high,f(r.write_norm),f(r.projection_223_remainder),f(r.verdict_effect_norm),f(r.margin_effect)])}/>
<Table headers={["Inclusion–exclusion component","Order","Local vector norm","Signed projection coefficient","Signed finite-margin contrast (nats)"]} rows={interactions.map((r:any)=>[r.component,String(r.order),f(r.write_norm),f(r.projection_223_remainder),f(r.margin_contrast)])}/>
<p>Exact component vectors sum to FFF−LLL. Projection coefficient is component·R223 / (R223·R223); norms and medians are not additive causal fractions. Final-margin interactions include the responding tail and head. Neither an interaction nor a sign regime identifies a learned feature.</p>
<H2>Posthoc: hold SiLU inputs fixed, switch the product background</H2>
<Table headers={["Normalization","SiLU margin effect with affine product (nats)","With finite product (nats)","Sign reverses","Actual local interaction norm","Raw ideal coordinate error","Rounding-ledger closure"]} rows={D.product.rows.filter((r:any)=>r.context===key&&r.site===Number(site)).map((r:any)=>[r.norm==="F"?"Finite":"False-affine",f(r.linear_product_silu_margin_effect),f(r.finite_product_silu_margin_effect),String(r.sign_reversal),f(r.actual_write_norm),f(r.raw_ideal_coordinate_error),f(r.rounding_closure)])}/>
<p>Gate/up parents are exactly equal across all four S/P settings at a fixed N setting. If C is finite-minus-affine SiLU output, the ideal difference between its finite-product and affine-product write effects is D(C×Δup). Actual multiplication, affine casts and down-projection rounding account for the measured vector contrast.</p>
<Text>All128 signed vector comparisons are saved. {D.product.raw_ideal_failures}/128 raw ideal comparisons fail1e-4 (maximum {f(D.product.maximum_raw_ideal_coordinate_error)}); those failures remain. The separately measured rounding ledger closes within {f(D.product.maximum_rounding_closure)} at1e-9. This is a known bilinear identity, not a new learned mechanism.</Text>
<p>The final sign reversal is still unresolved: switching the product changes both this curvature increment and the baseline presented to the finite tail. Separating those two changes requires a further direct intervention. The local identity alone cannot establish which causes the behavioral reversal.</p>
<H2>Every schema/order stratum at this site</H2>
<Table headers={["Purpose / setting","Schema / order","Eligible /8","Beats random /8","Combined /8"]} rows={gates.flatMap((g:any)=>g.strata.map((s:any)=>[g.purpose+" / "+g.mode,s.schema+" / "+s.order,String(s.counts.eligible),String(s.counts.beats_random),String(s.counts.combined)]))}/>
<H2>Numerical qualification and executed work</H2>
<Table headers={["Check","Executed maximum or count"]} rows={[
["Endpoint primitive directions",String(D.qualification.primitive_checks)],
["Hybrid/control primitive directions",String(x.primitive_checks)],
["Endpoint AD / promoted CPU64 FD max",f(D.qualification.maxima.ad)+" / "+f(D.qualification.maxima.fd)+"; bound1e-4"],
["Hybrid/control AD / promoted CPU64 FD max",f(x.maxima.ad)+" / "+f(x.maxima.fd)+"; bound1e-4"],
["Hybrid/control independent finite-head max",f(x.maxima.head)+"; bound.005"],
["Signed paired down-projection arithmetic closure",f(x.maximum_paired_down_rounding_closure)+"; bound1e-9"],
["Ordinary full models",String(D.qualification.counts.ordinary_models)],
["Finite suffix continuations",String(D.qualification.counts.suffix_continuations+x.counts.suffix_continuations)],
["Remaining public block evaluations",String(D.qualification.counts.remaining_public_blocks+x.counts.remaining_public_blocks)],
["Original whole-block Jacobian qualified",String(x.original_wholeblock_jacobian_qualified)],
["Prospective / full QuestionB solved",String(x.prospective)+" / "+String(x.full_question_B_solved)]
]}/>
<p>CPU64 differences promote arithmetic and do not replay the MPS forward map. The explicit primitive directions are qualified separately. The old original derivative disagreement is unresolved. This is one small checkpoint, dependent synthetic templates, retrospective native inputs and selected sites. No browser, training, end-to-end correction sweep or publication.</p>
</main>;}'''
    content=template.replace('__DATA__',json.dumps(data,separators=(',',':')));DEST.write_text(content);(R/'.context/mlp-primitive-factorial-224b.canvas.tsx').write_text(content);print(DEST)
if __name__=='__main__':main()
