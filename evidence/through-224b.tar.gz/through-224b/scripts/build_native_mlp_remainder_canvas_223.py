"""Offline audited local-write decomposition and primary natural-response viewer."""

import hashlib,json
from pathlib import Path
import numpy as np
R=Path(__file__).resolve().parents[1]
DEST=Path('/Users/samanseshadri/.cursor/projects/Users-samanseshadri-conductor-workspaces-training-jev-v1-bucharest/canvases/native-mlp-remainder-223.canvas.tsx')
def main():
    x=json.loads((R/'docs/analysis/223-native-mlp-remainder.json').read_text());q=json.loads((R/'docs/analysis/223-local-mlp-qualification.json').read_text());assert x['qualified'] and q['qualified'];geometry=[]
    for key in sorted({r['context'] for r in x['rows']}):
        p=R/'runs/native-mlp-remainder-223/interventions'/(key+'.npz');rec=json.loads(p.with_suffix('.json').read_text());assert hashlib.sha256(p.read_bytes()).hexdigest()==rec['arrays_sha256']
        with np.load(p) as z:
            for arm in ('FF','LF','FL','LL','rescue','rand22','rand23','randboth'):
                for site in (22,23):
                    prefix=f'{arm}_{site}_';rr=z[prefix+'remainder'];jt=z[prefix+'tangent'];geometry.append(dict(context=key,arm=arm,site=site,
                        remainder_norm=float(np.linalg.norm(rr)),linear_norm=float(np.linalg.norm(jt)),incoming_delta_norm=float(np.linalg.norm(z[prefix+'direction'])),
                        applied_write_edit_norm=float(np.linalg.norm(z[prefix+'after']-z[prefix+'before'])),remainder_linear_dot=float(np.sum(rr*jt))))
    data=dict(result=x,qualification=q,geometry=geometry)
    template='''import {H1,H2,Text,Table,Select,useState,useHostTheme} from "cursor/canvas";
const D:any=__DATA__;const f=(v:number)=>Number.isFinite(v)?v.toPrecision(5):String(v);
const names:any={FF:"Native22 / Native23",LF:"Remove remainder22",FL:"Remove remainder23",LL:"Remove both remainders",rescue:"Remove + reinsert both",rand22:"Matched random22",rand23:"Matched random23",randboth:"Matched random both"};
export default function MLPRemainder(){const t=useHostTheme();const x=D.result;const [key,setKey]=useState(x.rows[0].context);const [arm,setArm]=useState("LL");const [site,setSite]=useState("23");
const rows=x.rows.filter((r:any)=>r.context===key);const a=rows.find((r:any)=>r.label===arm);const geo=D.geometry.find((r:any)=>r.context===key&&r.arm===arm&&r.site===Number(site));
const removed=(site==="22"&&(arm==="LF"||arm==="LL"))||(site==="23"&&(arm==="FL"||arm==="LL"));
return <main style={{padding:24,maxWidth:1280,margin:"auto",background:t.bg.editor,color:t.text.primary}}>
<H1>Do MLP22/23 need their nonlinear remainders?</H1>
<p style={{fontSize:18}}><strong>Keep the False write and its linear response. Remove only the finite-minus-first-order remainder.</strong></p>
<Text>Experiment223 · 32 old larch/marzipan contexts · Qwen2.5-1.5B-Instruct · native finite downstream computation · retrospective necessity test</Text>
<p>222 found influential full writes. That did not establish that their nonlinear parts generate the response. Here the primary measurements are the actual natural verdict residual and margin. The frozen32-neuron product diagnostic is secondary. No native input is presented as a prospective forecast.</p>
<H2>Registered primary action rule</H2>
<Table headers={["Removed remainder","Primary response preserved /32","Both endpoints materially changed /32","Both larger than random /32","Combined /32","Whole gate"]} rows={x.gates.map((g:any)=>[names[g.arm],String(g.totals.preserved),String(g.totals.material),String(g.totals.beats_random),String(g.totals.combined),String(g.passed)])}/>
<p>Material: verdict relativeL2 deviation&gt;.05 and absolute margin change&gt;.10nats. Both deviations must exceed the matched random control. Whole gate requires24/32 and6/8 in every schema/order stratum. A failed gate is retained; it is not a proof of global linear sufficiency.</p>
<H2>Inspect an actual native-tail intervention</H2>
<Select value={key} onChange={setKey} options={[...new Set<string>(x.rows.map((r:any)=>r.context))].map((c:string)=>{const g=x.rows.find((r:any)=>r.context===c).group;return {value:c,label:g.block+" · "+g.schema+" · order "+g.reverse+" · assignment/target "+g.assignment+"/"+g.target};})}/>
<div style={{display:"flex",gap:20,flexWrap:"wrap",margin:"16px 0"}}>
<label>Actual computation <Select value={arm} onChange={setArm} options={rows.map((r:any)=>({value:r.label,label:names[r.label]}))}/></label>
<label>Local site <Select value={site} onChange={setSite} options={[{value:"22",label:"MLP22"},{value:"23",label:"MLP23"}]}/></label></div>
<svg viewBox="0 0 1000 165" role="img" aria-label="False write plus linear response plus finite nonlinear remainder" style={{width:"100%",maxHeight:165}}>
<rect x="15" y="30" width="240" height="70" fill={t.fill.tertiary} stroke={t.stroke.secondary}/><text x="135" y="60" textAnchor="middle" fill={t.text.primary}>Actual False write</text><text x="135" y="82" textAnchor="middle" fill={t.text.secondary}>fixed anchor</text>
<text x="282" y="74" fontSize="25" fill={t.text.secondary}>+</text>
<rect x="315" y="30" width="270" height="70" fill={t.fill.tertiary} stroke={t.stroke.secondary}/><text x="450" y="60" textAnchor="middle" fill={t.text.primary}>Qualified JFalse × current Δs</text><text x="450" y="82" textAnchor="middle" fill={t.text.secondary}>linear response retained</text>
<text x="610" y="74" fontSize="25" fill={t.text.secondary}>+</text>
<rect x="650" y="30" width="325" height="70" fill={removed?t.fill.secondary:t.fill.tertiary} stroke={t.stroke.secondary}/><text x="812" y="60" textAnchor="middle" fill={t.text.primary}>Finite-minus-first-order remainder</text><text x="812" y="82" textAnchor="middle" fill={t.text.secondary}>{removed?"REMOVED at this site":"retained, reinserted or random-control arm"}</text>
<text x="500" y="135" textAnchor="middle" fill={t.text.secondary}>Only receiving rows change. In the joint arm, MLP23 uses the actual input after the MLP22 intervention.</text>
</svg>
<div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:24,margin:"20px 0"}}>
<section><H2>Primary natural response</H2><p>Verdict residual relative deviation: <strong>{f(a.verdict_relative_deviation)}</strong><br/>All receivers relative deviation: {f(a.receiver_relative_deviation)}<br/>Verdict displacement cosine: {f(a.cosine)}</p><p>Actual natural margin: {f(a.natural_margin)}nats<br/>Native margin: {f(a.native_margin)}nats<br/>Signed change: <strong>{f(a.margin_change)}nats</strong></p></section>
<section><H2>Local write operands</H2><p>Current incoming displacement norm: {f(geo.incoming_delta_norm)}<br/>Linear response norm: {f(geo.linear_norm)}<br/>Finite remainder norm: {f(geo.remainder_norm)}<br/>Applied receiving-write edit norm: {f(geo.applied_write_edit_norm)}</p><p>Signed remainder · linear-response dot product: {f(geo.remainder_linear_dot)}</p><Text>These are Euclidean norms and a signed dot product in local write coordinates. Norms do not add and are not causal percentages.</Text></section>
</div>
<Table headers={["Actual arm","Verdict relative deviation","All receivers relative deviation","Natural margin change (nats)","SECONDARY finite32 effect (nats)","Primary response preserved"]} rows={rows.map((r:any)=>[names[r.label],f(r.verdict_relative_deviation),f(r.receiver_relative_deviation),f(r.margin_change),f(r.product_effect),String(r.response_preserved)])}/>
<Text>Response-preserving bounds: verdict relativeL2≤.05, cosine≥.99 and absolute margin change≤.10nats. Deviations are from the native response, normalized by nativeTrue−False displacement; they are not predictor accuracy claims.</Text>
<H2>All schema/order strata</H2>
<Table headers={["Arm","Schema / order","Preserved /8","Material both /8","Beats random /8","Combined /8"]} rows={x.gates.flatMap((g:any)=>g.strata.map((s:any)=>[names[g.arm],s.schema+" / "+s.order,String(s.counts.preserved),String(s.counts.material),String(s.counts.beats_random),String(s.counts.combined)]))}/>
<H2>Numerical qualification and limits</H2>
<Table headers={["Executed comparison","Maximum or count"]} rows={[
["Pre-intervention local derivative directions",String(D.qualification.local_derivative_directions)],
["Pre-intervention AD / CPU64 FD discrepancy",f(D.qualification.maxima.ad)+" / "+f(D.qualification.maxima.fd)+"; bound1e-4"],
["Actual intervention-direction AD / CPU64 FD discrepancy",f(x.local_maxima.ad)+" / "+f(x.local_maxima.fd)+"; bound1e-4"],
["Intervention-direction derivative checks",String(x.local_derivative_directions)],
["Public controls",String(x.controls)],
["StageI ordinary models / finite heads",x.counts.ordinary_models+" / "+x.counts.finite_heads],
["Independent CPU64 finite-head discrepancy",f(x.maximum_finite_head_error)+"; bound.005"],
["Raw ideal product-vector failures",x.raw_ideal_failures+" / "+x.raw_ideal_comparisons+"; max "+f(x.maximum_raw_ideal_error)],
["Measured product/cast/down/add arithmetic closure",f(x.maximum_product_rounding_closure)+"; bound1e-9"],
["Original whole-block Jacobian qualified",String(x.original_wholeblock_jacobian_qualified)],
["Prospective / full QuestionB solved",String(x.prospective)+" / "+String(x.full_question_B_solved)]
]}/>
<p>CPU64 finite differences promote arithmetic and do not replay the MPS forward map. All realized local directions are qualified separately. Native finite tails can compensate an edit; null effects do not prove global linearity. Neither the write sites nor neuron indices identify learned features or circuits. No browser, training, publication or push.</p>
</main>;}'''
    content=template.replace('__DATA__',json.dumps(data,separators=(',',':')));DEST.write_text(content);(R/'.context/native-mlp-remainder-223.canvas.tsx').write_text(content);print(DEST)
if __name__=='__main__':main()
