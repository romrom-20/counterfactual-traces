"""Offline interactive factorial from audited intervention data."""

import json
from pathlib import Path
R=Path(__file__).resolve().parents[1]
DEST=Path("/Users/samanseshadri/.cursor/projects/Users-samanseshadri-conductor-workspaces-training-jev-v1-bucharest/canvases/native-receiver-mechanism-221.canvas.tsx")
def main():
    x=json.loads((R/"docs/analysis/221-native-receiver-factorial.json").read_text());assert x["qualified"]
    geometry=json.loads((R/"docs/analysis/221b-projection-geometry-weights.json").read_text())
    data=dict(result=x,geometry=geometry["geometry"])
    template='''import {H1,H2,Text,Table,Select,useState,useHostTheme} from "cursor/canvas";
const D:any=__DATA__;const f=(x:number|null)=>x===null?"undefined":Number.isFinite(x)?x.toPrecision(5):String(x);
export default function NativeReceiver(){const t=useHostTheme();const [index,setIndex]=useState("0");const [a,setA]=useState("F");const [norm,setNorm]=useState("F");const [b,setB]=useState("N");const [carry,setCarry]=useState("1");const [write,setWrite]=useState("1");
const x=D.result;const contexts=[...new Set<string>(x.rows.map((r:any)=>r.context))];const context=contexts[Number(index)];const group=x.rows.find((r:any)=>r.context===context).group;
const state=carry==="0"&&write==="0"?"00":b+carry+write;const rows=x.rows.filter((r:any)=>r.context===context&&r.attention===a&&r.norm===norm);const current=rows.find((r:any)=>r.state===state);
const options=(v:any[])=>v.map(([value,label])=>({value,label}));
return <main style={{padding:24,maxWidth:1280,margin:"auto",background:t.bg.editor,color:t.text.primary}}>
<H1>Where is the final-block parent response generated?</H1>
<p style={{fontSize:18}}><strong>Native attention bridge → carried residual / attention-write factorial → normalization intervention → actual finite readout.</strong></p>
<Text>Experiment221 · 16 October 2026 · all64 old208 contexts · frozen219 top32 neurons · Qwen2.5-1.5B-Instruct · retrospective causal interventions</Text>
<p>The prior source-only explanation failed on fresh prompts in220. This test asks whether the established local account survives native attention, and whether the parent response is carried in or written in the final block. It does not identify the earlier block that created a carried residual or certify the unresolved original whole-block Jacobian.</p>
<H2>Inspect an actual intervention</H2>
<Select value={index} onChange={setIndex} options={contexts.map((c:string,i:number)=>{const g=x.rows.find((r:any)=>r.context===c).group;return {value:String(i),label:g.block+" · "+g.schema+" · order "+g.reverse+" · assignment/target "+g.assignment+"/"+g.target};})}/>
<div style={{display:"flex",gap:16,flexWrap:"wrap",margin:"14px 0"}}>
<label>Attention <Select value={a} onChange={setA} options={options([["F","Native attention"],["L","False-affine attention"]])}/></label>
<label>RMS scale <Select value={norm} onChange={setNorm} options={options([["F","Finite scale"],["S","Source-only fixed scale"]])}/></label>
<label>Receiving background <Select value={b} onChange={setB} options={options([["N","Native receiving input"],["P","Original forecast input"]])}/></label>
</div>
<div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:18,margin:"16px 0"}}>
<section><strong>Carried receiving state</strong><Select value={carry} onChange={setCarry} options={options([["1","Background receiving residual"],["0","Source-only receiving residual"]])}/><p>→ add measured attention write</p><Select value={write} onChange={setWrite} options={options([["1","Background attention write"],["0","Source-only attention write"]])}/></section>
<section><strong>RMS → gate and up</strong><p>Inverse RMS gain: {f(current.gain)}</p><p>Neuron6411 ΔΦ: {f(current.parents6411[0])}<br/>ΔU: {f(current.parents6411[1])}</p><p>Neuron3902 ΔΦ: {f(current.parents3902[0])}<br/>ΔU: {f(current.parents3902[1])}</p></section>
<section><strong>Product → down → finite head</strong><p>Selected32 finite effect: <strong>{f(current.finite_group)} nats</strong></p><p>All-neuron finite effect: {f(current.finite_full)} nats</p><p>Initial selected projection: {f(current.initial_group)} nats</p></section>
</div>
<Table headers={["Mid condition","6411 ΔΦ","6411 ΔU","6411 initial projection (nats)","3902 initial projection (nats)","Finite32 common effect (nats)"]} rows={rows.filter((r:any)=>r.state==="00"||r.background===b).map((r:any)=>[r.state,f(r.parents6411[0]),f(r.parents6411[1]),f(r.initial6411),f(r.initial3902),f(r.finite_group)])}/>
<Text>00 source only;10 carry only;01 attention write only;11 both. Crossed writes and fixed gains are explicit synthetic interventions. All finite effects transplant only receiving corrections into the SAME False final state. Initial projections are separate diagnostics.</Text>
<H2>Native-attention transfer of the frozen neuron account</H2>
<Table headers={["Swap direction","Guarded opposite signs","Selected donor signs attained","Selected beats BOTH controls /64","Median distance: selected / cardinality random / norm random (nats)"]} rows={x.native_bridge.map((r:any)=>[r.background==="N"?"Native → forecast mixed terms":"Forecast → native mixed terms",String(r.eligible),String(r.donor_sign_attained),String(r.beats_both_controls),[r.median_distance.selected,r.median_distance.random,r.median_distance.norm_random].map(f).join(" / ")])}/>
<H2>Carry/write sufficiency at the registered bounds</H2>
<Table headers={["Attention / RMS / background / part","Individual passes /64","Median parent relative error","Median finite32 effect error (nats)","Whole panel pass"]} rows={x.sufficiency.map((r:any)=>[r.attention+" / "+r.norm+" / "+r.background+" / "+r.part,String(r.passes),f(r.median_parent_relative),f(r.median_group_error),String(r.whole_pass)])}/>
<p>Individual sufficiency needs parent relative error≤.25 and group-effect error≤.10 nats. Four assignment/target cells must pass per panel; a whole pass requires at least3/4 panels in EVERY schema/order stratum. This is a local diagnostic, not earlier full-network accuracy.</p>
<H2>Normalization interaction for the selected context</H2>
<Table headers={["Attention / RMS / background","Pre-gate interaction6411","Up interaction6411","Post-SiLU interaction6411","Finite32 interaction (nats)"]} rows={x.interactions.filter((r:any)=>r.context===context).map((r:any)=>[r.attention+" / "+r.norm+" / "+r.background,f(r.gate_units[0]),f(r.up_units[0]),f(r.phi_units[0]),f(r.finite_group)])}/>
<p>Interaction is11−10−01+00. Fixed-denominator pre-SiLU linearity is expected. Measured input/projection rounding is retained. Its disappearance alone is not evidence for a new mechanism; compare the actual finite-response changes under the gain intervention.</p>
<H2>Independent projection-geometry check</H2>
<Table headers={["Neuron","Effective gate/up weight cosine","Weight-only Δup / Δgate coefficient","Up-row perpendicular fraction","Nearly opposite rows"]} rows={D.geometry.map((g:any)=>[String(g.neuron),f(g.cosine),f(g.alpha),f(g.perpendicular_fraction),String(g.near_opposite)])}/>
<p>Rows are not nearly mirrored. A common normalization gain remains a possible coupling, so this weight check does not imply independent learned circuits. Native activation changes are still observations to explain.</p>
<H2>Numerical scope</H2>
<Table headers={["Executed check","Result"]} rows={[
["Required controls / actual local derivatives",x.controls+" / "+x.local_derivative_checks+" pass"],
["Public blocks / explicit down projections / finite heads",x.counts.public_blocks+" / "+x.counts.direct_down+" / "+x.counts.finite_heads],
["Maximum local derivative discrepancy",f(x.maximum_local_derivative_error)],
["Independent finite-head score replay",f(x.maximum_head_error)+" maximum; bound .005"],
["Selected gate/up coordinate replay",f(x.maximum_selected_parent_replay_error)+" maximum; bound1e-4"],
["Raw ideal-vector failures",x.raw_ideal_failures+" / "+x.raw_ideal_comparisons+"; maximum "+f(x.maximum_raw_ideal_error)],
["Measured arithmetic closure",f(x.maximum_rounding_closure)],
["Interaction accounting",f(x.maximum_interaction_accounting_error)],
["Original whole-block Jacobian qualified",String(x.original_wholeblock_jacobian_qualified)],
["Full Question B solved",String(x.full_question_B_solved)]
]}/>
<p>No browser, training, correction sweep, publication or push. Qualified prior results and their failures are preserved unchanged. A native final endpoint replay is a control, not a False-state-only forecast.</p>
</main>;}
'''
    content=template.replace("__DATA__",json.dumps(data,separators=(",",":")));DEST.write_text(content);(R/".context/native-receiver-mechanism-221.canvas.tsx").write_text(content);print(DEST)
if __name__=="__main__":main()
