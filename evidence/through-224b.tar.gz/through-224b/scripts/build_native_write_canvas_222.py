"""Offline, case-level viewer of the audited native write ledger and causal tests."""

import json
from pathlib import Path
R=Path(__file__).resolve().parents[1]
DEST=Path('/Users/samanseshadri/.cursor/projects/Users-samanseshadri-conductor-workspaces-training-jev-v1-bucharest/canvases/native-write-mechanism-222.canvas.tsx')
def main():
    d=json.loads((R/'docs/analysis/222-native-write-ledger.json').read_text());assert d['qualified']
    template='''import {H1,H2,Text,Table,Select,useState,useHostTheme} from "cursor/canvas";
const D:any=__DATA__;const f=(v:number)=>Number.isFinite(v)?v.toPrecision(5):String(v);
export default function NativeWrites(){const t=useHostTheme();const [key,setKey]=useState(D.causal[0].context);const [field,setField]=useState("0");const [arm,setArm]=useState("op0_clamp");
const ledger=D.ledger.find((r:any)=>r.context===key);const rows=D.causal.filter((r:any)=>r.context===key);const active=rows.find((r:any)=>r.label===arm);const j=Number(field);
const values=ledger.operation_projection.map((p:number[])=>p[j]);const max=Math.max(...values.map(Math.abs),.001);const y=(v:number)=>140-105*v/max;
const name=(index:number)=>String(Math.floor(index/2)+1)+(index%2===0?"A":"M");
return <main style={{padding:24,maxWidth:1280,margin:"auto",background:t.bg.editor,color:t.text.primary}}>
<H1>What writes the native receiving-state displacement?</H1>
<p style={{fontSize:18}}><strong>Exact finite write ledger → frozen operation selection → actual write removal and direction-specific rescue.</strong></p>
<Text>222 · Qwen2.5-1.5B-Instruct · 64 old examples for the ledger · two families select operations; the other two supply 32 causal cases · retrospective</Text>
<p>221 established that the local product account survives native attention and that its parent response is mostly carried into the final block. Here the ledger identifies candidate upstream writes. Only the subsequent finite interventions establish their causal effects; a large signed projection is not a causal fraction.</p>
<H2>Registered causal gate</H2>
<Table headers={["Selected operation","Clamp erases /32","Plane rescues /32","Beats both controls /32","Joint /32","Whole gate"]} rows={D.gates.map((g:any)=>["Block "+g.operation.layer+" "+g.operation.kind,String(g.totals.erase),String(g.totals.rescue),String(g.totals.beats_both),String(g.totals.combined),String(g.passed)])}/>
<p>Gate: at least24/32 and6/8 in every schema/order stratum. Erasure needs a positive native effect&gt;.02 nats and at least50% reduction. Rescue needs parent relativeL2≤.25, finite-effect error≤.10 nats and a smaller effect error than both complement and matched random rescue. Full rescue must replay native states and scores.</p>
<H2>Inspect the actual signed writes and intervention</H2>
<Select value={key} onChange={setKey} options={[...new Set<string>(D.causal.map((r:any)=>r.context))].map((c:string)=>{const g=D.ledger.find((r:any)=>r.context===c).group;return {value:c,label:g.block+" · "+g.schema+" · order "+g.reverse+" · assignment/target "+g.assignment+"/"+g.target};})}/>
<div style={{display:"flex",gap:18,flexWrap:"wrap",margin:"16px 0"}}><label>Fixed projection <Select value={field} onChange={setField} options={[{value:"0",label:"6411 gate preactivation"},{value:"1",label:"6411 up"},{value:"2",label:"3902 gate preactivation"},{value:"3",label:"3902 up"}]}/></label>
<label>Finite intervention <Select value={arm} onChange={setArm} options={rows.map((r:any)=>({value:r.label,label:r.label}))}/></label></div>
<svg viewBox="0 0 1000 310" role="img" aria-label="Signed operation contribution to fixed final-block gate or up projection" style={{width:"100%",maxHeight:310}}>
<text x="45" y="20" fill={t.text.primary} fontSize="15">Actual native write projection: {field==="0"?"6411 gate":field==="1"?"6411 up":field==="2"?"3902 gate":"3902 up"}</text>
<line x1="65" x2="970" y1="140" y2="140" stroke={t.stroke.primary}/>
{[-max,0,max].map((v:number)=><text key={v} x="58" y={y(v)+4} textAnchor="end" fontSize="10" fill={t.text.secondary}>{f(v)}</text>)}
{values.map((v:number,i:number)=><g key={i}><rect x={70+i*16.4} y={Math.min(140,y(v))} width="11" height={Math.max(.5,Math.abs(y(v)-140))} fill={D.selected_operations.some((o:any)=>o.index===i)?t.accent.primary:t.fill.secondary}><title>{name(i)+": "+f(v)+" activation units"}</title></rect>{i%2===0&&<text x={75+i*16.4} y="270" textAnchor="middle" fontSize="9" fill={t.text.secondary}>{Math.floor(i/2)+1}</text>}</g>)}
<text x="510" y="291" textAnchor="middle" fill={t.text.secondary} fontSize="12">Transformer block (1-based); attention then MLP; vertical units = fixed-gain activation projection</text>
</svg>
<Text>Source: actual finite native True−False writes in222. Source00 gain and final gate/up rows are fixed from221. Selected sites are accented. This is an additive ledger, not a learned circuit or a causal percentage.</Text>
<div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:24,margin:"22px 0"}}>
<section><H2>Local response</H2><p>Native finite32 effect: <strong>{f(active.native_group)} nats</strong><br/>Intervened effect: <strong>{f(active.group_effect)} nats</strong></p><p>6411 parent relative error: {f(active.parent_relative_error)}<br/>Finite32 effect error: {f(active.group_error)} nats</p><p>ΔΦ, ΔU native: {active.native_parents.map(f).join(" / ")}<br/>ΔΦ, ΔU intervened: {active.parents6411.map(f).join(" / ")}</p></section>
<section><H2>Natural final consequences</H2><p>Native verdict margin: {f(active.native_margin)} nats<br/>Intervened margin: {f(active.intervened_margin)} nats<br/>Signed margin change: {f(active.final_margin_change)} nats</p><p>Final receiving-residual change / native True−False change: {f(active.final_native_response_relative_error)}</p><Text>These are actual intervention consequences. They are separate from the finite32 product diagnostic, and are not forecast accuracy scores.</Text></section>
</div>
<Table headers={["Actual arm","Finite32 effect (nats)","Parent relative error","Finite32 error (nats)","Natural margin change (nats)","Final residual edit / native response"]} rows={rows.map((r:any)=>[r.label,f(r.group_effect),f(r.parent_relative_error),f(r.group_error),f(r.final_margin_change),f(r.final_native_response_relative_error)])}/>
<H2>Every stratum and control</H2>
<Table headers={["Site","Schema/order","Erases /8","Rescues /8","Beats both /8","Combined /8"]} rows={D.gates.flatMap((g:any)=>g.strata.map((s:any)=>["Block "+g.operation.layer+" "+g.operation.kind,s.schema+" / "+s.order,String(s.counts.erase),String(s.counts.rescue),String(s.counts.beats_both),String(s.counts.combined)]))}/>
<H2>Numerical qualification</H2>
<Table headers={["Check","Result"]} rows={[
["Controls and product first-derivative checks",D.controls+" / "+D.product_derivative_checks+" pass"],
["Ordinary model calls",String(D.counts.ordinary_models)],
["Public target replays / explicit down / finite heads",D.counts.public_target_blocks+" / "+D.counts.direct_down+" / "+D.counts.finite_heads],
["Exact native-write ledger maximum error",f(D.maximum_ledger_error)+"; bound1e-9"],
["Fixed-probe replay against221",f(D.maximum_probe_replay_error)+"; bound1e-4"],
["Local product derivative discrepancy",f(D.maximum_product_derivative_error)+"; bound1e-4"],
["Independent CPU64 finite-head replay",f(D.maximum_head_error)+"; bound.005"],
["Raw ideal-vector failures",D.raw_ideal_failures+" / "+D.raw_ideal_comparisons+"; max "+f(D.maximum_raw_ideal_error)],
["Measured arithmetic closure",f(D.maximum_rounding_closure)+"; bound1e-9"],
["Original whole-block Jacobian qualified",String(D.original_wholeblock_jacobian_qualified)],
["Prospective / QuestionB solved",String(D.prospective)+" / "+String(D.full_question_B_solved)]
]}/>
<p>All neural indices identify fixed coordinates only. The plane is defined by final gate/up weights and includes learned norm weights; it is not fitted to native targets. Every tail is native and finite. No browser, training, global correction sweep, publication or push.</p>
</main>;}'''
    content=template.replace('__DATA__',json.dumps(d,separators=(',',':')));DEST.write_text(content);(R/'.context/native-write-mechanism-222.canvas.tsx').write_text(content);print(DEST)
if __name__=='__main__':main()
