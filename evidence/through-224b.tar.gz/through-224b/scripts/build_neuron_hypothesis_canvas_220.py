"""Offline view of retrospective localization and its frozen fresh upstream test."""

import json
from pathlib import Path
R=Path(__file__).resolve().parents[1]
DEST=Path("/Users/samanseshadri/.cursor/projects/Users-samanseshadri-conductor-workspaces-training-jev-v1-bucharest/canvases/neuron-upstream-hypothesis-219-220.canvas.tsx")
def main():
    old=json.loads((R/"docs/analysis/219-neuron-mixed-interventions.json").read_text());new=json.loads((R/"docs/analysis/220-source-only-neuron-hypothesis.json").read_text());assert old["qualified"] and new["qualified"]
    data=dict(retrospective=dict(summaries=[s for s in old["summaries"] if s["subset"]=="excluded"],gates=old["compact_gates"],top=old["top_neurons"][:8]),fresh=new)
    template='''import {H1,H2,Text,Table,Select,useState,useHostTheme} from "cursor/canvas";
const D:any=__DATA__;const f=(x:number|null)=>x===null?"undefined":Number.isFinite(x)?x.toPrecision(5):String(x);
export default function NeuronUpstream(){const t=useHostTheme();const [i,setI]=useState("0");const x=D.fresh;const r=x.rows[Number(i)];
return <main style={{padding:24,maxWidth:1240,margin:"auto",background:t.bg.editor,color:t.text.primary}}>
<H1>A stable local account faces a fresh upstream test</H1>
<p style={{fontSize:18}}><strong>The retrospective neuron group passes its causal gate. The frozen source-only upstream hypothesis {x.hypothesis_accepted?"passes":"fails"} its fresh local prediction gate.</strong></p>
<Text>Experiments 219–220 · 16 October 2026 · pinned Qwen2.5-1.5B-Instruct · MPS Float32/eager/eval · finite SiLU / MLP-input RMSNorm, attention False-affine</Text>
<H2>219: fixed groups on the old families excluded from selection</H2>
<Table headers={["Fixed neurons","Median absolute contrast mass","Median per-case oracle mass","Median neurons for 90% mass"]} rows={D.retrospective.summaries.map((s:any)=>[String(s.k),f(s.median_fixed_absolute_fraction),f(s.median_oracle_absolute_fraction),f(s.median_neurons_for_90pct_absolute)])}/>
<Table headers={["Fixed group","Compact causal gate","Native→forecast donor signs / eligible","Forecast→native donor signs / eligible"]} rows={D.retrospective.gates.map((g:any)=>[String(g.k),String(g.passed),g.directions[0].donor_sign_attained+" / "+g.directions[0].eligible,g.directions[1].donor_sign_attained+" / "+g.directions[1].eligible])}/>
<p>Selection uses native observations from chalice/gimbal; larch/marzipan are excluded from selection. All 64 are previously observed synthetic contexts. This localizes product terms, rather than identifying learned features. Positive and negative contributions and a substantial long tail coexist.</p>
<H2>220: two frozen False-state-only predictions</H2>
<p>S keeps receiving rows at False and inserts the known Boolean-source state before block28. P is the original executed finite-source / False-first-AD receiver forecast. Both predict selected group terms with no fit or native target rescaling. N is measured later from native True incoming states, with the same attention-affine local computation.</p>
<Text>Freshness: 16 pairs / 32 full token sequences absent from the historical forecast catalog. All forecasts sealed before any fresh ordinary True forward: {String(x.all_forecasts_sealed_before_native)}. One literal family, with related assignment/target/order/schema cells.</Text>
<Table headers={["Schema / prediction","Median group effect (finite nats)","Median group absolute error (nats)","Median neuron6411 initial projection (nats)","Median neuron6411 absolute error (nats)","Median parent relative L2 error"]} rows={x.summaries.flatMap((s:any)=>["S","P"].map(a=>[(s.schema??"all")+" / "+a,f(s.quantities[a].group_finite_effect),f(s.errors[a].group_absolute),f(s.quantities[a].neuron6411_projection),f(s.errors[a].neuron_absolute),f(s.errors[a].parents_relative)]))}/>
<H2>Frozen gate: small errors and improvement in every stratum</H2>
<Table headers={["Schema / order","Group passes /4","Neuron6411 passes /4","Parent passes /4"]} rows={x.panels.map((p:any)=>[p.schema+" / "+p.order,String(p.passes.group),String(p.passes.neuron),String(p.passes.parents)])}/>
<p>Each column requires at least3/4 per schema/order and12/16 overall. Group and neuron errors must be ≤.10 nats and strictly smaller than P. The two-dimensional gate/up parent relative error must be ≤.25 and smaller than P. These new local-test criteria do not alter earlier full residual/verdict accuracy bounds.</p>
<H2>Inspect every fresh context</H2>
<Select value={i} onChange={setI} options={x.rows.map((r:any,j:number)=>({value:String(j),label:r.group.schema+" · order "+r.group.reverse+" · assignment/target "+r.group.assignment+"/"+r.group.target}))}/>
<Table headers={["Computation","Group finite common effect (nats)","Neuron6411 initial projection (nats)","Gate increment","Up increment"]} rows={["S","P","N"].map(a=>[a,f(r.quantities[a].group_finite_effect),f(r.quantities[a].neuron6411_projection),f(r.quantities[a].parents6411[0]),f(r.quantities[a].parents6411[1])])}/>
<Table headers={["Forecast","Group absolute error (nats)","Neuron6411 error (nats)","Parent relative L2 error"]} rows={["S","P"].map(a=>[a,f(r.errors[a].group_absolute),f(r.errors[a].neuron_absolute),f(r.errors[a].parents_relative)])}/>
<H2>Qualification and limits</H2>
<Table headers={["Check","Result"]} rows={[
["Required controls / local primitive checks",x.controls+" / "+x.local_derivative_checks+" pass"],
["Upstream first-reverse projections",x.upstream_reverse_checks+" pass; maximum error "+f(x.maximum_upstream_reverse_error)],
["Maximum local derivative discrepancy",f(x.maximum_local_derivative_error)],
["Independent saved P update reconstruction",f(x.maximum_saved_update_error)],
["Independent CPU64 finite-head scores",f(x.maximum_cpu64_head_error)+" maximum; bound .005"],
["Raw ideal-vector failures",x.raw_ideal_failures+" /48; maximum "+f(x.maximum_raw_ideal_error)],
["Measured arithmetic closure",f(x.maximum_rounding_closure)],
["Original whole-block coordinate Jacobian qualified",String(x.original_wholeblock_jacobian_qualified)],
["Full Question B solved",String(x.full_question_B_solved)]
]}/>
<p>A successful local prediction would still not explain the full native residual or establish a learned circuit. A failed source-only prediction leaves the 219 retrospective causal result intact and rejects this upstream proposal at the frozen bounds. No correction sweep, browser search, publication or push.</p>
</main>;}
'''
    content=template.replace("__DATA__",json.dumps(data,separators=(",",":")));DEST.write_text(content);(R/".context/neuron-upstream-hypothesis-219-220.canvas.tsx").write_text(content);print(DEST)
if __name__=="__main__":main()
