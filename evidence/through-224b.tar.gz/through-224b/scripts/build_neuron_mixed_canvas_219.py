"""Offline presentation of every signed account and direct product intervention."""

import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
DEST=Path("/Users/samanseshadri/.cursor/projects/Users-samanseshadri-conductor-workspaces-training-jev-v1-bucharest/canvases/neuron-mixed-interventions-219.canvas.tsx")


def main():
    obj=json.loads((ROOT/"docs/analysis/219-neuron-mixed-interventions.json").read_text());assert obj["qualified"]
    data={k:v for k,v in obj.items() if k not in ("auditor_sha256","weights_sha256")}
    template='''import {H1,H2,Text,Table,Select,useState,useHostTheme} from "cursor/canvas";
const D:any=__DATA__;
const fmt=(x:number|null)=>x===null?"undefined":Number.isFinite(x)?x.toPrecision(5):String(x);
export default function NeuronMixed(){
 const t=useHostTheme();const [index,setIndex]=useState("0");const [k,setK]=useState("128");
 const n=D.neurons[Number(index)];const rows=D.rows.filter((r:any)=>r.key===n.key);const gate=D.compact_gates.find((g:any)=>String(g.k)===k);
 return <main style={{padding:24,maxWidth:1280,margin:"auto",background:t.bg.editor,color:t.text.primary}}>
 <H1>Signed neuron products: concentration and causal edits</H1>
 <p style={{fontSize:18}}><strong>Neuron contributions are tested through the actual product pathway, with finite readouts and matched controls.</strong></p>
 <Text>Experiment 219 · 16 October 2026 · all 64 old 208 contexts · Qwen2.5-1.5B-Instruct · finite SiLU and MLP-input RMSNorm · attention False-affine</Text>
 <p>Chalice/gimbal select a fixed ranking using native observations; larch/marzipan are excluded from selection. All examples were already observed in prior experiments. This is retrospective family separation, not fresh prediction or independent replication. A neuron index is not a learned feature.</p>
 <H2>How much absolute contrast mass is concentrated?</H2>
 <Table headers={["Subset / fixed neuron count","Median selected absolute mass (ratio)","Median per-case oracle absolute mass (ratio)","Median neurons needed for 90% absolute mass"]} rows={D.summaries.map((r:any)=>[r.subset+" / "+r.k,fmt(r.median_fixed_absolute_fraction),fmt(r.median_oracle_absolute_fraction),fmt(r.median_neurons_for_90pct_absolute)])}/>
 <Text>The denominator is sum of absolute signed contributions. It does not divide by a nearly cancelled net. Per-case oracle ordering and fixed discovery ordering are different diagnostics.</Text>
 <H2>Conditional gate versus up accounting</H2>
 <Table headers={["Subset","Median gate contrast (initial nats)","Median up contrast (initial nats)","Median total contrast (initial nats)","Median |net| / absolute mass"]} rows={D.summaries.filter((r:any)=>r.k===128).map((r:any)=>[r.subset,fmt(r.median_gate_contrast),fmt(r.median_up_contrast),fmt(r.median_net_contrast),fmt(r.median_net_over_absolute)])}/>
 <p>The symmetric gate/up accounting sums exactly case by case, not necessarily across separate medians. It is algebraic accounting of the mixed term, not a unique causal fraction. Direct gate/up crosses and neuron edits below evaluate finite outcomes separately.</p>
 <H2>Predefined compact-account gate</H2>
 <Table headers={["Fixed k","Excluded-family absolute mass ≥.5","Both swap-direction sign gates","Every matched-control stratum passes","Eligible compact account"]} rows={D.compact_gates.map((g:any)=>[String(g.k),String(g.mass_pass),String(g.directions.every((x:any)=>x.passed)),String(g.strata.every((x:any)=>x.passed)),String(g.passed)])}/>
 <label>Inspect fixed group size <Select value={k} onChange={setK} options={[8,32,128,512].map(v=>({value:String(v),label:String(v)+" neurons"}))}/></label>
 <Table headers={["Swap direction","Guarded opposite-sign cases","Donor sign attained","80% gate"]} rows={gate.directions.map((r:any)=>[r.background==="N"?"Native → forecast mixed terms":"Forecast → native mixed terms",String(r.eligible),String(r.donor_sign_attained),String(r.passed)])}/>
 <Table headers={["Background / schema / order","Selected closer to all-neuron effect than BOTH controls","75% gate"]} rows={gate.strata.map((r:any)=>[r.background+" / "+r.schema+" / "+r.order,r.wins+" / "+r.count,String(r.passed)])}/>
 <p>Only k≤128 is eligible. This is a frozen action rule for deciding whether a compact follow-up is warranted; it is not a significance test. The norm-matched random control matches L2 in receiving product coordinates, not residual or readout norm.</p>
 <H2>Inspect every matched context</H2>
 <Select value={index} onChange={setIndex} options={D.neurons.map((r:any,i:number)=>({value:String(i),label:r.group.block+" · "+r.group.schema+" · order "+r.group.reverse+" · assignment/target "+r.group.assignment+"/"+r.group.target}))}/>
 <Text>Excluded from mask selection: {String(n.held_out_of_selection)}. Absolute contrast {fmt(n.concentration.absolute)}; positive {fmt(n.concentration.positive)}; negative {fmt(n.concentration.negative)}; net {fmt(n.concentration.net)} initial projection nats.</Text>
 <Table headers={["Gate/up increment origins","Initial fixed-readout mixed projection (nats)"]} rows={Object.keys(n.cross_projections).map(a=>[a,fmt(n.cross_projections[a])])}/>
 <Table headers={["Background / direct product edit","Finite common-readout effect (nats)","Initial common-readout projection (nats)","Natural final margin (nats)","Public full-block replay"]} rows={rows.filter((r:any)=>r.kind==="cross"||String(r.k)===k).map((r:any)=>[r.background+" / "+r.label,fmt(r.common_margin_change),fmt(r.projection),fmt(r.natural_margin),String(r.replay)])}/>
 <p>Each mixed-term swap edits actual receiving product coordinates before the public down projection, with source/prefix fixed. Common-readout effects transplant the measured correction into the same False final state. Cross combinations are synthetic interventions, not native trajectories.</p>
 <H2>Numerical qualification remains bounded</H2>
 <Table headers={["Executed check","Result"]} rows={[
 ["Model work",D.counts.blocks+" blocks; "+D.counts.direct_down+" direct down projections; "+D.counts.finite_heads+" finite heads; "+D.counts.reverse_heads+" head gradients"],
 ["Required controls and local derivatives",D.controls+" controls; "+D.local_derivative_checks+" local checks passed"],
 ["Maximum local derivative discrepancy",fmt(D.maximum_local_derivative_error)],
 ["Independent CPU64 finite-head score replay",fmt(D.maximum_cpu64_finite_head_error)+" maximum; bound .005"],
 ["Raw ideal-vector checks above 1e-4",D.raw_ideal_vector_failures+" / "+D.interventions+"; maximum "+fmt(D.maximum_raw_ideal_vector_error)],
 ["Measured product/down/residual rounding closure",fmt(D.maximum_saved_rounding_closure)],
 ["Original whole-block Jacobian coordinate qualification",String(D.original_wholeblock_jacobian_qualified)],
 ["Prospective prediction",String(D.prospective)]
 ]}/>
 <p>218 is preserved unchanged. No end-to-end correction sweep or learned feature interpretation follows from this diagnostic. A fresh-context hypothesis requires a separately frozen False-state-only upstream rule.</p>
 </main>;
}
'''
    content=template.replace("__DATA__",json.dumps(data,separators=(",",":")))
    DEST.write_text(content);(ROOT/".context/neuron-mixed-interventions-219.canvas.tsx").write_text(content);print(DEST)


if __name__=="__main__":main()
