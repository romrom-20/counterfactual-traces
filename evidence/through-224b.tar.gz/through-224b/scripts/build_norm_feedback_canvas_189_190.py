"""Embed qualified operation cuts, every cell and scale/projection cancellation."""

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def main():
    data = []
    for i in (189, 190):
        a = json.loads((ROOT / f"docs/analysis/{i}-independent-audit.json").read_text())
        n = json.loads((ROOT / f"docs/analysis/{i}-numerical-recheck.json").read_text())
        g = json.loads((ROOT / f"docs/analysis/{i}-norm-readout-cancellation.json").read_text())
        assert (
            a["numerical_qualified"]
            and all(a["controls"].values())
            and n["passed"]
            and a["fingerprint"] == g["fingerprint"] == n["fingerprint"]
        )
        geometry = {
            tuple(c[k] for k in ("block", "schema", "reverse", "assignment", "target")): c
            for c in g["cells"]
        }
        cases = [
            {
                **c,
                "geometry": geometry[
                    tuple(c[k] for k in ("block", "schema", "reverse", "assignment", "target"))
                ],
            }
            for c in a["cells"]
        ]
        accounts = []
        for name, v in a["accounts"].items():
            den = 8 if "compatible_comparisons" in v else 16
            accounts.append(
                [
                    name.replace("_", " "),
                    f"{v.get('compatible_panels', v.get('compatible_comparisons'))}/{den}",
                    "PASS" if v["whole_passed"] else "FAIL",
                    ", ".join(f"{k}: {value}/4" for k, value in v["strata"].items()),
                ]
            )
        data.append(
            {
                "id": str(i),
                "cases": cases,
                "accounts": accounts,
                "main": a["main_forwards"],
                "numerical": n["forwards"],
                "controls": len(a["controls"]),
                "exactScores": n["all_scores_exact"],
                "exactStates": n["all_states_exact"],
                "captureError": n["maximum_capture_error"],
                "geometryError": g["maximum_public_score_reconstruction_error"],
                "counterfactualError": g["maximum190_fixed_final_counterfactual_error"],
                "fingerprint": a["fingerprint"],
                "cuts": ["live", "N", "W", "U", "NW", "NU", "WU", "NWU"]
                if i == 189
                else ["live", "U", "FU", "IU", "NU"],
            }
        )
    (ROOT / ".context/norm-feedback-canvas-data.json").write_text(json.dumps(data, indent=2) + "\n")
    code = r"""import {H1,H2,Text,Stack,Row,Grid,Select,Table,BarChart,Callout,Code,useCanvasState,useHostTheme} from "cursor/canvas";
const DATA=__DATA__ as any[];
const f=(x:number)=>x.toFixed(6);
export default function NormFeedback(){
 const theme=useHostTheme();
 const [id,setId]=useCanvasState("norm-exp","190");const d=DATA.find(v=>v.id===id)||DATA[1];
 const [src,setSrc]=useCanvasState("norm-source","beryl");const sources=[...new Set(d.cases.map((c:any)=>c.block))] as string[];const source=sources.includes(src)?src:sources[0];
 const [schema,setSchema]=useCanvasState("norm-schema","descriptive");const [order,setOrder]=useCanvasState("norm-order","0");const [cell,setCell]=useCanvasState("norm-cell","0:0");
 const rows=d.cases.filter((c:any)=>c.block===source&&c.schema===schema&&c.reverse===Number(order));const c=rows.find((r:any)=>`${r.assignment}:${r.target}`===cell)||rows[0];
 const [cond,setCond]=useCanvasState("norm-condition","U");const cut=d.cuts.includes(cond)?cond:d.cuts[0];
 const capture=`Source: final ${d.id} artifact/numerical audits and saved-state geometry · 14 October 2026 UTC · ${source}, ${schema}, order ${order}, assignment ${c.assignment}, question ${c.target}.`;
 const geo=c.geometry.decomposition;const geomCuts=Object.keys(geo);
 return <Stack gap={18} style={{maxWidth:1160,margin:"0 auto",padding:24,color:theme.text.primary}}>
  <H1>When a shared correction changes direction</H1>
  <Text>Two operation tests distinguish multiplying branches, attention, internal RMS scales and the final scale before the verdict logits. Every endpoint and frozen-account failure remains inspectable.</Text>
  <Callout tone="info">Margin = RMS scale × residual projection. A positive change in the projection can be opposed by a negative scale contribution. This decomposition is exact arithmetic; it is distinct from the scientific question of whether fixing the final scale explains the normalization cut.</Callout>
  <Row gap={12} wrap><Select value={d.id} onChange={setId} options={[{value:"189",label:"189 · complete N/W/U factorial (reused contexts)"},{value:"190",label:"190 · final versus internal norm (new prompts)"}]}/></Row>
  <Grid columns={2} gap={24}><Stack gap={10}><H2>Every registered account</H2><Table headers={["Account","Compatible panels","Whole result","All strata"]} rows={d.accounts}/><Text size="sm" tone="secondary">Whole rules require at least 3 of 4 sources in EVERY schema/order. Paired-schema comparisons require that in each order. Thresholds and eligibility are frozen. Success of one account cannot rescue another.</Text></Stack>
   <Stack gap={10}><H2>Verification and calibration</H2><Text>{d.main} main + {d.numerical} separate numerical full-model forwards. All {d.controls} artifact controls pass. Selected scores {d.exactScores?"EXACT":"within fixed tolerance"}; full states {d.exactStates?"EXACT":"within fixed tolerance"}; max capture discrepancy {d.captureError.toExponential(3)}.</Text><Text>Saved-state CPUfloat64 public score error {d.geometryError.toExponential(3)} nats; zero additional full-model forwards.190 final-only counterfactual score error {d.counterfactualError.toExponential(3)} nats.</Text><Text>{d.id==="189"?"Live/NW/NWU values are768 immutable parent patch references, not new executions. The other five cuts were executed here on the186–188cohort.":"Four new day blocks were held out of hypothesis specification. Paired native states still calibrate the maps. All256 final-only comparisons leave the full block28 residual EXACT."}</Text><Text size="sm" tone="secondary">One Qwen checkpoint; dependent day templates; dense paired maps/means; changed baselines. No incomplete-state forecast, unique semantic circuit, priority or competence recovery claim.</Text><Code>{d.fingerprint}</Code></Stack></Grid>
  <H2>Inspect every context</H2><Row gap={12} wrap>
   <Stack gap={4}><Text size="sm">Source</Text><Select value={source} onChange={setSrc} options={sources.map(v=>({value:v,label:v}))}/></Stack>
   <Stack gap={4}><Text size="sm">Schema</Text><Select value={schema} onChange={setSchema} options={[{value:"generic",label:"Generic"},{value:"descriptive",label:"Descriptive"}]}/></Stack>
   <Stack gap={4}><Text size="sm">Sentence order</Text><Select value={order} onChange={setOrder} options={[{value:"0",label:"Original"},{value:"1",label:"Reversed"}]}/></Stack>
   <Stack gap={4}><Text size="sm">Assignment / question</Text><Select value={`${c.assignment}:${c.target}`} onChange={setCell} options={rows.map((r:any)=>({value:`${r.assignment}:${r.target}`,label:`${r.assignment}/${r.target} · ${r.supported?"supported":"unsupported"}`}))}/></Stack>
  </Row>
  <Grid columns={2} gap={24}>
   <Stack gap={8}><H2>Correction-induced margin shift by operation cut</H2><Text size="sm">Y: P+C minus P verdict margin (nats). X: factors held to identical paired means.</Text><BarChart categories={d.cuts} series={[{name:"False-bit C margin shift",data:d.cuts.map((k:string)=>c.margins[k].even[0]-c.margins[k].paired[0]),tone:"neutral"},{name:"True-bit C margin shift",data:d.cuts.map((k:string)=>c.margins[k].even[1]-c.margins[k].paired[1]),tone:"info"}]} height={260} valueSuffix=" nats" beginAtZero={true}/><Text size="sm">N=all57 RMS scales;W=attention;U=up branch;F=final RMS only;I=56internal RMS scales. live holds none fixed. Kappa is true shift minus false shift.</Text><Text size="sm" tone="secondary">{capture} Actual individual cell; no averaging.</Text></Stack>
   <Stack gap={8}><H2>Projection and scale contributions to kappa</H2><Text size="sm">Y: contribution to C's bit-response difference (nats). X: operation cut.</Text><BarChart categories={geomCuts} series={[{name:"Readout projection term",data:geomCuts.map(k=>geo[k].projection_kappa),tone:"info"},{name:"RMS scale term",data:geomCuts.map(k=>geo[k].scale_kappa),tone:"neutral"}]} height={260} valueSuffix=" nats"/><Text size="sm">For each bit: change in margin = mean(scale)×change(projection) + change(scale)×mean(projection). Chart subtracts false from true. Sum reconstructs kappa; terms are not unique upstream causal attributions.</Text><Text size="sm" tone="secondary">{capture} CPUfloat64 geometry with pinned norm/output weights and recorded effective final scales.</Text></Stack>
  </Grid>
  <Row gap={12}><H2>Individual endpoints and bit effect</H2><Select value={cut} onChange={setCond} options={d.cuts.map((v:string)=>({value:v,label:v}))}/></Row>
  <Table headers={["Assignment / question","Support","Paired false (nats)","Even false (nats)","Paired true (nats)","Even true (nats)","Kappa (nats)"]} rows={rows.map((r:any)=>[`${r.assignment}/${r.target}`,r.supported?"Supported":"Unsupported",f(r.margins[cut].paired[0]),f(r.margins[cut].even[0]),f(r.margins[cut].paired[1]),f(r.margins[cut].even[1]),f(r.kappa[cut])])}/>
  <Text size="sm" tone="secondary">All128 context pairs are selectable across the two tests. Data retain full precision internally, display six decimals. Inline data only; no network requests. Syntax/data checked; host rendering not observed.</Text>
 </Stack>;
}
"""
    print(json.dumps(code.replace("__DATA__", json.dumps(data, separators=(",", ":")))))


if __name__ == "__main__":
    main()
