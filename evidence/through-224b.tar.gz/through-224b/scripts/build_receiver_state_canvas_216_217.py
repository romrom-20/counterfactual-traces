"""Offline presentation of all fixed-reference crosses and selected-depth resets."""

import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
DEST=Path("/Users/samanseshadri/.cursor/projects/Users-samanseshadri-conductor-workspaces-training-jev-v1-bucharest/canvases/receiver-state-mechanism-216-217.canvas.tsx")


def main():
    a=json.loads((ROOT/"docs/analysis/216-vector-readout-cross-audit.json").read_text())
    b=json.loads((ROOT/"docs/analysis/217-selected-receiver-reset.json").read_text())
    assert a["qualified"] and b["qualified"]
    cases=[]
    for r in b["rows"]:
        cases.append(dict(key=r["key"],group=r["group"],boundary=r["boundary"],incoming=r["incoming"],
            natural_margin=r["natural_product_margin_change"],common_margin=r["common_product_margin_change"],diagnostics=r["diagnostics"],
            correction=r["receiver_correction"],arms={k:dict(q=v["final"]["verdict"]["relative_l2"],cosine=v["final"]["verdict"]["cosine"],
                margin=v["absolute_margin_error"],signed_error=v["signed_margin_error"],pass_=v["primary_pass"]) for k,v in r["arms"].items()}))
    data=dict(cross_summaries=a["summaries"],cross_segments=a["segments"],cross_signs=a["vector_sign_disagreements_at_fixed_base"],
        same_vector_signs=a["same_vector_sign_disagreements_between_natural_bases"],reset_summaries=[r for r in b["strata"] if r["field"] is None],
        reset_schema=[r for r in b["strata"] if r["field"]=="schema"],whole=b["whole"],cases=cases,
        checks=dict(cross_controls=a["controls"],cross_gradient_coordinate=a["maximum_gradient_coordinate_error"],cross_gradient_contract=a["maximum_gradient_contraction_error"],
            cross_self_state=a["maximum_natural_receiving_replay_error"],cross_self_score=a["maximum_natural_score_replay_error"],
            reset_controls=b["controls"],reset_local=b["local_derivative_checks"],reset_reverse=b["reverse_projections"],
            reset_coordinate=b["maximum_coordinate_control_error"],reset_score=b["maximum_score_control_error"],
            reset_local_max=b["maximum_local_derivative_error"],reset_reverse_max=b["maximum_reverse_projection_error"],reset_update=b["maximum_saved_update_formula_error"]))
    template='''import {H1,H2,Text,Table,Select,useState,useHostTheme} from "cursor/canvas";
const D: any = __DATA__;
const fmt=(x:number|null)=>x===null?"undefined":Number.isFinite(x)?x.toPrecision(5):String(x);
const baseNames: Record<string,string>={native:"Native FL",predicted:"Forecast FL",false:"False final"};
const armNames: Record<string,string>={original:"Original208 final update",FL:"Product affine / RMSNorm finite",FF:"Product and RMSNorm finite",finite:"Entire finite block28 control"};
export default function ReceiverStateMechanism(){
 const t=useHostTheme();const [depth,setDepth]=useState("0");const [index,setIndex]=useState("0");
 const cases=D.cases.filter((r:any)=>String(r.boundary)===depth);const c=cases[Number(index)];
 const cross=D.cross_segments.filter((r:any)=>r.key===c.key);const checks=D.checks;
 return <main style={{padding:24,maxWidth:1240,margin:"auto",background:t.bg.editor,color:t.text.primary}}>
 <H1>Receiving state, correction vector and readout</H1>
 <p style={{fontSize:18}}><strong>216 separates vector changes from readout geometry. 217 tests one oracle receiver reset at each of five depths.</strong></p>
 <Text>15 October 2026 · all64old208 contexts · pinned Qwen2.5-1.5B-Instruct · MPS Float32/eager/eval · related synthetic templates · retrospective and oracle diagnostics</Text>
 <p>All finite-head effects are measured through the actual readout. Original whole-block coordinate Jacobian qualification remains false. Oracle resets do not establish prospective prediction or a learned circuit.</p>
 <H2>216: compare vectors at a common fixed readout</H2>
 <Table headers={["Fixed readout / vector source","Median finite margin change (nats)","Positive / negative out of64","Median initial gradient projection (nats)"]} rows={D.cross_summaries.map((r:any)=>[baseNames[r.base]+" / "+r.vector,fmt(r.median_finite_margin_change),r.positive_finite+" / "+r.negative_finite,fmt(r.median_initial_projection)])}/>
 <Table headers={["Comparison","Sign disagreements /64"]} rows={[
 ...Object.keys(D.cross_signs).map(k=>["Native vs forecast vectors; same "+baseNames[k]+" base",String(D.cross_signs[k])]),
 ...Object.keys(D.same_vector_signs).map(k=>["Same "+k+" vector; change native-FL to forecast-FL base",String(D.same_vector_signs[k])])
 ]}/>
 <p>All32descriptive-schema cases retain opposite vector effects at every fixed base. Off-diagonal evaluations are vector transplants, not primitive recomputations at those bases. Readout changes still affect magnitudes; symmetric crossed accounting is not a unique causal allocation.</p>
 <H2>217: one reset, then resume the original approximation</H2>
 <Text>Boundary k means k completed blocks. Only receiving rows are reset to native observations; the exact known Boolean source and False prefix stay fixed. Each later update actually recomputes the False-state receiver JVP plus the independently cached finite-source response.</Text>
 <Table headers={["Oracle reset after k blocks","Incoming receiver error at27 (median ratio)","Common-base product effect (median nats)","Native-like sign >.02 /64","Natural product improves BOTH /64"]} rows={D.reset_summaries.map((r:any)=>[String(r.boundary),fmt(r.median_incoming_receiving_relative_l2),fmt(r.median_common_product_margin_change),r.diagnostics.common_sign_restored_guard+"/64",r.diagnostics.natural_product_both_improve+"/64"])}/>
 <p>The .02-nat sign guard is a diagnostic, separate from prediction accuracy. The five boundaries are a coarse registered grid. Earliest tested success cannot identify the exact error-onset layer or distinguish new nonlinear error from amplification.</p>
 <Table headers={["Boundary / endpoint","Median verdict relative L2 error","Median margin-response error (nats)","Original joint passes /64"]} rows={D.reset_summaries.flatMap((r:any)=>["original","FF","finite"].map(a=>[r.boundary+" / "+armNames[a],fmt(r.arms[a].median_verdict_relative_l2),fmt(r.arms[a].median_absolute_margin_error),r.arms[a].primary_passes+"/64"]))}/>
 <H2>Inspect one matched context and reset</H2>
 <div style={{display:"flex",gap:18,flexWrap:"wrap",margin:"12px 0"}}>
 <label>Reset boundary <Select value={depth} onChange={setDepth} options={[0,8,16,24,27].map(k=>({value:String(k),label:String(k)+" completed blocks"}))}/></label>
 <label>Context <Select value={index} onChange={setIndex} options={cases.map((r:any,i:number)=>({value:String(i),label:r.group.block+" · "+r.group.schema+" · order "+r.group.reverse+" · assignment/target "+r.group.assignment+"/"+r.group.target}))}/></label>
 </div>
 <Table headers={["Selected endpoint","Verdict relative L2 error","Cosine","Margin error (nats)","Original joint pass"]} rows={["original","FL","FF","finite"].map(a=>{const v=c.arms[a];return[armNames[a],fmt(v.q),fmt(v.cosine),fmt(v.margin),String(v.pass_)];})}/>
 <Text>Receiving correction norm: {fmt(c.correction.norm)} residual units; signed projection toward native-minus-FL error: {fmt(c.correction.signed_projection)}. Natural finite margin change: {fmt(c.natural_margin)} nats; same correction at fixed native-FL base: {fmt(c.common_margin)} nats.</Text>
 <Table headers={["216 selected context: base / vector","Finite margin change (nats)","Initial gradient projection","Finite minus initial"]} rows={cross.map((r:any)=>[baseNames[r.base]+" / "+r.vector,fmt(r.finite_margin_change),fmt(r.initial_projection),fmt(r.finite_minus_initial)])}/>
 <H2>Prespecified panel criteria</H2>
 <Table headers={["Boundary / criterion","Whole-test pass","Passing four-cell panels: generic order0 /1; descriptive order0 /1"]} rows={D.whole.filter((r:any)=>String(r.boundary)===depth).map((r:any)=>[r.category+" / "+r.metric,String(r.passed),r.strata.map((s:any)=>s.schema+"/"+s.reverse+": "+s.passing_panels+"/4").join("; ")])}/>
 <p>Each panel needs all four assignment/target cells; whole-test success needs at least3/4panels in EVERY schema/order stratum. Original accuracy bounds: native verdict norm≥.001, relativeL2≤.05, cosine≥.99, margin error≤.10nats. Native-input entire-finite28 results are trivial controls.</p>
 <H2>Numerical checks and retained limitations</H2>
 <Table headers={["Executed check","Observed result"]} rows={[
 ["216 finite-head checks",checks.cross_controls+"pass; self state/score max "+fmt(checks.cross_self_state)+" / "+fmt(checks.cross_self_score)],
 ["216 closedform vs first reverse", "Gradientcoordinate max "+fmt(checks.cross_gradient_coordinate)+"; contraction max "+fmt(checks.cross_gradient_contract)],
 ["217 required controls",checks.reset_controls+"pass; coordinate/score maxima "+fmt(checks.reset_coordinate)+" / "+fmt(checks.reset_score)],
 ["217 actual primitive derivative checks",checks.reset_local+"pass; max "+fmt(checks.reset_local_max)],
 ["217 retained JVP reverse projections",checks.reset_reverse+"pass; max "+fmt(checks.reset_reverse_max)+"; scalarchecks are not a whole-coordinate certificate"],
 ["217 saved update reconstruction","Max coordinate "+fmt(checks.reset_update)],
 ["217 second implementation","80whole-model forward-AD replays: all5resets in16registered marzipan contexts"],
 ["Preserved failures","216original auditor serialization failure, original whole-Jacobian and rawmixed equality failures remain recorded; 204 scope unchanged"]
 ]}/>
 <p>One reset can localize sensitivity to the incoming computation without identifying a learned feature or proving a unique mechanism. Fresh prospective work requires a separately frozen False-state-only rule; native resets cannot supply it. No browser, publication or push was used.</p>
 </main>;
}
'''
    content=template.replace("__DATA__",json.dumps(data,separators=(",",":")))
    DEST.write_text(content)
    (ROOT/".context/receiver-state-mechanism-216-217.canvas.tsx").write_text(content)
    print(DEST)


if __name__=="__main__":main()
