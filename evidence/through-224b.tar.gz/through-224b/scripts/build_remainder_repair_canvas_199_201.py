"""Offline paired diagnosis versus genuinely heldout False-only repair results."""

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def main():
    discovery = json.loads(
        (ROOT / "docs/analysis/199-layerwise-remainder-summary.json").read_text()
    )
    audit = json.loads((ROOT / "docs/analysis/201-independent-audit.json").read_text())
    numerical = json.loads((ROOT / "docs/analysis/201-numerical-recheck.json").read_text())
    summary = json.loads((ROOT / "docs/analysis/201-ranked-repair-summary.json").read_text())
    assert audit["numerical_qualified"] and all(audit["controls"].values()) and numerical["passed"]
    assert audit["fingerprint"] == numerical["fingerprint"] == summary["fingerprint"]
    data = {
        "discovery": discovery,
        "repair": summary,
        "cases": audit["cells"],
        "numeric": {k: v for k, v in numerical.items() if k != "checks"},
    }
    code = r"""import { H1,H2,Text,Table,BarChart,LineChart,Select,useState,useHostTheme } from "cursor/canvas";
const DATA=__DATA__;
const ARMS=["source_linear","exact_readout","residual_blocks","margin_blocks","union_blocks","control_blocks"];
const fmt=(x:number|null)=>x===null?"undefined":x.toPrecision(5);
export default function RemainderRepair(){
 const theme=useHostTheme();
 const [schema,setSchema]=useState("generic");
 const [order,setOrder]=useState("0");
 const [arm,setArm]=useState("union_blocks");
 const [cell,setCell]=useState("0");
 const filtered=DATA.cases.filter(c=>c.schema===schema&&String(c.reverse)===order);
 const chosen=filtered.filter(c=>c.arm===arm);
 const item=chosen[Number(cell)]||chosen[0];
 const baseline=filtered.find(c=>c.arm==="source_linear"&&c.block===item.block&&c.assignment===item.assignment&&c.target===item.target)!;
 const ranks=DATA.discovery.all_blocks;
 return <main style={{padding:24,maxWidth:1180,margin:"auto",background:theme.bg.editor,color:theme.text.primary}}>
  <H1>Remainder analysis and held-out counterfactual prediction</H1>
  <p style={{fontSize:18}}>The error budgets closed. The discovery-ranked repair failed all registered native matching and joint-progress accounts: <strong>0/16panels for every arm.</strong></p>
  <Text>199retrospective diagnosis ·201newFalse-only forecasts ·14Oct2026UTC /15OctIST · one pinned Qwen1.5B checkpoint</Text>
  <H2>Different objectives rank different nonlinear remainder blocks</H2>
  <BarChart categories={ranks.map(r=>String(r.block))} height={270} series={[
   {name:"Mean |residual-error projection contribution| / error norm",data:ranks.map(r=>r.mean_abs_normalized_residual_contribution),tone:"neutral"},
   {name:"Mean |margin-error contribution| / max(|error|,0.1nats)",data:ranks.map(r=>r.mean_abs_normalized_margin_contribution),tone:"info"}
  ]}/>
  <Text>Horizontal axis: transformer block2–28. Vertical axis: normalized absolute contribution (ratio). Means across64dependent OLD193pairs; source:199paired diagnosis. Contributions can cancel; ratios are ranking statistics, not causal fractions. Initial exact displacement and final-error direction are oracle quantities here.</Text>
  <p>Residual projection selects18/21; margin projection selects16/18. The registered union is16/18/21; equal-budget low-ranked controls are3/7/27. The two scalar error budgets include a separate nonlinear final readout remainder for margin.</p>
  <Table headers={["Verified199diagnostic quantity","Maximum discrepancy","Scope"]} rows={[
   ["Margin error budget",fmt(DATA.discovery.maximum_margin_budget_error)+" nats","64/64 within frozen bound"],
   ["Residual-error projection budget",fmt(DATA.discovery.maximum_residual_projection_budget_error)+" hidden units","64/64 within frozen bound"],
   ["Local forward/reverse contractions",fmt(DATA.discovery.maximum_duality_error),"3456/3456 within 0.001+0.0001|reference|"],
   ["Median readout remainder",fmt(DATA.discovery.median_readout_remainder_nats)+" nats","One normalization/readout function"]
  ]}/>
  <H2>Prospective repair on64new Boolean-prefix pairs</H2>
  <p>Known embedding edit and finite first-block computation generate the starting displacement fromFalse; this control is not obtained from nativeTrue observations. Selected later blocks use known finite functions at their <em>predicted</em> inputs. Every other transition uses a nativeFalse Jacobian. All384arm forecasts were globally sealed before any new nativeTrue trajectory.</p>
  <Table headers={["Arm","Individual margin panels","Final residual panels","Joint-progress panels","Whole account"]} rows={ARMS.map(a=>[
   a,DATA.repair.accounts.individual_matching[a].compatible_panels+"/16",DATA.repair.accounts.residual_matching[a].compatible_panels+"/16",DATA.repair.accounts.prospective_progress[a].compatible_panels+"/16",DATA.repair.accounts.individual_matching[a].whole_passed?"PASS":"FAIL"
  ])}/>
  <BarChart categories={ARMS} horizontal height={320} series={[{name:"Median final-verdict relativeL2 error",data:ARMS.map(a=>DATA.repair.all_arms[a].final_relative_error.median),tone:"neutral"}]} referenceLines={[{value:0.05,label:"Native vector bound"}]}/>
  <Text>Horizontal axis: relative displacement error (ratio); vertical axis: repair arm. Medians across64dependent NEW201pairs. Source:201independent-audit.json;14OctUTC/15OctIST. Vector matching also requires cosine≥0.99 and norm≥0.001 in everycell.</Text>
  <H2>Inspect a held-out trajectory</H2>
  <div style={{display:"flex",gap:12,flexWrap:"wrap",margin:"12px 0"}}>
   <label>Schema <Select value={schema} onChange={setSchema} options={[{value:"generic",label:"Generic"},{value:"descriptive",label:"Descriptive"}]}/></label>
   <label>Order <Select value={order} onChange={setOrder} options={[{value:"0",label:"Original"},{value:"1",label:"Reversed"}]}/></label>
   <label>Repair <Select value={arm} onChange={setArm} options={ARMS.map(a=>({value:a,label:a}))}/></label>
   <label>Cell <Select value={cell} onChange={setCell} options={chosen.map((c,i)=>({value:String(i),label:c.block+" · assignment"+c.assignment+" · target"+c.target}))}/></label>
  </div>
  <LineChart categories={Array.from({length:28},(_,i)=>String(i+1))} height={280} series={[
   {name:"Finite source +False-linear tail",data:baseline.all28_verdict_relative_errors.map(v=>v!),tone:"neutral"},
   {name:arm,data:item.all28_verdict_relative_errors.map(v=>v!),tone:"info"}
  ]} referenceLines={[{value:0.05,label:"Registered vector-error bound"}]}/>
  <Text>Horizontal axis: transformer block1–28. Vertical axis: verdict-row relative displacement error (ratio). Source:201sealed forecasts versus later nativeTrue observations; cosine/norm requirements are separate.</Text>
  <Table headers={["Quantity","Baseline","Selected arm"]} rows={[
   ["Final relative error",fmt(baseline.final.relative_error),fmt(item.final.relative_error)],
   ["Final cosine",fmt(baseline.final.cosine),fmt(item.final.cosine)],
   ["Predicted margin change (nats)",fmt(baseline.predicted_delta_margin),fmt(item.predicted_delta_margin)],
   ["Observed margin change (nats)",fmt(baseline.actual_delta_margin),fmt(item.actual_delta_margin)],
   ["Margin error, predicted−observed (nats)",fmt(baseline.margin_error),fmt(item.margin_error)]
  ]}/>
  <H2>What remains unresolved</H2>
  <p>The diagnosis used native counterfactual inputs. The prospective finite blocks received predicted inputs that can already be wrong. Input-state dependence is an open explanation of the failed repair, not an established mechanism. Correcting source generation in blockone also leaves subsequent nonlinear encoding at the source untested.</p>
  <p style={{color:theme.text.secondary}}>201code-path verification passed:48whole-model hook reconstructions matched stored states exactly; maximum score discrepancy {fmt(DATA.numeric.maximum_hook_score_error)}, standard reverse baseline maximum discrepancy {fmt(DATA.numeric.maximum_reverse_contraction_error)}. Independent structure shares the forward-AD backend; standard reverse checks cover source_linear. The original196primitive reverse-over-reverse disagreement remains unresolved. 200/201preflight wiring failures are preserved. One smallcheckpoint, dependent templates, earlier grounding failures; no reliable-verifier failure, unique learned feature, novelty priority, or solvedQuestionB claim. No publication or push.</p>
  <Text>199fingerprint: {DATA.discovery.fingerprint} ·201fingerprint: {DATA.repair.fingerprint}</Text>
 </main>;
}
""".replace("__DATA__", json.dumps(data, separators=(",", ":")))
    (ROOT / ".context/remainder-repair-canvas-code.txt").write_text(code)
    (ROOT / ".context/remainder-repair-canvas-data.json").write_text(json.dumps(data))
    print(f"199/201viewer prepared: {len(audit['cells'])}cases; {len(code)}characters")


if __name__ == "__main__":
    main()
