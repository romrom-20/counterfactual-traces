"""Presentation-only offline viewer; embed audited data and every fixed arm."""

import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
DEST=Path("/Users/samanseshadri/.cursor/projects/Users-samanseshadri-conductor-workspaces-training-jev-v1-bucharest/canvases/rms-product-transfer-212-215.canvas.tsx")


def compact_endpoint(e):
    v=e.get("verdict",e.get("final",{}).get("verdict"))
    return dict(q=v["relative_l2"],margin=e["absolute_margin_error"],passed=e["primary_pass"])


def main():
    x=json.loads((ROOT/"docs/analysis/212-rms-product-factorial.json").read_text())
    a=json.loads((ROOT/"docs/analysis/213-gate-up-arithmetic-audit.json").read_text())
    y=json.loads((ROOT/"docs/analysis/214-last-block-transfer.json").read_text())
    z=json.loads((ROOT/"docs/analysis/215-matched-incoming-control.json").read_text())
    signs=json.loads((ROOT/"docs/analysis/215b-paired-readout-signs.json").read_text())
    schema=json.loads((ROOT/"docs/analysis/215c-schema-readout-regimes.json").read_text())
    data=dict(factorial=[s for s in x["strata"] if s["field"] is None],geometry=x["geometry_summary"],
        cases=[dict(key=r["key"],group=r["group"],branch=r["branch"],background=r["background"],
                    endpoints={k:compact_endpoint(e) for k,e in r["endpoints"].items()},effects=r["effects"],conditional=r["conditional"],margins=r["margin_effects"]) for r in x["rows"]],
        transfer=y["strata"][0],transfer_whole=y["whole"],matched=[s for s in z["strata"] if s["field"] is None],paired_signs=signs["summary"],schema_regimes=schema["rows"],
        checks=dict(factorial_controls=x["controls"],factorial_derivatives=x["local_derivative_checks"],readout=x["readout_gradient_checks"],
            mixed_closure=x["maximum_mixed_interaction_closure"],raw_mixed_failures=x["raw_mixed_agreement_failures"],
            affine_jvp_failures=x["affine_LL_original_JVP_failures"],affine_jvp_max=x["maximum_affine_LL_original_JVP_error"],
            product_closure=a["maximum_saved_vector_closure_error"],transfer_controls=y["controls"],transfer_derivatives=y["local_derivative_checks"],
            transfer_projections=y["reverse_projections"],transfer_jvp_failures=y["optional_LL_original_JVP_failures"],
            matched_controls=z["controls"],matched_derivatives=z["local_derivative_checks"]))
    template='''import {H1,H2,Text,Table,Select,useState,useHostTheme} from "cursor/canvas";
const D: any = __DATA__;
const arms=["LL","FL","LF","FF"];
const names: Record<string,string>={LL:"Neither finite",FL:"RMSNorm finite",LF:"Product finite",FF:"Both finite",finite:"Entire finite block (control)",source_linear_finite_head:"Source-linear / finite head",zero_displacement:"Zero displacement"};
const fmt=(x:number)=>Number.isFinite(x)?x.toPrecision(5):String(x);
export default function RmsProductTransfer(){
 const t=useHostTheme(); const [branch,setBranch]=useState("native"); const [bg,setBg]=useState("affine");const [index,setIndex]=useState("0");
 const s=D.factorial.find((r:any)=>r.branch===branch&&r.background===bg);
 const cases=D.cases.filter((r:any)=>r.branch===branch&&r.background===bg);const c=cases[Number(index)];
 const checks=D.checks;
 return <main style={{padding:24,maxWidth:1200,margin:"auto",background:t.bg.editor,color:t.text.primary}}>
 <H1>RMSNorm × gate–up product: local explanation and transfer boundary</H1>
 <p style={{fontSize:18}}><strong>Qualified finite interventions; original whole-block Jacobian remains unqualified.</strong></p>
 <Text>Source: experiments 212b, 213, 214/214b and 215 · 15 October 2026 · pinned Qwen2.5-1.5B-Instruct · Float32 MPS/eager · dependent synthetic templates · all new tests retrospective</Text>
 <p>The mixed gate–up contribution persists after MLP-input RMSNorm repair. Its local behavioral benefit does not transfer to the old 208 predictor. The matched incoming-state experiment tests this limitation within the same contexts.</p>
 <H2>212: four arms under two explicit backgrounds</H2>
 <div style={{display:"flex",gap:18,flexWrap:"wrap",margin:"12px 0"}}>
 <label>Incoming state <Select value={branch} onChange={setBranch} options={[{value:"native",label:"Native after block 27"},{value:"linear27",label:"Block-27-linear"}]}/></label>
 <label>Fixed background <Select value={bg} onChange={setBg} options={[{value:"affine",label:"Other primitives False-affine"},{value:"finite",label:"Other primitives finite"}]}/></label>
 </div>
 <Table headers={["RMSNorm / product arm","Median verdict residual error (ratio)","Median absolute margin error (nats)","Joint passes / 64"]} rows={arms.map(a=>{const e=s.endpoints[a];return[names[a],fmt(e.median_verdict_relative_l2),fmt(e.median_absolute_margin_error),e.primary_passes+"/64"];})}/>
 <p>Letters are ordered RMSNorm, then product. L is a False-anchored affine primitive and F the finite primitive. In the finite background, native-input FF is the ordinary native block: its perfect result is a trivial control. In the affine background, LL is a defined surrogate; it is not certified equal to the original MPS Jacobian.</p>
 <Table headers={["Product correction","Residual improves / 64","Margin improves / 64","Both improve / 64"]} rows={["gate_before_rms","gate_after_rms"].map(k=>[k==="gate_before_rms"?"Before RMSNorm repair: LF − LL":"After RMSNorm repair: FF − FL",s.conditional[k].residual_improves+"/64",s.conditional[k].margin_improves+"/64",s.conditional[k].both_improve+"/64"])}/>
 <Text>Median receiver product-effect norm ratio after/before RMS repair: {fmt(s.gate.median_receiving_norm_ratio)}. Signed interaction I = FF − FL − LF + LL; norms are not explanatory fractions.</Text>
 <H2>Inspect a complete context</H2>
 <label>Context <Select value={index} onChange={setIndex} options={cases.map((r:any,i:number)=>({value:String(i),label:r.group.block+" · "+r.group.schema+" · order "+r.group.reverse+" · assignment/target "+r.group.assignment+"/"+r.group.target}))}/></label>
 <Table headers={["Endpoint","Verdict residual error","Margin error (nats)","Original joint pass"]} rows={["original_jvp",...arms,...arms.map(a=>a+"_anchor")].map(a=>{const e=c.endpoints[a];return[a,fmt(e.q),fmt(e.margin),String(e.passed)];})}/>
 <Text>Anchor endpoints insert measured receiving-row arm-minus-LL contrasts into the original 209c forecast. They are oracle repairs, distinct from running the raw surrogate.</Text>
 <Table headers={["Signed receiving vector","Norm (residual units)","Projection toward native-minus-LL error","Projection toward local FF-minus-LL error"]} rows={["rms","gate","interaction","gate_after_rms"].map(k=>{const e=c.effects[k].receivers;return[k,fmt(e.toward_native.norm),fmt(e.toward_native.signed_projection),fmt(e.toward_local.signed_projection)];})}/>
 <H2>212: opposite readout signs, measured through a finite head</H2>
 <Table headers={["Correction / base","Finite margin change (nats; median)","Initial gradient projection (nats; median)","Finite minus projection (median)","Margin improves / 64"]} rows={D.geometry.filter((r:any)=>r.branch===branch).map((r:any)=>[r.vector+" / "+r.base,fmt(r.median_finite_margin_change),fmt(r.median_initial_gradient_projection),fmt(r.median_finite_minus_initial_projection),r.error_improves+"/64"])}/>
 <p>The same SiLU vector lowers the margin at all three bases. At the original forecast it worsens error; at its own native lesioned endpoint it restores native output. That is a context-dependent correction, not an inherently harmful SiLU mechanism. Product corrections raise the margin. Readout curvature is separately measured.</p>
 <H2>214: fixed correction fails retrospective transfer to 208</H2>
 <Table headers={["Fixed correction / baseline","Median verdict residual error","Median margin error (nats)","Both improve original / 64","Joint / partial passes"]} rows={[...arms,"source_linear_finite_head","zero_displacement"].map(a=>{const e=D.transfer.arms[a];return[names[a],fmt(e.median_verdict_relative_l2),fmt(e.median_absolute_margin_error),e.both_improve+"/64",e.primary_passes+" / "+e.partial_progress_passes];})}/>
 <p>E_A = E_old + receiving[(T_A−T_LL)(full predicted input) − (T_A−T_LL)(source-only input)]. This subtracts the new source-only contrast; it does not establish exact replacement of the original source/receiver update. All candidates were sealed before this run opened native observations; 208 had already been observed in earlier work.</p>
 <H2>215: matched context, native versus forecast receiving states</H2>
 {D.matched.map((m:any)=><section key={m.branch} style={{marginBottom:22}}>
 <p><strong>{m.branch==="native"?"Native incoming state (oracle)":"Forecast incoming state"}</strong> · median incoming receiver relative error {fmt(m.median_incoming_receiving_relative_l2)}</p>
 <Table headers={["Endpoint","Median verdict residual error","Median margin error (nats)","Both improve LL /64","Joint passes /64"]} rows={[...arms,"finite"].map(a=>{const e=m.arms[a];return[names[a],fmt(e.median_verdict_relative_l2),fmt(e.median_absolute_margin_error),e.both_improve_LL+"/64",e.primary_passes+"/64"];})}/>
 <Table headers={["Conditional product effect","Residual improves /64","Margin improves /64","Both improve /64","Median signed margin change (nats)"]} rows={["gate_before_rms","gate_after_rms"].map(k=>{const e=m.conditional[k];return[k,e.residual_improves+"/64",e.margin_improves+"/64",e.both_improve+"/64",fmt(e.median_finite_margin_change)];})}/>
 </section>)}
 <Text>Post-hoc paired description after RMSNorm repair: {D.paired_signs.gate_after_rms.raw_sign_flips}/64 product-effect sign reversals; {D.paired_signs.gate_after_rms.native_positive_and_predicted_negative_beyond_002}/64 have native change above +.02 nats and forecast change below −.02 nats. This guard does not change any accuracy criterion.</Text>
 <Table headers={["Post-hoc schema / order / input","Median signed product margin change (nats)","Positive / negative out of 16","Incoming receiver relative error (median)"]} rows={D.schema_regimes.map((r:any)=>[r.schema+" / "+r.order+" / "+r.branch,fmt(r.median_product_margin_change),r.positive+" / "+r.negative,fmt(r.median_incoming_receiver_error)])}/>
 <Text>All 32 descriptive-schema pairs reverse sign after RMS repair; 7/32 generic pairs do so. These are post-hoc descriptive strata in related templates, not a fresh predictive rule.</Text>
 <H2>Checks and preserved failures</H2>
 <Table headers={["Check","Observed result"]} rows={[
 ["212 finite controls / local derivatives / readout gradients",checks.factorial_controls+" / "+checks.factorial_derivatives+" / "+checks.readout+" pass"],
 ["212 signed interaction = mixed-term change + measured rounding","Max coordinate closure "+fmt(checks.mixed_closure)],
 ["213 measured arithmetic account","Max saved-vector closure "+fmt(checks.product_closure)+"; old 211c equality failure remains"],
 ["212 raw mixed-term coordinate equality",checks.raw_mixed_failures+"/512 FAIL at unchanged 1e-4"],
 ["212 affine LL vs original Jacobian",checks.affine_jvp_failures+"/128 FAIL; max "+fmt(checks.affine_jvp_max)],
 ["214 controls / actual local derivatives / reverse projections",checks.transfer_controls+" / "+checks.transfer_derivatives+" / "+checks.transfer_projections+" pass"],
 ["214 LL-receiver compatibility with original J",checks.transfer_jvp_failures+"/64 FAIL at unchanged 1e-4"],
 ["215 controls / local derivatives",checks.matched_controls+" / "+checks.matched_derivatives+" pass"],
 ["Technical corrections","212 serialization-only correction; 214 auditor count-only correction. Original failed attempts preserved."],
 ["204 and replacement-agent scope","204 remains qualified retrospective reset diagnostic; invalid replacement conclusions remain invalid."]
 ]}/>
 <p>Original joint bounds: native norm ≥ .001, verdict relative L2 ≤ .05, cosine ≥ .99, margin error ≤ .10 nats. Whole tests require all four cells per panel and ≥3/4 panels in every schema/order stratum. Neither a learned circuit nor general Question B is established. No publication or push. No literature priority assessment was made in this browser-free continuation.</p>
 </main>;
}
'''
    content=template.replace("__DATA__",json.dumps(data,separators=(",",":")))
    DEST.write_text(content)
    (ROOT/".context/rms-product-transfer-212-215.canvas.tsx").write_text(content)
    print(DEST)


if __name__=="__main__":main()
