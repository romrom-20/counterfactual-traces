"""Offline viewer of all audited SiLU replacement conditions."""

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DEST = Path("/Users/samanseshadri/.cursor/projects/Users-samanseshadri-conductor-workspaces-training-jev-v1-bucharest/canvases/silu-range-falsification-218.canvas.tsx")


def main():
    obj = json.loads((ROOT / "docs/analysis/218-silu-range-falsification-audit.json").read_text())
    assert obj["qualified"]
    template = '''import {H1,H2,Text,Table,Select,useState,useHostTheme} from "cursor/canvas";
const D:any=__DATA__;
const fmt=(x:number|null)=>x===null?"undefined":Number.isFinite(x)?x.toPrecision(6):String(x);
const name=(s:string)=>s==="L"?"False-affine SiLU":"Real finite SiLU";
export default function SiLURange(){
 const t=useHostTheme();const [index,setIndex]=useState("0");
 const keys=[...new Set<string>(D.rows.map((r:any)=>r.key))];const key=keys[Number(index)];
 const rows=D.rows.filter((r:any)=>r.key===key);const group=rows[0].group;
 return <main style={{padding:24,maxWidth:1200,margin:"auto",background:t.bg.editor,color:t.text.primary}}>
 <H1>Impossible gate values do not explain the reversal</H1>
 <p style={{fontSize:18}}><strong>Real SiLU eliminates range violations, while the same 39 natural-effect sign reversals persist.</strong></p>
 <Text>Source: experiment 218 saved-array audit · 15 October 2026 · all 64 related old 215 contexts · Qwen2.5-1.5B-Instruct · MPS Float32/eager/eval</Text>
 <p>Both incoming states use finite MLP-input RMSNorm. Attention nonlinearities remain False-affine. SiLU and product are crossed independently. This tests replacing the whole SiLU response, rather than clipping alone. It does not establish a native learned circuit or prospective predictor.</p>
 <H2>The matched comparisons</H2>
 <Table headers={["Incoming state / SiLU", "Below-bound receiver coordinates", "Minimum gate activation (units)", "Natural product effect (median nats)", "Negative cases /64", "Both errors improve /64"]} rows={D.summaries.map((r:any)=>[
 r.branch+" / "+name(r.silu),r.receiver_coordinates_below_minimum.toLocaleString(),fmt(r.minimum_phi),fmt(r.median_natural_margin_change),String(64-r.natural_positive),String(r.product_both_improve)
 ])}/>
 <p>Analytic SiLU minimum: {fmt(D.silu_minimum)}. A range violation needs activation below this minimum minus 1e-4. Sign is the signed true-minus-false margin change; positive does not automatically mean a better native prediction.</p>
 <Table headers={["SiLU", "Native / forecast sign disagreements, natural /64", "Disagreements at the same False readout /64"]} rows={["L","F"].map(s=>[name(s),String(D.native_predicted_sign_disagreements[s].natural_margin_change),String(D.native_predicted_sign_disagreements[s].common_margin_change)])}/>
 <p>The common-readout comparison transplants only receiving rows into the same False final state. It tests correction vectors at that readout; it is not a primitive recomputation at False. Absolute gate/up signs differ from signs of their increments and from readout-weighted contributions.</p>
 <H2>Inspect every matched case</H2>
 <Select value={index} onChange={setIndex} options={keys.map((k:string,i:number)=>{const g=D.rows.find((r:any)=>r.key===k).group;return {value:String(i),label:g.block+" · "+g.schema+" · order "+g.reverse+" · assignment/target "+g.assignment+"/"+g.target};})}/>
 <Text>Selected: {group.block}, {group.schema} schema, order {group.reverse}, assignment {group.assignment}, target {group.target}.</Text>
 <Table headers={["State / SiLU", "Natural finite effect (nats)", "Common-base finite effect (nats)", "Initial common-base gradient projection (nats)", "Finite minus initial (nats)"]} rows={rows.map((r:any)=>[r.branch+" / "+name(r.silu),fmt(r.natural_margin_change),fmt(r.common_margin_change),fmt(r.initial_projection),fmt(r.finite_minus_initial)])}/>
 <Table headers={["State / SiLU", "Below-bound receiver coordinates", "Absolute negative gate × negative up", "Total receiver coordinates"]} rows={rows.map((r:any)=>{const z=r.regimes.receivers;return [r.branch+" / "+name(r.silu),String(z.below_silu_minimum_guard),String(z.negative_negative),String(z.coordinates)];})}/>
 <H2>Actual accuracy endpoints, including failures</H2>
 <Text>Arm letters are SiLU then product: L means False-affine, F means finite. These are all four endpoints for each selected input, evaluated against the native target.</Text>
 <Table headers={["State / SiLU-product arm", "Verdict relative L2 error", "Verdict cosine", "Absolute margin error (nats)", "Original joint pass"]} rows={rows.filter((r:any)=>r.silu==="L").flatMap((r:any)=>["LL","LF","FL","FF"].map(a=>{const e=r.endpoints[a];return [r.branch+" / "+a,fmt(e.verdict.relative_l2),fmt(e.verdict.cosine),fmt(e.absolute_margin_error),String(e.primary_pass)];}))}/>
 <p>No arm passes the joint criterion in any of the 64 contexts. Bounds remain native verdict norm ≥.001, relative L2 ≤.05, cosine ≥.99 and margin error ≤.10 nats. These dependent contexts are not 64 independent replications.</p>
 <H2>Qualification and unresolved issues</H2>
 <Table headers={["Executed check", "Result"]} rows={[
 ["Required controls / local primitive checks",D.controls+" / "+D.local_derivative_checks+" passed"],
 ["Actual model operations",D.counts.blocks+" blocks; "+D.counts.finite_heads+" finite heads; "+D.counts.reverse_heads+" first reverse head gradients"],
 ["Maximum local derivative discrepancy",fmt(D.maximum_local_derivative_error)+" (bound 1e-4)"],
 ["Maximum readout gradient coordinate / contraction discrepancy",fmt(D.maximum_gradient_coordinate_error)+" / "+fmt(D.maximum_gradient_contraction_error)],
 ["Raw mixed-term equality", "256/256 comparisons fail the original 1e-4 bound; failures retained"],
 ["Measured rounding reconstruction", "Maximum closure error "+fmt(D.maximum_saved_rounding_closure)],
 ["Original whole-block Jacobian coordinate qualification",String(D.original_wholeblock_jacobian_qualified)+"; not repaired by these checks"]
 ]}/>
 <p>216–217 separately found fixed-readout vector contrasts and fresh error after exact receiver resets. 218 excludes one explanation for those contrasts in the specified surrogate. Why the earlier False-state approximation generates the wrong response direction remains open.</p>
 <p>Goodfire's first-party essay suggested a sign-regime lead. Its broad legibility claims and learned feature interpretations are not conclusions of this experiment. No outside paper search informed this test. No publication or push.</p>
 </main>;
}
'''
    content = template.replace("__DATA__", json.dumps(obj, separators=(",", ":")))
    DEST.write_text(content)
    (ROOT / ".context/silu-range-falsification-218.canvas.tsx").write_text(content)
    print(DEST)


if __name__ == "__main__":
    main()
