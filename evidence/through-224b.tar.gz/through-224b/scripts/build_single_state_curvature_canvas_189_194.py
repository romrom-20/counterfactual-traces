"""Offline embedded viewer of all qualified cuts and genuinely single-state forecasts."""

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def main():
    data = []
    for stage in (189, 190, 191, 193, 194):
        a = json.loads((ROOT / f"docs/analysis/{stage}-independent-audit.json").read_text())
        n = json.loads((ROOT / f"docs/analysis/{stage}-numerical-recheck.json").read_text())
        assert (
            a["numerical_qualified"]
            and all(a["controls"].values())
            and n["passed"]
            and a["fingerprint"] == n["fingerprint"]
        )
        accounts = []
        if stage in (191, 194):
            for metric, arms in a["accounts"].items():
                for arm, v in arms.items():
                    accounts.append(
                        [
                            metric.replace("_", " ") + " · " + arm,
                            f"{v['compatible_panels']}/16",
                            "PASS" if v["whole_passed"] else "FAIL",
                            str(v["strata"]),
                        ]
                    )
        else:
            for metric, v in a["accounts"].items():
                den = 8 if "compatible_comparisons" in v else 16
                accounts.append(
                    [
                        metric.replace("_", " "),
                        f"{v.get('compatible_panels', v.get('compatible_comparisons'))}/{den}",
                        "PASS" if v["whole_passed"] else "FAIL",
                        str(v["strata"]),
                    ]
                )
        cases = a["cells"]
        if stage == 194:
            lookup = {
                tuple(
                    r[k] for k in ("block", "schema", "reverse", "assignment", "target", "arm")
                ): r
                for r in a["residual_cells"]
            }
            cases = [
                {
                    **c,
                    "residual": {
                        arm: lookup[
                            tuple(
                                c[k] for k in ("block", "schema", "reverse", "assignment", "target")
                            )
                            + (arm,)
                        ]
                        for arm in ("all_T1", "all_Q2", "all_C3", "source_C3", "receiver_C3")
                    },
                }
                for c in cases
            ]
        if stage in (189, 190):
            geom = json.loads(
                (ROOT / f"docs/analysis/{stage}-norm-readout-cancellation.json").read_text()
            )
            assert geom["fingerprint"] == a["fingerprint"]
            geo = {
                tuple(c[k] for k in ("block", "schema", "reverse", "assignment", "target")): c
                for c in geom["cells"]
            }
            cases = [
                {
                    **c,
                    "geometry": {
                        k: {p: v[p] for p in ("projection_kappa", "scale_kappa")}
                        for k, v in geo[
                            tuple(
                                c[k] for k in ("block", "schema", "reverse", "assignment", "target")
                            )
                        ]["decomposition"].items()
                    },
                }
                for c in cases
            ]
        data.append(
            {
                "id": str(stage),
                "cases": cases,
                "accounts": accounts,
                "controls": len(a["controls"]),
                "fingerprint": a["fingerprint"],
                "main": a.get("main_forwards"),
                "numerical": n.get("forwards"),
                "ordinary": a.get("ordinary_model_invocations"),
                "differentiated": a.get("differentiated_false_invocations"),
                "numericalOrdinary": n.get("ordinary_model_invocations"),
                "numericalDifferentiated": n.get("reverse_differentiated_invocations"),
                "cuts": list(cases[0]["kappa"]) if stage in (189, 190) else [],
            }
        )
    atlas = json.loads((ROOT / "docs/analysis/190-residual-source-atlas.json").read_text())
    assert atlas["fingerprint"] == data[1]["fingerprint"] and len(atlas["rows"]) == 3584
    atlas_rows = [
        {
            k: r[k]
            for k in (
                "block",
                "schema",
                "reverse",
                "assignment",
                "target",
                "cut",
                "layer",
                "last_token_bit_differential_shift_norm",
            )
        }
        for r in atlas["rows"]
    ]
    payload = {"experiments": data, "atlas": atlas_rows}
    code = r"""import {H1,H2,Text,Stack,Row,Grid,Select,Table,BarChart,LineChart,Callout,Code,useCanvasState,useHostTheme} from "cursor/canvas";
const PAYLOAD=__DATA__ as any;const DATA=PAYLOAD.experiments as any[];const f=(x:number)=>x.toFixed(6);
export default function CurvatureResponse(){
 const theme=useHostTheme();const [id,setId]=useCanvasState("curvature-stage","194");const d=DATA.find(x=>x.id===id)||DATA[4];
 const [src,setSrc]=useCanvasState("curvature-block","nectar");const sources=[...new Set(d.cases.map((c:any)=>c.block))] as string[];const source=sources.includes(src)?src:sources[0];
 const [schema,setSchema]=useCanvasState("curvature-schema","descriptive");const [rev,setRev]=useCanvasState("curvature-order","0");const [cell,setCell]=useCanvasState("curvature-cell","0:0");
 const contexts=d.cases.filter((c:any)=>c.block===source&&c.schema===schema&&c.reverse===Number(rev));const c=contexts.find((x:any)=>`${x.assignment}:${x.target}`===cell)||contexts[0];const cut=id==="189"||id==="190";
 const citation=`Source: qualified ${id} artifact/numerical audits · 14 October 2026 UTC · ${source}, ${schema}, sentence order ${rev}, assignment ${c.assignment}, question ${c.target}.`;
 const choices=[{value:"189",label:"189 · N/W/U factorial"},{value:"190",label:"190 · final / internal normalization"},{value:"191",label:"191 · false-calibrated SiLU; live receiver"},{value:"193",label:"193 · first-order native response from false only"},{value:"194",label:"194 · source / receiver nonlinear surrogate"}];
 const ar=PAYLOAD.atlas.filter((r:any)=>r.block===source&&r.schema===schema&&r.reverse===Number(rev)&&r.assignment===c.assignment&&r.target===c.target);
 const nr=contexts.filter((r:any)=>r.assignment===c.assignment&&r.target===c.target);const doses=[.125,.25,.5,1];
 return <Stack gap={18} style={{maxWidth:1180,margin:"0 auto",padding:24,color:theme.text.primary}}>
 <H1>Can one false computation predict the Boolean flip?</H1>
 <Text>The target is the native state-dependent residual displacement and verdict response. Diagnostic paired corrections, live-receiver approximations and single-state native forecasts answer different questions.</Text>
 <Callout tone="info">190 confirms a normalization-conditioned sign reversal in 16/16 panels, while both simple final-only and internal-only accounts fail.191's cubic SiLU map matches the balanced evidence response in 16/16 but no whole individual-preference panel.193 directly tests native displacement prediction without observing target-state computation during forecasting. The preserved192second-order attempt failed numerical qualification, with maximum0.1402 derivative-contraction discrepancy; its forecasts are excluded here.</Callout>
 <Callout tone="info">194 preserves balanced evidence only with the Boolean source encoder native: receiver_C3 passes14/16panels under the whole rule, source_C3 passes8/16 and all_C3 passes7/16, all descriptive. Every primary preference/residual account fails. Coefficients use False only, but this surrogate evaluates known counterfactual components; it is not derivative-only transport.</Callout>
 <Select value={d.id} onChange={setId} options={choices}/>
 <Grid columns={2} gap={24}><Stack gap={10}><H2>Verification and information boundary</H2><Text>{id==="193"?`${d.ordinary} ordinary + ${d.differentiated} differentiated main model invocations; ${d.numericalOrdinary} ordinary + ${d.numericalDifferentiated} reverse-differentiated numerical invocations. Derivative invocations have different costs.`:`${d.main} main + ${d.numerical} separate numerical full-model forwards.`} All {d.controls} artifact controls pass.</Text>
 <Text>{id==="193"?"All native-response derivatives and forecasts were saved before ANY true or finite-dose observation. Input change and weights are known; derivatives evaluated only at false. Native dose1 uses actual true input IDs. Smaller doses are continuous embedding diagnostics.":id==="194"?"All704 forecasts/False measurements precede ANY nativeTrue. Source=Boolean row; Receiver=strictly later rows; All=both. Normalization, attention, multiplication and live inputs are evaluated on surrogate counterfactual trajectories. This has a larger computation budget than193 and is not a compact circuit.":id==="191"?"All448 false measurements and forecasts were sealed before native true observation. Coefficients use false only, but receiving gate inputs, up, attention and norms stay live during mapped true forecasts.":"Maps and dense paired means use both native activation trajectories. C is a paired finite-difference diagnostic, not an independently generated learned signal.189 also references768 parent rows; they are not new executions."}</Text><Text size="sm" tone="secondary">One Qwen checkpoint, dependent day tasks, dense white-box access, failed grounding/specificity controls. No priority, complete learned circuit, training-origin or competent-verifier claim.</Text><Code>{d.fingerprint}</Code></Stack>
 <Stack gap={10}><H2>Every registered account</H2><Table headers={["Account","Panels","Whole result","Every stratum"]} rows={d.accounts}/><Text size="sm" tone="secondary">At least3/4 sources in EVERY schema/order; allfour relation cells per panel.193 native individual/residual accounts are primary; smaller doses and evidence balancing cannot rescue them.191 matching and retention are separately reported.</Text></Stack></Grid>
 <H2>Inspect every context</H2><Row gap={12} wrap><Select value={source} onChange={setSrc} options={sources.map(v=>({value:v,label:v}))}/><Select value={schema} onChange={setSchema} options={[{value:"generic",label:"Generic schema"},{value:"descriptive",label:"Descriptive schema"}]}/><Select value={rev} onChange={setRev} options={[{value:"0",label:"Original sentence order"},{value:"1",label:"Reversed sentence order"}]}/><Select value={`${c.assignment}:${c.target}`} onChange={setCell} options={[0,1].flatMap(a=>[0,1].map(t=>({value:`${a}:${t}`,label:`Assignment ${a}, question ${t}`})))}/></Row>
 {cut&&<Grid columns={2} gap={24}><Stack gap={8}><H2>Shared correction's Boolean-response shift</H2><Text size="sm">Y: kappa (nats). X: receiving factors held to paired means.</Text><BarChart categories={d.cuts} series={[{name:"True-minus-false C margin shift",data:d.cuts.map((k:string)=>c.kappa[k]),tone:"info"}]} valueSuffix=" nats" height={250}/><Text size="sm">N=all RMS scales;U=up;W=attention matrices;F=final RMS;I=internal RMS. live=none held. C effect compares P+C against P under the SAME cut.</Text><Text size="sm" tone="secondary">{citation} Individual cell, no averaging.</Text></Stack><Stack gap={8}><H2>One final-normalization product</H2><Text size="sm">Y: contribution to kappa (nats). X: operation cut.</Text><BarChart categories={Object.keys(c.geometry)} series={[{name:"Residual projection term",data:Object.values(c.geometry).map((v:any)=>v.projection_kappa),tone:"info"},{name:"Final RMS scale term",data:Object.values(c.geometry).map((v:any)=>v.scale_kappa),tone:"neutral"}]} height={250} valueSuffix=" nats"/><Text size="sm">The two terms are exact finite arithmetic of ONE normalization operation. Opposing terms are not competing learned mechanisms; this does not explain upstream displacement generation.</Text><Text size="sm" tone="secondary">{citation} Saved-state pinned-weight geometry; zero extra model calls.</Text></Stack></Grid>}
 {id==="190"&&<Stack gap={8}><H2>Layerwise state-dependent displacement from the same local source</H2><Text size="sm">Y: log10 displacement norm (residual units). X: receiving block1–28. Curves are true shift minus false shift at the final verdict position.</Text><LineChart categories={Array.from({length:28},(_,i)=>`${i+1}`)} series={[{name:"U · internal normalization live",data:ar.filter((r:any)=>r.cut==="U").map((r:any)=>Math.log10(r.last_token_bit_differential_shift_norm)),tone:"neutral"},{name:"IU · internal normalization fixed",data:ar.filter((r:any)=>r.cut==="IU").map((r:any)=>Math.log10(r.last_token_bit_differential_shift_norm)),tone:"info"}]} beginAtZero={false} height={270}/><Text size="sm" tone="secondary">{citation} Read-only190 residual atlas; observed shifts, not independent transport forecasts. Layer1 contains subtraction/rounding noise. The literal local source is D(C×meanUP), identical for both bits/cuts.</Text></Stack>}
 {id==="191"&&<Stack gap={8}><H2>False-state SiLU approximation: individual preference errors</H2><Text size="sm">Y: true-endpoint error (nats). X: polynomial order at false; target receiver stays live.</Text><BarChart categories={["T1","Q2","C3"]} series={[{name:"True forecast minus native true margin",data:["T1","Q2","C3"].map(k=>c.errors[k]),tone:"info"}]} valueSuffix=" nats" height={240}/><Table headers={["Arm","Native false (nats)","Native true (nats)","Predicted true (nats)","Error (nats)"]} rows={["T1","Q2","C3"].map(k=>[k,f(c.native[0]),f(c.native[1]),f(c.forecasts[k][1]),f(c.errors[k])])}/><Text size="sm" tone="secondary">{citation} Because false is exact, true-endpoint error equals bit-effect error. They are not independent confirmations.</Text></Stack>}
 {id==="193"&&<Grid columns={2} gap={24}><Stack gap={8}><H2>Native-response preference prediction versus dose</H2><Text size="sm">Y: Boolean-response margin shift (nats). X: known embedding-change dose (unitless).</Text><LineChart categories={doses.map(String)} series={[{name:"Observed native/dose response",data:doses.map(v=>nr.find((r:any)=>r.dose===v&&r.order===1).actual_delta_margin),tone:"neutral"},{name:"First-order false-state forecast",data:doses.map(v=>nr.find((r:any)=>r.dose===v&&r.order===1).predicted_delta_margin),tone:"info"}]} valueSuffix=" nats" height={270}/><Text size="sm" tone="secondary">{citation} Dose1 is the native Boolean flip. All predictions sealed before observed responses; other doses are diagnostic.</Text></Stack><Stack gap={8}><H2>Native displacement prediction at every layer</H2><Text size="sm">Y: relative L2 error at verdict position (unitless). X: block1–28; native dose1.</Text><LineChart categories={Array.from({length:28},(_,i)=>`${i+1}`)} series={[{name:"First-order false-state forecast",data:nr.find((r:any)=>r.dose===1&&r.order===1).all28_last_relative_errors,tone:"neutral"}]} height={270}/><Text size="sm" tone="secondary">{citation} Prospective tensor predictions; layerwise error locations are post-observation diagnostics, not fitted explanations.</Text></Stack></Grid>}
 {id==="193"&&<Table headers={["Dose","Order","Actual response (nats)","Forecast response (nats)","Error (nats)","Final residual relative error","Final residual cosine"]} rows={nr.map((r:any)=>[r.dose,r.order,f(r.actual_delta_margin),f(r.predicted_delta_margin),f(r.margin_error),f(r.last_relative_error),f(r.last_cosine)])}/>}

 {id==="194"&&<Stack gap={8}><H2>Source versus receiver approximation: every primary error</H2><Text size="sm">Y: individual Boolean-response error (nats). X: polynomial order / modified positions.</Text><BarChart categories={["all_T1","all_Q2","all_C3","source_C3","receiver_C3"]} series={[{name:"Forecast minus native True margin",data:["all_T1","all_Q2","all_C3","source_C3","receiver_C3"].map(k=>c.errors[k]),tone:"info"}]} height={260} valueSuffix=" nats"/><Table headers={["Arm","Native False (nats)","Native True (nats)","Predicted True (nats)","Error (nats)","Residual relative error","Residual cosine"]} rows={["all_T1","all_Q2","all_C3","source_C3","receiver_C3"].map(k=>[k,f(c.native[0]),f(c.native[1]),f(c.forecasts[k][1]),f(c.errors[k]),f(c.residual[k].relative_error),f(c.residual[k].cosine)])}/><Text size="sm" tone="secondary">{citation} All five forecasts were globally sealed before observations. Absolute margin matching0.10nats; residual relativeL2≤5% and cosine ≥0.99. Evidence is secondary and cannot rescue primary failures.</Text></Stack>}
 <Text size="sm" tone="secondary">All contexts, errors, failed accounts and strata remain available. Inline audited data only; no network. Syntax/data checked; host rendering not observed. This is a research milestone with unresolved mechanism questions.</Text>
 </Stack>;
}"""
    text = code.replace("__DATA__", json.dumps(payload, separators=(",", ":")))
    (ROOT / ".context/single-state-curvature-canvas-code.txt").write_text(text + "\n")
    (ROOT / ".context/single-state-curvature-canvas-data.json").write_text(
        json.dumps(payload) + "\n"
    )
    print(
        f"Generated offline viewer: {len(text)} characters; cases {[len(d['cases']) for d in data]}."
    )


if __name__ == "__main__":
    main()
