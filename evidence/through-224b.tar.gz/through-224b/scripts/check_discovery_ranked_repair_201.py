"""Offline engineering preflight of sequential and public-hook forecasts; no nativeTrue call."""

import json
from pathlib import Path

import public_ranked_block_response_201 as public
import ranked_block_response_201 as response
import run_discovery_ranked_repair_201 as run
import torch

from latent_decisions.target import load_target


def main():
    pb = json.loads((run.parent.RUN / "design.json").read_text())
    pa = json.loads(run.parent.OUT.read_text())
    selection = run.selections(pa)
    model, tok, device = load_target(pb["design"]["models"]["qwen15"], "mps", offline=True)
    block = {
        "id": "quarry",
        "stage": "201-preflight",
        "subjects": ["quarry", "marble"],
        "days": ["Friday", "Tuesday"],
        "old_block": None,
    }
    checks = []
    for schema in ("generic", "descriptive"):
        g = run.native.fixture.group(block, 0, 0, 0, schema)
        bases, _ = run.native.paired_bases(tok, block, g)
        ids = torch.tensor([bases[0]["free_input_ids"]], device=device)
        edited = torch.tensor([bases[1]["free_input_ids"]], device=device)
        states, context, scores = response.observe(model, ids)
        with torch.no_grad():
            edit = model.model.embed_tokens(edited) - context["input"]
            initial = response.source(model, context, states, edit)
        for arm in response.ARMS:
            finite, finite_head = response.placements(selection, arm)
            prediction, predicted_scores, _ = response.forecast(
                model, context, states, initial, finite, finite_head
            )
            primal, tangent = public.response(model, context["input"], edit, finite, finite_head)
            pe = float(torch.max(abs(primal[0] - torch.stack(states)[:, 0])))
            pse = float(torch.max(abs(primal[1] - scores)))
            he = float(torch.max(abs(tangent[0] - prediction)))
            se = float(torch.max(abs(tangent[1] - predicted_scores)))
            checks.append(
                {
                    "schema": schema,
                    "arm": arm,
                    "state_error": he,
                    "score_error": se,
                    "primal_state_error": pe,
                    "primal_score_error": pse,
                    "passed": he <= 1e-4 and se <= 0.005 and pe <= 1e-4 and pse <= 0.005,
                }
            )
            print(checks[-1], flush=True)
        assert all(c["passed"] for c in checks)
    record = {
        "passed": all(c["passed"] for c in checks),
        "source_hash": run.source_hash(),
        "preflight_source_sha256": run.hashed(Path(__file__)),
        "ordinary_false_model_invocations": 2,
        "public_forward_false_model_invocations": 12,
        "native_true_model_invocations": 0,
        "selection": selection,
        "checks": checks,
    }
    run.write_json(run.ROOT / ".context/201-ranked-repair-preflight.json", record)
    print(json.dumps(record, indent=2))


if __name__ == "__main__":
    main()
