"""Independent public first-block dual hooks; revalidate immutable196 forecasts only."""

import itertools
import json
from contextlib import contextmanager
from pathlib import Path

import audit_first_block_primitive_repair_196 as artifacts
import numpy as np
import torch
from torch.autograd import forward_ad
from torch.nn import functional as F
from transformers.models.qwen2 import modeling_qwen2 as qwen

from latent_decisions.evidence_policy import digest, write_json
from latent_decisions.target import load_target

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "docs/analysis/198-dual-primitive-recheck.json"


def finite_unary(module, args, output):
    x, dx = forward_ad.unpack_dual(args[0])
    y, _ = forward_ad.unpack_dual(output)
    return forward_ad.make_dual(y, module.forward(x + dx) - y)


def finite_product(output, left, right):
    base, _ = forward_ad.unpack_dual(output)
    a, da = forward_ad.unpack_dual(left)
    b, db = forward_ad.unpack_dual(right)
    return forward_ad.make_dual(base, (a + da) @ (b + db) - base)


@contextmanager
def nonlinear_hooks(layer, enabled):
    handles, values = [], {}
    original = qwen.eager_attention_forward
    try:
        for label, module in (
            ("input_rms", layer.input_layernorm),
            ("post_rms", layer.post_attention_layernorm),
            ("silu", layer.mlp.act_fn),
        ):
            if label in enabled:
                handles.append(module.register_forward_hook(finite_unary))

        def attention(module, query, key, value, attention_mask, scaling, dropout=0.0, **kwargs):
            assert dropout == 0 and not module.training
            k = qwen.repeat_kv(key, module.num_key_value_groups)
            v = qwen.repeat_kv(value, module.num_key_value_groups)
            raw = query @ k.transpose(2, 3)
            if "qk_product" in enabled:
                raw = finite_product(raw, query, k.transpose(2, 3))
            logits = raw * scaling + attention_mask
            weights = F.softmax(logits, dim=-1, dtype=torch.float32).to(query.dtype)
            if "softmax" in enabled:
                z, dz = forward_ad.unpack_dual(logits)
                p, _ = forward_ad.unpack_dual(weights)
                weights = forward_ad.make_dual(p, F.softmax(z + dz, -1, dtype=torch.float32) - p)
            av = weights @ v
            if "weight_value" in enabled:
                av = finite_product(av, weights, v)
            return av.transpose(1, 2).contiguous(), weights

        qwen.eager_attention_forward = attention
        if "gate_up" in enabled:

            def save(label):
                def hook(module, args, output):
                    values[label] = output

                return hook

            handles.append(layer.mlp.act_fn.register_forward_hook(save("phi")))
            handles.append(layer.mlp.up_proj.register_forward_hook(save("up")))

            def product(module, args):
                base, _ = forward_ad.unpack_dual(args[0])
                phi, dphi = forward_ad.unpack_dual(values["phi"])
                up, dup = forward_ad.unpack_dual(values["up"])
                return (forward_ad.make_dual(base, (phi + dphi) * (up + dup) - base),)

            handles.append(layer.mlp.down_proj.register_forward_pre_hook(product))
        yield
    finally:
        qwen.eager_attention_forward = original
        for handle in handles:
            handle.remove()


def reconstruct(layer, x, dx, mask, rope, enabled):
    with nonlinear_hooks(layer, enabled):
        primal, tangent = torch.func.jvp(
            lambda z: layer(z, attention_mask=mask, position_embeddings=rope),
            (x,),
            (dx,),
        )
        return primal.detach().clone(), tangent.detach().clone()


def main():
    bundle = json.loads((artifacts.RUN / "design.json").read_text())
    assert bundle["design"]["source_hash"] == artifacts.source_hash()
    old = json.loads((ROOT / "docs/analysis/196-numerical-recheck.json").read_text())
    assert not old["passed"]
    model, tok, device = load_target(bundle["design"]["models"]["qwen15"], "mps", offline=True)
    checks = []
    # Same predefined selected8contexts; no threshold or outcome-based selection.
    for schema, assignment, target in itertools.product(
        ("generic", "descriptive"), range(2), range(2)
    ):
        block = artifacts.blocks()[0]
        g = artifacts.native.fixture.group(block, assignment, target, 0, schema)
        key = digest(g)
        fr = artifacts.native.read_record(artifacts.RUN / "qwen15/forecasts" / f"{key}.json")[
            "record"
        ]
        fp = artifacts.RUN / "qwen15/forecasts" / f"{key}.npz"
        assert artifacts.hashed(fp) == fr["states_sha256"]
        context = {}

        def capture(module, args, kwargs):
            context.update(
                x=args[0].detach().clone(),
                mask=kwargs["attention_mask"].detach().clone(),
                rope=tuple(v.detach().clone() for v in kwargs["position_embeddings"]),
            )

        handle = model.model.layers[0].register_forward_pre_hook(capture, with_kwargs=True)
        ids = torch.tensor([fr["bases"][0]["free_input_ids"]], device=device)
        other = torch.tensor([fr["bases"][1]["free_input_ids"]], device=device)
        try:
            with torch.no_grad():
                model(
                    input_ids=ids,
                    attention_mask=torch.ones_like(ids),
                    use_cache=False,
                    logits_to_keep=1,
                )
                dx = model.model.embed_tokens(other) - context["x"]
        finally:
            handle.remove()
        local = {}
        with np.load(fp, allow_pickle=False) as z:
            for arm in artifacts.ARMS[:-1]:
                enabled = (
                    artifacts.FACTORS if arm == "exact_block" else () if arm == "linear" else (arm,)
                )
                primal, direction = reconstruct(
                    model.model.layers[0],
                    context["x"],
                    dx,
                    context["mask"],
                    context["rope"],
                    enabled,
                )
                local[arm] = direction
                pe = float(np.max(abs(primal[0].cpu().numpy() - z["false_first"])))
                de = float(np.max(abs(direction[0].cpu().numpy() - z[f"{arm}_first_delta"])))
                checks.append(
                    {
                        **g,
                        "arm": arm,
                        "primal_error": pe,
                        "direction_error": de,
                        "passed": pe <= 1e-4 and de <= 1e-4,
                    }
                )
            pos = fr["position"]
            combined = torch.cat(
                (
                    local["linear"][:, :pos],
                    local["exact_block"][:, pos : pos + 1],
                    local["linear"][:, pos + 1 :],
                ),
                1,
            )
            de = float(np.max(abs(combined[0].cpu().numpy() - z["exact_source_first_delta"])))
            checks.append(
                {
                    **g,
                    "arm": "exact_source",
                    "primal_error": 0.0,
                    "direction_error": de,
                    "passed": de <= 1e-4,
                }
            )
        print(
            f"198 public dual reconstruction {schema} {assignment}/{target}: {len(checks)}/80",
            flush=True,
        )
    assert len(checks) == 80
    refs = [c for c in old["checks"] if c["kind"] == "independent_primitive_and_reverse_tail"]
    reverse_passed = all(
        all(
            abs(p - r) <= 0.001 + 0.0001 * abs(r)
            for p, r in zip(c["forward_contractions"], c["reverse_references"])
        )
        for c in refs
    )
    native_passed = all(c["passed"] for c in old["checks"] if c["kind"].startswith("native"))
    report = {
        "fingerprint": bundle["fingerprint"],
        "source_sha256": artifacts.hashed(Path(__file__)),
        "protocol_sha256": artifacts.hashed(ROOT / "docs/experiments/198-dual-revalidation.md"),
        "original_numerical_sha256": artifacts.hashed(
            ROOT / "docs/analysis/196-numerical-recheck.json"
        ),
        "ordinary_false_model_invocations": 8,
        "local_dual_block_invocations": 72,
        "retained_original_reverse_checks_passed": reverse_passed,
        "retained_original_native_checks_passed": native_passed,
        "maximum_direction_error": max(c["direction_error"] for c in checks),
        "passed": all(c["passed"] for c in checks) and reverse_passed and native_passed,
        "checks": checks,
        "scope": "Separately registered revalidation of unchanged196predictions after its primitive reverse-over-reverse coordinate failure. Public first-block low-level dual hooks, independent architecture code, same forward-AD backend as forecast. Algorithmic independence applies to retained reverse scalar contractions; NOT independent forward-AD backend or new held-out prediction. Original195/196qualification failures untouched.",
    }
    write_json(OUT, report)
    print(json.dumps({k: v for k, v in report.items() if k != "checks"}, indent=2))


if __name__ == "__main__":
    main()
