"""Preserve exact saved-array replay evidence for the serialization-only correction."""

import hashlib
import json
from pathlib import Path

import numpy as np

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/"docs/analysis/212c-failed-first-pair-replay.json"


def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    assert not OUT.exists()
    files=sorted((ROOT/"runs/rms-product-factorial-212/pairs").glob("*.npz"));assert len(files)==1
    old=files[0];new=ROOT/"runs/rms-product-factorial-212b/pairs"/old.name
    rows=[]
    with np.load(old,allow_pickle=False) as a,np.load(new,allow_pickle=False) as b:
        assert a.files==b.files
        for k in a.files:
            error=float(np.max(abs(a[k].astype(np.float64)-b[k].astype(np.float64))))
            rows.append(dict(array=k,maximum_coordinate_error=error,exact=np.array_equal(a[k],b[k])))
    assert len(rows)==161 and all(r["exact"] for r in rows)
    result=dict(passed=True,arrays=len(rows),maximum_coordinate_error=max(r["maximum_coordinate_error"] for r in rows),
        original_arrays_sha256=sha(old),corrected_arrays_sha256=sha(new),script_sha256=sha(Path(__file__)),rows=rows,
        scope="Firstcompletedpartialpaironly; actualserializationfailurepreserved; other212bpairsqualifiedbyfullauditor.")
    OUT.write_text(json.dumps(result,indent=2,sort_keys=True)+"\n")
    print(f"Exact replay of all {len(rows)} first-pair arrays; maximum difference 0.")


if __name__=="__main__":main()
