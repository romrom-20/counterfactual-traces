"""One false-only differentiated model invocation; preserve any preflight failure."""

import hashlib
import json
from pathlib import Path

import false_state_response_192 as response
import run_natural_bit_shared_reader_181 as native
import run_one_sided_curvature_forecast_191 as parent
import torch

from latent_decisions.target import load_target


def main():
    root = Path(__file__).resolve().parents[1]
    design = json.loads((parent.DEFAULT / "design.json").read_text())
    model, tok, _ = load_target(design["design"]["models"]["qwen15"], "mps", offline=True)
    # This is a new, declared engineering preflight, not a held-out result.
    block = {
        "id": "opal",
        "stage": "192-preflight",
        "subjects": ["opal", "jasper"],
        "days": ["Monday", "Thursday"],
        "old_block": None,
    }
    g = native.fixture.group(block, 0, 0, 0, "generic")
    bases, pos = native.paired_bases(tok, block, g)
    margin, state = native.score(model, bases[0])
    inputs = response.embedding_pair(model, *[b["free_input_ids"] for b in bases])
    primal, d1, d2, again = response.second_order(model, *inputs)
    arrays = [[x.detach().cpu().numpy() for x in values] for values in (primal, d1, d2, again)]
    import numpy as np

    result = {
        "native_false_calls": 1,
        "differentiated_false_model_invocations": 1,
        "forward_ad_levels": 2,
        "native_true_calls": 0,
        "false_state_error": float(np.max(abs(arrays[0][0][-1] - state))),
        "false_score_error": max(
            abs(float(arrays[0][1][i]) - margin[k])
            for i, k in enumerate(("false_score", "true_score"))
        ),
        "redundant_d1_error": max(float(np.max(abs(a - b))) for a, b in zip(arrays[1], arrays[3])),
        "d1_last_norm": float(np.linalg.norm(arrays[1][0][-1, -1])),
        "d2_last_norm": float(np.linalg.norm(arrays[2][0][-1, -1])),
        "d1_margin": float(arrays[1][1][1] - arrays[1][1][0]),
        "d2_margin": float(arrays[2][1][1] - arrays[2][1][0]),
        "prefix_derivative_max": max(
            float(np.max(abs(x[:, :pos]))) for x in (arrays[1][0], arrays[2][0])
        ),
        "all_finite": all(np.isfinite(x).all() for values in arrays for x in values),
        "helper_sha256": hashlib.sha256(Path(response.__file__).read_bytes()).hexdigest(),
    }
    (root / ".context/192-false-response-preflight.json").write_text(
        json.dumps(result, indent=2) + "\n"
    )
    print(json.dumps(result, indent=2))
    assert result["false_state_error"] <= 1e-4 and result["false_score_error"] <= 0.005
    assert result["redundant_d1_error"] <= 1e-4 and result["all_finite"]
    del model
    torch.mps.empty_cache()


if __name__ == "__main__":
    main()
