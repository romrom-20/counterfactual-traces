"""One offline engineering false-state preflight; no nativeTrue full forward."""

import json
from pathlib import Path

import first_block_response_195 as response
import run_first_block_primitive_repair_195 as run
import torch

from latent_decisions.target import load_target


def main():
    spec = json.loads((run.ROOT / "runs/single-state-native-response-193/design.json").read_text())[
        "design"
    ]["models"]["qwen15"]
    model, tok, device = load_target(spec, "mps", offline=True)
    block = {
        "id": "quartz",
        "stage": "195-preflight",
        "subjects": ["quartz", "slate"],
        "days": ["Friday", "Tuesday"],
        "old_block": None,
    }
    g = run.native.fixture.group(block, 0, 0, 0, "generic")
    bases, pos = run.native.paired_bases(tok, block, g)
    states, ctx, scores = run.observed(model, bases[0])
    ids = torch.tensor([bases[0]["free_input_ids"]], device=device)
    other = torch.tensor([bases[1]["free_input_ids"]], device=device)
    with torch.no_grad():
        dx = model.model.embed_tokens(other) - ctx["x"]
    directions, traces = response.local_directions(model.model.layers[0], ctx, dx, pos)
    _, derivative = torch.func.jvp(
        lambda x: model.model.layers[0](
            x, attention_mask=ctx["attention_mask"], position_embeddings=ctx["position_embeddings"]
        ),
        (ctx["x"],),
        (dx,),
    )
    local_error = float(torch.max(abs(derivative - directions["linear"])))
    assert local_error <= 1e-4
    with torch.no_grad():
        layer = model.model.layers[0]
        expected = layer(
            ctx["x"] + dx,
            attention_mask=ctx["attention_mask"],
            position_embeddings=ctx["position_embeddings"],
        ) - layer(
            ctx["x"],
            attention_mask=ctx["attention_mask"],
            position_embeddings=ctx["position_embeddings"],
        )
    exact_error = float(torch.max(abs(expected - directions["exact_block"])))
    assert exact_error <= 1e-4
    checks = []
    for arm in response.ARMS:
        zero = torch.zeros((), device=device)
        primal, tangent = torch.func.jvp(
            lambda lam: response.tail(model, ids, states[0][None], directions[arm], lam),
            (zero,),
            (torch.ones_like(zero),),
        )
        pe = float(torch.max(abs(primal[0] - torch.stack(states))))
        se = float(torch.max(abs(primal[1] - scores)))
        assert pe <= 1e-4 and se <= 0.005 and all(torch.isfinite(v).all() for v in tangent)
        checks.append({"arm": arm, "primal_state_error": pe, "primal_score_error": se})
    report = {
        "passed": True,
        "source_hash": run.source_hash(),
        "preflight_source_sha256": run.hashed(Path(__file__)),
        "ordinary_false_model_invocations": 1,
        "false_tail_ad_invocations": 10,
        "local_first_ad_invocations": 1,
        "local_public_layer_calls": 2,
        "local_analytical_responses": 9,
        "native_true_full_model_invocations": 0,
        "local_ad_error": local_error,
        "exact_local_error": exact_error,
        "norm_eps": model.config.rms_norm_eps,
        "checks": checks,
    }
    run.write_json(run.ROOT / ".context/195-first-block-preflight.json", report)
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
