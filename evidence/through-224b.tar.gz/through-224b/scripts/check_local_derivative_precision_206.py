"""Bound a local additivity discrepancy with explicit public versus promoted precision."""

import hashlib
import inspect
import json
import types
from pathlib import Path

import numpy as np
import torch
import transformers.models.qwen2.modeling_qwen2 as qwen
from huggingface_hub import try_to_load_from_cache
from safetensors import safe_open
from transformers import Qwen2Config

ROOT = Path(__file__).resolve().parents[1]
REVISION = "989aa7980e4cf806f80c7fef2b1adb7bc71aa306"
KEY = "4740553aaaf7a59cd259d56eb72e5e578d9051b9d9d718cec03b9e9c2c84a7bd"
MODES = [
    ("public32", torch.float32, False, False),
    ("public64_mixed", torch.float64, False, False),
    ("norm64", torch.float64, True, False),
    ("softmax64", torch.float64, False, True),
    ("all64", torch.float64, True, True),
]


def high_norm(module, x):
    variance = x.square().mean(-1, keepdim=True)
    return module.weight * (x * torch.rsqrt(variance + module.variance_epsilon))


def high_attention(module, query, key, value, attention_mask, scaling, dropout=0.0, **kwargs):
    assert not module.training and dropout == 0
    key = qwen.repeat_kv(key, module.num_key_value_groups)
    value = qwen.repeat_kv(value, module.num_key_value_groups)
    logits = query @ key.transpose(2, 3) * scaling
    if attention_mask is not None:
        logits = logits + attention_mask[:, :, :, : key.shape[-2]]
    probabilities = torch.softmax(logits, dim=-1)
    return (probabilities @ value).transpose(1, 2).contiguous(), probabilities


def main():
    out = ROOT / "docs/analysis/206-local-derivative-precision.json"
    assert not out.exists()
    audit = json.loads((ROOT / "docs/analysis/204-sample-oracle-vector-audit.json").read_text())
    assert audit["reset_qualified"]
    snapshot = ROOT / "runs/genuine-oracle-continuation-204-sample/pairs" / f"{KEY}.npz"
    checkpoint = try_to_load_from_cache(
        "Qwen/Qwen2.5-1.5B-Instruct", "model.safetensors", revision=REVISION
    )
    config_path = try_to_load_from_cache(
        "Qwen/Qwen2.5-1.5B-Instruct", "config.json", revision=REVISION
    )
    assert isinstance(checkpoint, str) and isinstance(config_path, str)
    torch.set_num_threads(2)
    original_attention = qwen.eager_attention_forward
    records = []
    with (
        np.load(snapshot, allow_pickle=False) as z,
        safe_open(checkpoint, framework="pt", device="cpu") as weights,
    ):
        pos = int(z["source_position"])
        for block in [2, 28]:
            b = block - 1
            base = z["false_boundaries"][b][None]
            actual = np.zeros_like(base)
            predicted = np.zeros_like(base)
            actual[:, pos:] = z["native_delta_suffix"][b]
            predicted[:, pos:] = z["ordinary_source_linear_delta_suffix"][b]
            reference = torch.tensor(z["false_boundaries"][b + 1][None], dtype=torch.float64)
            prefix = f"model.layers.{b}."
            state = {
                k[len(prefix) :]: weights.get_tensor(k)
                for k in weights.keys()
                if k.startswith(prefix)
            }
            for label, dtype, norm64, softmax64 in MODES:
                config = Qwen2Config.from_dict(json.loads(Path(config_path).read_text()))
                config._attn_implementation = "eager"
                layer = qwen.Qwen2DecoderLayer(config, layer_idx=b).to(dtype=dtype).eval()
                layer.load_state_dict(state, strict=True)
                layer.requires_grad_(False)
                if norm64:
                    layer.input_layernorm.forward = types.MethodType(
                        high_norm, layer.input_layernorm
                    )
                    layer.post_attention_layernorm.forward = types.MethodType(
                        high_norm, layer.post_attention_layernorm
                    )
                qwen.eager_attention_forward = high_attention if softmax64 else original_attention
                x = torch.tensor(base, dtype=dtype)
                a, p = torch.tensor(actual, dtype=dtype), torch.tensor(predicted, dtype=dtype)
                e = a - p
                mask = torch.tensor(z["mask"], dtype=dtype)
                rope = tuple(
                    torch.tensor(z[name], dtype=dtype) for name in ["rope_cos", "rope_sin"]
                )

                def function(v):
                    return layer(v, attention_mask=mask, position_embeddings=rope)

                results = [torch.func.jvp(function, (x,), (v,)) for v in [a, p, e]]
                ja, jp, je = [r[1].double() for r in results]
                error = float(torch.max(abs(ja - jp - je)))
                forward_error = float(torch.max(abs(results[0][0].double() - reference)))
                row = dict(
                    block=block,
                    mode=label,
                    dtype=str(dtype),
                    promoted_norm=norm64,
                    promoted_softmax=softmax64,
                    maximum_additivity_error=error,
                    additivity_passed=error <= 1e-4,
                    maximum_forward_difference_from_original_mps=forward_error,
                    original_mps_forward_bound_passed=forward_error <= 1e-4,
                    maximum_direction_subtraction_rounding=float(
                        torch.max(abs(a.double() - p.double() - e.double()))
                    ),
                )
                if label == "all64":
                    reverse_checks, finite_checks = [], []
                    rx = x.detach().requires_grad_(True)
                    output = function(rx)
                    count = output.numel()
                    for divisor in [17, 29]:
                        vector = (
                            torch.sin(torch.arange(count, dtype=torch.float64) / divisor)
                            / np.sqrt(count)
                        ).reshape(output.shape)
                        grad = torch.autograd.grad((output * vector).sum(), rx, retain_graph=True)[
                            0
                        ]
                        for name, v, j in zip(
                            ["native", "predicted", "error"], [a, p, e], [ja, jp, je]
                        ):
                            reverse = float((grad * v).sum())
                            forward = float((j * vector).sum())
                            reverse_checks.append(
                                dict(
                                    direction=name,
                                    divisor=divisor,
                                    reverse=reverse,
                                    forward=forward,
                                    absolute_error=abs(forward - reverse),
                                    passed=abs(forward - reverse) <= 0.001 + 0.0001 * abs(reverse),
                                )
                            )
                    for name, v, j in zip(
                        ["native", "predicted", "error"], [a, p, e], [ja, jp, je]
                    ):
                        with torch.no_grad():
                            estimate = (function(x + 1e-5 * v) - function(x - 1e-5 * v)) / 2e-5
                        discrepancy = float(torch.max(abs(estimate - j)))
                        finite_checks.append(
                            dict(
                                direction=name,
                                epsilon=1e-5,
                                maximum_coordinate_error=discrepancy,
                                passed=discrepancy <= 1e-4,
                            )
                        )
                    row.update(
                        standard_reverse_checks=reverse_checks,
                        central_difference_checks=finite_checks,
                    )
                records.append(row)
                print(json.dumps(row), flush=True)
                del layer, results
    qwen.eager_attention_forward = original_attention
    result = dict(
        revision=REVISION,
        backend="CPU; original204MPS forecasts unchanged",
        threads=2,
        key=KEY,
        records=records,
        source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        public_qwen_source_sha256=hashlib.sha256(inspect.getsource(qwen).encode()).hexdigest(),
        parent_npz_sha256=hashlib.sha256(snapshot.read_bytes()).hexdigest(),
        limits="Explicitly altered arithmetic precision and CPU backend in a local numerical reference, not a replacement forecast. No original196/203failure retroactively passes. No learned mechanism, prospective result or QuestionBsolution.",
    )
    out.write_text(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
