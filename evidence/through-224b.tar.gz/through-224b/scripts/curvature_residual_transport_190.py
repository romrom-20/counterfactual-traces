"""Read-only all-layer residual/attention/MLP capture for shared-curvature transport."""

from contextlib import contextmanager

from latent_decisions.target import block_tensor


@contextmanager
def trajectory(model, pos):
    captures, trace, handles = {}, [], []
    try:
        for site, layer in enumerate(model.model.layers, 1):

            def before(module, args, site=site):
                v = args[0][0, pos + 1 :].detach().cpu().numpy().copy()
                captures[f"R_{site}_input"] = v
                trace.append(
                    {"site": site, "kind": "input", "start": pos + 1, "end": args[0].shape[1]}
                )

            handles.append(layer.register_forward_pre_hook(before))
            for kind, module in (
                ("attention", layer.self_attn),
                ("mlp", layer.mlp),
                ("output", layer),
            ):

                def after(module, args, out, site=site, kind=kind):
                    v = block_tensor(out)
                    captures[f"R_{site}_{kind}"] = v[0, pos + 1 :].detach().cpu().numpy().copy()
                    trace.append({"site": site, "kind": kind, "start": pos + 1, "end": v.shape[1]})

                handles.append(module.register_forward_hook(after))
        yield captures, trace
        assert len(captures) == len(trace) == 112
    finally:
        for handle in handles:
            handle.remove()
