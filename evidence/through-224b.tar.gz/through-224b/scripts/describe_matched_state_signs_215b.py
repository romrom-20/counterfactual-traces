"""Post-hoc descriptive paired signs; no fitting or changed accuracy criteria."""

import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
SOURCE=ROOT/"docs/analysis/215-matched-incoming-control.json"
OUT=ROOT/"docs/analysis/215b-paired-readout-signs.json"


def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    assert not OUT.exists()
    data=json.loads(SOURCE.read_text());assert data["qualified"]
    native={r["key"]:r for r in data["rows"] if r["branch"]=="native"}
    predicted={r["key"]:r for r in data["rows"] if r["branch"]=="predicted"}
    assert len(native)==64 and native.keys()==predicted.keys()
    rows=[]
    for key in sorted(native):
        n,p=native[key],predicted[key]
        row=dict(key=key,group=n["group"],effects={})
        for label in ("gate_before_rms","gate_after_rms"):
            a,b=n["conditional"][label]["finite_margin_change"],p["conditional"][label]["finite_margin_change"]
            row["effects"][label]=dict(native_margin_change=a,predicted_margin_change=b,raw_sign_flip=a*b<0,
                native_positive_and_predicted_negative_at_002=a>.02 and b<-.02)
        rows.append(row)
    summary={k:dict(raw_sign_flips=sum(r["effects"][k]["raw_sign_flip"] for r in rows),
        native_positive_and_predicted_negative_beyond_002=sum(r["effects"][k]["native_positive_and_predicted_negative_at_002"] for r in rows))
        for k in rows[0]["effects"]}
    result=dict(post_hoc_descriptive=True,cases=64,source_sha256=sha(SOURCE),script_sha256=sha(Path(__file__)),
        numerical_note="Rawsignedfiniteheadchanges; .02natguardreportedseparately(4timesoriginal.005logitscorebound),noaccuracythresholdchanged.",
        rows=rows,summary=summary)
    OUT.write_text(json.dumps(result,indent=2,sort_keys=True)+"\n")
    print(json.dumps(summary,indent=2))


if __name__=="__main__":main()
