"""Explicitly posthoc complete-stratum descriptions; never a new confirmation gate."""
import hashlib,itertools,json
from pathlib import Path
import numpy as np
R=Path(__file__).resolve().parents[1]
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def describe(rr,keys):
    return {k:dict(median=float(np.median([r[k] for r in rr])),minimum=min(r[k] for r in rr),maximum=max(r[k] for r in rr),positive=sum(r[k]>0 for r in rr),negative=sum(r[k]<0 for r in rr),zero=sum(r[k]==0 for r in rr)) for k in keys}
def main():
    p=R/'docs/analysis/224b-mlp-primitive-factorial.json';q=R/'docs/analysis/224b-posthoc-descriptions.json';assert not q.exists();x=json.loads(p.read_text());assert x['qualified'];arms=[];edges=[];components=[]
    for site,schema in itertools.product((22,23),('generic','descriptive')):
        for mode in ('LLL','LLF','LFL','LFF','FLL','FLF','FFL','FFF'):
            rr=[r for r in x['rows'] if r['site']==site and r['group']['schema']==schema and r['kind']!='random' and r['mode']==mode];assert len(rr)==16
            arms.append(dict(site=site,schema=schema,mode=mode,count=16,preserved=sum(r['response_preserved'] for r in rr),material_both=sum(r['material_both'] for r in rr),values=describe(rr,('verdict_relative_deviation','margin_change','absolute_margin_change'))))
        for index,factor in enumerate(('norm','silu','product')):
            for others in itertools.product('LF',repeat=2):
                lo=list(others);lo.insert(index,'L');lo=''.join(lo);hi=list(lo);hi[index]='F';hi=''.join(hi)
                rr=[r for r in x['edges'] if r['site']==site and r['group']['schema']==schema and r['low']==lo and r['high']==hi];assert len(rr)==16
                edges.append(dict(site=site,schema=schema,factor=factor,low=lo,high=hi,count=16,values=describe(rr,('write_norm','projection_223_remainder','margin_effect'))))
        for component in ('N','S','P','NS','NP','SP','NSP'):
            rr=[r for r in x['interactions'] if r['site']==site and r['group']['schema']==schema and r['component']==component];assert len(rr)==16
            components.append(dict(site=site,schema=schema,component=component,count=16,values=describe(rr,('write_norm','projection_223_remainder','margin_contrast'))))
    out=dict(scope='Explicitly posthoc exhaustive old-context stratum descriptions, not fresh confirmation, mechanism selection, learned features or forecasts.',input_sha256=digest(p),source_sha256=digest(Path(__file__)),arms=arms,edges=edges,components=components)
    q.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
if __name__=='__main__':main()
