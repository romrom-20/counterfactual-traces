"""Explicitly posthoc descriptions of already audited223 arrays; zero model calls."""

import hashlib,json
from pathlib import Path
import numpy as np
R=Path(__file__).resolve().parents[1]
def main():
    out=R/'docs/analysis/223-posthoc-descriptions.json';assert not out.exists()
    x=json.loads((R/'docs/analysis/223-native-mlp-remainder.json').read_text());assert x['qualified'];signs=[];sizes=[]
    for schema in ('generic','descriptive'):
        for arm in ('LF','FL','LL'):
            rr=[r for r in x['rows'] if r['label']==arm and r['group']['schema']==schema]
            signs.append(dict(schema=schema,arm=arm,count=len(rr),margin_positive=sum(r['margin_change']>0 for r in rr),margin_negative=sum(r['margin_change']<0 for r in rr),
                product_effect_increases=sum(r['product_effect']>r['native_product_effect'] for r in rr)))
    for key in sorted({r['context'] for r in x['rows']}):
        p=R/'runs/native-mlp-remainder-223/interventions'/(key+'.npz');rec=json.loads(p.with_suffix('.json').read_text());assert hashlib.sha256(p.read_bytes()).hexdigest()==rec['arrays_sha256']
        with np.load(p) as z:
            for site in (22,23):sizes.append(dict(context=key,site=site,remainder_norm=float(np.linalg.norm(z[f'FF_{site}_remainder'])),
                tangent_norm=float(np.linalg.norm(z[f'FF_{site}_tangent'])),AD_discrepancy_norm=float(np.linalg.norm(z[f'FF_{site}_q_analytic']-z[f'FF_{site}_q_dual']))))
    result=dict(posthoc=True,model_calls=0,signs=signs,sizes=sizes,
        scope='Descriptions chosen after observing223, not preregistered tests, causal fractions, source localization or fresh confirmation. Original primary gates unchanged.')
    out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(signs,indent=2))
if __name__=='__main__':main()
