"""Posthoc saved-operand description, without model calls or new mask selection."""

import hashlib,json
from pathlib import Path
import numpy as np

R=Path(__file__).resolve().parents[1];RUN=R/"runs/neuron-mixed-interventions-219";OUT=R/"docs/analysis/219b-selected-neuron-parents.json"
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    assert not OUT.exists()
    audit=json.loads((R/"docs/analysis/219-neuron-mixed-interventions.json").read_text());assert audit["qualified"]
    masks=json.loads((RUN/"selection.json").read_text());selected=masks["ranking"][:32];rows=[]
    for p in sorted((RUN/"captures").glob("*.npz")):
        rec=json.loads(p.with_suffix(".json").read_text());assert sha(p)==rec["arrays_sha256"]
        with np.load(p) as z:
            for i in selected:
                r=dict(key=p.stem,group=rec["group"],neuron=i,phi_false=float(z["phi0"][-1,i]),up_false=float(z["up0"][-1,i]),weight=float(z["projection_weights"][i]))
                for b in ("N","P"):
                    r[b+"_phi"]=float(z[b+"_phi"][-1,i]);r[b+"_up"]=float(z[b+"_up"][-1,i])
                    r[b+"_dphi"]=r[b+"_phi"]-r["phi_false"];r[b+"_du"]=r[b+"_up"]-r["up_false"]
                for ab in ("NN","NP","PN","PP"):r["a_"+ab]=float(z["a_"+ab][i])
                rows.append(r)
    summaries=[]
    for i in selected:
        for schema in ("generic","descriptive"):
            rs=[r for r in rows if r["neuron"]==i and r["group"]["schema"]==schema]
            summaries.append(dict(neuron=i,schema=schema,count=len(rs),medians={k:float(np.median([r[k] for r in rs])) for k in rs[0] if k not in ("key","group","neuron")},
                positive_counts={k:sum(r[k]>0 for r in rs) for k in ("N_dphi","N_du","P_dphi","P_du","a_NN","a_NP","a_PN","a_PP")}))
    OUT.write_text(json.dumps(dict(scope="Posthoc saved parent increments; no model calls, inversion of SiLU or fresh prediction.",audit_sha256=sha(R/"docs/analysis/219-neuron-mixed-interventions.json"),selection_sha256=sha(RUN/"selection.json"),source_sha256=sha(Path(__file__)),selected=selected,summaries=summaries,rows=rows),indent=2)+"\n")
    print(json.dumps([s for s in summaries if s["neuron"] in selected[:2]],indent=2))
if __name__=="__main__":main()
