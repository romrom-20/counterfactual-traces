"""Post-hoc full crossed schema/order description, no new prediction claim."""

import hashlib
import itertools
import json
from pathlib import Path

import numpy as np

ROOT=Path(__file__).resolve().parents[1]
SOURCE=ROOT/"docs/analysis/215-matched-incoming-control.json"
OUT=ROOT/"docs/analysis/215c-schema-readout-regimes.json"


def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    assert not OUT.exists()
    data=json.loads(SOURCE.read_text());assert data["qualified"]
    rows=[]
    for branch,schema,order in itertools.product(("native","predicted"),("generic","descriptive"),range(2)):
        selected=[r for r in data["rows"] if r["branch"]==branch and r["group"]["schema"]==schema and r["group"]["reverse"]==order]
        assert len(selected)==16
        values=np.array([r["conditional"]["gate_after_rms"]["finite_margin_change"] for r in selected])
        rows.append(dict(branch=branch,schema=schema,order=order,cases=16,
            median_product_margin_change=float(np.median(values)),minimum=float(min(values)),maximum=float(max(values)),
            positive=int(sum(values>0)),negative=int(sum(values<0)),
            median_incoming_receiver_error=float(np.median([r["incoming"]["receivers"]["relative_l2"] for r in selected]))))
    OUT.write_text(json.dumps(dict(post_hoc_descriptive=True,after_rms_repair=True,source_sha256=sha(SOURCE),
        script_sha256=sha(Path(__file__)),rows=rows,
        scope="Crossedstratawerepreexisting; contrastdescriptionafterseeingresults. Noheldouttest, independence, circuit, priorityorprospectiveclaim."),indent=2,sort_keys=True)+"\n")
    print(json.dumps(rows,indent=2))


if __name__=="__main__":main()
