"""Exact experiment schematic; this figure contains no simulated measurement curve."""

from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch

R=Path(__file__).resolve().parents[1]
def main():
    fig,ax=plt.subplots(figsize=(13,6));ax.set(xlim=(0,13),ylim=(0,6));ax.axis("off")
    def box(x,y,w,h,text,accent=False):
        ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle="round,pad=.08,rounding_size=.08",facecolor="#edf3f7" if accent else "#f3f3f3",edgecolor="#1d4f77" if accent else ".45",linewidth=1))
        ax.text(x+w/2,y+h/2,text,ha="center",va="center",fontsize=10)
    def arrow(x0,y0,x1,y1):ax.annotate("",xy=(x1,y1),xytext=(x0,y0),arrowprops=dict(arrowstyle="->",color=".3",lw=1.1))
    box(.2,3.6,2.5,1.1,"Carried receiving state\nxS or xN / xP",True)
    box(.2,1.1,2.5,1.5,"Measured attention write\naS or aN / aP\n(native or False-affine)")
    box(3.2,2.6,1.35,1.1,"Add actual\noperands")
    arrow(2.7,4.15,3.2,3.25);arrow(2.7,1.85,3.2,3.)
    box(5.,2.45,2.,1.4,"MLP-input RMSNorm\nfinite scale or\nsource-only scale",True);arrow(4.55,3.15,5.,3.15)
    box(7.5,3.75,2.2,1.,"Gate projection\nand real SiLU: Φ")
    box(7.5,1.45,2.2,1.,"Up projection: U")
    arrow(7.,3.25,7.5,4.2);arrow(7.,2.95,7.5,1.95)
    box(10.15,2.45,2.45,1.4,"Product intervention\nΔΦ × ΔU\nfixed 32 neurons",True)
    arrow(9.7,4.2,10.15,3.45);arrow(9.7,1.95,10.15,2.85)
    ax.text(11.4,1.25,"Public down projection\n→ common False state\n→ actual finite readout",ha="center",va="center",fontsize=10)
    arrow(11.4,2.45,11.4,1.85)
    ax.text(6.5,5.55,"221: locate the parent response before naming an upstream mechanism",ha="center",fontsize=15)
    ax.text(6.5,.35,"2 × 2 carried-state / attention-write factorial · normalization intervention · all 64 old contexts\nEach switch is an explicit intervention; this schematic is not a learned-circuit claim.",ha="center",fontsize=10)
    fig.tight_layout()
    for ext in ("png","svg"):fig.savefig(R/f"docs/figures/221-receiver-flow-schematic.{ext}",dpi=160)
    plt.close(fig)
if __name__=="__main__":main()
