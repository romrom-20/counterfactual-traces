"""First/second directional derivatives at the false input; never target-state calibration."""

import torch

from latent_decisions.target import block_tensor


def embedding_pair(model, false_ids, true_ids):
    device = next(model.parameters()).device
    ids = torch.tensor([false_ids], device=device)
    other = torch.tensor([true_ids], device=device)
    changed = torch.nonzero(ids[0] != other[0]).flatten()
    assert len(changed) == 1
    with torch.no_grad():
        base = model.model.embed_tokens(ids).detach()
        delta = model.model.embed_tokens(other).detach() - base
    assert torch.count_nonzero(delta[0, : int(changed[0])]) == 0
    assert torch.count_nonzero(delta[0, int(changed[0]) + 1 :]) == 0
    return base, delta, torch.ones_like(ids)


def computation(model, base, delta, mask, lam):
    states, handles = [], []

    def capture(module, args, output):
        states.append(block_tensor(output)[0])

    try:
        for layer in model.model.layers:
            handles.append(layer.register_forward_hook(capture))
        output = model(
            inputs_embeds=base + lam * delta,
            attention_mask=mask,
            use_cache=False,
            logits_to_keep=1,
        )
        assert len(states) == 28
        return torch.stack(states), output.logits[0, -1, [895, 830]]
    finally:
        for handle in handles:
            handle.remove()


def second_order(model, base, delta, mask):
    zero = torch.zeros((), device=base.device, dtype=base.dtype)
    one = torch.ones_like(zero)

    def f(lam):
        return computation(model, base, delta, mask, lam)

    def first(lam):
        return torch.func.jvp(f, (lam,), (one,))

    # A single primal f invocation, evaluated at lambda=0, with two AD levels.
    (primal, d1), (redundant_d1, d2) = torch.func.jvp(first, (zero,), (one,))
    return primal, d1, d2, redundant_d1
