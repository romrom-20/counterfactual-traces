"""False-anchored primitive repairs in block one, followed by false-state tangent transport."""

from contextlib import contextmanager

import torch
from torch.nn import functional as F
from transformers.models.qwen2 import modeling_qwen2 as qwen

from latent_decisions.target import block_tensor, replace_block_tensor

FACTORS = ("input_rms", "qk_product", "softmax", "weight_value", "post_rms", "silu", "gate_up")
ARMS = ("linear", *FACTORS, "exact_block", "exact_source")


@contextmanager
def capture(model):
    states, context, handles = [], {}, []

    def first(module, args, kwargs):
        context["x"] = args[0].detach().clone()
        for key in ("attention_mask", "position_embeddings"):
            value = kwargs[key]
            context[key] = (
                tuple(v.detach().clone() for v in value)
                if isinstance(value, tuple)
                else value.detach().clone()
            )

    def save(module, args, out):
        states.append(block_tensor(out)[0].detach().clone())

    try:
        handles.append(model.model.layers[0].register_forward_pre_hook(first, with_kwargs=True))
        for layer in model.model.layers:
            handles.append(layer.register_forward_hook(save))
        yield states, context
        assert len(states) == 28 and len(context) == 3
    finally:
        for handle in handles:
            handle.remove()


def linear(module, dx):
    return F.linear(dx, module.weight, None)


def rms_delta(module, x, dx, finite):
    if finite:
        return module(x + dx) - module(x)
    return torch.func.jvp(module, (x,), (dx,))[1]


def primitive(function, bases, deltas, finite):
    output = function(*bases)
    delta = (
        function(*[base + step for base, step in zip(bases, deltas)]) - output
        if finite
        else torch.func.jvp(function, tuple(bases), tuple(deltas))[1]
    )
    return output, delta


def source_forecast(layer, context, dx, enabled=()):
    """Compose finite selected primitives and public primitive AD for every other primitive."""
    enabled = set(enabled)
    x, mask, rope = context["x"], context["attention_mask"], context["position_embeddings"]
    attn, mlp = layer.self_attn, layer.mlp
    n = layer.input_layernorm(x)
    dn = rms_delta(layer.input_layernorm, x, dx, "input_rms" in enabled)
    shape = (*x.shape[:-1], -1, attn.head_dim)
    q, k, v = [
        projection(n).view(shape).transpose(1, 2)
        for projection in (attn.q_proj, attn.k_proj, attn.v_proj)
    ]
    dq, dk, dv = [
        linear(projection, dn).view(shape).transpose(1, 2)
        for projection in (attn.q_proj, attn.k_proj, attn.v_proj)
    ]
    q, k = qwen.apply_rotary_pos_emb(q, k, *rope)
    dq, dk = qwen.apply_rotary_pos_emb(dq, dk, *rope)
    k, dk, v, dv = [qwen.repeat_kv(z, attn.num_key_value_groups) for z in (k, dk, v, dv)]
    logits, dlogits = primitive(
        lambda q, k: (q @ k.transpose(2, 3)) * attn.scaling,
        (q, k),
        (dq, dk),
        "qk_product" in enabled,
    )
    weights, dw = primitive(
        lambda z: F.softmax(z + mask, dim=-1, dtype=torch.float32),
        (logits,),
        (dlogits,),
        "softmax" in enabled,
    )
    av, dav = primitive(lambda w, v: w @ v, (weights, v), (dw, dv), "weight_value" in enabled)
    attention = attn.o_proj(av.transpose(1, 2).contiguous().reshape(x.shape))
    da = linear(attn.o_proj, dav.transpose(1, 2).contiguous().reshape(x.shape))
    mid, dmid = x + attention, dx + da
    mn = layer.post_attention_layernorm(mid)
    dmn = rms_delta(layer.post_attention_layernorm, mid, dmid, "post_rms" in enabled)
    gate, up = mlp.gate_proj(mn), mlp.up_proj(mn)
    dg, du = linear(mlp.gate_proj, dmn), linear(mlp.up_proj, dmn)
    phi, dphi = primitive(mlp.act_fn, (gate,), (dg,), "silu" in enabled)
    product, dp = primitive(lambda a, b: a * b, (phi, up), (dphi, du), "gate_up" in enabled)
    mout, dm = mlp.down_proj(product), linear(mlp.down_proj, dp)
    return dx + da + dm, {
        "input": x,
        "embedding_delta": dx,
        "norm_input": n,
        "norm_input_delta": dn,
        "attention": attention,
        "attention_delta": da,
        "mid": mid,
        "mid_delta": dmid,
        "norm_post": mn,
        "norm_post_delta": dmn,
        "gate": gate,
        "gate_delta": dg,
        "up": up,
        "up_delta": du,
        "phi": phi,
        "phi_delta": dphi,
        "mlp": mout,
        "mlp_delta": dm,
        "output": mid + mout,
    }


def local_directions(layer, context, dx, position):
    directions, traces = {}, {}
    with torch.no_grad():
        for arm in ARMS[:-1]:
            enabled = FACTORS if arm == "exact_block" else () if arm == "linear" else (arm,)
            directions[arm], traces[arm] = source_forecast(layer, context, dx, enabled)
        directions["exact_source"] = directions["linear"].clone()
        directions["exact_source"][:, position] = directions["exact_block"][:, position]
    return directions, traces


def tail(model, false_ids, first_state, direction, lam):
    """Evaluate derivatives ONLY at the false state; no finite counterfactual tail."""
    states, handles = [], []

    def inject(module, args, out):
        return replace_block_tensor(out, first_state + lam * direction)

    def save(module, args, out):
        states.append(block_tensor(out)[0])

    try:
        handles.append(model.model.layers[0].register_forward_hook(inject))
        for layer in model.model.layers:
            handles.append(layer.register_forward_hook(save))
        output = model(
            input_ids=false_ids,
            attention_mask=torch.ones_like(false_ids),
            use_cache=False,
            logits_to_keep=1,
        )
        return torch.stack(states), output.logits[0, -1, [895, 830]]
    finally:
        for handle in handles:
            handle.remove()
