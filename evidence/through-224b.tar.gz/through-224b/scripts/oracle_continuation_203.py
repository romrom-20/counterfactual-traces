"""Full-sequence continuations of the frozen 201 hybrid computation.

Boundary b means b COMPLETED blocks. Public block k starts at b=k-1.
Nothing in this module changes the original 201 implementations.
"""

import numpy as np
import ranked_block_response_201 as original
import torch
from torch.autograd import forward_ad

from latent_decisions.target import block_tensor, replace_block_tensor


def cpu(t):
    return t.detach().cpu().numpy().copy()


def jvp(model, index, x, direction, context, counts):
    primal, tangent = torch.func.jvp(
        lambda v: original.block(model.model.layers[index], v, context), (x,), (direction,)
    )
    counts["local_block_jvp"] += 1
    return primal.detach(), tangent.detach()


def finite(model, index, state, context, counts):
    with torch.no_grad():
        result = original.block(model.model.layers[index], state, context)
    counts["local_finite_block"] += 1
    return result.detach()


def readout(model, false_final, direction, finite_head, counts):
    if finite_head:
        with torch.no_grad():
            scores = original.head(model, false_final + direction) - original.head(
                model, false_final
            )
        counts["finite_head_evaluations"] += 2
    else:
        _, scores = torch.func.jvp(lambda x: original.head(model, x), (false_final,), (direction,))
        counts["head_jvp"] += 1
    return scores.detach()


def continuation(
    model, false_boundaries, context, boundary, incoming, finite_blocks, finite_head, counts
):
    """Actually execute every remaining block; all states include the causal prefix."""
    values = [incoming.detach().clone()]
    maximum_primal = 0.0
    for index in range(boundary, 28):
        xf = false_boundaries[index]
        if index + 1 in finite_blocks:
            outgoing = (
                finite(model, index, xf + values[-1], context, counts) - false_boundaries[index + 1]
            )
        else:
            primal, outgoing = jvp(model, index, xf, values[-1], context, counts)
            maximum_primal = max(
                maximum_primal, float(torch.max(abs(primal - false_boundaries[index + 1])))
            )
        values.append(outgoing.detach().clone())
    assert maximum_primal <= 1e-4, ("false primal", maximum_primal)
    return (
        values,
        readout(model, false_boundaries[-1], values[-1], finite_head, counts),
        maximum_primal,
    )


def public_hybrid(model, embedding, edit, boundary, reset, selected, finite_head):
    """Structurally distinct whole-model forward-AD hooks, extending public201."""
    values, handles = [], []

    def run(lam):
        def hook_for(index):
            def hook(module, args, kwargs, output):
                result = block_tensor(output)
                yp, _ = forward_ad.unpack_dual(result)
                if index == boundary:
                    result = forward_ad.make_dual(yp, reset)
                elif index in selected:
                    xp, dx = forward_ad.unpack_dual(args[0])
                    result = forward_ad.make_dual(
                        yp, block_tensor(module.forward(xp + dx, **kwargs)) - yp
                    )
                values.append(result)
                return replace_block_tensor(output, result)

            return hook

        def final_norm(module, args, output):
            xp, dx = forward_ad.unpack_dual(args[0])
            yp, _ = forward_ad.unpack_dual(output)
            return forward_ad.make_dual(yp, module.forward(xp + dx) - yp)

        try:
            for index, layer in enumerate(model.model.layers, 1):
                handles.append(layer.register_forward_hook(hook_for(index), with_kwargs=True))
            if finite_head:
                handles.append(model.model.norm.register_forward_hook(final_norm))
            result = model(
                inputs_embeds=embedding + lam * (reset if boundary == 0 else edit),
                attention_mask=torch.ones(
                    embedding.shape[:2], device=embedding.device, dtype=torch.long
                ),
                use_cache=False,
                logits_to_keep=1,
            )
            return torch.stack(values), result.logits[0, -1, [895, 830]]
        finally:
            for handle in handles:
                handle.remove()

    zero = torch.zeros((), device=embedding.device, dtype=embedding.dtype)
    return torch.func.jvp(run, (zero,), (torch.ones_like(zero),))


def public_native_tail(model, ids, next_block, absolute_native):
    """Ordinary public forward with exactly ONE full-state replacement before k."""
    values, handles = [], []

    def inject(module, args, kwargs):
        return (absolute_native, *args[1:]), kwargs

    def save(module, args, output):
        values.append(block_tensor(output).detach().clone())

    try:
        handles.append(
            model.model.layers[next_block - 1].register_forward_pre_hook(inject, with_kwargs=True)
        )
        for layer in model.model.layers:
            handles.append(layer.register_forward_hook(save))
        with torch.no_grad():
            result = model(
                input_ids=ids,
                attention_mask=torch.ones_like(ids),
                use_cache=False,
                logits_to_keep=1,
            )
        return values, result.logits[0, -1, [895, 830]].detach()
    finally:
        for handle in handles:
            handle.remove()


def slices(position):
    return {
        "full": (slice(None), slice(None)),
        "source": (slice(None), slice(position, position + 1)),
        "receivers": (slice(None), slice(position + 1, None)),
        "verdict": (slice(None), slice(-1, None)),
    }


def vector_budget(
    error, propagated, native_remainder, predicted_remainder, observed_next, position
):
    """Terms were evaluated separately using actual model JVPs, not defined as e_next."""
    tensors = [error, propagated, native_remainder, predicted_remainder, observed_next]
    arrays = [cpu(t).astype(np.float64) for t in tensors]
    e, je, rn, rp, en = arrays
    missing = rn - rp
    discrepancy = en - je - missing
    result = {"maximum_identity_coordinate_error": float(np.max(abs(discrepancy)))}
    for label, selection in slices(position).items():
        ei, ji, ni, pi, mi, oi = [x[selection].ravel() for x in (e, je, rn, rp, missing, en)]
        norm = float(np.linalg.norm(oi))
        incoming = float(np.linalg.norm(ei))
        result[label] = {
            "incoming_error_norm": incoming,
            "transported_error_norm": float(np.linalg.norm(ji)),
            "native_remainder_norm": float(np.linalg.norm(ni)),
            "predicted_remainder_norm": float(np.linalg.norm(pi)),
            "missing_remainder_norm": float(np.linalg.norm(mi)),
            "next_error_norm": norm,
            "transport_gain": float(np.linalg.norm(ji) / incoming) if incoming else None,
            "signed_transport_projection": float(np.dot(ji, oi) / norm) if norm else None,
            "signed_missing_projection": float(np.dot(mi, oi) / norm) if norm else None,
            "transport_missing_dot": float(np.dot(ji, mi)),
        }
    return result
