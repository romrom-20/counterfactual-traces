"""Presentation packaging only; preserve both prior closures and all new failures."""

import hashlib
import json
import shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PACKAGE = ROOT / "results/block28-primitives-210-211"


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    previous = ROOT / "results/source-receiver-factorial-208-209/manifest.json"
    old = json.loads(previous.read_text())
    files = dict(old["files"])
    assert len(files) == 1210 and all(sha(ROOT / p) == h for p, h in files.items())
    files[str(previous.relative_to(ROOT))] = sha(previous)
    sources = []
    for directory, patterns in (
        ("scripts", ("*210*.py", "*211*.py")),
        ("docs/experiments", ("210*.md", "211*.md")),
        ("docs/analysis", ("210*.json", "210*.md", "211*.json", "211*.md")),
        ("docs/figures", ("211*.png", "211*.svg")),
    ):
        for pattern in patterns:
            sources.extend((ROOT / directory).glob(pattern))
    for name in (
        "block28-derivative-210",
        "block28-derivative-210b",
        "block28-derivative-210c",
        "block28-primitive-211",
    ):
        for p in (ROOT / "runs" / name).rglob("*.json"):
            target = PACKAGE / "recorded-runs" / name / p.relative_to(ROOT / "runs" / name)
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(p, target)
    for pattern in ("210*.log", "211*.log"):
        sources.extend((ROOT / ".context").glob(pattern))
    sources.extend(p for p in (ROOT / ".context/frozen-211").rglob("*") if p.is_file())
    sources.extend(p for p in PACKAGE.rglob("*") if p.is_file() and p.name != "manifest.json")
    for p in sources:
        files[str(p.relative_to(ROOT))] = sha(p)
    (PACKAGE / "manifest.json").write_text(
        json.dumps(
            dict(
                files=files,
                prior_files=1210,
                previous_manifest_sha256=sha(previous),
                scope="211definedfiniteinterventionsqualified;210originalJacobiancompatibilityand211csavedvectorcoordinateequalityFAILEDandpreserved. No208extensionorlearnedcircuitclaim.",
            ),
            indent=2,
            sort_keys=True,
        )
        + "\n"
    )
    print(f"Packaged {len(files)}files; prior1210unchanged.")


if __name__ == "__main__":
    main()
