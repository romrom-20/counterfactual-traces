"""Assemble the scoped publication manifest and explicit historical seeds; no inference."""

import ast
import hashlib
import importlib.metadata
import json
import platform
import shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "results/norm-curvature-189-194"
STEMS = {
    185: "tangent-offset-slope-crossing",
    186: "one-sided-gain-forecast",
    187: "shared-signed-curvature",
    188: "curvature-multiplication",
    189: "factorial-curvature-routes",
    190: "fresh-norm-split",
    191: "one-sided-curvature-forecast",
    192: "single-state-native-response",
    193: "single-state-native-response",
    194: "source-receiver-curvature",
}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2) + "\n")


def closure():
    pending = [
        f"{kind}_{name.replace('-', '_')}_{stage}"
        for stage, name in STEMS.items()
        if stage >= 186
        for kind in ("run", "audit", "recheck")
    ]
    pending += [
        "analyze_norm_readout_cancellation_189_190",
        "analyze_residual_sources_190",
        "report_norm_feedback_189_190",
        "report_residual_generation_190_191",
        "reproduce_curvature_findings",
        "package_curvature_findings",
        "build_norm_feedback_canvas_189_190",
        "build_single_state_curvature_canvas_189_194",
        "report_single_state_native_response_193",
        "analyze_boolean_source_breakdown_193",
        "report_source_receiver_curvature_194",
        "check_false_state_response_192",
        "check_false_state_response_192_corrected",
        "write_curvature_research_post",
    ]
    files = set()
    while pending:
        module = pending.pop()
        path = ROOT / "scripts" / f"{module}.py"
        relative = str(path.relative_to(ROOT))
        if not path.exists() or relative in files:
            continue
        files.add(relative)
        for node in ast.walk(ast.parse(path.read_text())):
            if isinstance(node, ast.Import):
                pending.extend(alias.name.split(".")[0] for alias in node.names)
            if isinstance(node, ast.ImportFrom) and node.module:
                pending.append(node.module.split(".")[0])
            if isinstance(node, ast.Constant) and isinstance(node.value, str):
                if (
                    node.value.startswith(("docs/experiments/", "configs/"))
                    and (ROOT / node.value).is_file()
                ):
                    files.add(node.value)
    files.update(str(p.relative_to(ROOT)) for p in (ROOT / "src/latent_decisions").rglob("*.py"))
    files.update(("pyproject.toml", "README.md"))
    files.update(str(p.relative_to(ROOT)) for p in (ROOT / "tests").glob("test_*18[6-9].py"))
    files.update(str(p.relative_to(ROOT)) for p in (ROOT / "tests").glob("test_*19[014].py"))
    return files


def main():
    for stage in range(186, 195):
        audit = json.loads((ROOT / f"docs/analysis/{stage}-independent-audit.json").read_text())
        numerical = json.loads((ROOT / f"docs/analysis/{stage}-numerical-recheck.json").read_text())
        assert all(audit["controls"].values())
        if stage == 192:
            assert not audit["numerical_qualified"] and not numerical["passed"]
        else:
            assert audit["numerical_qualified"] and numerical["passed"]
        assert audit["fingerprint"] == numerical["fingerprint"]
        directory = ROOT / "runs" / f"{STEMS[stage]}-{stage}"
        for name, suffix in (
            ("design.json", "design"),
            ("qwen15/runtime.json", "runtime"),
            ("pipeline-status.json", "pipeline-status"),
        ):
            destination = OUT / "provenance" / f"{stage}-{suffix}.json"
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(directory / name, destination)
    for stage in (185, 189):
        folder = OUT / "prerequisites" / str(stage)
        folder.mkdir(parents=True, exist_ok=True)
        paths = {
            "design.json": f"runs/{STEMS[stage]}-{stage}/design.json",
            "runtime.json": f"runs/{STEMS[stage]}-{stage}/qwen15/runtime.json",
            "artifact-audit.json": f"docs/analysis/{stage}-independent-audit.json",
            "numerical-recheck.json": f"docs/analysis/{stage}-numerical-recheck.json",
        }
        for dest, source in paths.items():
            shutil.copyfile(ROOT / source, folder / dest)
        write(folder / "index.json", paths)
    for source, name in (
        (".context/192-false-response-preflight.log", "192-preflight-reporting-failure.log"),
        (".context/192-false-response-preflight-corrected.log", "192-preflight-corrected.log"),
        (".context/192-false-response-preflight.json", "192-preflight-corrected.json"),
    ):
        shutil.copyfile(ROOT / source, OUT / "provenance" / name)
    packages = [
        "numpy",
        "torch",
        "transformers",
        "safetensors",
        "tokenizers",
        "huggingface-hub",
        "matplotlib",
        "scikit-learn",
        "scipy",
        "accelerate",
        "pytest",
        "ruff",
    ]
    versions = {}
    for name in packages:
        try:
            versions[name] = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            pass
    (OUT / "environment-lock.txt").write_text(
        "\n".join(f"{k}=={v}" for k, v in versions.items()) + "\n"
    )
    write(
        OUT / "environment.json",
        {
            "python": platform.python_version(),
            "platform": platform.platform(),
            "packages": versions,
            "device": "MPS",
            "precision": "float32",
            "attention": "eager",
            "eval": True,
        },
    )
    files = closure()
    for stage in range(186, 195):
        files.update(
            str(p.relative_to(ROOT)) for p in (ROOT / "docs/analysis").glob(f"{stage}-*.json")
        )
    for prefix in ("189-", "190-", "191-", "192-", "193-", "194-"):
        files.update(
            str(p.relative_to(ROOT)) for p in (ROOT / "docs/analysis").glob(f"{prefix}*.md")
        )
        files.update(
            str(p.relative_to(ROOT)) for p in (ROOT / "docs/analysis/figures").glob(f"{prefix}*")
        )
    files.add("docs/drafts/lesswrong-shared-curvature-normalization.md")
    files.update(
        str(p.relative_to(ROOT))
        for p in OUT.rglob("*")
        if p.is_file() and p.name != "manifest.json"
    )
    hashes = {name: sha(ROOT / name) for name in sorted(files)}
    write(
        OUT / "manifest.json",
        {
            "scope": "186–188 dependencies and qualified 189–191/193–194 findings and preserved numerically unqualified192 attempt, scoped source import/hash closure, historical prerequisites explicitly distinguished from fresh reexecution; no raw activation arrays or model weights included",
            "files": hashes,
            "fresh190194_ordinary_model_invocations": 3840,
            "from186_ordinary_model_invocations": 8024,
            "differentiated_model_invocations": 144,
            "component190_down_projection_evaluations": 1792,
            "component190_numerical_matrix_evaluations": 224,
        },
    )
    write(
        ROOT / ".context/curvature-publication-paths.json",
        sorted([*files, str((OUT / "manifest.json").relative_to(ROOT))]),
    )
    print(f"Packaged {len(files)} file hashes; no model calls.")


if __name__ == "__main__":
    main()
