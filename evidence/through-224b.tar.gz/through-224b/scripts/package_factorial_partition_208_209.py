"""Presentation packaging: extend preserved closure without changing old evidence."""

import hashlib
import json
import shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PACKAGE = ROOT / "results/source-receiver-factorial-208-209"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    old_path = ROOT / "results/genuine-oracle-202-204/manifest.json"
    old = json.loads(old_path.read_text())
    files = dict(old["files"])
    assert len(files) == 423 and all(sha(ROOT / f) == h for f, h in files.items())
    files[str(old_path.relative_to(ROOT))] = sha(old_path)
    sources = []
    for pattern in ("*208*.py", "*209*.py"):
        sources.extend((ROOT / "scripts").glob(pattern))
    sources.extend((ROOT / "docs/experiments").glob("208-*.md"))
    sources.extend((ROOT / "docs/experiments").glob("209*.md"))
    sources.extend((ROOT / "docs/analysis").glob("208-*.json"))
    sources.extend((ROOT / "docs/analysis").glob("209c-*.json"))
    sources += [
        ROOT / "docs/analysis/208-209-research-verdict.md",
        ROOT / "docs/analysis/209-two-block-factorial-result.md",
    ]
    sources.extend((ROOT / "docs/figures").glob("208-209-*.?*"))
    for name in (
        "two-block-factorial-209",
        "two-block-factorial-209b",
        "two-block-factorial-209c",
        "source-receiver-partition-208",
    ):
        for path in (ROOT / "runs" / name).rglob("*.json"):
            target = PACKAGE / "recorded-runs" / name / path.relative_to(ROOT / "runs" / name)
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(path, target)
    catalog = json.loads(
        (ROOT / "runs/source-receiver-partition-208/historical-input-catalog.json").read_text()
    )
    for record in catalog["records"]:
        assert sha(ROOT / record["path"]) == record["sha256"]
        target = PACKAGE / "historical-input-records" / record["path"]
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(ROOT / record["path"], target)
    for name in (
        "209-factorial.log",
        "209b-factorial.log",
        "209c-factorial.log",
        "209c-audit.log",
        "209d-effects.log",
        "208-partition.log",
        "208-audit.log",
        "208d-errors.log",
    ):
        sources.append(ROOT / ".context" / name)
    for name in ("frozen-209", "frozen-209b", "frozen-209c", "frozen-208"):
        sources.extend(p for p in (ROOT / ".context" / name).rglob("*") if p.is_file())
    sources.extend(p for p in PACKAGE.rglob("*") if p.is_file() and p.name != "manifest.json")
    for path in sources:
        files[str(path.relative_to(ROOT))] = sha(path)
    output = dict(
        files=files,
        old_closure_files=423,
        previous_manifest_sha256=sha(old_path),
        scope="Qualified209c plus failed209/209b preserved, globallysealedfresh208all64outcomes. RawNPZ/weightslocalonly; nolearnedcircuitclaim. Old423closureunchanged.",
    )
    (PACKAGE / "manifest.json").write_text(json.dumps(output, indent=2, sort_keys=True) + "\n")
    print(f"Packaged {len(files)}files, including unchanged423-file prior closure.")


if __name__ == "__main__":
    main()
