"""Scoped local reproducibility bundle, retaining195failure and all196arms."""

import hashlib
import json
import shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DEST = ROOT / "results/norm-curvature-195-196"


def copy(source, destination):
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, destination)


def main():
    audit = json.loads((ROOT / "docs/analysis/198-revalidated-196-audit.json").read_text())
    assert audit["numerical_qualified"] and all(audit["controls"].values())
    DEST.mkdir(parents=True, exist_ok=True)
    for n in (195, 196):
        source = ROOT / f"runs/first-block-primitive-repair-{n}"
        for name in ("design.json", "pipeline-status.json"):
            copy(source / name, DEST / f"provenance/{n}-{name}")
        copy(
            ROOT / f".context/{n}-frozen-source-snapshot.json",
            DEST / f"provenance/{n}-source-snapshot.json",
        )
        copy(
            ROOT / f".context/{n}-first-block-preflight.json",
            DEST / f"provenance/{n}-preflight.json",
        )
        for name in ("preflight", "run"):
            copy(ROOT / f".context/{n}-first-block-{name}.log", DEST / f"provenance/{n}-{name}.log")
    for n in (197, 198):
        copy(
            ROOT / f".context/{n}-frozen-source-snapshot.json",
            DEST / f"provenance/{n}-source-snapshot.json",
        )
        copy(
            ROOT / f".context/{n}-dual-primitive-recheck.log", DEST / f"provenance/{n}-recheck.log"
        )
    seed = DEST / "prerequisites/193"
    index = {
        "design.json": "runs/single-state-native-response-193/design.json",
        "runtime.json": "runs/single-state-native-response-193/qwen15/runtime.json",
    }
    for name, path in index.items():
        copy(ROOT / path, seed / name)
    (seed / "index.json").write_text(json.dumps(index, indent=2) + "\n")
    (DEST / "README.md").write_text(
        "# First-block operation repair, experiments195–198\n\nThis local extension preserves195/196/197failures and198mixed-code-path revalidation of unchanged196forecasts, including every failed scientific account. Read [the result](../../docs/analysis/198-first-block-primitive-repair-result.md) and [methods accounting](../../docs/experiments/196-methods-addendum.md). Primary Question B remains a forecasting question, not a claim that exact finite local computation identifies a learned mechanism.\n\nUse the same pinned offline environment as [the earlier bundle](../norm-curvature-189-194/README.md). From a clean checkout, run `HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 PYTHONPATH=src:scripts .venv/bin/python scripts/reproduce_first_block_repair_196.py`. `--verify-only` verifies hashes/source fingerprint without model calls; `--plan` lists commands. The wrapper refuses an existing196run and seeds the explicitly historical193design/runtime; accompanying193audit/numericalqualification files are historical prerequisites, not independently rerun by this wrapper. To reproduce193fresh, use the earlier186–194pipeline first in a clean checkout. Reexecuting196writes canonical196audit/report files locally.\n\nFresh196main+verification+198revalidation costs152ordinary full-model calls and720False-state differentiated full-model calls, plus local first-block/primitive evaluations documented separately.195failure and engineering preflights add separate costs; no training or generated completions. Original196primitive reverse-over-reverse coordinate checks failed and remain failed;198local reconstruction uses independent public-layer code but the same forward-AD backend. Retained original reverse scalar contractions/native replays pass; the original primitive discrepancy remains unresolved.198is validation/reanalysis, not fresh prospective predictions. Raw arrays/checkpointweights are ignored and regenerated, not in Git. The full file manifest includes prior scientific dependencies from the earlier scoped bundle. Exact_block/exact_source are finite first-block computation controls; downstream transport remains linearized atFalse. A local source fit or balanced evidence contrast cannot substitute for individual residual/verdict forecasting. No browser/literature calls, commit, push or site publication were performed.\n"
    )
    base = json.loads((ROOT / "results/norm-curvature-189-194/manifest.json").read_text())["files"]
    files = set(base)
    for n in (195, 196):
        for stem in (
            "first_block_response",
            "run_first_block_primitive_repair",
            "audit_first_block_primitive_repair",
            "recheck_first_block_primitive_repair",
            "check_first_block_primitive_repair",
        ):
            files.add(f"scripts/{stem}_{n}.py")
        files.add(f"docs/experiments/{n}-first-block-primitive-repair.md")
    files.update(
        {
            "docs/analysis/196-first-block-primitive-repair-result.md",
            "docs/analysis/197-technical-failure.json",
            "docs/analysis/198-source-versus-propagation-assessment.md",
            "scripts/report_first_block_primitive_repair_196.py",
            "scripts/build_first_block_repair_canvas_196.py",
            "scripts/reproduce_first_block_repair_196.py",
            "scripts/package_first_block_repair_196.py",
            "docs/experiments/196-methods-addendum.md",
            "docs/analysis/195-technical-failure.json",
            "docs/analysis/196-independent-audit.json",
            "docs/analysis/196-numerical-recheck.json",
            "docs/analysis/196-first-block-repair-summary.json",
            "docs/analysis/198-first-block-primitive-repair-result.md",
            "docs/figures/196-first-block-repair.png",
            "docs/figures/196-first-block-repair.svg",
            "tests/test_first_block_primitive_repair_195.py",
            "tests/test_first_block_primitive_repair_195_eager.py",
            "tests/test_first_block_primitive_repair_196.py",
        }
    )
    files.update(
        {
            "scripts/check_dual_primitive_reconstruction_197.py",
            "scripts/check_dual_primitive_reconstruction_198.py",
            "scripts/audit_dual_revalidation_197.py",
            "scripts/audit_dual_revalidation_198.py",
            "docs/experiments/197-dual-revalidation.md",
            "docs/experiments/198-dual-revalidation.md",
            "tests/test_dual_primitive_revalidation_197.py",
            "tests/test_dual_primitive_revalidation_198.py",
            "scripts/report_revalidated_first_block_repair_198.py",
            "docs/analysis/198-dual-primitive-recheck.json",
            "docs/analysis/198-revalidated-196-audit.json",
            "docs/analysis/198-first-block-repair-summary.json",
            "docs/analysis/198-first-block-primitive-repair-result.md",
            "docs/figures/198-first-block-repair.png",
            "docs/figures/198-first-block-repair.svg",
        }
    )
    files.update(
        str(p.relative_to(ROOT))
        for p in DEST.rglob("*")
        if p.is_file() and p.name != "manifest.json"
    )
    manifest = {
        "scope": "Preserved195/196/197qualification/technical failures;198mixed-code-path revalidation of unchanged196forecasts, all registered arms retained; original primitive reverse-over-reverse discrepancy unresolved. Shared prior217file dependencies included; historical193seed distinguished from fresh reexecution. No raw arrays/modelweights.",
        "files": {p: hashlib.sha256((ROOT / p).read_bytes()).hexdigest() for p in sorted(files)},
    }
    (DEST / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    (ROOT / ".context/196-publication-paths.json").write_text(
        json.dumps(sorted(files | {str((DEST / "manifest.json").relative_to(ROOT))}), indent=2)
        + "\n"
    )
    print(f"196 scoped local package: {len(files)}files; scientific failure/success all retained.")


if __name__ == "__main__":
    main()
