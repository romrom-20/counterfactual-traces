"""Mutable local packaging only; never stages, commits, publishes or runs a model."""

import hashlib
import json
import shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def main():
    previous = ROOT / "results/remainder-repair-199-201/manifest.json"
    old = json.loads(previous.read_text())
    print("Previous manifest fields", list(old))
    entries = old.get("files", old.get("sha256", {}))
    assert isinstance(entries, dict) and len(entries) >= 342
    for f, expected in entries.items():
        assert hashlib.sha256((ROOT / f).read_bytes()).hexdigest() == expected, f
    paths = set(entries) | {str(previous.relative_to(ROOT))}
    patterns = [
        "scripts/*202*.py",
        "scripts/*203*.py",
        "scripts/*204*.py",
        "scripts/*205*.py",
        "scripts/*206*.py",
        "scripts/*207*.py",
        "docs/experiments/203-*.md",
        "docs/experiments/204-*.md",
        "docs/experiments/206-*.md",
        "docs/experiments/208-*.md",
        "docs/analysis/202-*",
        "docs/analysis/204-*",
        "docs/analysis/205-*",
        "docs/analysis/206-*",
        "docs/analysis/207-*",
        "docs/figures/204-*",
        "docs/figures/207-*",
        "results/genuine-oracle-202-204/README.md",
        "results/genuine-oracle-202-204/*.canvas.tsx",
        ".context/202-203-frozen-source-snapshot.json",
        ".context/204-*-source-snapshot.json",
        ".context/205-frozen-source-snapshot.json",
        ".context/206-frozen-source-snapshot.json",
        ".context/207-frozen-source-snapshot.json",
        ".context/204-full-thread-environment.json",
        ".context/203-sample.log",
        ".context/204-sample.log",
        ".context/204-full-postprocess.log",
        ".context/204-full-postprocess-complete.json",
        ".context/finish-full-204.py",
        ".context/204-*-vector-audit.log",
        ".context/205-*-separation.log",
        ".context/206-local-precision.log",
    ]
    for pattern in patterns:
        paths.update(str(p.relative_to(ROOT)) for p in ROOT.glob(pattern) if p.is_file())
    recorded = ROOT / "results/genuine-oracle-202-204/recorded-runs"
    for run in sorted((ROOT / "runs").glob("genuine-oracle-continuation-*")):
        if not (run / "status.json").exists():
            continue
        status = json.loads((run / "status.json").read_text())
        if status["status"] == "running":
            continue
        for source in run.glob("*.json"):
            target = recorded / run.name / source.name
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(source, target)
            paths.add(str(target.relative_to(ROOT)))
        if (
            run.name == "genuine-oracle-continuation-204-full"
            and (ROOT / ".context/204-full.log").exists()
        ):
            paths.add(".context/204-full.log")
    audit = json.loads((ROOT / "docs/analysis/202-replacement-metric-audit.json").read_text())
    paths.update(audit["preserved_replacement_hashes"])
    paths.update(
        [
            "scripts/stage2_real_reset_start_201.py",
            ".context/stage1_decomposition.json",
            ".context/stage2_reset_started.json",
            ".context/stage2_reset_framework.json",
        ]
    )
    files = {
        f: hashlib.sha256((ROOT / f).read_bytes()).hexdigest()
        for f in sorted(paths)
        if (ROOT / f).is_file()
    }
    result = dict(
        files=files,
        raw_arrays_excluded=True,
        checkpoint_weights_excluded=True,
        parent_manifest_sha256=hashlib.sha256(previous.read_bytes()).hexdigest(),
        publication="local only; no commit/push/post",
        scopes=[p.name for p in (ROOT / "runs").glob("genuine-oracle-continuation-204-*")],
    )
    (ROOT / "results/genuine-oracle-202-204/manifest.json").write_text(json.dumps(result, indent=2))
    (ROOT / ".context/202-204-publication-paths.json").write_text(
        json.dumps(sorted(files), indent=2)
    )
    print(f"Packaged {len(files)} hashed local files; raw arrays and weights regenerate offline.")


if __name__ == "__main__":
    main()
