"""Preserve actual-node factorial, failed224 and all2,665 prior evidence files."""
import hashlib,json,shutil
from pathlib import Path
R=Path(__file__).resolve().parents[1];P=R/'results/mlp-primitive-factorial-224b'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    assert not (P/'manifest.json').exists(),'Preserve an existing evidence closure unchanged.'
    prior=R/'results/native-mlp-remainder-223/manifest.json';old=json.loads(prior.read_text());files=dict(old['files']);assert len(files)==2665 and all(sha(R/p)==h for p,h in files.items())
    result=json.loads((R/'docs/analysis/224b-mlp-primitive-factorial.json').read_text());qualification=json.loads((R/'docs/analysis/224b-endpoint-qualification.json').read_text());assert result['qualified'] and qualification['qualified']
    run=R/'runs/mlp-primitive-factorial-224b';design=json.loads((run/'design.json').read_text());assert all(sha(R/p)==h for p,h in design['source_hashes'].items())
    seal=json.loads((run/'endpoint-seal.json').read_text());assert all(sha(R/p)==h for p,h in seal['files'].items())
    assert result['auditor_sha256']==sha(R/'scripts/audit_mlp_primitive_factorial_224b.py')
    post=json.loads((R/'docs/analysis/224b-silu-product-accounting.json').read_text());assert len(post['rows'])==128 and post['source_sha256']==sha(R/'scripts/audit_silu_product_contrast_224b.py') and post['maximum_rounding_closure']<=1e-9
    for frozen in ('frozen-224','frozen-224b','frozen-224b-posthoc'):
        h=json.loads((R/'.context'/frozen/'source-hashes.json').read_text());assert all(sha(R/p)==v for p,v in h.items())
    assert sha(R/'runs/mlp-primitive-factorial-224/failure.json')==design['failed224_sha256']
    files[str(prior.relative_to(R))]=sha(prior);sources=[];raw=[]
    for folder,patterns in (('scripts',('*224*.py',)),('docs/experiments',('224*.md',)),('docs/analysis',('224*.md','224*.json')),('docs/figures',('224*.png','224*.svg')),
        ('.context',('224*.log','224*.png','224*.txt','224b-initial-packaging-manifest.json','224-preexecution-check.py','mlp-primitive-factorial-224b.canvas.tsx','223-clean-copy-verification.log'))):
        for pattern in patterns:sources.extend((R/folder).glob(pattern))
    for frozen in ('frozen-224','frozen-224b','frozen-224b-posthoc'):sources.extend(p for p in (R/'.context'/frozen).rglob('*') if p.is_file())
    for name in ('mlp-primitive-factorial-224','mlp-primitive-factorial-224b'):
        root=R/'runs'/name
        for p in root.rglob('*'):
            if not p.is_file():continue
            if p.suffix=='.npz':raw.append(dict(path=str(p.relative_to(R)),bytes=p.stat().st_size,sha256=sha(p)))
            elif p.suffix in ('.json','.log'):
                q=P/'recorded-runs'/name/p.relative_to(root);q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q)
    assert len(raw)==128,len(raw)
    P.mkdir(parents=True,exist_ok=True)
    (P/'local-raw-inventory.json').write_text(json.dumps(dict(arrays=raw,reused_weights_path=design['weights_path'],reused_weights_sha256=design['weights_sha256'],scope='Actual arrays remain local and inventoried;223 weights reused unchanged. Failed224 stopped before saving its first case. No model array replication is claimed.'),indent=2,sort_keys=True)+'\n')
    sources.extend(p for p in P.rglob('*') if p.is_file() and p.name!='manifest.json')
    for p in sources:files[str(p.relative_to(R))]=sha(p)
    (P/'manifest.json').write_text(json.dumps(dict(files=files,prior_files=2665,previous_manifest_sha256=sha(prior),scope='Qualified224b actual-node primitive factorial, distinct from failed224 composite-affine final-coordinate bridge. Native full-sequence input and finite tails; no learned circuit, old whole-Jacobian recertification or prospective result.'),indent=2,sort_keys=True)+'\n')
    print(f'Packaged {len(files)} files; prior2,665 unchanged; {len(raw)} local raw archives inventoried.')
if __name__=='__main__':main()
