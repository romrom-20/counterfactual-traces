"""Preserve qualified local-MLP nonlinear-remainder interventions and inherited evidence."""

import hashlib,json,shutil
from pathlib import Path
R=Path(__file__).resolve().parents[1];P=R/'results/native-mlp-remainder-223'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    prior=R/'results/native-write-ledger-222/manifest.json';old=json.loads(prior.read_text());files=dict(old['files'])
    assert len(files)==2561 and all(sha(R/p)==h for p,h in files.items())
    result=json.loads((R/'docs/analysis/223-native-mlp-remainder.json').read_text());qualification=json.loads((R/'docs/analysis/223-local-mlp-qualification.json').read_text());assert result['qualified'] and qualification['qualified']
    run=R/'runs/native-mlp-remainder-223';design=json.loads((run/'design.json').read_text());assert all(sha(R/p)==h for p,h in design['source_hashes'].items())
    seal=json.loads((run/'qualification-seal.json').read_text());assert all(sha(R/p)==h for p,h in seal['files'].items())
    assert result['auditor_sha256']==sha(R/'scripts/audit_native_mlp_remainder_223.py')
    files[str(prior.relative_to(R))]=sha(prior);sources=[];raw=[]
    for folder,patterns in (('scripts',('*223*.py',)),('docs/experiments',('223*.md',)),('docs/analysis',('223*.md','223*.json')),('docs/figures',('223*.png','223*.svg')),
        ('.context',('223*.log','223*.png','223*.txt','native-mlp-remainder-223.canvas.tsx','222-clean-copy-verification.log'))):
        for pattern in patterns:sources.extend((R/folder).glob(pattern))
    sources.extend(p for p in (R/'.context/frozen-223').rglob('*') if p.is_file())
    for p in run.rglob('*'):
        if not p.is_file():continue
        if p.suffix=='.npz':raw.append(dict(path=str(p.relative_to(R)),bytes=p.stat().st_size,sha256=sha(p)))
        elif p.suffix in ('.json','.log'):
            q=P/'recorded-runs/native-mlp-remainder-223'/p.relative_to(run);q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q)
    (P/'local-raw-inventory.json').write_text(json.dumps(dict(arrays=raw,scope='Model arrays remain local and hash-inventoried. Historical originals are covered by inherited closures; code, metadata, reports, logs and viewer source are preserved.'),indent=2,sort_keys=True)+'\n')
    sources.extend(p for p in P.rglob('*') if p.is_file() and p.name!='manifest.json')
    for p in sources:files[str(p.relative_to(R))]=sha(p)
    (P/'manifest.json').write_text(json.dumps(dict(files=files,prior_files=2561,previous_manifest_sha256=sha(prior),
        scope='Qualified local MLP22/23 nonlinear-remainder necessity test. Native finite tails, primary natural verdict residual/margin and secondary product diagnostics. No original whole-Jacobian recertification, learned circuit or prospective prediction.'),indent=2,sort_keys=True)+'\n')
    print(f'Packaged {len(files)} files; prior2561 unchanged; {len(raw)} local raw archives inventoried.')
if __name__=='__main__':main()
