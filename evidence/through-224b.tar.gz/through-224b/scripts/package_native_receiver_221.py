"""Preserve native-attention factorial, weight diagnostic and explicitly corrected auditor."""

import hashlib,json,shutil
from pathlib import Path
R=Path(__file__).resolve().parents[1];P=R/"results/native-receiver-factorial-221"
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    prior=R/"results/source-only-neurons-220/manifest.json";old=json.loads(prior.read_text());files=dict(old["files"])
    assert len(files)==2312 and all(sha(R/p)==h for p,h in files.items())
    result=json.loads((R/"docs/analysis/221-native-receiver-factorial.json").read_text());assert result["qualified"]
    run=R/"runs/native-receiver-factorial-221";design=json.loads((run/"design.json").read_text());assert all(sha(R/p)==h for p,h in design["source_hashes"].items())
    correction=json.loads((R/"runs/native-receiver-factorial-221c/design.json").read_text());assert all(sha(R/p)==h for p,h in correction["source_hashes"].items())
    assert result["auditor_sha256"]==sha(R/"scripts/audit_native_receiver_factorial_221c.py")
    files[str(prior.relative_to(R))]=sha(prior);sources=[];raw=[]
    for folder,patterns in (("scripts",("*221*.py",)),("docs/experiments",("221*.md",)),("docs/analysis",("221*.md","221*.json")),("docs/figures",("221*.png","221*.svg")),
        (".context",("221*.log","221*.png","native-receiver-mechanism-221.canvas.tsx"))):
        for pattern in patterns:sources.extend((R/folder).glob(pattern))
    for name in ("frozen-221","frozen-221b","frozen-221c"):sources.extend(p for p in (R/".context"/name).rglob("*") if p.is_file())
    for name in ("native-receiver-factorial-221","native-receiver-factorial-221c"):
        for p in (R/"runs"/name).rglob("*"):
            if not p.is_file():continue
            if p.suffix==".npz":raw.append(dict(path=str(p.relative_to(R)),bytes=p.stat().st_size,sha256=sha(p)))
            elif p.suffix in (".json",".log"):
                q=P/"recorded-runs"/name/p.relative_to(R/"runs"/name);q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q)
    (P/"local-raw-inventory.json").write_text(json.dumps(dict(arrays=raw,scope="New arrays/weights and original hash-bound historical inputs remain local. Code, reports and array hashes are preserved."),indent=2,sort_keys=True)+"\n")
    sources.extend(p for p in P.rglob("*") if p.is_file() and p.name!="manifest.json")
    for p in sources:files[str(p.relative_to(R))]=sha(p)
    (P/"manifest.json").write_text(json.dumps(dict(files=files,prior_files=2312,previous_manifest_sha256=sha(prior),
        scope="Qualified native-attention carry/write/RMS retrospective factorial, frozen neuron controls and explicit221c dtype-only audit correction. Original whole-Jacobian and raw ideal failures preserved; no learned feature or prospective claim."),indent=2,sort_keys=True)+"\n")
    print(f"Packaged {len(files)} files; prior2312 unchanged; {len(raw)} local raw archives inventoried.")
if __name__=="__main__":main()
