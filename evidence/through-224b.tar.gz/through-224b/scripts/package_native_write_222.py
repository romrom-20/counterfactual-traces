"""Extend the immutable native-factorial closure with actual native-write interventions."""

import hashlib,json,shutil
from pathlib import Path
R=Path(__file__).resolve().parents[1];P=R/"results/native-write-ledger-222"
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    prior=R/"results/native-receiver-factorial-221/manifest.json";old=json.loads(prior.read_text());files=dict(old["files"])
    assert len(files)==2428 and all(sha(R/p)==h for p,h in files.items())
    result=json.loads((R/"docs/analysis/222-native-write-ledger.json").read_text());assert result["qualified"]
    run=R/"runs/native-write-ledger-222";design=json.loads((run/"design.json").read_text());assert all(sha(R/p)==h for p,h in design["source_hashes"].items())
    assert result["auditor_sha256"]==sha(R/"scripts/audit_native_write_ledger_222.py")
    files[str(prior.relative_to(R))]=sha(prior);sources=[];raw=[]
    for folder,patterns in (("scripts",("*222*.py",)),("docs/experiments",("222*.md",)),("docs/analysis",("222*.md","222*.json")),("docs/figures",("222*.png","222*.svg")),
        (".context",("222*.log","222*.png","222*.txt","native-write-mechanism-222.canvas.tsx","221-clean-copy-verification.log"))):
        for pattern in patterns:sources.extend((R/folder).glob(pattern))
    sources.extend(p for p in (R/".context/frozen-222").rglob("*") if p.is_file())
    for p in run.rglob("*"):
        if not p.is_file():continue
        if p.suffix==".npz":raw.append(dict(path=str(p.relative_to(R)),bytes=p.stat().st_size,sha256=sha(p)))
        elif p.suffix in (".json",".log"):
            q=P/"recorded-runs/native-write-ledger-222"/p.relative_to(run);q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q)
    (P/"local-raw-inventory.json").write_text(json.dumps(dict(arrays=raw,scope="Original numerical arrays remain local. This inventory hash-binds all new weights, ledger and intervention archives; historical inputs are covered by preserved parent manifests."),indent=2,sort_keys=True)+"\n")
    sources.extend(p for p in P.rglob("*") if p.is_file() and p.name!="manifest.json")
    for p in sources:files[str(p.relative_to(R))]=sha(p)
    (P/"manifest.json").write_text(json.dumps(dict(files=files,prior_files=2428,previous_manifest_sha256=sha(prior),
        scope="Qualified finite native write ledger and upstream knockout/rescue on operation-excluded old examples. All failed causal gates, prior original whole-Jacobian and raw ideal-vector caveats preserved. No learned circuit or prospective claim."),indent=2,sort_keys=True)+"\n")
    print(f"Packaged {len(files)} files; prior2428 unchanged; {len(raw)} local raw archives inventoried.")
if __name__=="__main__":main()
