"""Preserve the qualified retrospective neuron experiment without changing old evidence."""

import hashlib
import json
import shutil
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
PACKAGE=ROOT/"results/neuron-mixed-interventions-219"


def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    previous=ROOT/"results/silu-range-falsification-218/manifest.json";prior=json.loads(previous.read_text());files=dict(prior["files"])
    assert len(files)==2089 and all(sha(ROOT/p)==h for p,h in files.items())
    result=json.loads((ROOT/"docs/analysis/219-neuron-mixed-interventions.json").read_text());assert result["qualified"]
    run=ROOT/"runs/neuron-mixed-interventions-219";design=json.loads((run/"design.json").read_text())
    assert all(sha(ROOT/p)==h for p,h in design["source_hashes"].items())
    files[str(previous.relative_to(ROOT))]=sha(previous)
    sources=[]
    for folder,patterns in (("scripts",("*219*.py",)),("docs/experiments",("219*.md",)),("docs/analysis",("219*.md","219*.json")),
        ("docs/figures",("219*.png","219*.svg")),(".context",("219*.log","219-neuron-mixed-interventions.png","neuron-mixed-interventions-219.canvas.tsx"))):
        for pattern in patterns:sources.extend((ROOT/folder).glob(pattern))
    sources.extend(p for p in (ROOT/".context/frozen-219").rglob("*") if p.is_file())
    raw=[]
    for p in run.rglob("*"):
        if not p.is_file():continue
        if p.suffix==".npz":raw.append(dict(path=str(p.relative_to(ROOT)),bytes=p.stat().st_size,sha256=sha(p)))
        elif p.suffix==".json":
            dest=PACKAGE/"recorded-runs"/p.relative_to(run);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest)
    (PACKAGE/"local-raw-inventory.json").write_text(json.dumps(dict(arrays=raw,scope="Original parent datasets and new arrays/weights stay local; restore original hash-bound inputs for a repeat. Numerical re-execution has not been repeated in a clean copy."),indent=2,sort_keys=True)+"\n")
    sources.extend(p for p in PACKAGE.rglob("*") if p.is_file() and p.name!="manifest.json")
    for p in sources:files[str(p.relative_to(ROOT))]=sha(p)
    (PACKAGE/"manifest.json").write_text(json.dumps(dict(files=files,prior_files=2089,previous_manifest_sha256=sha(previous),
        scope="Qualified retrospective signed-neuron accounting and direct product interventions in the specified surrogate. Old 218 and numerical failures unchanged. No learned features or prospective accuracy claim."),indent=2,sort_keys=True)+"\n")
    print(f"Packaged {len(files)} files; all prior2089 unchanged; {len(raw)} local raw archives inventoried.")


if __name__=="__main__":main()
