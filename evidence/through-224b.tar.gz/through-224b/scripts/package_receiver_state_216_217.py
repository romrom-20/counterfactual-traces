"""Preserve the prior closure and new finite-head/reset evidence without publishing."""

import hashlib
import json
import shutil
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
PACKAGE=ROOT/"results/receiver-state-mechanism-216-217"


def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    prior=ROOT/"results/rms-product-transfer-212-215/manifest.json"
    previous=json.loads(prior.read_text());files=dict(previous["files"])
    assert len(files)==1807 and all(sha(ROOT/p)==h for p,h in files.items())
    assert json.loads((ROOT/"docs/analysis/216-vector-readout-cross-audit.json").read_text())["qualified"]
    assert json.loads((ROOT/"docs/analysis/217-selected-receiver-reset.json").read_text())["qualified"]
    files[str(prior.relative_to(ROOT))]=sha(prior)
    sources=[]
    for folder,patterns in (
        ("scripts",("*216*.py","*217*.py")),
        ("docs/experiments",("216*.md","217*.md")),
        ("docs/analysis",("216*.md","216*.json","217*.md","217*.json")),
        ("docs/figures",("216*.png","216*.svg","217*.png","217*.svg")),
        (".context",("216*.log","217*.log","receiver-state-mechanism-216-217.canvas.tsx","217-selected-receiver-resets.png","sol-review-217.md")),
    ):
        for pattern in patterns:sources.extend((ROOT/folder).glob(pattern))
    raw=[]
    for name in ("vector-readout-cross-216","vector-readout-cross-216b","selected-receiver-reset-217"):
        parent=ROOT/"runs"/name
        for path in parent.rglob("*.json"):
            target=PACKAGE/"recorded-runs"/name/path.relative_to(parent)
            target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(path,target)
        for path in parent.rglob("*.npz"):
            raw.append(dict(path=str(path.relative_to(ROOT)),bytes=path.stat().st_size,sha256=sha(path)))
    for name in ("frozen-216","frozen-216b","frozen-217"):
        sources.extend(p for p in (ROOT/".context"/name).rglob("*") if p.is_file())
    (PACKAGE/"local-raw-inventory.json").write_text(json.dumps(dict(arrays=raw,scope="Raw NPZ and weights remain local; regenerate in a compatible fresh checkout using preserved code."),indent=2,sort_keys=True)+"\n")
    sources.extend(p for p in PACKAGE.rglob("*") if p.is_file() and p.name!="manifest.json")
    for path in sources:files[str(path.relative_to(ROOT))]=sha(path)
    (PACKAGE/"manifest.json").write_text(json.dumps(dict(files=files,prior_files=1807,previous_manifest_sha256=sha(prior),
        scope="Qualified retrospective finite-head crosses and selected receiver resets. Original whole-Jacobian coordinate failures and qualified 204 scope preserved. No exact error-onset layer, learned circuit or prospective claim."),indent=2,sort_keys=True)+"\n")
    print(f"Packaged {len(files)} files; all prior 1807 unchanged; {len(raw)} local raw archives inventoried.")


if __name__=="__main__":main()
