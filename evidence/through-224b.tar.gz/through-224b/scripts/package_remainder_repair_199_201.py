"""Local scoped reproducibility extension, preserving numerical and wiring failures."""

import hashlib
import json
import shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DEST = ROOT / "results/remainder-repair-199-201"


def copy(source, destination):
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, destination)


def main():
    for stage in (199, 201):
        audit = json.loads((ROOT / f"docs/analysis/{stage}-independent-audit.json").read_text())
        assert audit["numerical_qualified"] and all(audit["controls"].values())
    for stage, folder in (
        (199, "layerwise-nonlinear-remainder-199"),
        (201, "discovery-ranked-repair-201"),
    ):
        for filename in ("design.json", "pipeline-status.json"):
            copy(ROOT / "runs" / folder / filename, DEST / f"provenance/{stage}-{filename}")
    for stage in (199, 200, 201):
        copy(
            ROOT / f".context/{stage}-frozen-source-snapshot.json",
            DEST / f"provenance/{stage}-source-snapshot.json",
        )
    for name in (
        "200-ranked-repair-preflight.log",
        "201-ranked-repair-preflight.log",
        "201-ranked-repair-preflight-corrected.log",
        "201-ranked-repair-preflight.json",
        "199-layerwise-remainder-run.log",
        "201-ranked-repair-run.log",
        "201-ranked-repair-numerical.log",
    ):
        copy(ROOT / ".context" / name, DEST / "provenance" / name)
    seed = DEST / "prerequisites/191"
    index = {
        "design.json": "runs/one-sided-curvature-forecast-191/design.json",
        "runtime.json": "runs/one-sided-curvature-forecast-191/qwen15/runtime.json",
    }
    for name, path in index.items():
        copy(ROOT / path, seed / name)
    (seed / "index.json").write_text(json.dumps(index, indent=2) + "\n")
    (DEST / "README.md").write_text(
        "# Remainder diagnosis and failed prospective repair,199–201\n\nBoth computations passed their defined verification packages.199is paired/oracle retrospective diagnosis;201is genuinely newFalse-only forecasts with discovery data selecting block IDs only. ALLsix201arms failed native individual/residual and joint-progress accounts0/16panels. Read [the diagnosis](../../docs/analysis/199-layerwise-nonlinear-remainder-result.md) and [the heldout result](../../docs/analysis/201-discovery-ranked-repair-result.md). Original196primitive reverse-over-reverse discrepancy remains unresolved; later checks share the forwardADbackend for local maps and use standard firstreverse contractions. No unique learned mechanism or solvedQuestionB claim.\n\nUse the pinned offline environment documented in [earlier reproducibility bundle](../norm-curvature-189-194/README.md). In a clean checkout run `HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 PYTHONPATH=src:scripts .venv/bin/python scripts/reproduce_remainder_repair_199_201.py`; `--verify-only` checks hashes/sourcefingerprints with zero models; `--plan` shows commands. Wrapper seeds explicitly historical191design/runtime/audit/numerics, NOT a fresh qualification of191. It freshly regenerates193fullrawFalse/True trajectories and qualifies193 before199/201. For a fully fresh earlier chain, run the older186–194pipeline in a separate clean checkout and then199/201there; this wrapper deliberately refuses existing193/199/201runs. Fresh executions overwrite canonical audit/report JSON locally; scientific sources unchanged.\n\nFull pipeline from historical191costs544ordinary full-model calls+256differentiated full-model calls+11456local blockJVPs; finite source/block/head operations counted separately in protocols/status. A new201fingerprint may differ because its design includes fresh parent-auditSHA with execution timestamps; fixed source/code/selection criteria are verified. No training/generation. Raw arrays and checkpointweights are excluded fromGit and regenerated; scopedmanifest includes prior source closure and all preserved failures.200andinitial201preflights failed wiring/import before any model evaluations; corrected201preflight passed before the study.201helper aliases are byte-identical to frozen200helpers; bothcopiesincluded.\n\nThe finite-first-block control uses knownFalseinput+embeddingedit/functions; it is not supplied by an observedTrue trajectory.199uses pairedTrue states and an oracle error direction explicitly.201keeps up to4wholeblocks finite includingSource, using known model functions at CURRENTpredicted inputs; this is not a cheap circuit or prediction without counterfactual component computation. OneQwen1.5Bcheckpoint, dependent synthetic templates, no independent team and failed earlier grounding controls constrain claims. No commit,push orLessWrong publication.\n"
    )
    files = set(
        json.loads((ROOT / "results/norm-curvature-195-196/manifest.json").read_text())["files"]
    )
    files.add("results/norm-curvature-195-196/manifest.json")
    for path in (
        "scripts/run_layerwise_nonlinear_remainder_199.py",
        "scripts/audit_layerwise_nonlinear_remainder_199.py",
        "scripts/report_layerwise_nonlinear_remainder_199.py",
        "scripts/plot_layerwise_remainder_199.py",
        "tests/test_layerwise_nonlinear_remainder_199.py",
        "docs/experiments/199-layerwise-nonlinear-remainder.md",
        "docs/analysis/199-independent-audit.json",
        "docs/analysis/199-layerwise-remainder-summary.json",
        "docs/analysis/199-layerwise-nonlinear-remainder-result.md",
        "docs/figures/199-local-remainder-amplification.png",
        "docs/figures/199-local-remainder-amplification.svg",
        "docs/figures/199-local-remainder-amplification-layout.png",
        "docs/figures/199-local-remainder-amplification-layout.svg",
        "docs/analysis/201-independent-audit.json",
        "docs/analysis/201-numerical-recheck.json",
        "docs/analysis/201-ranked-repair-summary.json",
        "docs/analysis/201-discovery-ranked-repair-result.md",
        "docs/figures/201-ranked-repair.png",
        "docs/figures/201-ranked-repair.svg",
        "docs/analysis/200-preflight-technical-failure.json",
        "docs/analysis/201-initial-import-preflight-failure.json",
        "tests/test_ranked_block_response_200.py",
        "scripts/build_remainder_repair_canvas_199_201.py",
        "scripts/reproduce_remainder_repair_199_201.py",
        "scripts/package_remainder_repair_199_201.py",
        "scripts/report_discovery_ranked_repair_201.py",
    ):
        files.add(path)
    for stage in (200, 201):
        for stem in (
            "run_discovery_ranked_repair",
            "audit_discovery_ranked_repair",
            "recheck_discovery_ranked_repair",
            "check_discovery_ranked_repair",
            "ranked_block_response",
            "public_ranked_block_response",
        ):
            files.add(f"scripts/{stem}_{stage}.py")
        files.add(f"docs/experiments/{stage}-discovery-ranked-finite-block-repair.md")
    files.update(
        str(p.relative_to(ROOT))
        for p in DEST.rglob("*")
        if p.is_file() and p.name != "manifest.json"
    )
    manifest = {
        "scope": "Verified199paired diagnosis and verified201FAILEDprospective repair; allarms/failures preserved, historical191seed explicitly notfreshqualification, priorclosure included, original196discrepancy open, norawarrays/weights.",
        "files": {p: hashlib.sha256((ROOT / p).read_bytes()).hexdigest() for p in sorted(files)},
    }
    (DEST / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    (ROOT / ".context/199-201-publication-paths.json").write_text(
        json.dumps(sorted(files | {str((DEST / "manifest.json").relative_to(ROOT))}), indent=2)
        + "\n"
    )
    print(
        f"199/201local scoped bundle: {len(files)}hashedfiles, allfailedarms andpreflights retained."
    )


if __name__ == "__main__":
    main()
