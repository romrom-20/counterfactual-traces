"""Presentation packaging; extend the unchanged prior closure, including failures."""

import hashlib
import json
import shutil
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
PACKAGE=ROOT/"results/rms-product-transfer-212-215"


def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    previous=ROOT/"results/block28-primitives-210-211/manifest.json"
    old=json.loads(previous.read_text());files=dict(old["files"])
    assert len(files)==1390 and all(sha(ROOT/p)==h for p,h in files.items())
    files[str(previous.relative_to(ROOT))]=sha(previous)
    sources=[]
    for directory,patterns in (
        ("scripts",("*212*.py","*213*.py","*214*.py","*215*.py")),
        ("docs/experiments",("212*.md","213*.md","214*.md","215*.md")),
        ("docs/analysis",("212*.json","212*.md","213*.json","213*.md","214*.json","214*.md","215*.json","215*.md")),
        ("docs/figures",("212*.png","212*.svg","214*.png","214*.svg","215*.png","215*.svg")),
        (".context",("212*.log","213*.log","214*.log","215*.log","212-215*.log","rms-product-transfer-212-215.canvas.tsx","215-paired-product-effects.png","sol-review-212-215.md")),
    ):
        for pattern in patterns:sources.extend((ROOT/directory).glob(pattern))
    raw=[]
    for name in ("rms-product-factorial-212","rms-product-factorial-212b","gate-up-arithmetic-213","last-block-transfer-214","matched-incoming-control-215"):
        run=ROOT/"runs"/name
        for p in run.rglob("*.json"):
            target=PACKAGE/"recorded-runs"/name/p.relative_to(run)
            target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target)
        for p in run.rglob("*.npz"):
            raw.append(dict(path=str(p.relative_to(ROOT)),bytes=p.stat().st_size,sha256=sha(p)))
    # The sole failed212partial is small enough to preserve its actual arrays, too.
    for p in (ROOT/"runs/rms-product-factorial-212/pairs").glob("*.npz"):
        target=PACKAGE/"failed-artifacts"/"212"/p.name
        target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target)
    (PACKAGE/"local-raw-inventory.json").write_text(json.dumps(dict(arrays=raw,scope="RawsuccessfulNPZremainlocal; regeneratetheminfreshcheckout. Thefailed212partialarrayisalsoarchived."),indent=2,sort_keys=True)+"\n")
    for name in ("frozen-212","frozen-212b","frozen-213","frozen-214","frozen-214b","frozen-215"):
        sources.extend(p for p in (ROOT/".context"/name).rglob("*") if p.is_file())
    sources.extend(p for p in PACKAGE.rglob("*") if p.is_file() and p.name!="manifest.json")
    for p in sources:files[str(p.relative_to(ROOT))]=sha(p)
    manifest=dict(files=files,prior_files=1390,previous_manifest_sha256=sha(previous),
        scope="Qualifiedconditionalfiniteinterventionsandarithmeticaccount;214transferfails,215matchedinputdependence. OriginalwholeblockJacobianunqualified;204qualifiedscopepreserved; nolearnedcircuitorprospectiveaccuracyclaim.")
    (PACKAGE/"manifest.json").write_text(json.dumps(manifest,indent=2,sort_keys=True)+"\n")
    print(f"Packaged {len(files)} files; prior1390 unchanged; {len(raw)} localNPZhashes recorded.")


if __name__=="__main__":main()
