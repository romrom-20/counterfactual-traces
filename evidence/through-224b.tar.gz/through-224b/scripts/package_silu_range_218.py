"""Extend the preserved 216–217 closure with the completed SiLU falsification test."""

import hashlib
import json
import shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PACKAGE = ROOT / "results/silu-range-falsification-218"


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    previous = ROOT / "results/receiver-state-mechanism-216-217/manifest.json"
    obj = json.loads(previous.read_text())
    files = dict(obj["files"])
    assert len(files) == 1988 and all(sha(ROOT / p) == h for p, h in files.items())
    assert json.loads((ROOT / "docs/analysis/218-silu-range-falsification-audit.json").read_text())["qualified"]
    run = ROOT / "runs/silu-range-falsification-218"
    design = json.loads((run / "design.json").read_text())
    bindings = json.loads((run / "artifact-bindings.json").read_text())
    assert all(sha(ROOT / p) == h for p, h in design["source_hashes"].items())
    assert all(sha(ROOT / p) == h for p, h in bindings["files"].items())
    files[str(previous.relative_to(ROOT))] = sha(previous)
    sources = []
    for folder, patterns in (
        ("scripts", ("*218*.py",)),
        ("docs/experiments", ("218*.md",)),
        ("docs/analysis", ("218*.md", "218*.json")),
        ("docs/figures", ("218*.png", "218*.svg")),
        (".context", ("silu-range-falsification-218.canvas.tsx", "218-silu-range-and-product-effect.png", "216-217-clean-copy-verification.log")),
    ):
        for pattern in patterns:
            sources.extend((ROOT / folder).glob(pattern))
    sources.extend(p for p in (ROOT / ".context/archived-218-executed-sources").rglob("*") if p.is_file())
    raw = []
    for path in run.rglob("*"):
        if not path.is_file():
            continue
        if path.suffix == ".npz":
            raw.append(dict(path=str(path.relative_to(ROOT)), bytes=path.stat().st_size, sha256=sha(path)))
        elif path.suffix in (".json", ".log"):
            target = PACKAGE / "recorded-runs" / path.relative_to(run)
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(path, target)
    (PACKAGE / "local-raw-inventory.json").write_text(json.dumps(dict(arrays=raw,
        scope="Raw arrays and pinned weights stay local; regenerate in a compatible fresh checkout."), indent=2, sort_keys=True) + "\n")
    sources.extend(p for p in PACKAGE.rglob("*") if p.is_file() and p.name != "manifest.json")
    for path in sources:
        files[str(path.relative_to(ROOT))] = sha(path)
    (PACKAGE / "manifest.json").write_text(json.dumps(dict(files=files, prior_files=1988,
        previous_manifest_sha256=sha(previous),
        scope="Finite SiLU replacement falsification in a defined retrospective attention-affine surrogate. Not range clipping alone, a learned circuit or prospective prediction. Original whole-Jacobian and raw mixed-term failures remain recorded."), indent=2, sort_keys=True) + "\n")
    print(f"Packaged {len(files)} files; prior 1988 unchanged; {len(raw)} local raw archives inventoried.")


if __name__ == "__main__":
    main()
