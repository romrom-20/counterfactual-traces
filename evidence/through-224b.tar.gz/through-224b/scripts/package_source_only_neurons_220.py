"""Preserve the frozen fresh hypothesis test and keep the prior closure unchanged."""

import hashlib,json,shutil
from pathlib import Path
R=Path(__file__).resolve().parents[1];P=R/"results/source-only-neurons-220"
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    previous=R/"results/neuron-mixed-interventions-219/manifest.json";old=json.loads(previous.read_text());files=dict(old["files"])
    assert len(files)==2250 and all(sha(R/p)==h for p,h in files.items())
    result=json.loads((R/"docs/analysis/220-source-only-neuron-hypothesis.json").read_text());assert result["qualified"] and result["all_forecasts_sealed_before_native"]
    run=R/"runs/source-only-neurons-220";design=json.loads((run/"design.json").read_text());assert all(sha(R/p)==h for p,h in design["source_hashes"].items())
    files[str(previous.relative_to(R))]=sha(previous);sources=[];raw=[]
    for folder,patterns in (("scripts",("*220*.py",)),("docs/experiments",("220*.md",)),("docs/analysis",("220*.md","220*.json")),("docs/figures",("220*.png","220*.svg")),
        (".context",("220*.log","220-source-only-neuron-hypothesis.png","neuron-upstream-hypothesis-219-220.canvas.tsx","219-clean-copy-verification.log"))):
        for pattern in patterns:sources.extend((R/folder).glob(pattern))
    sources.extend(p for p in (R/".context/frozen-220").rglob("*") if p.is_file())
    for p in run.rglob("*"):
        if not p.is_file():continue
        if p.suffix==".npz":raw.append(dict(path=str(p.relative_to(R)),bytes=p.stat().st_size,sha256=sha(p)))
        elif p.suffix==".json":
            q=P/"recorded-runs"/p.relative_to(run);q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q)
    (P/"local-raw-inventory.json").write_text(json.dumps(dict(arrays=raw,scope="New False forecasts and later True observations remain local. Their hashes, seal ordering and code are preserved; regenerate with pinned offline inputs/runtime."),indent=2,sort_keys=True)+"\n")
    sources.extend(p for p in P.rglob("*") if p.is_file() and p.name!="manifest.json")
    for p in sources:files[str(p.relative_to(R))]=sha(p)
    (P/"manifest.json").write_text(json.dumps(dict(files=files,prior_files=2250,previous_manifest_sha256=sha(previous),
        scope="Frozen fresh test of a source-only local neuron hypothesis. All earlier evidence unchanged. Native-incoming attention-affine target, not full Question B or a learned circuit."),indent=2,sort_keys=True)+"\n")
    print(f"Packaged {len(files)} files; prior 2250 unchanged; {len(raw)} local raw archives inventoried.")
if __name__=="__main__":main()
