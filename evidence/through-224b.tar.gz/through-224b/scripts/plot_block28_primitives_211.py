"""Presentation-only figures from qualified finite-intervention results."""

import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).resolve().parents[1]


def main():
    data = json.loads((ROOT / "docs/analysis/211-block28-primitives.json").read_text())
    assert data["finite_interventions_qualified"]
    primitives = (
        "input_rms",
        "qk_product",
        "softmax",
        "weight_value",
        "post_rms",
        "silu",
        "gate_up",
    )
    groups = (
        "attention_norm_routing",
        "value_output_interaction",
        "mlp_input_rms",
        "silu_curvature",
        "gate_up_interaction",
    )
    labels = (
        "Attn input\nRMS",
        "QK\nproduct",
        "Softmax",
        "Weight–\nvalue",
        "MLP input\nRMS",
        "SiLU",
        "Gate–up",
    )
    group_labels = ("Attn norm\n+ routing", "Weight–\nvalue", "MLP input\nRMS", "SiLU", "Gate–up")
    plt.rcParams.update({"font.size": 9, "axes.spines.top": False, "axes.spines.right": False})
    fig, axes = plt.subplots(2, 3, figsize=(14, 8), constrained_layout=True)
    for row, branch in enumerate(("native", "linear27")):
        cases = [r for r in data["rows"] if r["branch"] == branch]
        a = axes[row]
        for i, name in enumerate(primitives):
            values = [
                r["vectors"]["component_" + name]["receivers"]["toward_native"]["signed_projection"]
                for r in cases
            ]
            a[0].scatter(i + np.linspace(-0.13, 0.13, 64), values, s=7, color="0.6", alpha=0.5)
            a[0].plot([i - 0.25, i + 0.25], [np.median(values)] * 2, color="#1d4f77", lw=3)
        a[0].axhline(0, color="0.3", lw=0.8)
        a[0].set(
            xticks=range(7),
            xticklabels=labels,
            ylabel="Signed projection toward native error (residual units)",
            xlabel="Frozen-reference local remainder",
            title=branch + ": receiving rows; reference/public gap kept separate",
        )
        for j, (metric, title, bound) in enumerate(
            (
                ("relative_l2", "Final verdict residual error", 0.05),
                ("absolute_margin_error", "Final absolute margin-response error", 0.10),
            ),
            1,
        ):
            for i, name in enumerate(groups):
                for shift, prefix, color, marker in (
                    (-0.14, "budget_repair_", "0.55", "o"),
                    (0.14, "surgery_repair_", "#1d4f77", "s"),
                ):
                    operand_name = (
                        {
                            "value_output_interaction": "weight_value",
                            "mlp_input_rms": "post_rms",
                            "silu_curvature": "silu",
                            "gate_up_interaction": "gate_up",
                        }.get(name, name)
                        if prefix == "budget_repair_"
                        else name
                    )
                    vals = [
                        r["endpoints"][prefix + operand_name]["verdict"][metric]
                        if metric == "relative_l2"
                        else r["endpoints"][prefix + operand_name][metric]
                        for r in cases
                    ]
                    a[j].scatter(
                        i + shift,
                        np.median(vals),
                        color=color,
                        marker=marker,
                        s=40,
                        label=(
                            "Reference remainder insertion"
                            if prefix.startswith("budget")
                            else "Finite surgery-effect insertion"
                        )
                        if i == 0
                        else None,
                    )
            baseline = [
                r["endpoints"]["baseline"]["verdict"][metric]
                if metric == "relative_l2"
                else r["endpoints"]["baseline"][metric]
                for r in cases
            ]
            a[j].axhline(
                np.median(baseline), color="0.3", ls="--", label="Original209c JVP baseline"
            )
            a[j].axhline(bound, color="0.7", ls=":", label="Original accuracy bound")
            a[j].set(
                xticks=range(5),
                xticklabels=group_labels,
                xlabel="Only receiving-row corrections inserted; retrospective",
                ylabel="Median relative L2 error (ratio)"
                if j == 1
                else "Median absolute margin error (nats)",
                title=branch + ": " + title,
            )
            if row == 0:
                a[j].legend(fontsize=7)
    fig.suptitle(
        "Block28: signed local discrepancies and finite primitive intervention tests", fontsize=14
    )
    fig.savefig(ROOT / "docs/figures/211-block28-primitives.png", dpi=160)
    fig.savefig(ROOT / "docs/figures/211-block28-primitives.svg")
    plt.close(fig)


if __name__ == "__main__":
    main()
