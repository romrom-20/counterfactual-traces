"""Presentation only: plot qualified factorial and prospective partition results."""

import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).resolve().parents[1]


def main():
    fact = json.loads((ROOT / "docs/analysis/209c-two-block-factorial.json").read_text())
    part = json.loads((ROOT / "docs/analysis/208-source-receiver-partition.json").read_text())
    assert fact["qualified"] and part["qualified"]
    plt.rcParams.update({"font.size": 10, "axes.spines.top": False, "axes.spines.right": False})
    fig, axes = plt.subplots(2, 2, figsize=(12, 8), constrained_layout=True)
    for ax, metric, label in [
        (axes[0, 0], "residual", "Verdict displacement relative L2 error (ratio)"),
        (axes[0, 1], "margin", "Absolute verdict margin-response error (nats)"),
    ]:
        for i, arm in enumerate(("LL", "FL", "LF", "FF")):
            values = [
                r["arms"][arm]["verdict"]["relative_l2"]
                if metric == "residual"
                else r["arms"][arm]["absolute_margin_error"]
                for r in fact["rows"]
            ]
            ax.scatter(
                i + np.linspace(-0.13, 0.13, len(values)), values, s=9, color="0.6", alpha=0.65
            )
            ax.plot([i - 0.23, i + 0.23], [np.median(values)] * 2, color="#1d4f77", lw=3)
        ax.axhline(
            0.05 if metric == "residual" else 0.10,
            color="0.3",
            ls="--",
            lw=1,
            label="Original bound",
        )
        ax.set(
            xticks=range(4),
            xticklabels=["27L / 28L", "27F / 28L", "27L / 28F", "27F / 28F"],
            xlabel="Block response: L=False-state linear; F=finite",
            ylabel=label,
        )
        ax.set_title("209c: fixed native reset before block 27; all readouts finite", fontsize=10)
        ax.legend(fontsize=8)
    selected = (
        "source_linear",
        "source_linear_finite_head",
        "source_receiver",
        "full_finite_control",
        "zero_displacement",
    )
    names = (
        "Source-linear",
        "Same + finite head",
        "Source–receiver",
        "Full finite",
        "Zero displacement",
    )
    colors = ("0.45", "0.7", "#1d4f77", "0.2", "0.6")
    for arm, name, color in zip(selected, names, colors):
        curve = np.median(
            [
                [layer["verdict"]["relative_l2"] for layer in r["arms"][arm]["layers"]]
                for r in part["rows"]
            ],
            axis=0,
        )
        axes[1, 0].plot(
            range(1, 29),
            curve,
            label=name,
            color=color,
            ls=":" if arm == "source_linear_finite_head" else "-",
        )
    axes[1, 0].axhline(0.05, color="0.3", ls="--", lw=1)
    axes[1, 0].set(
        xlabel="Completed transformer blocks",
        ylabel="Median verdict displacement relative L2 error (ratio)",
        title="208: all 64 fresh contexts, globally sealed forecasts",
    )
    axes[1, 0].legend(fontsize=8)
    for i, (arm, name, color) in enumerate(zip(selected, names, colors)):
        values = [r["arms"][arm]["absolute_margin_error"] for r in part["rows"]]
        axes[1, 1].scatter(
            i + np.linspace(-0.13, 0.13, len(values)), values, s=9, color=color, alpha=0.55
        )
        axes[1, 1].plot([i - 0.23, i + 0.23], [np.median(values)] * 2, color="0.15", lw=2)
    axes[1, 1].axhline(0.10, color="0.3", ls="--", lw=1, label="Original 0.10-nat bound")
    axes[1, 1].set(
        xticks=range(5),
        xticklabels=["Source\nlinear", "Finite\nhead", "Source–\nreceiver", "Full\nfinite", "Zero"],
        xlabel="Frozen prospective arm",
        ylabel="Absolute margin-response error (nats)",
        title="208: individual final margin errors; lines show medians",
    )
    axes[1, 1].legend(fontsize=8)
    fig.suptitle("Finite block interactions and the false-only source–receiver test", fontsize=15)
    fig.savefig(ROOT / "docs/figures/208-209-factorial-partition.png", dpi=170)
    fig.savefig(ROOT / "docs/figures/208-209-factorial-partition.svg")
    plt.close(fig)


if __name__ == "__main__":
    main()
