"""Presentation only: draw already frozen 202/204 numerical summaries."""

import argparse
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--scope", choices=["sample", "full"], required=True)
    scope = parser.parse_args().scope
    data = json.loads((ROOT / f"docs/analysis/204-{scope}-oracle-summary.json").read_text())
    fig, axes = plt.subplots(1, 3, figsize=(16, 4.8), layout="constrained")
    for row in data["original201_layerwise"]:
        if row["arm"] == "source_linear":
            axes[0].plot(
                range(1, 29), row["source_median_q"], label="Boolean source", color="#333333"
            )
            axes[0].plot(
                range(1, 29), row["verdict_median_q"], label="Verdict position", color="#24758b"
            )
    axes[0].set(
        title="201 error begins after an accurate first block",
        xlabel="Completed public blocks",
        ylabel="Median relative displacement error",
    )
    for arm, color in [("source_linear", "#333333"), ("union_blocks", "#24758b")]:
        rows = [r for r in data["reset_summary"] if r["arm"] == arm]
        k = [r["next_block"] for r in rows]
        axes[1].plot(
            k, [r["median_relative_error"] for r in rows], marker="o", label=arm, color=color
        )
        axes[2].plot(
            k, [r["median_absolute_margin_error"] for r in rows], marker="o", label=arm, color=color
        )
    axes[1].axhline(1, color="#888888", ls=":", label="Zero displacement")
    axes[1].axhline(0.05, color="#888888", ls="--", label="Original error bound")
    axes[1].set(
        title=f"Genuine oracle resets: {scope}",
        xlabel="Next public block k (reset BEFORE k)",
        ylabel="Median final verdict displacement error",
    )
    axes[2].axhline(0.1, color="#888888", ls="--", label="Original margin bound")
    axes[2].set(
        title="Final behavior after the same reset",
        xlabel="Next public block k (reset BEFORE k)",
        ylabel="Median absolute margin error (nats)",
    )
    for ax in axes:
        ax.spines[["top", "right"]].set_visible(False)
        ax.legend(fontsize=8)
        ax.grid(axis="y", alpha=0.15)
    fig.suptitle(
        f"201 panel: 64 pairs. Reset panels: {data['reset_summary'][0]['count']} pairs. Retrospective oracle diagnosis.",
        fontsize=13,
    )
    out = ROOT / f"docs/figures/204-{scope}-genuine-oracle"
    fig.savefig(out.with_suffix(".png"), dpi=160)
    fig.savefig(out.with_suffix(".svg"))
    plt.close(fig)
    print(out.with_suffix(".png"))
    norms_path = ROOT / f"docs/analysis/207-{scope}-layerwise-norms.json"
    if norms_path.exists():
        norms = json.loads(norms_path.read_text())
        fig, axes = plt.subplots(1, 2, figsize=(13, 4.8), layout="constrained")
        for ax, position in zip(axes, ["source", "verdict"]):
            rows = [
                r
                for r in norms["rows"]
                if r["arm"] == "source_linear" and r["position"] == position
            ]
            x = [r["completed_blocks"] for r in rows]
            for field, label, color, style in [
                ("median_native_norm", "Native displacement", "#333333", "-"),
                ("median_error_norm", "Forecast error", "#24758b", "-"),
                ("median_native_remainder_norm", "Local native remainder", "#888888", "--"),
            ]:
                ax.plot(x, [r[field] for r in rows], label=label, color=color, ls=style)
            ax.set(
                title=f"{position.capitalize()} position",
                xlabel="Completed public blocks",
                ylabel="Median vector L2 norm (hidden units)",
            )
            ax.spines[["top", "right"]].set_visible(False)
            ax.grid(axis="y", alpha=0.15)
            ax.legend(fontsize=8)
        fig.suptitle(
            f"{scope} matched cases: descriptive norms, not additive causal fractions; direct derivative identity unqualified",
            fontsize=11,
        )
        stem = ROOT / f"docs/figures/207-{scope}-layerwise-norms"
        fig.savefig(stem.with_suffix(".png"), dpi=160)
        fig.savefig(stem.with_suffix(".svg"))
        plt.close(fig)


if __name__ == "__main__":
    main()
