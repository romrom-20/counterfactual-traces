"""Presentation-only layout from immutable199diagnostic summaries."""

import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]


def main():
    data = json.loads((ROOT / "docs/analysis/199-layerwise-remainder-summary.json").read_text())
    rows = data["all_blocks"]
    fig, axes = plt.subplots(2, 2, figsize=(13, 8))
    specs = (
        (
            "median_local_remainder_full_norm",
            "Local nonlinear remainder",
            "Median L2 norm\n(hidden units)",
        ),
        (
            "median_residual_projected_gain",
            "Downstream gain along error direction",
            "Median projected gain\n(ratio)",
        ),
        (
            "mean_abs_normalized_residual_contribution",
            "Contribution to residual-error projection",
            "Mean absolute contribution / error norm\n(ratio; not a causal fraction)",
        ),
        (
            "mean_abs_normalized_margin_contribution",
            "Contribution to verdict-margin error",
            "Mean absolute contribution / margin error*\n(ratio; not a causal fraction)",
        ),
    )
    for ax, (key, title, label) in zip(axes.ravel(), specs):
        ax.bar([r["block"] for r in rows], [r[key] for r in rows], color="#3c5366")
        ax.set_title(title, fontsize=12)
        ax.set_ylabel(label, fontsize=10)
        ax.set_xlabel("Transformer block (one-indexed)")
        ax.set_xticks(list(range(2, 29, 2)))
        ax.grid(axis="y", alpha=0.15)
        ax.set_axisbelow(True)
    fig.suptitle("Local remainder size and downstream effect pick different blocks", fontsize=15)
    fig.text(
        0.5,
        0.02,
        "Source:199 paired diagnosis on193's64 dependent cases ·14Oct2026UTC · oracle initial displacement and error direction.\n*Margin denominator=max(|observed prediction error|,0.1nats). Contributions can cancel. Gain is directional, not an operator norm. Final readout remainder is separate.",
        ha="center",
        fontsize=9,
    )
    fig.tight_layout(rect=(0, 0.1, 1, 0.95), h_pad=2.0, w_pad=3.0)
    path = ROOT / "docs/figures/199-local-remainder-amplification-layout.png"
    fig.savefig(path, dpi=175)
    fig.savefig(path.with_suffix(".svg"))
    plt.close(fig)


if __name__ == "__main__":
    main()
