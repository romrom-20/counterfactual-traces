"""All registered native-node outcomes and signed conditional interactions."""
import json,shutil
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
R=Path(__file__).resolve().parents[1];MODES=('LLL','LLF','LFL','LFF','FLL','FLF','FFL','FFF');LABELS=('None','P','S','S+P','N','N+P','N+S','N+S+P')
def save(fig,name):
    for ext in ('png','svg'):fig.savefig(R/f'docs/figures/{name}.{ext}',dpi=160)
    shutil.copyfile(R/f'docs/figures/{name}.png',R/f'.context/{name}.png');plt.close(fig)
def main():
    x=json.loads((R/'docs/analysis/224b-mlp-primitive-factorial.json').read_text());assert x['qualified'];rows=[r for r in x['rows'] if r['kind']!='random']
    fig,axes=plt.subplots(2,2,figsize=(13,9),constrained_layout=True)
    for i,site in enumerate((22,23)):
        for schema,color,marker in (('generic','.45','o'),('descriptive','#1d4f77','s')):
            for j,key in enumerate(('verdict_relative_deviation','margin_change')):
                series=[[r[key] for r in rows if r['site']==site and r['mode']==mode and r['group']['schema']==schema] for mode in MODES]
                ax=axes[i,j];ax.plot(range(8),[np.median(v) for v in series],color=color,marker=marker,label=schema+' median')
                for k,v in enumerate(series):ax.scatter(k+np.linspace(-.06,.06,len(v)),v,s=10,alpha=.4,color=color,marker=marker)
        axes[i,0].axhline(.05,color='.5',ls='--',lw=.8);axes[i,0].set(ylabel='Verdict residual edit / native displacement',ylim=(0,None),title=f'MLP{site}: actual verdict residual')
        axes[i,1].axhline(0,color='.5',lw=.8);axes[i,1].axhspan(-.1,.1,color='.9',alpha=.5);axes[i,1].set(ylabel='Actual intervened − native margin (nats)',title=f'MLP{site}: actual natural verdict preference')
    for ax in axes.flat:ax.set(xticks=range(8),xticklabels=LABELS,xlabel='Primitives retained finite; all others False-affine');ax.tick_params(axis='x',labelsize=8);ax.spines[['top','right']].set_visible(False);ax.legend(fontsize=8)
    fig.suptitle('224b: which MLP nonlinearities matter in the native receiving state?',fontsize=14)
    fig.supxlabel('N = RMSNorm; S = SiLU; P = gate–up product · 32 old larch/marzipan contexts · finite public tails/readout\nActual-node factorial, distinct from failed224 composite-coordinate bridge. Points are dependent examples; no prediction or learned-circuit claim.',fontsize=8.5)
    save(fig,'224b-primitive-factorial-response')
    fig,axes=plt.subplots(1,2,figsize=(13,6),constrained_layout=True)
    for ax,site in zip(axes,(22,23)):
        gg=[g for g in x['gates'] if g['site']==site];names=[('Retain ' if g['purpose']=='restore' else 'Remove ')+('+'.join('NSP'[i] for i,c in enumerate(g['mode']) if c==('F' if g['purpose']=='restore' else 'L'))) for g in gg]
        vals=[g['totals']['combined'] for g in gg];ax.barh(range(9),vals,color=['#1d4f77' if g['passed'] else '.65' for g in gg]);ax.axvline(24,color='.4',ls='--');ax.set(yticks=range(9),yticklabels=names,xlim=(0,34),xlabel='Cases passing ALL matched-control criteria /32',title=f'MLP{site}: frozen sufficiency/deletion gates');ax.invert_yaxis();ax.spines[['top','right']].set_visible(False)
        for i,g in enumerate(gg):
            inside=vals[i]>=24;ax.text(vals[i]-.4 if inside else vals[i]+.25,i,str(vals[i])+f" (min stratum {min(s['counts']['combined'] for s in g['strata'])}/8)",fontsize=7,va='center',ha='right' if inside else 'left',color='white' if inside else '.15')
    fig.supxlabel('Blue requires ≥24/32 overall AND ≥6/8 in every schema/order stratum. A count alone is not the whole gate.\nRetention: match native and beat restoration random. Deletion: material residual/margin, beat deletion random and clear100× measured implementation contrast.',fontsize=8.5)
    save(fig,'224b-primitive-factorial-gates')
    fig,axes=plt.subplots(2,2,figsize=(13,9),constrained_layout=True);components=('N','S','P','NS','NP','SP','NSP')
    for i,site in enumerate((22,23)):
        for schema,color,marker in (('generic','.45','o'),('descriptive','#1d4f77','s')):
            for j,key in enumerate(('projection_223_remainder','margin_contrast')):
                series=[[r[key] for r in x['interactions'] if r['site']==site and r['component']==c and r['group']['schema']==schema] for c in components]
                ax=axes[i,j];ax.plot(range(7),[np.median(v) for v in series],color=color,marker=marker,label=schema+' median')
                for k,v in enumerate(series):ax.scatter(k+np.linspace(-.06,.06,len(v)),v,s=9,alpha=.3,color=color,marker=marker)
        axes[i,0].set(ylabel='Signed projection coefficient on223 remainder',title=f'MLP{site}: local receiving-write components')
        axes[i,1].set(ylabel='Signed finite-margin contrast (nats)',title=f'MLP{site}: natural response contrasts')
    for ax in axes.flat:ax.axhline(0,color='.5',lw=.8);ax.set(xticks=range(7),xticklabels=components,xlabel='Inclusion–exclusion component from all-linear background');ax.spines[['top','right']].set_visible(False);ax.legend(fontsize=8)
    fig.suptitle('Signed factorial components: do not add their norms as causal fractions',fontsize=14)
    fig.supxlabel('Exact component vectors add to FFF−LLL; medians and norms do not. Projection coefficient = <component,R223>/<R223,R223>.\nFinite-margin interactions include all responding downstream computation and the head. These are conditional interventions, not learned features.',fontsize=8.5)
    save(fig,'224b-signed-factorial-components')
    fig,axes=plt.subplots(1,2,figsize=(12,5),constrained_layout=True)
    pairs=(('LLL','LFL'),('LLF','LFF'),('FLL','FFL'),('FLF','FFF'));labels=('N affine\nP affine','N affine\nP finite','N finite\nP affine','N finite\nP finite')
    for ax,site in zip(axes,(22,23)):
        for schema,color,marker in (('generic','.45','o'),('descriptive','#1d4f77','s')):
            series=[[r['margin_effect'] for r in x['edges'] if r['site']==site and r['group']['schema']==schema and (r['low'],r['high'])==pair] for pair in pairs]
            ax.plot(range(4),[np.median(v) for v in series],color=color,marker=marker,label=schema+' median')
            for k,v in enumerate(series):ax.scatter(k+np.linspace(-.06,.06,len(v)),v,color=color,marker=marker,s=12,alpha=.4)
        ax.axhline(0,color='.5',lw=.8);ax.set(xticks=range(4),xticklabels=labels,ylabel='Finite-SiLU − affine-SiLU natural margin (nats)',xlabel='Fixed normalization and product background',title=f'MLP{site}: conditional SiLU effect');ax.spines[['top','right']].set_visible(False);ax.legend(fontsize=8)
    fig.suptitle('POSTHOC: the product background reverses the SiLU effect at MLP23, but not MLP22',fontsize=13)
    fig.supxlabel('32 old contexts · both N settings · within each N setting, actual gate/up parents are identical across S/P switches\nLocal bilinear vector identity closes after measured rounding. It does not isolate the final-margin cause from the responding tail baseline.',fontsize=8.5)
    save(fig,'224b-silu-product-sign-reversal')
if __name__=='__main__':main()
