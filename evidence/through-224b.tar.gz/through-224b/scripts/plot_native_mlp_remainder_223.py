"""Scientific figures for audited native MLP-remainder necessity tests."""

import json,shutil
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
R=Path(__file__).resolve().parents[1]
def save(fig,name):
    for ext in ('png','svg'):fig.savefig(R/f'docs/figures/{name}.{ext}',dpi=160)
    shutil.copyfile(R/f'docs/figures/{name}.png',R/f'.context/{name}.png');plt.close(fig)
def main():
    x=json.loads((R/'docs/analysis/223-native-mlp-remainder.json').read_text());assert x['qualified'];rr=x['rows']
    arms=('FF','LF','FL','LL','rand22','rand23','randboth');labels=('Native','Remove R22','Remove R23','Remove both','Random22','Random23','Random both')
    fig,axes=plt.subplots(2,2,figsize=(13,9),constrained_layout=True)
    for schema,color,marker in (('generic','.45','o'),('descriptive','#1d4f77','s')):
        groups=[[r for r in rr if r['label']==a and r['group']['schema']==schema] for a in arms]
        for ax,key in ((axes[0,0],'verdict_relative_deviation'),(axes[0,1],'margin_change'),(axes[1,0],'receiver_relative_deviation'),(axes[1,1],'product_effect')):
            series=[[r[key] for r in group] for group in groups];ax.plot(range(len(arms)),[np.median(v) for v in series],color=color,marker=marker,label=schema+' median')
            for i,values in enumerate(series):ax.scatter(i+np.linspace(-.06,.06,len(values)),values,s=9,color=color,marker=marker,alpha=.4)
    axes[0,0].axhline(.05,color='.4',ls='--',lw=.8);axes[0,0].set(ylabel='Verdict residual edit / native verdict displacement',title='PRIMARY: actual final verdict residual')
    axes[0,1].axhline(0,color='.5',lw=.7);axes[0,1].set(ylabel='Actual intervened − native verdict margin (nats)',title='PRIMARY: actual natural verdict preference')
    axes[1,0].set(ylabel='Full receiving residual edit / native displacement',title='All receiving rows: vector displacement')
    axes[0,0].set_ylim(bottom=0);axes[1,0].set_ylim(bottom=0)
    axes[1,1].axhline(0,color='.5',lw=.7);axes[1,1].set(ylabel='Finite32 common-False-readout effect (nats)',title='SECONDARY: frozen neuron-product diagnostic')
    for ax in axes.flat:
        ax.set(xticks=range(len(arms)),xticklabels=labels);ax.tick_params(axis='x',labelrotation=30,labelsize=7);ax.spines[['top','right']].set_visible(False);ax.legend(fontsize=7)
    fig.suptitle('223: remove nonlinear remainders while retaining the False write and linear response',fontsize=13)
    fig.supxlabel('32 old operation-excluded contexts · qualified local derivatives · downstream computation and final head finite/native\nRandom edits match realized receiving-write norms. Individual points are dependent synthetic examples, not confidence intervals.',fontsize=8.5)
    save(fig,'223-native-mlp-remainder-factorial')
    fig,axes=plt.subplots(1,2,figsize=(12,5),constrained_layout=True)
    pairs=[('LF','22'),('FL','23'),('LL','Both')]
    for j,(arm,label) in enumerate(pairs):
        current={r['context']:r for r in rr if r['label']==arm};old=[r for r in x['previous_full_write_clamps'] if r['removal_arm']==arm]
        for ax,key,oldkey in ((axes[0],'verdict_relative_deviation','full_write_clamp_verdict_relative'),(axes[1],'margin_change','full_write_clamp_margin_change')):
            a=[current[r['context']][key] for r in old];b=[r[oldkey] for r in old]
            for k,(values,color) in enumerate(((a,'#1d4f77'),(b,'.55'))):
                pos=j*3+k;ax.scatter(pos+np.linspace(-.08,.08,len(values)),values,color=color,s=12,alpha=.6);ax.plot([pos-.13,pos+.13],[np.median(values)]*2,color=color,lw=3)
    for ax in axes:
        ax.set(xticks=[0,1,3,4,6,7],xticklabels=['R22','Write22','R23','Write23','Both R','Both writes']);ax.tick_params(axis='x',labelrotation=25,labelsize=8);ax.spines[['top','right']].set_visible(False)
    axes[0].set(ylabel='Verdict residual edit / native displacement',title='Nonlinear-remainder removal versus whole-write clamp')
    axes[0].set_ylim(bottom=0)
    axes[1].axhline(0,color='.5',lw=.7);axes[1].set(ylabel='Actual intervened − native verdict margin (nats)',title='Natural margin consequences, same old contexts')
    fig.supxlabel('Blue:223 removes only local nonlinear remainder. Gray:222 replaces the whole write with its paired False write.\nThese are different interventions; their norms and medians are not additive causal fractions.',fontsize=8.5)
    save(fig,'223-remainder-versus-write-clamp')
if __name__=='__main__':main()
