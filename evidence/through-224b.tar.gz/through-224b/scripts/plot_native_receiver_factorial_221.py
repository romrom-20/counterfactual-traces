"""Presentation of the audited native bridge and intervention geometry."""

import json
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

R=Path(__file__).resolve().parents[1]
BLUE="#1d4f77"
def save(fig,name):
    for ext in ("png","svg"):fig.savefig(R/f"docs/figures/{name}.{ext}",dpi=160)
    plt.close(fig)
def main():
    d=json.loads((R/"docs/analysis/221-native-receiver-factorial.json").read_text());assert d["qualified"]
    rows=d["rows"];fig,axes=plt.subplots(2,2,figsize=(12,8),constrained_layout=True)
    for b,color in (("N",BLUE),("P",".5")):
        for schema,marker in (("generic","o"),("descriptive","s")):
            vals=[]
            for a in ("F","L"):
                vals.append(np.median([r["finite_group"] for r in rows if r["attention"]==a and r["norm"]=="F" and r["state"]==b+"11" and r["group"]["schema"]==schema]))
            axes[0,0].plot([0,1],vals,color=color,marker=marker,label=("Native input" if b=="N" else "Forecast input")+" / "+schema)
    axes[0,0].set(xticks=[0,1],xticklabels=["Native attention","False-affine attention"],xlabel="Actual attention computation",ylabel="Median finite32 common-readout effect (nats)",title="Bridge from the surrogate to native attention")
    axes[0,0].axhline(0,color=".3",lw=.8);axes[0,0].legend(fontsize=7)
    states=("00","N10","N01","N11")
    for schema,color,marker in (("generic",".5","o"),("descriptive",BLUE,"s")):
        vals=[np.median([r["finite_group"] for r in rows if r["attention"]=="F" and r["norm"]=="F" and r["state"]==s and r["group"]["schema"]==schema]) for s in states]
        axes[0,1].plot(range(4),vals,color=color,marker=marker,label=schema+" schema")
    axes[0,1].set(xticks=range(4),xticklabels=["Source00","Carry10","Write01","Both11"],xlabel="Native-input carry/write intervention",ylabel="Median finite32 common-readout effect (nats)",title="Receiving carry versus final attention write")
    axes[0,1].axhline(0,color=".3",lw=.8);axes[0,1].legend(fontsize=7)
    points=[]
    for schema,color,marker in (("generic",".5","o"),("descriptive",BLUE,"s")):
        contexts=sorted({r["context"] for r in rows if r["group"]["schema"]==schema})
        xx=[];yy=[]
        for context in contexts:
            pair={r["norm"]:r for r in rows if r["context"]==context and r["attention"]=="F" and r["state"]=="N11"}
            xx.append(pair["F"]["finite_group"]);yy.append(pair["S"]["finite_group"])
        points+=xx+yy;axes[1,0].scatter(xx,yy,color=color,marker=marker,s=18,alpha=.7,label=schema+" schema")
    lo,hi=min(points),max(points);pad=max(.1,(hi-lo)*.08);axes[1,0].plot([lo-pad,hi+pad],[lo-pad,hi+pad],color=".4",ls="--",lw=.8)
    axes[1,0].set(xlabel="Finite MLP-input RMS scale effect (nats)",ylabel="Source-only fixed RMS scale effect (nats)",title="Causal scale intervention at the same full native mid")
    axes[1,0].legend(fontsize=7)
    for schema,color,marker in (("generic",".5","o"),("descriptive",BLUE,"s")):
        med=[]
        for i,norm in enumerate(("F","S")):
            ir=[r for r in d["interactions"] if r["attention"]=="F" and r["norm"]==norm and r["background"]=="N" and r["group"]["schema"]==schema]
            vals=[np.hypot(r["gate_units"][0],r["up_units"][0]) for r in ir]
            axes[1,1].scatter(i+np.linspace(-.06,.06,len(vals)),vals,color=color,marker=marker,s=12,alpha=.6);med.append(np.median(vals))
        axes[1,1].plot([0,1],med,color=color,marker=marker,label=schema+" median")
    axes[1,1].set(xticks=[0,1],xticklabels=["Finite RMS scale","Source-only fixed scale"],xlabel="RMS denominator intervention",ylabel="Pre-SiLU gate/up interaction L2 (activation units)",title="6411 parent-map interaction",yscale="symlog")
    axes[1,1].set_yscale("symlog",linthresh=1e-5);axes[1,1].set_ylim(bottom=0)
    axes[1,1].legend(fontsize=7)
    for ax in axes.flat:ax.spines[["top","right"]].set_visible(False)
    fig.suptitle("221: native attention, carried state and normalization",fontsize=14)
    fig.supxlabel("16 Oct 2026 · all 64 old208 contexts · frozen 219 top32 neurons · actual finite heads at a common False state · retrospective, not a learned circuit",fontsize=8.5)
    save(fig,"221-native-bridge-and-factorial")
    context=sorted({r["context"] for r in rows})[0];rr=[r for r in rows if r["context"]==context and r["attention"]=="F"]
    with np.load(R/"runs/native-receiver-factorial-221/pairs"/(context+".npz")) as z:weights={i:float(z["projection_weights"][i]) for i in (6411,3902)}
    fig,axes=plt.subplots(1,2,figsize=(11,5),constrained_layout=True)
    for ax,unit,field in zip(axes,(6411,3902),("parents6411","parents3902")):
        chosen=[next(r for r in rr if r["norm"]=="F" and r["state"]==s) for s in states]
        p=next(r for r in rr if r["norm"]=="F" and r["state"]=="P11");fixed=next(r for r in rr if r["norm"]=="S" and r["state"]=="N11")
        pts=np.array([r[field] for r in chosen+[p,fixed]]);bounds=[]
        for j in range(2):
            lo,hi=min(0,float(pts[:,j].min())),max(0,float(pts[:,j].max()));pad=max(.15,(hi-lo)*.1);bounds.append((lo-pad,hi+pad))
        xx,yy=np.meshgrid(np.linspace(*bounds[0],160),np.linspace(*bounds[1],160));q=weights[unit]*xx*yy
        cs=ax.contour(xx,yy,q,levels=[-4,-2,-1,-.5,.5,1,2,4],colors=".7",linewidths=.6);ax.clabel(cs,inline=True,fontsize=7,fmt="%g")
        for r,label,marker in zip(chosen,("Source00","Carry10","Write01","Both11"),("o","s","^","D")):
            point=r[field];ax.scatter(*point,color=BLUE,marker=marker,s=40,label=label)
        ax.scatter(*p[field],color=".35",marker="x",s=45,label="Forecast P11");ax.annotate("P11",p[field],xytext=(5,-12),textcoords="offset points",fontsize=8)
        ax.scatter(*fixed[field],edgecolors=BLUE,facecolors="none",marker="D",s=70,label="Both11, fixed RMS")
        ax.axhline(0,color=".5",lw=.5);ax.axvline(0,color=".5",lw=.5)
        ax.set(xlim=bounds[0],ylim=bounds[1],xlabel="Gate activation increment ΔΦ (units)",ylabel="Up activation increment ΔU (units)",title=f"Neuron {unit}: fixed-readout weight {weights[unit]:+.3f}")
        ax.spines[["top","right"]].set_visible(False)
    axes[1].legend(fontsize=7,loc="best")
    group=rr[0]["group"];fig.suptitle(f"Measured parent coordinates: {group['block']} / {group['schema']} / order{group['reverse']} / {group['assignment']},{group['target']}",fontsize=12)
    fig.supxlabel("Contour labels: ideal initial weighted product projection (nats), not finite behavioral effects · actual interventions from221 · one predeclared first context",fontsize=8.5)
    save(fig,"221-neuron-parent-plane")
if __name__=="__main__":main()
