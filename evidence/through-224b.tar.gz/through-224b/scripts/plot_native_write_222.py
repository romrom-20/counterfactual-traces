"""Plots of audited finite native writes and causal interventions, with no new fitting."""

import json,shutil
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
R=Path(__file__).resolve().parents[1]
def save(fig,name):
    for ext in ("png","svg"):fig.savefig(R/f"docs/figures/{name}.{ext}",dpi=160)
    shutil.copyfile(R/f"docs/figures/{name}.png",R/f".context/{name}.png");plt.close(fig)
def main():
    d=json.loads((R/"docs/analysis/222-native-write-ledger.json").read_text());assert d["qualified"]
    selected=[r["index"] for r in d["selected_operations"]]
    fig,axes=plt.subplots(2,2,figsize=(13,9),constrained_layout=True)
    for kind,label,color,offset in ((0,"Attention",".6",-.19),(1,"MLP","#1d4f77",.19)):
        axes[0,0].bar(np.arange(1,28)+offset,np.array(d["scores"])[kind::2],width=.36,label=label,color=color)
    for i in selected:axes[0,0].annotate(f"{i//2+1}{'A' if i%2==0 else 'M'}",(i//2+1,d["scores"][i]),xytext=(0,7 if d["scores"][i]>0 else -12),textcoords="offset points",ha="center",fontsize=8)
    axes[0,0].set(xlabel="Transformer block (1-based)",ylabel="Mean signed 6411 projection (activation units)",title="Descriptive native ledger: selection families only")
    axes[0,0].legend(fontsize=8);axes[0,0].axhline(0,color=".3",lw=.6)
    for schema,style,color in (("generic","--",".45"),("descriptive","-","#1d4f77")):
        values=np.array([r["cumulative"] for r in d["ledger"] if r["group"]["schema"]==schema])
        for j,label,marker in ((0,"gate","o"),(1,"up","s")):
            axes[0,1].plot(range(28),np.median(values[:,:,j],axis=0),label=schema+" / "+label,ls=style,color=color,marker=marker,markersize=2)
    axes[0,1].set(xlabel="Native residual boundary (0 = embedding)",ylabel="Median fixed-gain projection (activation units)",title="Accumulated displacement: all 64 old contexts")
    axes[0,1].legend(fontsize=7);axes[0,1].axhline(0,color=".3",lw=.6)
    labels=("Native","Clamp","Full","Plane","Complement","Random edit","Random rescue","Source only")
    arms=(None,"clamp","full","plane","complement","rand_edit","rand_rescue","source")
    for j,op in enumerate(d["selected_operations"]):
        ax=axes[1,j];native=[r["native_group"] for r in d["causal"] if r["label"]==f"op{j}_clamp"]
        vals=[native]+[[r["group_effect"] for r in d["causal"] if r["label"]==f"op{j}_{a}"] for a in arms[1:]]
        ax.boxplot(vals,positions=range(8),widths=.48,showfliers=False,medianprops={"color":"#1d4f77"})
        for i,v in enumerate(vals):ax.scatter(i+np.linspace(-.12,.12,len(v)),v,s=7,color=".35",alpha=.55)
        ax.axhline(0,color=".3",lw=.6);ax.set(xticks=range(8),xticklabels=labels,ylabel="Finite32 common-readout effect (nats)",title=f"Block {op['layer']} {op['kind']}: actual native-tail interventions")
        ax.tick_params(axis="x",labelrotation=45,labelsize=7)
    for ax in axes.flat:ax.spines[["top","right"]].set_visible(False)
    fig.suptitle("222: trace native writes, then test their causal role",fontsize=14)
    fig.supxlabel("Ledger selection: chalice/gimbal32 · causal tests: operation-excluded larch/marzipan32 · pinned Qwen · fully finite native tails · retrospective, not prospective",fontsize=8)
    save(fig,"222-native-ledger-and-interventions")
    fig,axes=plt.subplots(1,2,figsize=(12,5),constrained_layout=True)
    for j,op in enumerate(d["selected_operations"]):
        ax=axes[j]
        for arm,marker,color in (("plane","o","#1d4f77"),("complement","s",".5"),("rand_rescue","x",".7"),("source","^",".25")):
            rows=[r for r in d["causal"] if r["label"]==f"op{j}_{arm}"]
            ax.scatter([r["parent_relative_error"] for r in rows],[r["group_error"] for r in rows],label=arm,s=23,marker=marker,color=color,alpha=.65)
        ax.axvline(.25,color=".4",ls="--",lw=.8);ax.axhline(.1,color=".4",ls="--",lw=.8)
        ax.set(xlabel="6411 parent relative L2 error (unitless)",ylabel="Absolute finite32 effect error (nats)",title=f"Block {op['layer']} {op['kind']}: direction-rescue limits",xscale="symlog",yscale="symlog")
        ax.set_xscale("symlog",linthresh=.01);ax.set_yscale("symlog",linthresh=.01);ax.set_xlim(left=0);ax.set_ylim(bottom=0);ax.legend(fontsize=8);ax.spines[["top","right"]].set_visible(False)
    fig.supxlabel("Each point is an actual finite intervention in one old context. Dashed lines are registered rescue bounds; parent similarity alone is insufficient.",fontsize=8)
    save(fig,"222-plane-rescue-controls")
    fig,axes=plt.subplots(1,2,figsize=(12,5),constrained_layout=True)
    labels=("Clamp MLP23","Clamp MLP22","Clamp both","Both random edits")
    arms=("op0_clamp","op1_clamp","both_clamp","both_random")
    for schema,color,marker in (("generic",".45","o"),("descriptive","#1d4f77","s")):
        groups=[[r for r in d["causal"] if r["label"]==a and r["group"]["schema"]==schema] for a in arms]
        vals=[[100*r["group_effect"]/r["native_group"] for r in rr] for rr in groups]
        margins=[[r["final_margin_change"] for r in rr] for rr in groups]
        for ax,series in zip(axes,(vals,margins)):
            ax.plot(range(4),[np.median(v) for v in series],color=color,marker=marker,label=schema+" median")
            for i,v in enumerate(series):ax.scatter(i+np.linspace(-.055,.055,len(v)),v,color=color,marker=marker,s=10,alpha=.45)
    axes[0].axhline(50,color=".4",ls="--",lw=.8,label="50% erasure threshold")
    axes[0].axhline(100,color=".6",lw=.6);axes[0].set(ylabel="Finite32 effect retained (% of each native effect)",title="Both-write clamp erases at least half in32/32 cases")
    axes[1].axhline(0,color=".5",lw=.7);axes[1].set(ylabel="Actual intervened − native verdict margin (nats)",title="The native verdict preference also changes")
    for ax in axes:
        ax.set(xticks=range(4),xticklabels=labels);ax.tick_params(axis="x",labelrotation=20,labelsize=8);ax.spines[["top","right"]].set_visible(False);ax.legend(fontsize=8)
    fig.suptitle("222: upstream MLP writes matter; the fixed-plane rescue is insufficient",fontsize=13)
    fig.supxlabel("32 operation-excluded old contexts · all tails native/finite · random edits match write norms at each site\nLeft: declared32-neuron product diagnostic; right: actual natural-model score margin. Neither is a False-only forecast.",fontsize=8.3)
    save(fig,"222-joint-write-knockout")
if __name__=="__main__":main()
