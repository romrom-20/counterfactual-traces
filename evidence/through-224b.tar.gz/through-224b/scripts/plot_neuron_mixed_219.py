"""Presentation only: contrast concentration, crossed factors and actual product edits."""

import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

ROOT=Path(__file__).resolve().parents[1]


def main():
    obj=json.loads((ROOT/"docs/analysis/219-neuron-mixed-interventions.json").read_text());assert obj["qualified"]
    fig,axes=plt.subplots(1,3,figsize=(14,4.7),constrained_layout=True)
    rows=[r for r in obj["summaries"] if r["subset"]=="excluded"]
    ks=[r["k"] for r in rows]
    for key,label,color,style in (("median_fixed_absolute_fraction","Fixed selection from other old families","#1d4f77","-"),
                                 ("median_oracle_absolute_fraction","Per-case oracle ranking",".5","--")):
        axes[0].plot(ks,[r[key] for r in rows],label=label,color=color,ls=style,marker="o")
    axes[0].set(xscale="log",xlabel="Number of neurons (count)",ylabel="Median fraction of absolute contrast mass (ratio)",title="Concentration of absolute contrast",ylim=(0,1))
    axes[0].legend(fontsize=7)
    crosses=("NN","NP","PN","PP")
    for schema,color,marker in (("generic",".5","o"),("descriptive","#1d4f77","s")):
        selected=[r for r in obj["neurons"] if r["held_out_of_selection"] and r["group"]["schema"]==schema]
        vals=[np.median([r["cross_projections"][ab] for r in selected]) for ab in crosses]
        axes[1].plot(range(4),vals,label=schema+" schema",color=color,marker=marker)
    axes[1].axhline(0,color=".4",lw=.8)
    axes[1].set(xticks=range(4),xticklabels=["N gate\nN up","N gate\nP up","P gate\nN up","P gate\nP up"],
        xlabel="Origin of finite activation increments (N=native; P=forecast)",ylabel="Median initial fixed-readout projection (nats)",title="Gate/up crosses before finite-head curvature")
    axes[1].tick_params(axis="x",labelsize=8);axes[1].legend(fontsize=7)
    held=[r for r in obj["rows"] if r["held_out_of_selection"]]
    for kind,label,color,style in (("selected","Fixed selected neurons","#1d4f77","-"),("random","Cardinality-matched random",".4","--"),("norm_random","Product-norm-matched random",".6",":")):
        values=[]
        for k in ks:
            errors=[]
            for r in held:
                if r["label"]!=f"{kind}_{k}":continue
                donor="P" if r["background"]=="N" else "N"
                benchmark=next(t for t in held if t["key"]==r["key"] and t["background"]==r["background"] and t["label"]=="cross_"+donor*2)
                errors.append(abs(r["common_margin_change"]-benchmark["common_margin_change"]))
            values.append(np.median(errors))
        axes[2].plot(ks,values,label=label,color=color,ls=style,marker="o")
    axes[2].set(xscale="log",xlabel="Number of directly edited neurons (count)",ylabel="Median distance from all-neuron swap effect (nats)",title="Actual finite common-readout effects")
    axes[2].legend(fontsize=7)
    for ax in axes:ax.spines[["top","right"]].set_visible(False)
    fig.suptitle("219: neuron mixed terms and matched product interventions",fontsize=14)
    fig.supxlabel("16 Oct 2026 · two old families select / two old families excluded from selection · retrospective attention-affine, finite-SiLU/RMS diagnostic",fontsize=9)
    for suffix in ("png","svg"):fig.savefig(ROOT/f"docs/figures/219-neuron-mixed-interventions.{suffix}",dpi=160)
    plt.close(fig)


if __name__=="__main__":main()
