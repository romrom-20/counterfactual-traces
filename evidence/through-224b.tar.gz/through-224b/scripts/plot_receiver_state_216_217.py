"""Presentation-only scientific figures from audited fixed-reference and reset data."""

import argparse
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
BLUE="#1d4f77"


def save(fig,name):
    for ext in ("png","svg"):fig.savefig(ROOT/f"docs/figures/{name}.{ext}",dpi=160)
    plt.close(fig)


def main():
    p=argparse.ArgumentParser();p.add_argument("--head-only",action="store_true");args=p.parse_args()
    x=json.loads((ROOT/"docs/analysis/216-vector-readout-cross-audit.json").read_text());assert x["qualified"]
    plt.rcParams.update({"font.size":10,"axes.spines.top":False,"axes.spines.right":False})
    fig,axes=plt.subplots(1,3,figsize=(12,4.5),constrained_layout=True)
    for ax,base,title in zip(axes,("native","predicted","false"),("Fixed native-FL reference","Fixed forecast-FL reference","Fixed False final reference")):
        segments=[r for r in x["segments"] if r["base"]==base]
        bykey={r["key"]:{v:next(s for s in segments if s["key"]==r["key"] and s["vector"]==v) for v in ("native","predicted")} for r in segments}
        for pair in bykey.values():
            ax.plot([0,1],[pair[v]["finite_margin_change"] for v in ("native","predicted")],color=".8",lw=.5,alpha=.5,zorder=1)
        for schema,color,marker in (("generic",".5","o"),("descriptive",BLUE,"s")):
            for i,v in enumerate(("native","predicted")):
                vals=[r["finite_margin_change"] for r in segments if r["vector"]==v and r["group"]["schema"]==schema]
                ax.scatter(i+np.linspace(-.06,.06,len(vals)),vals,color=color,marker=marker,s=15,alpha=.7,label=schema+" schema" if i==0 else None,zorder=2)
        ax.axhline(0,color=".4",lw=.8)
        ax.set(xticks=[0,1],xticklabels=["Native-input\ncorrection vector","Forecast-input\ncorrection vector"],xlabel="Correction vector source",
               ylabel="Signed finite margin change (nats)",title=title)
        ax.tick_params(axis="x",labelsize=9)
        if base=="native":ax.legend(fontsize=8)
    fig.suptitle("216: product-vector sign contrasts persist when the readout reference is fixed",fontsize=13)
    fig.supxlabel("15 Oct 2026 · 64 dependent old208 contexts · after RMSNorm repair · finite-head transplants, not new primitive runs",fontsize=9)
    save(fig,"216-fixed-readout-vector-cross")
    if args.head_only:return
    y=json.loads((ROOT/"docs/analysis/217-selected-receiver-reset.json").read_text());assert y["qualified"]
    depths=y["depths"];allrows=y["rows"]
    fig,axes=plt.subplots(2,2,figsize=(12,8),constrained_layout=True)
    for schema,color,marker in (("generic",".5","o"),("descriptive",BLUE,"s")):
        med_input=[];med_effect=[]
        for depth in depths:
            cases=[r for r in allrows if r["boundary"]==depth and r["group"]["schema"]==schema]
            q=[r["incoming"]["receivers"]["relative_l2"] for r in cases]
            m=[r["common_product_margin_change"] for r in cases]
            jitter=np.linspace(-.25,.25,len(cases))
            axes[0,0].scatter(depth+jitter,q,color=color,marker=marker,s=9,alpha=.35)
            axes[0,1].scatter(depth+jitter,m,color=color,marker=marker,s=9,alpha=.35)
            med_input.append(np.median(q));med_effect.append(np.median(m))
        for ax,vals in ((axes[0,0],med_input),(axes[0,1],med_effect)):
            ax.plot(depths,vals,color=color,marker=marker,label=schema+" median")
    axes[0,0].set(title="Receiving error at boundary 27",ylabel="Relative L2 error (ratio)")
    axes[0,1].set(title="Product effect at a common native-FL readout",ylabel="Signed finite margin change (nats)")
    axes[0,1].axhline(.02,color=".6",ls=":",label=".02-nat diagnostic sign guard")
    axes[0,1].axhline(0,color=".4",lw=.8)
    for arm,label,color,style in (("original","Original 208 final update",".2","--"),("FF","RMS/product surrogate FF",BLUE,"-"),("finite","Entire finite block 28 control",".55",":")):
        q=[];m=[]
        for depth in depths:
            cases=[r for r in allrows if r["boundary"]==depth]
            q.append(np.median([r["arms"][arm]["final"]["verdict"]["relative_l2"] for r in cases]))
            m.append(np.median([r["arms"][arm]["absolute_margin_error"] for r in cases]))
        axes[1,0].plot(depths,q,color=color,ls=style,marker="o",label=label)
        axes[1,1].plot(depths,m,color=color,ls=style,marker="o",label=label)
    axes[1,0].axhline(.05,color=".6",ls=":",label="Original residual bound")
    axes[1,1].axhline(.10,color=".6",ls=":",label="Original margin bound")
    axes[1,0].set(title="Final verdict residual accuracy",ylabel="Median relative L2 error (ratio)")
    axes[1,1].set(title="Final behavioral accuracy",ylabel="Median absolute margin-response error (nats)")
    for ax in axes.flat:
        ax.set(xticks=depths,xlim=(-1,28),xlabel="One oracle receiving reset after k completed blocks")
        ax.legend(fontsize=7)
    fig.suptitle("217: selected receiver resets, then the original 208 approximation resumes",fontsize=13)
    fig.supxlabel("15 Oct 2026 · all 64 old 208 contexts · only marked boundaries tested · native resets are oracle controls",fontsize=9)
    save(fig,"217-selected-receiver-resets")
    fig,axes=plt.subplots(1,2,figsize=(12,4.8),constrained_layout=True)
    styles={0:(".15","-"),8:(".4","--"),16:(BLUE,"-"),24:(".5","-."),27:(".25",":")}
    for ax,metric,title in zip(axes,("receivers","verdict"),("Receiving rows","Verdict position")):
        for depth in depths:
            selected=[r for r in allrows if r["boundary"]==depth]
            blocks=range(depth+1,29)
            profile=[float(np.median([next(s[metric]["relative_l2"] for s in r["layerwise"] if s["after_block"]==block) for r in selected])) for block in blocks]
            color,style=styles[depth]
            points=list(blocks)
            points=[depth,*points];profile=[0.,*profile]
            ax.plot(points,profile,color=color,ls=style,marker="o",ms=3,label=f"Reset after block {depth}")
        ax.set(xlabel="Completed block after the single reset",ylabel="Median relative L2 prediction error (ratio)",title=title,xticks=[0,8,16,24,28])
        ax.legend(fontsize=8)
    fig.suptitle("217: error after each actually resumed source/receiver update",fontsize=13)
    fig.supxlabel("15 Oct 2026 · 64 dependent contexts per reset · error at reset is zero · profiles do not distinguish generation from amplification",fontsize=9)
    save(fig,"217-receiver-error-after-resets")


if __name__=="__main__":main()
