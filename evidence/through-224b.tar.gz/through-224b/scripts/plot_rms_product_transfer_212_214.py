"""Presentation only: every context, fixed arms and original accuracy bounds."""

import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
ARMS=("LL","FL","LF","FF")
LABELS=("Neither","RMS only","Product only","Both")
ACCENT="#1d4f77"


def dots(ax, values, x, label=None):
    ax.scatter(x+np.linspace(-.13,.13,len(values)),values,color=".65",s=9,alpha=.5)
    ax.plot([x-.22,x+.22],[np.median(values)]*2,color=ACCENT,lw=3,label=label)


def main():
    x=json.loads((ROOT/"docs/analysis/212-rms-product-factorial.json").read_text())
    y=json.loads((ROOT/"docs/analysis/214-last-block-transfer.json").read_text())
    z=json.loads((ROOT/"docs/analysis/215-matched-incoming-control.json").read_text())
    assert x["finite_factorial_qualified"] and y["qualified"]
    plt.rcParams.update({"font.size":10,"axes.spines.top":False,"axes.spines.right":False})
    fig,axes=plt.subplots(2,2,figsize=(11,8),constrained_layout=True)
    for row,branch in enumerate(("native","linear27")):
        cases=[r for r in x["rows"] if r["branch"]==branch and r["background"]=="affine"]
        for col,(metric,bound) in enumerate((("q",.05),("m",.10))):
            ax=axes[row,col]
            for i,a in enumerate(ARMS):
                vals=[r["endpoints"][a]["verdict"]["relative_l2"] if metric=="q" else r["endpoints"][a]["absolute_margin_error"] for r in cases]
                dots(ax,vals,i,"Median; dots are all 64 contexts" if i==0 else None)
            ax.axhline(bound,color=".45",ls=":",label="Original accuracy bound")
            ax.set(xticks=range(4),xticklabels=LABELS,xlabel="Finite MLP primitives in otherwise False-affine block 28",
                   ylabel="Verdict relative L2 error (ratio)" if metric=="q" else "Absolute margin-response error (nats)",
                   title=("Native after block 27" if branch=="native" else "Block-27-linear incoming state"))
            if row==0:ax.legend(fontsize=8)
    fig.suptitle("212: joint local repair improves predictions but passes no joint accuracy test",fontsize=13)
    fig.supxlabel("15 Oct 2026 · dependent synthetic contexts · oracle incoming states · finite readout · no original Jacobian certificate",fontsize=9)
    for ext in ("png","svg"):fig.savefig(ROOT/f"docs/figures/212-rms-product-factorial.{ext}",dpi=160)
    plt.close(fig)
    fig,axes=plt.subplots(1,2,figsize=(11,4.4),constrained_layout=True)
    for ax,branch in zip(axes,("native","linear27")):
        for i,vector in enumerate(("silu","gate_up")):
            cases=[r for r in x["readout_geometry"] if r["branch"]==branch and r["vector"]==vector and r["base"]=="original_jvp"]
            for shift,field,color,marker,label in ((-.12,"initial_gradient_projection",".5","o","Initial gradient projection"),(.12,"finite_margin_change",ACCENT,"s","Actual finite margin change")):
                vals=[r[field] for r in cases]
                ax.scatter(np.full(64,i+shift),vals,s=7,color=color,alpha=.35)
                ax.scatter(i+shift,np.median(vals),s=42,color=color,marker=marker,label=label if i==0 else None)
        ax.axhline(0,color=".4",lw=.8)
        ax.set(xticks=[0,1],xticklabels=["SiLU correction","Gate–up correction"],xlabel="Measured receiving-row correction added to original JVP forecast",
               ylabel="Signed verdict margin change (nats)",title="Native incoming" if branch=="native" else "Block-27-linear incoming")
        ax.legend(fontsize=8)
    fig.suptitle("212: opposite signed readout effects; curvature is small on these segments",fontsize=13)
    fig.supxlabel("15 Oct 2026 · 64 dependent contexts per incoming state · gradients checked against standard first reverse · head stays finite",fontsize=9)
    for ext in ("png","svg"):fig.savefig(ROOT/f"docs/figures/212-readout-directions.{ext}",dpi=160)
    plt.close(fig)
    fig,axes=plt.subplots(1,2,figsize=(11,4.8),constrained_layout=True)
    arms=(*ARMS,"source_linear_finite_head","zero_displacement")
    labels=(*LABELS,"Source-linear\nfinite head","Zero\ndisplacement")
    for col,(metric,bound) in enumerate((("q",.05),("m",.10))):
        ax=axes[col]
        for i,a in enumerate(arms):
            vals=[r["arms"][a]["final"]["verdict"]["relative_l2"] if metric=="q" else r["arms"][a]["absolute_margin_error"] for r in y["rows"]]
            dots(ax,vals,i,"Median; dots are all 64 contexts" if i==0 else None)
        ax.axhline(bound,color=".45",ls=":",label="Original accuracy bound")
        ax.set(xticks=range(len(arms)),xticklabels=labels,xlabel="Fixed last-block receiver-conditional correction; LL is old 208 predictor",
               ylabel="Verdict relative L2 error (ratio)" if metric=="q" else "Absolute margin-response error (nats)",title="214: residual" if metric=="q" else "214: behavior")
        ax.tick_params(axis="x",labelsize=8);ax.legend(fontsize=8)
    fig.suptitle("Retrospective transfer to already-observed 208: all arms retained",fontsize=13)
    fig.supxlabel("15 Oct 2026 · 64 dependent contexts · only last block modified · source-only contrast subtracted · finite readout · not prospective",fontsize=9)
    for ext in ("png","svg"):fig.savefig(ROOT/f"docs/figures/214-last-block-transfer.{ext}",dpi=160)
    plt.close(fig)
    fig,axes=plt.subplots(2,2,figsize=(11,8),constrained_layout=True)
    for row,branch in enumerate(("native","predicted")):
        cases=[r for r in z["rows"] if r["branch"]==branch]
        for col,(metric,bound) in enumerate((("q",.05),("m",.10))):
            ax=axes[row,col]
            for i,a in enumerate((*ARMS,"finite")):
                vals=[r["arms"][a]["final"]["verdict"]["relative_l2"] if metric=="q" else r["arms"][a]["absolute_margin_error"] for r in cases]
                dots(ax,vals,i,"Median; all 64 matched contexts" if i==0 else None)
            ax.axhline(bound,color=".45",ls=":",label="Original accuracy bound")
            ax.set(xticks=range(5),xticklabels=(*LABELS,"Entire finite\nblock control"),xlabel="Finite RMSNorm/product primitives; other primitives False-affine",
                ylabel="Verdict relative L2 error (ratio)" if metric=="q" else "Absolute margin-response error (nats)",
                title="Native incoming state (oracle)" if branch=="native" else "Forecast incoming state (same contexts)")
            ax.legend(fontsize=8)
    fig.suptitle("215: same contexts and source state; change only the incoming receiving states",fontsize=13)
    fig.supxlabel("15 Oct 2026 · all 64 old 208 contexts · final block and head finite controls · oracle/retrospective, no original Jacobian certificate",fontsize=9)
    for ext in ("png","svg"):fig.savefig(ROOT/f"docs/figures/215-matched-incoming-control.{ext}",dpi=160)
    plt.close(fig)
    native={r["key"]:r for r in z["rows"] if r["branch"]=="native"}
    predicted={r["key"]:r for r in z["rows"] if r["branch"]=="predicted"}
    fig,axes=plt.subplots(1,2,figsize=(10,4.5),constrained_layout=True)
    for ax,label,title in zip(axes,("gate_before_rms","gate_after_rms"),("Before RMSNorm repair","After RMSNorm repair")):
        xx=np.array([native[k]["conditional"][label]["finite_margin_change"] for k in sorted(native)])
        yy=np.array([predicted[k]["conditional"][label]["finite_margin_change"] for k in sorted(native)])
        schemas=np.array([native[k]["group"]["schema"] for k in sorted(native)])
        for schema,color,marker in (("generic",".55","o"),("descriptive",ACCENT,"s")):
            selected=schemas==schema
            ax.scatter(xx[selected],yy[selected],s=25,color=color,marker=marker,alpha=.65,label=schema+" schema")
        ax.axhline(0,color=".4",lw=.8);ax.axvline(0,color=".4",lw=.8)
        ax.set(xlim=(-.15,5.5),xlabel="Product correction at native input (margin change, nats)",
               ylabel="Product correction at forecast input (margin change, nats)",title=title)
        ax.text(.98,.44,f"{int(sum(xx*yy<0))}/64 raw sign reversals",transform=ax.transAxes,ha="right",fontsize=10)
        ax.legend(loc="upper right",fontsize=8)
    fig.suptitle("215: same context and source; receiving input changes the product effect",fontsize=13)
    fig.supxlabel("15 Oct 2026 · paired finite-head surgery effects · 64 dependent contexts · retrospective oracle comparison",fontsize=9)
    for ext in ("png","svg"):fig.savefig(ROOT/f"docs/figures/215-paired-product-effects.{ext}",dpi=160)
    plt.close(fig)


if __name__=="__main__":main()
