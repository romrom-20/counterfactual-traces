"""Presentation-only plots from the audited SiLU replacement diagnostic."""

import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).resolve().parents[1]


def main():
    data = json.loads((ROOT / "docs/analysis/218-silu-range-falsification-audit.json").read_text())
    assert data["qualified"] and data["cases"] == 64
    fig, axes = plt.subplots(2, 2, figsize=(11, 7), constrained_layout=True)
    for column, branch in enumerate(("native", "predicted")):
        label = "Native incoming state" if branch == "native" else "Forecast incoming state"
        selected = [r for r in data["rows"] if r["branch"] == branch]
        pairs = {r["key"]: {s: next(x for x in selected if x["key"] == r["key"] and x["silu"] == s)
                             for s in ("L", "F")} for r in selected}
        for row, metric in enumerate(("minimum", "effect")):
            ax = axes[row, column]
            for schema, color, marker in (("generic", ".5", "o"), ("descriptive", "#1d4f77", "s")):
                cases = [p for p in pairs.values() if p["L"]["group"]["schema"] == schema]
                values = [[p[s]["regimes"]["receivers"]["minimum_phi"] if metric == "minimum"
                           else p[s]["natural_margin_change"] for p in cases] for s in ("L", "F")]
                for left, right in zip(*values):
                    ax.plot([0, 1], [left, right], color=".8", lw=.5, alpha=.5)
                for i, ys in enumerate(values):
                    ax.scatter(i + np.linspace(-.05, .05, len(ys)), ys, color=color, marker=marker,
                               s=13, alpha=.7, label=schema + " schema" if i == 0 else None, zorder=3)
            if metric == "minimum":
                ax.axhline(data["silu_minimum"], color=".3", ls="--", lw=.8, label="Real SiLU minimum")
                ax.set(title=label + ": gate range", ylabel="Minimum receiving gate activation (units)")
            else:
                ax.axhline(0, color=".3", lw=.8)
                ax.set(title=label + ": product effect", ylabel="Signed natural finite margin change (nats)")
            ax.set(xticks=[0, 1], xticklabels=["False-affine SiLU", "Real finite SiLU"],
                   xlabel="SiLU computation in the same attention-affine block")
            ax.spines[["top", "right"]].set_visible(False)
            ax.legend(fontsize=7)
    fig.suptitle("218: real SiLU removes range violations; the product-effect sign contrast remains", fontsize=13)
    fig.supxlabel("15 Oct 2026 · 64 dependent old contexts · finite MLP-input RMSNorm · finite readout · no native-attention claim", fontsize=9)
    for suffix in ("png", "svg"):
        fig.savefig(ROOT / f"docs/figures/218-silu-range-and-product-effect.{suffix}", dpi=160)
    plt.close(fig)


if __name__ == "__main__":
    main()
