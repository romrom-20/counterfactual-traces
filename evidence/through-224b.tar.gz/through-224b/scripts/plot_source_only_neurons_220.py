"""Presentation of sealed source-only and receiver forecasts against fresh measurements."""

import json
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

R=Path(__file__).resolve().parents[1]
def main():
    x=json.loads((R/"docs/analysis/220-source-only-neuron-hypothesis.json").read_text());assert x["qualified"]
    fig,axes=plt.subplots(2,2,figsize=(11,8),constrained_layout=True)
    items=[("group_finite_effect",None,"Selected 32-neuron finite common-readout effect","nats"),
           ("neuron6411_projection",None,"Neuron 6411 initial mixed projection","nats"),
           ("parents6411",0,"Neuron 6411 gate increment","activation units"),
           ("parents6411",1,"Neuron 6411 up increment","activation units")]
    for ax,(metric,index,title,unit) in zip(axes.flat,items):
        def value(r,label):
            v=r["quantities"][label][metric];return v if index is None else v[index]
        allvals=[]
        for prediction,color in (("S","#1d4f77"),("P",".5")):
            for schema,marker in (("generic","o"),("descriptive","s")):
                rows=[r for r in x["rows"] if r["group"]["schema"]==schema]
                actual=[value(r,"N") for r in rows];predicted=[value(r,prediction) for r in rows]
                ax.scatter(actual,predicted,color=color,marker=marker,s=28,alpha=.75,label=("Source-only S" if prediction=="S" else "Receiver forecast P")+" / "+schema)
                allvals.extend(actual+predicted)
        lo,hi=min(allvals),max(allvals);pad=max(.05,(hi-lo)*.08);lo-=pad;hi+=pad
        ax.plot([lo,hi],[lo,hi],color=".3",lw=.8,ls="--",label="Exact prediction")
        ax.set(xlim=(lo,hi),ylim=(lo,hi),title=title,xlabel=f"Measured native-incoming surrogate N ({unit})",ylabel=f"Sealed forecast ({unit})")
        ax.spines[["top","right"]].set_visible(False);ax.legend(fontsize=6.5)
    result="passes" if x["hypothesis_accepted"] else "fails"
    fig.suptitle(f"220: the source-only upstream hypothesis {result} its frozen local prediction gate",fontsize=13)
    fig.supxlabel("16 Oct 2026 · 16 new prompt pairs, one template family · all forecasts sealed before True forwards · selected surrogate response, not full native behavior",fontsize=8.5)
    for suffix in ("png","svg"):fig.savefig(R/f"docs/figures/220-source-only-neuron-hypothesis.{suffix}",dpi=160)
    plt.close(fig)
if __name__=="__main__":main()
