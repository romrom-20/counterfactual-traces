"""Independent whole-public-model dual hooks, rather than sequential predictor assembly."""

import torch
from torch.autograd import forward_ad

from latent_decisions.target import block_tensor, replace_block_tensor


def response(model, false_input, edit, finite_blocks, finite_head):
    values, handles = [], []
    selected = {1, *finite_blocks}

    def run(lam):
        def block_hook(index):
            def hook(module, args, kwargs, output):
                result = block_tensor(output)
                if index in selected:
                    xp, dx = forward_ad.unpack_dual(args[0])
                    yp, _ = forward_ad.unpack_dual(result)
                    finite = module.forward(xp + dx, **kwargs)
                    result = forward_ad.make_dual(yp, block_tensor(finite) - yp)
                values.append(result[0])
                return replace_block_tensor(output, result)

            return hook

        def readout_hook(module, args, output):
            xp, dx = forward_ad.unpack_dual(args[0])
            yp, _ = forward_ad.unpack_dual(output)
            return forward_ad.make_dual(yp, module.forward(xp + dx) - yp)

        try:
            for index, layer in enumerate(model.model.layers, 1):
                handles.append(layer.register_forward_hook(block_hook(index), with_kwargs=True))
            if finite_head:
                handles.append(model.model.norm.register_forward_hook(readout_hook))
            result = model(
                inputs_embeds=false_input + lam * edit,
                attention_mask=torch.ones(
                    false_input.shape[:2], device=false_input.device, dtype=torch.long
                ),
                use_cache=False,
                logits_to_keep=1,
            )
            assert len(values) == len(model.model.layers)
            return torch.stack(values), result.logits[0, -1, [895, 830]]
        finally:
            for handle in handles:
                handle.remove()

    zero = torch.zeros((), device=false_input.device, dtype=false_input.dtype)
    return torch.func.jvp(run, (zero,), (torch.ones_like(zero),))
