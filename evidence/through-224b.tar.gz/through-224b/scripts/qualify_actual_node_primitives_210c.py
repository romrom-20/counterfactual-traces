"""Actual-node local derivative qualification, independent210c registration."""
import json,hashlib
from pathlib import Path
import torch,numpy as np
from torch.nn import functional as F
from latent_decisions.target import load_target
from frozen_block28_derivative_210 import trace
from local_primitive_derivative_210c import PARENTS,local
R=Path(__file__).resolve().parents[1];RUN=R/'runs/block28-derivative-210c'
def write(p,o):p.write_text(json.dumps(o,indent=2))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 assert not RUN.exists();RUN.mkdir()
 runtime_path=R/'runs/genuine-oracle-continuation-204-full/runtime.json';runtime=json.loads(runtime_path.read_text())
 write(RUN/'design.json',{'source_hashes':{p:sha(R/p) for p in ['scripts/qualify_actual_node_primitives_210c.py','scripts/local_primitive_derivative_210c.py','scripts/frozen_block28_derivative_210.py','docs/experiments/210c-actual-node-primitives.md']},'runtime_sha256':sha(runtime_path),'epsilon':1e-5,'coordinate_bound':1e-4,'expected_checks':896})
 model,_,device=load_target(runtime['model'],'mps',offline=True);torch.set_num_threads(2);layer=model.model.layers[27];records=[]
 for path in sorted((R/'runs/two-block-factorial-209c/pairs').glob('*.npz')):
  parent=R/'runs/genuine-oracle-continuation-204-full/pairs'/path.name
  with np.load(path) as z,np.load(parent) as p:
   x=torch.tensor(p['false_boundaries'][27][None],device=device);context={'mask':torch.tensor(p['mask'],device=device),'rope':tuple(torch.tensor(p[k],device=device) for k in ['rope_cos','rope_sin'])};c=trace(layer,x,context);pos=int(z['source_position'])
   for arm in ['native','linear27']:
    operand=x.clone()
    if arm=='native':operand[:,pos:]=torch.tensor(z['native_true_suffix'][1][None],device=device)
    else:
     d=torch.zeros_like(x);d[:,pos:]=torch.tensor(z['LL_delta_suffix'][0][None],device=device);operand=x+d
    c1=trace(layer,operand,context)
    for name,parents in PARENTS.items():
     bases=tuple(c[k] for k in parents);deltas=tuple(c1[k]-c[k] for k in parents);analytic=local(c,name,deltas)
     if name in ['input_rms','post_rms']:
      module=layer.input_layernorm if name=='input_rms' else layer.post_attention_layernorm;public=module;weight=c['weights'][name];eps=module.variance_epsilon
      ref=lambda a:weight*a*torch.rsqrt(a.square().mean(-1,keepdim=True)+eps)
     elif name=='qk_product':public=ref=lambda a,b:(a@b.transpose(2,3))*c['scaling']
     elif name=='softmax':
      mask=context['mask'].cpu().double();public=lambda a:F.softmax(a+context['mask'],-1,dtype=torch.float32);ref=lambda a:torch.softmax(a+mask,-1)
     elif name=='weight_value':public=ref=lambda a,b:a@b
     elif name=='silu':public=ref=F.silu
     else:public=ref=lambda a,b:a*b
     pb=tuple(a.to(device=device,dtype=torch.float32) for a in bases);pd=tuple(a.to(device=device,dtype=torch.float32) for a in deltas)
     pj=torch.func.jvp(public,pb,pd)[1].cpu().double();fd=(ref(*[a+1e-5*b for a,b in zip(bases,deltas)])-ref(*[a-1e-5*b for a,b in zip(bases,deltas)]))/2e-5
     pe=float((pj-analytic).abs().max());fe=float((fd-analytic).abs().max());records.append(dict(key=path.stem,arm=arm,primitive=name,public_coordinate_error=pe,cpu64_fd_coordinate_error=fe,passed=pe<=1e-4 and fe<=1e-4,parent209c_sha256=sha(path),parent204_sha256=sha(parent)))
    del c1
  write(RUN/'status.json',dict(status='running',completed_pairs=len(records)//14,completed_checks=len(records)));print(path.stem,len(records),flush=True)
 report=dict(records=records,passed=all(r['passed'] for r in records),completed_pairs=len(records)//14,completed_checks=len(records),limits='Actual finite parent-node displacements only; local checks do not qualify wholeblockMPSJacobian or original196/206 failures.')
 write(R/'docs/analysis/210c-actual-node-primitives.json',report);write(RUN/'status.json',dict(status='complete',**{k:v for k,v in report.items() if k!='records'}))
if __name__=='__main__':main()
