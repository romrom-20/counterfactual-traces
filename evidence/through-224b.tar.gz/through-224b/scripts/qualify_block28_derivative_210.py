"""Bound frozen-primal CPU64 tangent against original block28 MPS derivatives."""
import hashlib,json
from pathlib import Path
import numpy as np
import torch
import ranked_block_response_201 as original
from latent_decisions.target import load_target
from frozen_block28_derivative_210 import trace,tangent
R=Path(__file__).resolve().parents[1]; RUN=R/'runs/block28-derivative-210'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,o):p.write_text(json.dumps(o,indent=2))
def main():
 assert not RUN.exists(); RUN.mkdir()
 files=['scripts/frozen_block28_derivative_210.py','scripts/qualify_block28_derivative_210.py','docs/experiments/210-frozen-block28-derivative.md']
 write(RUN/'design.json',{'source_hashes':{p:sha(R/p) for p in files},'arithmetic':'MPS32 frozen primals / CPU64 analytic tangents','coordinate_bound':1e-4,'score_bound':.005})
 runtime=json.loads((R/'runs/genuine-oracle-continuation-204-full/runtime.json').read_text())
 model,_,device=load_target(runtime['model'],'mps',offline=True); torch.set_num_threads(2)
 records=[]
 for path in sorted((R/'runs/two-block-factorial-209c/pairs').glob('*.npz')):
  with np.load(path) as z,np.load(R/'runs/genuine-oracle-continuation-204-full/pairs'/path.name) as parent:
   pos=int(z['source_position']); x=torch.tensor(parent['false_boundaries'][27][None],device=device)
   context={'mask':torch.tensor(parent['mask'],device=device),'rope':tuple(torch.tensor(parent[k],device=device) for k in ['rope_cos','rope_sin'])}
   directions=[]
   for arm in ['FL','LL']:
    d=torch.zeros_like(x);d[:,pos:]=torch.tensor(z[arm+'_delta_suffix'][0][None],device=device);directions.append(d)
   directions.append(directions[0]-directions[1])
   c=trace(model.model.layers[27],x,context); ys=[]; js=[];checks=[]
   false_out=torch.tensor(parent['false_boundaries'][28][None],device=device)
   primal_error=float((c['output']-false_out.cpu().double()).abs().max())
   rx=x.detach().clone().requires_grad_(True); ry=original.block(model.model.layers[27],rx,context)
   v=(torch.sin(torch.arange(ry.numel(),device=device,dtype=ry.dtype)/17)/np.sqrt(ry.numel())).reshape(ry.shape)
   grad=torch.autograd.grad((ry*v).sum(),rx)[0].detach().cpu().double()
   for label,d in zip(['native','linear27','difference'],directions):
    _,j=torch.func.jvp(lambda a:original.block(model.model.layers[27],a,context),(x,),(d,))
    y,_=tangent(c,d); ys.append(y);js.append(j.cpu().double())
    err=float((y-j.cpu().double()).abs().max()); rev=float((grad*d.cpu().double()).sum()); con=float((y*v.cpu().double()).sum())
    score=0.
    if label!='difference':
     sy=original.head(model,false_out+y.to(device=device,dtype=x.dtype));sj=original.head(model,false_out+j)
     score=float((sy-sj).abs().max())
    checks.append(dict(direction=label,coordinate_error=err,coordinate_passed=err<=1e-4,score_error=score,score_passed=score<=.005,reverse_error=abs(rev-con),reverse_tolerance=.001+.0001*abs(rev),reverse_passed=abs(rev-con)<=.001+.0001*abs(rev)))
   add=float((ys[0]-ys[1]-ys[2]).abs().max()); oldadd=float((js[0]-js[1]-js[2]).abs().max())
   row=dict(key=path.stem,parent_sha256=sha(path),primal_error=primal_error,primal_passed=primal_error<=1e-4,reference_additivity_error=add,reference_additivity_passed=add<=1e-4,original_additivity_error=oldadd,checks=checks)
   records.append(row);write(RUN/'status.json',dict(status='running',completed=len(records)));write(RUN/(path.stem+'.json'),row)
   print(json.dumps(row),flush=True)
   del c,ry,rx,grad,ys,js
 report=dict(records=records,completed=len(records),strict_qualified=all(r['primal_passed'] and r['reference_additivity_passed'] and all(c['coordinate_passed'] and c['score_passed'] and c['reverse_passed'] for c in r['checks']) for r in records),reference_linear=all(r['reference_additivity_passed'] for r in records),limits='Frozen-primal changed tangent arithmetic; no original derivative retrocertification; reverse projection alone is not coordinate qualification.')
 write(R/'docs/analysis/210-frozen-block28-derivative.json',report);write(RUN/'status.json',{k:v for k,v in report.items() if k!='records'})
if __name__=='__main__':main()
