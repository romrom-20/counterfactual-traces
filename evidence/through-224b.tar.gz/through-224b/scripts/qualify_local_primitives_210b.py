"""Independently check local primitive derivatives after failed210 whole compatibility."""
import json,hashlib
from pathlib import Path
import torch,numpy as np
from torch.nn import functional as F
from latent_decisions.target import load_target
from frozen_block28_derivative_210 import trace,tangent
R=Path(__file__).resolve().parents[1];RUN=R/'runs/block28-derivative-210b'
def write(p,o):p.write_text(json.dumps(o,indent=2))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 assert not RUN.exists();RUN.mkdir()
 write(RUN/'design.json',{'source_hashes':{p:sha(R/p) for p in ['scripts/qualify_local_primitives_210b.py','scripts/frozen_block28_derivative_210.py','docs/experiments/210b-local-primitives.md']},'epsilon':1e-5,'coordinate_bound':1e-4})
 runtime=json.loads((R/'runs/genuine-oracle-continuation-204-full/runtime.json').read_text());model,_,device=load_target(runtime['model'],'mps',offline=True);torch.set_num_threads(2);layer=model.model.layers[27];records=[]
 for path in sorted((R/'runs/two-block-factorial-209c/pairs').glob('*.npz')):
  with np.load(path) as z,np.load(R/'runs/genuine-oracle-continuation-204-full/pairs'/path.name) as p:
   x=torch.tensor(p['false_boundaries'][27][None],device=device);context={'mask':torch.tensor(p['mask'],device=device),'rope':tuple(torch.tensor(p[k],device=device) for k in ['rope_cos','rope_sin'])};c=trace(layer,x,context);pos=int(z['source_position'])
   for arm in ['FL','LL']:
    d=torch.zeros_like(x);d[:,pos:]=torch.tensor(z[arm+'_delta_suffix'][0][None],device=device);_,t=tangent(c,d)
    for name in ['input_rms','qk_product','softmax','weight_value','post_rms','silu','gate_up']:
     if name in ['input_rms','post_rms']:
      node='x' if name=='input_rms' else 'mid';di='input' if name=='input_rms' else 'mid';module=layer.input_layernorm if name=='input_rms' else layer.post_attention_layernorm
      bases=(c[node],);deltas=(t[di],);public=module
      weight=c['weights'][name];eps=module.variance_epsilon
      ref=lambda a:weight*a*torch.rsqrt(a.square().mean(-1,keepdim=True)+eps)
     elif name=='qk_product':
      bases=(c['q'],c['k']);deltas=(t['q'],t['k']);public=ref=lambda a,b:(a@b.transpose(2,3))*c['scaling']
     elif name=='softmax':
      bases=(c['qk_product'],);deltas=(t['qk_product'],);mask=context['mask'].cpu().double()
      public=lambda a:F.softmax(a+context['mask'],-1,dtype=torch.float32)
      ref=lambda a:torch.softmax(a+mask,-1)
     elif name=='weight_value':bases=(c['softmax'],c['v']);deltas=(t['softmax'],t['v']);public=ref=lambda a,b:a@b
     elif name=='silu':bases=(c['gate'],);deltas=(t['gate'],);public=ref=F.silu
     else:bases=(c['silu'],c['up']);deltas=(t['silu'],t['up']);public=ref=lambda a,b:a*b
     pb=tuple(a.to(device=device,dtype=torch.float32) for a in bases);pd=tuple(a.to(device=device,dtype=torch.float32) for a in deltas)
     pj=torch.func.jvp(public,pb,pd)[1].cpu().double()
     fd=(ref(*[a+1e-5*b for a,b in zip(bases,deltas)])-ref(*[a-1e-5*b for a,b in zip(bases,deltas)]))/2e-5
     pe=float((pj-t[name]).abs().max());fe=float((fd-t[name]).abs().max());records.append(dict(key=path.stem,arm=arm,primitive=name,public_coordinate_error=pe,cpu64_fd_coordinate_error=fe,passed=pe<=1e-4 and fe<=1e-4))
  print(path.stem,len(records),flush=True)
 report=dict(records=records,passed=all(r['passed'] for r in records),completed=len(records),limits='Local derivative checks only. Wholeblock210 compatibility failed; no originalMPS Jacobian attribution qualified.')
 write(R/'docs/analysis/210b-local-primitives.json',report);write(RUN/'status.json',{k:v for k,v in report.items() if k!='records'})
if __name__=='__main__':main()
