"""Fresh operators, separate concatenation U cuts and public logits:64 forwards."""

import gc
import itertools
import json
from contextlib import contextmanager
from pathlib import Path

import audit_curvature_multiplication_188 as audit
import numpy as np
import recheck_natural_bit_shared_reader_181 as public
import recheck_shared_signed_curvature_187 as activation
import torch

from latent_decisions.evidence_policy import digest, write_json
from latent_decisions.target import load_target

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "docs/analysis/188-numerical-recheck.json"


@contextmanager
def concat_up(model, pos, fixed=None):
    caps, handles, fires = {}, [], []
    try:
        for site in range(1, 29):

            def hook(module, args, output, site=site):
                if fixed is not None:
                    suffix = torch.tensor(fixed[site], device=output.device)[None]
                    output = torch.cat((output[:, : pos + 1], suffix), dim=1)
                caps[f"U_{site}"] = output[0, pos + 1 :].detach().cpu().numpy().copy()
                fires.append(site)
                return output

            handles.append(model.model.layers[site - 1].mlp.up_proj.register_forward_hook(hook))
        yield caps
        assert fires == list(range(1, 29))
    finally:
        for handle in handles:
            handle.remove()


def main():
    native = audit.parent.parent.native
    b = json.loads((audit.RUN / "design.json").read_text())
    assert json.loads((audit.RUN / "pipeline-status.json").read_text())["status"] == "complete"
    assert b["design"]["source_hash"] == audit.source_hash()
    model, tok, _ = load_target(b["design"]["models"]["qwen15"], "mps", offline=True)
    rt = json.loads((audit.RUN / "qwen15/runtime.json").read_text())
    assert (
        digest(model.config.to_dict()) == rt["config_hash"]
        and digest(tok.get_vocab()) == rt["tokenizer_hash"]
        and not model.training
    )
    block = audit.parent.parent.blocks()[0]
    forwards, checks = 0, []
    for a, t in itertools.product(range(2), repeat=2):
        g = native.fixture.group(block, a, t, 0, "descriptive")
        key = digest(g)
        r = native.read_record(audit.RUN / "qwen15/records" / f"{key}.json")["record"]
        pr = native.read_record(audit.parent.RUN / "qwen15/records" / f"{key}.json")["record"]
        p, pp = (
            audit.RUN / "qwen15/states" / f"{key}.npz",
            audit.parent.RUN / "qwen15/states" / f"{key}.npz",
        )
        assert native.hashed(p) == r["states_sha256"] and native.hashed(pp) == pr["states_sha256"]
        bases = [
            native.fixture.reconstruct(tok, block, native.fixture.job(g, bit)) for bit in range(2)
        ]
        assert bases == [q["base"] for q in r["raw"]]
        pos = r["position"]
        with np.load(p, allow_pickle=False) as z, np.load(pp, allow_pickle=False) as pz:
            fresh, fresh_u, fresh_phi = [], [], []

            def save_check(m, h, expected, prefix, capture_error, cut, arm, bit):
                se = max(abs(m[k] - expected[k]) for k in m)
                he = float(np.max(abs(h - z[f"{prefix}_final"])))
                checks.append(
                    {
                        **g,
                        "cut": cut,
                        "arm": arm,
                        "bit": bit,
                        "score_error": se,
                        "state_error": he,
                        "capture_error": capture_error,
                        "exact_scores": m == expected,
                        "exact_states": np.array_equal(h, z[f"{prefix}_final"]),
                        "passed": se <= 0.005 and he <= 1e-4 and capture_error <= 1e-5,
                    }
                )

            for bit in range(2):
                with (
                    activation.concat(model, pos) as ac,
                    public.concatenation_cuts(model, pos) as cap,
                    concat_up(model, pos) as uc,
                ):
                    m, h = public.public_readout(model, bases[bit])
                forwards += 1
                fresh.append(cap)
                fresh_u.append(uc)
                fresh_phi.append(ac)
                ce = max(
                    float(np.max(abs(v - z[f"raw_{bit}_{name}"])))
                    for name, v in {**cap, **uc}.items()
                )
                save_check(m, h, r["raw"][bit]["margin"], f"raw_{bit}", ce, "native", "native", bit)
            means = {
                name: native.midpoint(fresh[0][name], fresh[1][name])
                for name in native.sites()
                if name[0] in "NW"
            }
            mean_u = {
                site: native.midpoint(fresh_u[0][f"U_{site}"], fresh_u[1][f"U_{site}"])
                for site in range(1, 29)
            }
            maps = {
                site: audit.parent.components(
                    fresh_phi[0][f"{site}_input"],
                    fresh_phi[1][f"{site}_input"],
                    fresh_phi[0][f"{site}_output"],
                    fresh_phi[1][f"{site}_output"],
                )
                for site in range(1, 29)
            }
            ce_means = max(
                [float(np.max(abs(v - z[f"shared_{name}"]))) for name, v in means.items()]
                + [float(np.max(abs(v - z[f"shared_U_{site}"]))) for site, v in mean_u.items()]
            )
            ce_maps = max(
                float(np.max(abs(v - pz[f"map_{site}_{name}"])))
                for site, c in maps.items()
                for name, v in c.items()
            )
            for bit in range(2):
                own = {name: v for name, v in fresh[bit].items() if name[0] in "NW"}
                own_u = {site: fresh_u[bit][f"U_{site}"] for site in range(1, 29)}
                with (
                    public.concatenation_cuts(model, pos, own) as cap,
                    concat_up(model, pos, own_u) as uc,
                ):
                    m, h = public.public_readout(model, bases[bit])
                forwards += 1
                ce = max(
                    float(np.max(abs(v - z[f"raw_{bit}_{name}"])))
                    for name, v in {**cap, **uc}.items()
                )
                save_check(
                    m, h, r["identities"][bit]["margin"], f"own_{bit}", ce, "own", "identity", bit
                )
            for cut, arm, bit in itertools.product(audit.CUTS, ("paired", "even"), range(2)):
                targets = means if cut != "live" else {}
                fixed_u = mean_u if cut == "NWU" else None
                with (
                    activation.concat(model, pos, maps, arm, bit) as ac,
                    public.concatenation_cuts(model, pos, targets) as cap,
                    concat_up(model, pos, fixed_u) as uc,
                ):
                    m, h = public.public_readout(model, bases[bit])
                forwards += 1
                prefix = f"{cut}_{arm}_{bit}"
                ce = max(
                    [ce_means, ce_maps]
                    + [
                        float(np.max(abs(v - z[f"{prefix}_{name}"])))
                        for name, v in {**ac, **uc}.items()
                    ]
                    + [float(np.max(abs(cap[name] - v))) for name, v in targets.items()]
                    + [
                        float(np.max(abs(cap[f"V_{site}"] - fresh[bit][f"V_{site}"])))
                        for site in range(1, 29)
                    ]
                    + [
                        float(np.max(abs(cap[f"G_{site}"] - ac[f"{site}_output"])))
                        for site in range(1, 29)
                    ]
                )
                expected = next(
                    q["margin"]
                    for q in r["patches"]
                    if (q["cut"], q["arm"], q["bit"]) == (cut, arm, bit)
                )
                save_check(m, h, expected, prefix, ce, cut, arm, bit)
        print(f"188 fresh numerical cell {a}/{t}: {forwards}/64", flush=True)
    assert forwards == len(checks) == 64
    result = {
        "fingerprint": b["fingerprint"],
        "source_sha256": native.hashed(Path(__file__)),
        "audit_sha256": native.hashed(Path(audit.__file__)),
        "public_helper_sha256": native.hashed(Path(public.__file__)),
        "activation_helper_sha256": native.hashed(Path(activation.__file__)),
        "component_helper_sha256": native.hashed(Path(audit.parent.__file__)),
        "forwards": forwards,
        "passed": all(c["passed"] for c in checks),
        "all_scores_exact": all(c["exact_scores"] for c in checks),
        "all_states_exact": all(c["exact_states"] for c in checks),
        "maximum_score_error": max(c["score_error"] for c in checks),
        "maximum_state_error": max(c["state_error"] for c in checks),
        "maximum_capture_error": max(c["capture_error"] for c in checks),
        "checks": checks,
        "method": "Fresh native N/W/U and activation pairs, independent analytic C components, separate concatenation operator/activation/up hooks and public logits; no188 runner import.",
    }
    write_json(OUT, result)
    print(json.dumps({k: v for k, v in result.items() if k != "checks"}, indent=2))
    del model, tok
    gc.collect()
    torch.mps.empty_cache()


if __name__ == "__main__":
    main()
