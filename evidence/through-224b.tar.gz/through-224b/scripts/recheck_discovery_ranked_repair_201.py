"""Public full-model tangent hooks and standard reverse source-linear contractions."""

import gc
import itertools
import json
import math
from contextlib import contextmanager
from pathlib import Path

import audit_discovery_ranked_repair_201 as audit
import numpy as np
import public_ranked_block_response_201 as public
import torch

from latent_decisions.evidence_policy import digest, write_json
from latent_decisions.target import block_tensor, load_target

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "docs/analysis/201-numerical-recheck.json"


@contextmanager
def capture(model):
    states, inputs, handles = [], {}, []

    def first(module, args, kwargs):
        inputs["embedding"] = args[0].detach().clone()

    def save(module, args, out):
        states.append(block_tensor(out))

    try:
        handles.append(model.model.layers[0].register_forward_pre_hook(first, with_kwargs=True))
        for layer in model.model.layers:
            handles.append(layer.register_forward_hook(save))
        yield states, inputs
    finally:
        for handle in handles:
            handle.remove()


def main():
    bundle = json.loads((audit.RUN / "design.json").read_text())
    assert bundle["design"]["source_hash"] == audit.source_hash()
    assert json.loads((audit.RUN / "pipeline-status.json").read_text())["status"] == "complete"
    model, tok, device = load_target(bundle["design"]["models"]["qwen15"], "mps", offline=True)
    rt = json.loads((audit.RUN / "runtime.json").read_text())
    assert (
        digest(tok.get_vocab()) == rt["tokenizer_hash"]
        and digest(model.config.to_dict()) == rt["config_hash"]
    )
    checks, ordinary, forward, reverse = [], 0, 0, 0
    for schema, assignment, target in itertools.product(
        ("generic", "descriptive"), range(2), range(2)
    ):
        block = audit.blocks()[0]
        g = audit.native.fixture.group(block, assignment, target, 0, schema)
        key = digest(g)
        fr = audit.native.read_record(audit.RUN / "forecasts" / f"{key}.json")["record"]
        pos = fr["position"]
        with (
            np.load(audit.RUN / "forecasts" / f"{key}.npz", allow_pickle=False) as z,
            np.load(audit.RUN / "observations" / f"{key}.npz", allow_pickle=False) as oz,
        ):
            xf, first_state, source_direction = None, None, None
            for bit in range(2):
                base = audit.native.fixture.reconstruct(
                    tok, block, audit.native.fixture.job(g, bit)
                )
                assert base == fr["bases"][bit]
                ids = torch.tensor([base["free_input_ids"]], device=device)
                with torch.no_grad(), capture(model) as (states, inputs):
                    result = model(
                        input_ids=ids,
                        attention_mask=torch.ones_like(ids),
                        use_cache=False,
                        logits_to_keep=1,
                    )
                ordinary += 1
                label, saved = ("false", z) if bit == 0 else ("true", oz)
                rows = torch.stack(states)[:, 0, [pos, -1]].cpu().numpy()
                scores = result.logits[0, -1, [895, 830]].cpu().numpy()
                he = float(np.max(abs(rows - saved[f"{label}_rows"])))
                se = float(np.max(abs(scores - saved[f"{label}_scores"])))
                checks.append(
                    {
                        **g,
                        "kind": f"native{bit}",
                        "state_error": he,
                        "score_error": se,
                        "passed": he <= 1e-4 and se <= 0.005,
                    }
                )
                if bit == 0:
                    xf, first_state = inputs["embedding"], states[0].detach().clone()
            with torch.no_grad():
                edited = torch.tensor([fr["bases"][1]["free_input_ids"]], device=device)
                edit = model.model.embed_tokens(edited) - xf
            for arm in audit.ARMS:
                selected = (
                    []
                    if arm in ("source_linear", "exact_readout")
                    else bundle["design"]["selection"][
                        {
                            "residual_blocks": "residual",
                            "margin_blocks": "margin",
                            "union_blocks": "union",
                            "control_blocks": "control",
                        }[arm]
                    ]
                )
                primal, tangent = public.response(
                    model, xf, edit, set(selected), arm != "source_linear"
                )
                forward += 1
                he = float(
                    np.max(
                        abs(
                            tangent[0][:, [pos, -1]].detach().cpu().numpy() - z[f"{arm}_delta_rows"]
                        )
                    )
                )
                se = float(
                    np.max(abs(tangent[1].detach().cpu().numpy() - z[f"{arm}_delta_scores"]))
                )
                pe = float(
                    np.max(abs(primal[0][:, [pos, -1]].detach().cpu().numpy() - z["false_rows"]))
                )
                pse = float(np.max(abs(primal[1].detach().cpu().numpy() - z["false_scores"])))
                checks.append(
                    {
                        **g,
                        "kind": "public_whole_model_hook_reconstruction",
                        "arm": arm,
                        "state_error": he,
                        "score_error": se,
                        "primal_state_error": pe,
                        "primal_score_error": pse,
                        "passed": he <= 1e-4 and se <= 0.005 and pe <= 1e-4 and pse <= 0.005,
                    }
                )
                if arm == "source_linear":
                    source_direction = tangent[0][0][None].detach().clone()
                del primal, tangent
                gc.collect()
            ids = torch.tensor([fr["bases"][0]["free_input_ids"]], device=device)
            lam = torch.zeros((), device=device, requires_grad=True)

            def inject(
                module,
                args,
                kwargs,
                lam=lam,
                first_state=first_state,
                source_direction=source_direction,
            ):
                return (first_state + lam * source_direction, *args[1:]), kwargs

            handle = model.model.layers[1].register_forward_pre_hook(inject, with_kwargs=True)
            try:
                with capture(model) as (states, _):
                    result = model(
                        input_ids=ids,
                        attention_mask=torch.ones_like(ids),
                        use_cache=False,
                        logits_to_keep=1,
                    )
                reverse += 1
                rows = torch.stack([first_state + lam * source_direction, *states[1:]])[
                    :, 0, [pos, -1]
                ]
                count = rows.numel()
                vectors = [
                    (
                        torch.sin(torch.arange(count, device=device, dtype=torch.float32) / divisor)
                        / math.sqrt(count)
                    ).reshape(rows.shape)
                    for divisor in (17, 29)
                ]
                scalars = [
                    result.logits[0, -1, 830] - result.logits[0, -1, 895],
                    *[(rows * v).sum() for v in vectors],
                ]
                refs = [
                    float(torch.autograd.grad(scalar, lam, retain_graph=True)[0])
                    for scalar in scalars
                ]
                preds = [
                    float(z["source_linear_delta_scores"][1] - z["source_linear_delta_scores"][0]),
                    *[
                        float(
                            np.sum(
                                z["source_linear_delta_rows"].astype(np.float64)
                                * v.detach().cpu().numpy().astype(np.float64)
                            )
                        )
                        for v in vectors
                    ],
                ]
                errors = [abs(p - r) for p, r in zip(preds, refs)]
                checks.append(
                    {
                        **g,
                        "kind": "standard_reverse_source_linear",
                        "reference": refs,
                        "forward": preds,
                        "maximum_contraction_error": max(errors),
                        "passed": all(
                            abs(p - r) <= 0.001 + 0.0001 * abs(r) for p, r in zip(preds, refs)
                        ),
                    }
                )
            finally:
                handle.remove()
            del result, states, rows, vectors, scalars, lam
            gc.collect()
        print(
            f"201 public/reverse verification {schema} {assignment}/{target}: {ordinary}ordinary/{forward}forward/{reverse}reverse",
            flush=True,
        )
    assert ordinary == 16 and forward == 48 and reverse == 8 and len(checks) == 72
    report = {
        "fingerprint": bundle["fingerprint"],
        "source_sha256": audit.hashed(Path(__file__)),
        "audit_sha256": audit.hashed(Path(audit.__file__)),
        "public_helper_sha256": audit.hashed(Path(public.__file__)),
        "ordinary_model_invocations": ordinary,
        "forward_false_model_invocations": forward,
        "reverse_false_model_invocations": reverse,
        "passed": all(c["passed"] for c in checks),
        "maximum_hook_state_error": max(c.get("state_error", 0) for c in checks),
        "maximum_hook_score_error": max(c.get("score_error", 0) for c in checks),
        "maximum_reverse_contraction_error": max(
            c.get("maximum_contraction_error", 0) for c in checks
        ),
        "checks": checks,
        "scope": "Independent whole public model selected-block/normalization dual hooks; sameforwardADbackend structuralindependenceonly. Standardfirstreversechecks source_linear; selected-modefinitefunctionsverifiedviaalternateimplementation,notindependentADbackend. NoTruecoeffcalibration or196primitive double-backward reconciliation.",
    }
    write_json(OUT, report)
    print(json.dumps({k: v for k, v in report.items() if k != "checks"}, indent=2))


if __name__ == "__main__":
    main()
