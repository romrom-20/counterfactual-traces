"""Independent primitive JVP construction, public replay, and reverse tail contractions."""

import gc
import itertools
import json
import math
from contextlib import contextmanager
from pathlib import Path

import audit_first_block_primitive_repair_196 as audit
import numpy as np
import torch
from torch.nn import functional as F
from transformers.models.qwen2 import modeling_qwen2 as qwen

from latent_decisions.evidence_policy import digest, write_json
from latent_decisions.target import block_tensor, load_target

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "docs/analysis/196-numerical-recheck.json"


@contextmanager
def public_capture(model):
    rows, ctx, handles = [], {}, []

    def start(module, args, kwargs):
        ctx.update(
            x=args[0].detach().clone(),
            mask=kwargs["attention_mask"].detach().clone(),
            rope=tuple(v.detach().clone() for v in kwargs["position_embeddings"]),
        )

    def save(module, args, output):
        rows.append(block_tensor(output)[0])

    try:
        handles.append(model.model.layers[0].register_forward_pre_hook(start, with_kwargs=True))
        for layer in model.model.layers:
            handles.append(layer.register_forward_hook(save))
        yield rows, ctx
    finally:
        for handle in handles:
            handle.remove()


def assemble(layer, ctx, dx, enabled):
    """Each nonlinear primitive uses actual autograd at FALSE, not hand-written derivatives."""

    def node(function, bases, deltas, label):
        y = function(*bases)
        if label in enabled:
            dy = function(*[base + delta for base, delta in zip(bases, deltas)]) - y
        else:
            _, dy = torch.autograd.functional.jvp(function, tuple(bases), tuple(deltas))
        return y, dy

    x = ctx["x"]
    n, dn = node(layer.input_layernorm, (x,), (dx,), "input_rms")
    shape = (*x.shape[:-1], -1, layer.self_attn.head_dim)
    attn, mlp = layer.self_attn, layer.mlp
    q, k, v = [f(n).view(shape).transpose(1, 2) for f in (attn.q_proj, attn.k_proj, attn.v_proj)]
    dq, dk, dv = [
        F.linear(dn, f.weight).view(shape).transpose(1, 2)
        for f in (attn.q_proj, attn.k_proj, attn.v_proj)
    ]
    q, k = qwen.apply_rotary_pos_emb(q, k, *ctx["rope"])
    dq, dk = qwen.apply_rotary_pos_emb(dq, dk, *ctx["rope"])
    k, dk, v, dv = [qwen.repeat_kv(z, attn.num_key_value_groups) for z in (k, dk, v, dv)]
    logits, dl = node(
        lambda q, k: (q @ k.transpose(2, 3)) * attn.scaling, (q, k), (dq, dk), "qk_product"
    )
    p, dp = node(
        lambda z: F.softmax(z + ctx["mask"], -1, dtype=torch.float32), (logits,), (dl,), "softmax"
    )
    av, dav = node(lambda p, v: p @ v, (p, v), (dp, dv), "weight_value")
    a = attn.o_proj(av.transpose(1, 2).contiguous().reshape(x.shape))
    da = F.linear(dav.transpose(1, 2).contiguous().reshape(x.shape), attn.o_proj.weight)
    mid, dmid = x + a, dx + da
    mn, dmn = node(layer.post_attention_layernorm, (mid,), (dmid,), "post_rms")
    gate, up = mlp.gate_proj(mn), mlp.up_proj(mn)
    dg, du = F.linear(dmn, mlp.gate_proj.weight), F.linear(dmn, mlp.up_proj.weight)
    phi, dphi = node(mlp.act_fn, (gate,), (dg,), "silu")
    _, dproduct = node(lambda a, b: a * b, (phi, up), (dphi, du), "gate_up")
    return dx + da + F.linear(dproduct, mlp.down_proj.weight)


def main():
    bundle = json.loads((audit.RUN / "design.json").read_text())
    assert bundle["design"]["source_hash"] == audit.source_hash()
    assert json.loads((audit.RUN / "pipeline-status.json").read_text())["status"] == "complete"
    model, tok, device = load_target(bundle["design"]["models"]["qwen15"], "mps", offline=True)
    rt = json.loads((audit.RUN / "qwen15/runtime.json").read_text())
    assert (
        digest(tok.get_vocab()) == rt["tokenizer_hash"]
        and digest(model.config.to_dict()) == rt["config_hash"]
    )
    checks, ordinary, reverse = [], 0, 0
    for schema, assignment, target in itertools.product(
        ("generic", "descriptive"), range(2), range(2)
    ):
        block = audit.blocks()[0]
        g = audit.native.fixture.group(block, assignment, target, 0, schema)
        key = digest(g)
        fr = audit.native.read_record(audit.RUN / "qwen15/forecasts" / f"{key}.json")["record"]
        fp, op = (
            audit.RUN / "qwen15/forecasts" / f"{key}.npz",
            audit.RUN / "qwen15/observations" / f"{key}.npz",
        )
        pos = fr["position"]
        with np.load(fp, allow_pickle=False) as z, np.load(op, allow_pickle=False) as oz:
            native_first, context = None, None
            for bit in range(2):
                base = audit.native.fixture.reconstruct(
                    tok, block, audit.native.fixture.job(g, bit)
                )
                assert base == fr["bases"][bit]
                ids = torch.tensor([base["free_input_ids"]], device=device)
                with torch.no_grad(), public_capture(model) as (rows, ctx):
                    result = model(
                        input_ids=ids,
                        attention_mask=torch.ones_like(ids),
                        use_cache=False,
                        logits_to_keep=1,
                    )
                ordinary += 1
                saved = z if bit == 0 else oz
                label = "false" if bit == 0 else "true"
                actual_rows = torch.stack(rows)[:, [pos, -1]].detach().cpu().numpy()
                actual_scores = result.logits[0, -1, [895, 830]].detach().cpu().numpy()
                se = float(np.max(abs(actual_scores - saved[f"{label}_scores"])))
                he = max(
                    float(np.max(abs(actual_rows - saved[f"{label}_rows"]))),
                    float(np.max(abs(rows[0].detach().cpu().numpy() - saved[f"{label}_first"]))),
                )
                checks.append(
                    {
                        **g,
                        "kind": f"native{bit}",
                        "score_error": se,
                        "state_error": he,
                        "passed": se <= 0.005 and he <= 1e-4,
                    }
                )
                if bit == 0:
                    native_first, context = rows[0].detach().clone()[None], ctx
            with torch.no_grad():
                edited_ids = torch.tensor([fr["bases"][1]["free_input_ids"]], device=device)
                dx = model.model.embed_tokens(edited_ids) - context["x"]
            assert np.array_equal(dx[0].cpu().numpy(), z["embedding_delta"])
            directions = {}
            for arm in audit.ARMS[:-1]:
                enabled = (
                    audit.FACTORS if arm == "exact_block" else () if arm == "linear" else (arm,)
                )
                direction = assemble(model.model.layers[0], context, dx, enabled).detach()
                directions[arm] = direction
            directions["exact_source"] = torch.cat(
                (
                    directions["linear"][:, :pos],
                    directions["exact_block"][:, pos : pos + 1],
                    directions["linear"][:, pos + 1 :],
                ),
                1,
            )
            ids = torch.tensor([fr["bases"][0]["free_input_ids"]], device=device)
            for arm in audit.ARMS:
                local_error = float(
                    np.max(abs(directions[arm][0].cpu().numpy() - z[f"{arm}_first_delta"]))
                )
                direction = directions[arm]
                lam = torch.zeros((), device=device, requires_grad=True)

                def second_input(module, args, kwargs):
                    return (native_first + lam * direction, *args[1:]), kwargs

                handle = model.model.layers[1].register_forward_pre_hook(
                    second_input, with_kwargs=True
                )
                try:
                    with public_capture(model) as (states, _):
                        result = model(
                            input_ids=ids,
                            attention_mask=torch.ones_like(ids),
                            use_cache=False,
                            logits_to_keep=1,
                        )
                    reverse += 1
                    # Blockone is not altered by this implementation; its derivative is direction analytically.
                    saved_rows = torch.stack([native_first[0] + lam * direction[0], *states[1:]])[
                        :, [pos, -1]
                    ]
                    count = saved_rows.numel()
                    weights = [
                        (
                            torch.sin(
                                torch.arange(count, device=device, dtype=torch.float32) / divisor
                            )
                            / math.sqrt(count)
                        ).reshape(saved_rows.shape)
                        for divisor in (17, 29)
                    ]
                    scalars = [
                        result.logits[0, -1, 830] - result.logits[0, -1, 895],
                        *[(saved_rows * v).sum() for v in weights],
                    ]
                    refs = [
                        float(torch.autograd.grad(scalar, lam, retain_graph=True)[0])
                        for scalar in scalars
                    ]
                    preds = [
                        float(z[f"{arm}_delta_scores"][1] - z[f"{arm}_delta_scores"][0]),
                        *[
                            float(
                                np.sum(
                                    z[f"{arm}_delta_rows"].astype(np.float64)
                                    * v.detach().cpu().numpy().astype(np.float64)
                                )
                            )
                            for v in weights
                        ],
                    ]
                    errors = [abs(p - r) for p, r in zip(preds, refs)]
                    checks.append(
                        {
                            **g,
                            "arm": arm,
                            "kind": "independent_primitive_and_reverse_tail",
                            "local_coordinate_error": local_error,
                            "reverse_references": refs,
                            "forward_contractions": preds,
                            "maximum_contraction_error": max(errors),
                            "passed": local_error <= 1e-4
                            and all(
                                abs(p - r) <= 0.001 + 0.0001 * abs(r) for p, r in zip(preds, refs)
                            ),
                        }
                    )
                finally:
                    handle.remove()
                del result, states, saved_rows, weights, scalars, lam
                gc.collect()
        print(
            f"196 independent primitive/reverse checks {schema} {assignment}/{target}: {ordinary}native {reverse}reverse",
            flush=True,
        )
    assert ordinary == 16 and reverse == 80 and len(checks) == 96
    report = {
        "fingerprint": bundle["fingerprint"],
        "source_sha256": audit.hashed(Path(__file__)),
        "audit_sha256": audit.hashed(Path(audit.__file__)),
        "ordinary_model_invocations": ordinary,
        "reverse_tail_ad_invocations": reverse,
        "passed": all(c["passed"] for c in checks),
        "maximum_local_coordinate_error": max(c.get("local_coordinate_error", 0) for c in checks),
        "maximum_contraction_error": max(c.get("maximum_contraction_error", 0) for c in checks),
        "checks": checks,
        "scope": "Separate primitive-by-primitive autograd Jacobians/finite functions; tail reverse AD injects at blocktwo input. Selected8contexts,3 scalar contractions, not coordinatewise certification of every28layer derivative; public native storedrows/firstblock checked.",
    }
    write_json(OUT, report)
    print(json.dumps({k: v for k, v in report.items() if k != "checks"}, indent=2))
    del model, tok
    gc.collect()
    torch.mps.empty_cache()


if __name__ == "__main__":
    main()
