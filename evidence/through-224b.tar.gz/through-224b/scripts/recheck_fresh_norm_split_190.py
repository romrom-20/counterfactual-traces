"""Fresh paired operators and independent concatenation fresh norm-split replay:192 forwards."""

import gc
import itertools
import json
from contextlib import contextmanager
from pathlib import Path

import audit_fresh_norm_split_190 as audit
import numpy as np
import recheck_curvature_multiplication_188 as up
import recheck_natural_bit_shared_reader_181 as public
import recheck_shared_signed_curvature_187 as activation
import torch

from latent_decisions.evidence_policy import digest, write_json
from latent_decisions.target import block_tensor, load_target

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "docs/analysis/190-numerical-recheck.json"


@contextmanager
def independent_trajectory(model, pos):
    cap, handles = {}, []
    try:
        for site, layer in enumerate(model.model.layers, 1):

            def before(module, args, site=site):
                cap[f"R_{site}_input"] = args[0][0, pos + 1 :].detach().cpu().numpy().copy()

            handles.append(layer.register_forward_pre_hook(before))
            for kind, module in (
                ("attention", layer.self_attn),
                ("mlp", layer.mlp),
                ("output", layer),
            ):

                def after(module, args, out, site=site, kind=kind):
                    cap[f"R_{site}_{kind}"] = (
                        block_tensor(out)[0, pos + 1 :].detach().cpu().numpy().copy()
                    )

                handles.append(module.register_forward_hook(after))
        yield cap
        assert len(cap) == 112
    finally:
        for handle in handles:
            handle.remove()


def main():
    native = audit.native
    b = json.loads((audit.RUN / "design.json").read_text())
    assert json.loads((audit.RUN / "pipeline-status.json").read_text())["status"] == "complete"
    assert b["design"]["source_hash"] == audit.source_hash()
    model, tok, _ = load_target(b["design"]["models"]["qwen15"], "mps", offline=True)
    rt = json.loads((audit.RUN / "qwen15/runtime.json").read_text())
    assert (
        digest(model.config.to_dict()) == rt["config_hash"]
        and digest(tok.get_vocab()) == rt["tokenizer_hash"]
        and not model.training
    )
    block = audit.blocks()[0]
    forwards, checks = 0, []
    for schema, a, t in itertools.product(("generic", "descriptive"), range(2), range(2)):
        g = native.fixture.group(block, a, t, 0, schema)
        key = digest(g)
        r = native.read_record(audit.RUN / "qwen15/records" / f"{key}.json")["record"]
        p = audit.RUN / "qwen15/states" / f"{key}.npz"
        assert native.hashed(p) == r["states_sha256"]
        bases = [
            native.fixture.reconstruct(tok, block, native.fixture.job(g, bit)) for bit in range(2)
        ]
        assert bases == [q["base"] for q in r["raw"]]
        pos = r["position"]
        with np.load(p, allow_pickle=False) as z:
            fresh, fresh_u, fresh_phi = [], [], []

            def save_check(m, h, expected, prefix, capture_error, cut, arm, bit):
                se = max(abs(m[k] - expected[k]) for k in m)
                he = float(np.max(abs(h - z[f"{prefix}_final"])))
                checks.append(
                    {
                        **g,
                        "cut": cut,
                        "arm": arm,
                        "bit": bit,
                        "score_error": se,
                        "state_error": he,
                        "capture_error": capture_error,
                        "exact_scores": m == expected,
                        "exact_states": np.array_equal(h, z[f"{prefix}_final"]),
                        "passed": se <= 0.005 and he <= 1e-4 and capture_error <= 1e-5,
                    }
                )

            for bit in range(2):
                with (
                    activation.concat(model, pos) as ac,
                    public.concatenation_cuts(model, pos) as cap,
                    up.concat_up(model, pos) as uc,
                ):
                    m, h = public.public_readout(model, bases[bit])
                forwards += 1
                fresh.append(cap)
                fresh_u.append(uc)
                fresh_phi.append(ac)
                ce = max(
                    float(np.max(abs(v - z[f"raw_{bit}_{name}"])))
                    for name, v in {**cap, **uc}.items()
                )
                save_check(m, h, r["raw"][bit]["margin"], f"raw_{bit}", ce, "native", "native", bit)
            means = {
                name: native.midpoint(fresh[0][name], fresh[1][name])
                for name in native.sites()
                if name[0] == "N"
            }
            mean_u = {
                site: native.midpoint(fresh_u[0][f"U_{site}"], fresh_u[1][f"U_{site}"])
                for site in range(1, 29)
            }
            maps = {
                site: audit.parent.parent.parent.components(
                    fresh_phi[0][f"{site}_input"],
                    fresh_phi[1][f"{site}_input"],
                    fresh_phi[0][f"{site}_output"],
                    fresh_phi[1][f"{site}_output"],
                )
                for site in range(1, 29)
            }
            ce_means = max(
                [float(np.max(abs(v - z[f"shared_{name}"]))) for name, v in means.items()]
                + [float(np.max(abs(v - z[f"shared_U_{site}"]))) for site, v in mean_u.items()]
            )
            ce_maps = max(
                float(np.max(abs(v - z[f"map_{site}_{name}"])))
                for site, c in maps.items()
                for name, v in c.items()
            )
            source_error = 0.0
            for site in range(1, 29):
                product = torch.tensor(
                    maps[site]["even"], device=next(model.parameters()).device
                ) * torch.tensor(mean_u[site], device=next(model.parameters()).device)
                predicted = product @ model.model.layers[site - 1].mlp.down_proj.weight.T
                source_error = max(
                    source_error,
                    float(np.max(abs(predicted.detach().cpu().numpy() - z[f"C_source_{site}"]))),
                )
            for bit in range(2):
                own = {name: v for name, v in fresh[bit].items() if name[0] in "NW"}
                own_u = {site: fresh_u[bit][f"U_{site}"] for site in range(1, 29)}
                with (
                    public.concatenation_cuts(model, pos, own) as cap,
                    up.concat_up(model, pos, own_u) as uc,
                ):
                    m, h = public.public_readout(model, bases[bit])
                forwards += 1
                ce = max(
                    float(np.max(abs(v - z[f"raw_{bit}_{name}"])))
                    for name, v in {**cap, **uc}.items()
                )
                save_check(
                    m, h, r["identities"][bit]["margin"], f"own_{bit}", ce, "own", "identity", bit
                )
            for cut, arm, bit in itertools.product(audit.CUTS, ("paired", "even"), range(2)):
                targets = {
                    name: v
                    for name, v in means.items()
                    if cut == "NU"
                    or cut == "FU"
                    and name == "N_final"
                    or cut == "IU"
                    and name != "N_final"
                }
                fixed_u = mean_u if cut != "live" else None
                with (
                    independent_trajectory(model, pos) as rc,
                    activation.concat(model, pos, maps, arm, bit) as ac,
                    public.concatenation_cuts(model, pos, targets) as cap,
                    up.concat_up(model, pos, fixed_u) as uc,
                ):
                    m, h = public.public_readout(model, bases[bit])
                forwards += 1
                prefix = f"{cut}_{arm}_{bit}"
                ce = max(
                    [
                        ce_means,
                        ce_maps,
                        source_error,
                        float(np.max(abs(cap["N_final"] - z[f"{prefix}_N_final"]))),
                    ]
                    + [
                        float(np.max(abs(v - z[f"{prefix}_{name}"])))
                        for name, v in {**ac, **uc, **rc}.items()
                    ]
                    + [float(np.max(abs(cap[name] - v))) for name, v in targets.items()]
                    + [
                        float(np.max(abs(cap[f"V_{site}"] - fresh[bit][f"V_{site}"])))
                        for site in range(1, 29)
                    ]
                    + [
                        float(np.max(abs(cap[f"G_{site}"] - ac[f"{site}_output"])))
                        for site in range(1, 29)
                    ]
                )
                expected = next(
                    q["margin"]
                    for q in r["patches"]
                    if (q["cut"], q["arm"], q["bit"]) == (cut, arm, bit)
                )
                save_check(m, h, expected, prefix, ce, cut, arm, bit)
        print(f"190 fresh numerical {schema} cell {a}/{t}: {forwards}/192", flush=True)
    assert forwards == len(checks) == 192
    result = {
        "fingerprint": b["fingerprint"],
        "source_sha256": native.hashed(Path(__file__)),
        "audit_sha256": native.hashed(Path(audit.__file__)),
        "public_helper_sha256": native.hashed(Path(public.__file__)),
        "activation_helper_sha256": native.hashed(Path(activation.__file__)),
        "component_helper_sha256": native.hashed(Path(audit.parent.parent.parent.__file__)),
        "up_helper_sha256": native.hashed(Path(up.__file__)),
        "forwards": forwards,
        "component_matrix_computations": 224,
        "passed": all(c["passed"] for c in checks),
        "all_scores_exact": all(c["exact_scores"] for c in checks),
        "all_states_exact": all(c["exact_states"] for c in checks),
        "maximum_score_error": max(c["score_error"] for c in checks),
        "maximum_state_error": max(c["state_error"] for c in checks),
        "maximum_capture_error": max(c["capture_error"] for c in checks),
        "checks": checks,
        "method": "Fresh native N/W/U and activation pairs, independent analytic C components, separate concatenation operator/activation/up hooks and public logits; no190 runner import. Four new dependent blocks; selected fresh beryl contexts in both schemas; all norm-split conditions. No parent score copies.",
    }
    write_json(OUT, result)
    print(json.dumps({k: v for k, v in result.items() if k != "checks"}, indent=2))
    del model, tok
    gc.collect()
    torch.mps.empty_cache()


if __name__ == "__main__":
    main()
