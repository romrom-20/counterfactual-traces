"""Fresh all-layer factors, separate concatenation cuts and public-model replay."""

import gc
import itertools
import json
import math
from contextlib import contextmanager
from pathlib import Path

import audit_natural_bit_shared_reader_181 as audit
import numpy as np
import torch
from transformers.models.qwen2 import modeling_qwen2 as impl

from latent_decisions.evidence_policy import digest, write_json
from latent_decisions.target import block_tensor, load_target

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "docs/analysis/181-numerical-recheck.json"


@contextmanager
def concatenation_cuts(model, position, targets=None):
    targets = targets or {}
    cap, hooks, fired = {}, [], []
    original = impl.eager_attention_forward
    try:
        norm_modules = (
            [
                (f"N_{index + 1}_pre", layer.input_layernorm)
                for index, layer in enumerate(model.model.layers)
            ]
            + [
                (f"N_{index + 1}_post", layer.post_attention_layernorm)
                for index, layer in enumerate(model.model.layers)
            ]
            + [("N_final", model.model.norm)]
        )
        for label, module in norm_modules:

            def norm(module, args, output, label=label):
                x = args[0]
                inv = torch.rsqrt(x.square().mean(dim=-1, keepdim=True) + module.variance_epsilon)
                assert torch.equal(output, module.weight * (x * inv))
                factor = inv[0, position + 1 :]
                if label in targets:
                    factor = torch.tensor(targets[label], device=x.device)
                    suffix = module.weight * (x[:, position + 1 :] * factor[None])
                    output = torch.cat((output[:, : position + 1], suffix), dim=1)
                cap[label] = factor.detach().cpu().numpy().copy()
                fired.append(label)
                return output

            hooks.append(module.register_forward_hook(norm))

        def attention(module, query, key, value, attention_mask, scaling, dropout=0.0, **kwargs):
            output, weights = original(
                module, query, key, value, attention_mask, scaling, dropout, **kwargs
            )
            label = f"W_{module.layer_idx + 1}"
            if label in targets:
                suffix = torch.tensor(targets[label], device=weights.device)[None]
                weights = torch.cat((weights[:, :, : position + 1], suffix), dim=2)
                output = (
                    (weights @ impl.repeat_kv(value, module.num_key_value_groups))
                    .transpose(1, 2)
                    .contiguous()
                )
            cap[label] = weights[0, :, position + 1 :].detach().cpu().numpy().copy()
            fired.append(label)
            return output, weights

        impl.eager_attention_forward = attention
        for index, layer in enumerate(model.model.layers, 1):

            def activation(module, args, output, label=f"G_{index}"):
                if label in targets:
                    suffix = torch.tensor(targets[label], device=output.device)[None]
                    output = torch.cat((output[:, : position + 1], suffix), dim=1)
                cap[label] = output[0, position + 1 :].detach().cpu().numpy().copy()
                fired.append(label)
                return output

            def projection(module, args, output, label=f"V_{index}"):
                if label in targets:
                    row = torch.tensor(targets[label], device=output.device)[None, None]
                    output = torch.cat(
                        (output[:, :position], row, output[:, position + 1 :]), dim=1
                    )
                cap[label] = output[0, position].detach().cpu().numpy().copy()
                fired.append(label)
                return output

            hooks.append(layer.mlp.act_fn.register_forward_hook(activation))
            hooks.append(layer.self_attn.v_proj.register_forward_hook(projection))
        yield cap
        assert set(cap) == audit.sites() and len(fired) == len(set(fired)) == 141
    finally:
        impl.eager_attention_forward = original
        for hook in hooks:
            hook.remove()


@torch.inference_mode()
def public_readout(model, base):
    hidden = {}

    def capture(module, args, output):
        hidden["final"] = block_tensor(output)[0].detach().cpu().numpy().copy()

    handle = model.model.layers[-1].register_forward_hook(capture)
    try:
        tokens = torch.tensor([base["free_input_ids"]], device=next(model.parameters()).device)
        output = model(
            input_ids=tokens,
            attention_mask=torch.ones_like(tokens),
            use_cache=False,
            logits_to_keep=1,
        )
        fs = float(output.logits[0, -1, base["false_token"]])
        ts = float(output.logits[0, -1, base["true_token"]])
        assert math.isfinite(fs) and math.isfinite(ts)
        return {"false_score": fs, "true_score": ts, "log_odds": ts - fs}, hidden["final"]
    finally:
        handle.remove()


def main():
    b = json.loads((audit.RUN / "design.json").read_text())
    status = json.loads((audit.RUN / "pipeline-status.json").read_text())
    assert status["status"] == "complete" and b["design"]["source_hash"] == audit.source_hash()
    model, tok, _ = load_target(b["design"]["models"]["qwen15"], "mps", offline=True)
    rt = json.loads((audit.RUN / "qwen15/runtime.json").read_text())
    assert (
        digest(model.config.to_dict()) == rt["config_hash"]
        and digest(tok.get_vocab()) == rt["tokenizer_hash"]
        and not model.training
    )
    block = audit.blocks()[0]
    fresh, checks = {}, []
    forwards = 0
    for a, t in itertools.product(range(2), repeat=2):
        g = audit.fixture.group(block, a, t, 0, "descriptive")
        key = digest(g)
        nr = audit.read_record(audit.RUN / "qwen15/native" / f"{key}.json")["record"]
        p = audit.RUN / "qwen15/native" / f"{key}.npz"
        assert audit.hashed(p) == nr["states_sha256"]
        entries = []
        with np.load(p, allow_pickle=False) as z:
            for bit in range(2):
                base = audit.fixture.reconstruct(tok, block, audit.fixture.job(g, bit))
                assert base == nr["natives"][bit]["base"]
                with concatenation_cuts(model, nr["position"]) as cap:
                    m, h = public_readout(model, base)
                forwards += 1
                score_error = max(abs(m[k] - nr["natives"][bit]["margin"][k]) for k in m)
                state_error = float(np.max(abs(h - z[f"native_{bit}_final"])))
                capture_error = max(
                    float(np.max(abs(v - z[f"native_{bit}_{name}"]))) for name, v in cap.items()
                )
                checks.append(
                    {
                        **g,
                        "bit": bit,
                        "arm": "native",
                        "score_error": score_error,
                        "state_error": state_error,
                        "capture_error": capture_error,
                        "exact_scores": m == nr["natives"][bit]["margin"],
                        "exact_states": np.array_equal(h, z[f"native_{bit}_final"]),
                        "passed": score_error <= 0.005
                        and state_error <= 1e-4
                        and capture_error <= 1e-5,
                    }
                )
                entries.append({"base": base, "cap": cap})
        fresh[(a, t)] = entries
    canonical = {
        name: fresh[(0, 0)][1]["cap"][name] - fresh[(0, 0)][0]["cap"][name]
        for name in audit.sites()
        if name[0] == "V"
    }
    for a, t in itertools.product(range(2), repeat=2):
        g = audit.fixture.group(block, a, t, 0, "descriptive")
        key = digest(g)
        nr = audit.read_record(audit.RUN / "qwen15/native" / f"{key}.json")["record"]
        r = audit.read_record(audit.RUN / "qwen15/records" / f"{key}.json")["record"]
        p = audit.RUN / "qwen15/states" / f"{key}.npz"
        assert audit.hashed(p) == r["states_sha256"]
        caps = [entry["cap"] for entry in fresh[(a, t)]]
        means = {
            name: (
                (caps[0][name].astype(np.float64) + caps[1][name].astype(np.float64)) / 2
            ).astype(np.float32)
            for name in audit.sites()
        }
        with np.load(p, allow_pickle=False) as z:
            for arm, bit in itertools.product(audit.ARMS[1:], range(2)):
                selected = "NWG" if arm in ("own", "NWG", "neutral", "canonical") else arm
                targets = {
                    name: v
                    for name, v in (caps[bit] if arm == "own" else means).items()
                    if name[0] in selected
                }
                if arm == "neutral":
                    targets.update({name: v for name, v in means.items() if name[0] == "V"})
                if arm == "canonical":
                    targets.update(
                        {
                            name: (
                                means[name].astype(np.float64) + (bit - 0.5) * v.astype(np.float64)
                            ).astype(np.float32)
                            for name, v in canonical.items()
                        }
                    )
                with concatenation_cuts(model, nr["position"], targets) as actual:
                    m, h = public_readout(model, fresh[(a, t)][bit]["base"])
                forwards += 1
                expected = next(
                    q["margin"] for q in r["patches"] if (q["arm"], q["bit"]) == (arm, bit)
                )
                score_error = max(abs(m[k] - expected[k]) for k in m)
                state_error = float(np.max(abs(h - z[f"{arm}_{bit}_final"])))
                capture_error = max(
                    [float(np.max(abs(v - z[f"mean_{name}"]))) for name, v in means.items()]
                    + [float(np.max(abs(actual[name] - v))) for name, v in targets.items()]
                    + [
                        float(np.max(abs(actual[f"V_{site}"] - z[f"{arm}_{bit}_V_{site}"])))
                        for site in range(1, 29)
                    ]
                )
                checks.append(
                    {
                        **g,
                        "bit": bit,
                        "arm": arm,
                        "score_error": score_error,
                        "state_error": state_error,
                        "capture_error": capture_error,
                        "exact_scores": m == expected,
                        "exact_states": np.array_equal(h, z[f"{arm}_{bit}_final"]),
                        "passed": score_error <= 0.005
                        and state_error <= 1e-4
                        and capture_error <= 1e-5,
                    }
                )
        print(f"181 numerical cell{a}/{t} complete, {forwards}/88", flush=True)
    assert forwards == len(checks) == 88
    result = {
        "fingerprint": b["fingerprint"],
        "source_sha256": audit.hashed(Path(__file__)),
        "audit_sha256": audit.hashed(Path(audit.__file__)),
        "forwards": forwards,
        "passed": all(c["passed"] for c in checks),
        "all_scores_exact": all(c["exact_scores"] for c in checks),
        "all_states_exact": all(c["exact_states"] for c in checks),
        "maximum_score_error": max(c["score_error"] for c in checks),
        "maximum_state_error": max(c["state_error"] for c in checks),
        "maximum_capture_error": max(c["capture_error"] for c in checks),
        "checks": checks,
        "method": "Fresh native factors, separate all28-layer concatenation cuts, actual token inputs, public model logits; no runner import or block14 replacement.",
    }
    write_json(OUT, result)
    print(json.dumps({k: v for k, v in result.items() if k != "checks"}, indent=2))
    del model, tok
    gc.collect()
    torch.mps.empty_cache()


if __name__ == "__main__":
    main()
