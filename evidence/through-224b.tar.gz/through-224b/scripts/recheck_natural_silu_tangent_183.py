"""Fresh natural-input tangents and separate concatenation,32 public forwards."""

import gc
import itertools
import json
from contextlib import contextmanager
from pathlib import Path

import audit_natural_silu_tangent_183 as audit
import numpy as np
import recheck_natural_bit_shared_reader_181 as helper
import torch

from latent_decisions.evidence_policy import digest, write_json
from latent_decisions.target import load_target

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "docs/analysis/183-numerical-recheck.json"


@contextmanager
def concat_activation(model, position, anchors=None):
    cap, hooks, fires = {}, [], []
    try:
        for site in range(1, 29):
            target = (
                {
                    k: torch.tensor(v, device=next(model.parameters()).device)
                    for k, v in anchors[site].items()
                }
                if anchors is not None
                else None
            )

            def hook(module, args, output, site=site, target=target):
                x = args[0][0, position + 1 :]
                if target is not None:
                    suffix = target["intercept"] + (x - target["center"]) * target["slope"]
                    output = torch.cat((output[:, : position + 1], suffix[None]), dim=1)
                cap[f"{site}_input"] = x.detach().cpu().numpy().copy()
                cap[f"{site}_output"] = output[0, position + 1 :].detach().cpu().numpy().copy()
                fires.append(site)
                return output

            hooks.append(model.model.layers[site - 1].mlp.act_fn.register_forward_hook(hook))
        yield cap
        assert fires == list(range(1, 29))
    finally:
        for hook in hooks:
            hook.remove()


def main():
    native = audit.native
    bundle = json.loads((audit.RUN / "design.json").read_text())
    assert (
        json.loads((audit.RUN / "pipeline-status.json").read_text())["status"] == "complete"
        and bundle["design"]["source_hash"] == audit.source_hash()
    )
    model, tok, _ = load_target(bundle["design"]["models"]["qwen15"], "mps", offline=True)
    rt = json.loads((audit.RUN / "qwen15/runtime.json").read_text())
    assert (
        digest(model.config.to_dict()) == rt["config_hash"]
        and digest(tok.get_vocab()) == rt["tokenizer_hash"]
        and not model.training
    )
    checks, forwards = [], 0
    block = native.blocks()[0]
    for a, t in itertools.product(range(2), repeat=2):
        g = native.fixture.group(block, a, t, 0, "descriptive")
        key = digest(g)
        nr = native.read_record(native.RUN / "qwen15/native" / f"{key}.json")["record"]
        r = native.read_record(audit.RUN / "qwen15/records" / f"{key}.json")["record"]
        p = audit.RUN / "qwen15/states" / f"{key}.npz"
        assert native.hashed(p) == r["states_sha256"]
        bases = [
            native.fixture.reconstruct(tok, block, native.fixture.job(g, bit)) for bit in range(2)
        ]
        assert bases == [v["base"] for v in nr["natives"]]
        pos = r["position"]
        with np.load(p, allow_pickle=False) as z:

            def check(mode, bit, m, h, cap, anchor_error=0.0):
                expected = next(
                    q["margin"] for q in r["patches"] if (q["mode"], q["bit"]) == (mode, bit)
                )
                se = max(abs(m[k] - expected[k]) for k in m)
                he = float(np.max(abs(h - z[f"{mode}_{bit}_final"])))
                ce = max(
                    anchor_error,
                    max(
                        float(np.max(abs(v - z[f"{mode}_{bit}_{name}"]))) for name, v in cap.items()
                    ),
                )
                checks.append(
                    {
                        **g,
                        "mode": mode,
                        "bit": bit,
                        "score_error": se,
                        "state_error": he,
                        "capture_error": ce,
                        "exact_scores": m == expected,
                        "exact_states": np.array_equal(h, z[f"{mode}_{bit}_final"]),
                        "passed": se <= 0.005 and he <= 1e-4 and ce <= 1e-5,
                    }
                )

            classes, raw = [], []
            for bit in range(2):
                with (
                    concat_activation(model, pos) as cap,
                    helper.concatenation_cuts(model, pos) as ops,
                ):
                    m, h = helper.public_readout(model, bases[bit])
                forwards += 1
                check("raw", bit, m, h, cap)
                classes.append(ops)
                raw.append(cap)
            anchors = {
                site: audit.anchor(raw[0][f"{site}_input"], raw[1][f"{site}_input"])
                for site in range(1, 29)
            }
            anchor_error = max(
                float(np.max(abs(v - z[f"anchor_{site}_{name}"])))
                for site, entry in anchors.items()
                for name, v in entry.items()
            )
            means = {
                name: native.midpoint(classes[0][name], classes[1][name])
                for name in native.sites()
                if name[0] in "NW"
            }
            for mode, bit in itertools.product(
                ("native_NW", "tangent_free", "tangent_NW"), range(2)
            ):
                targets = means if mode != "tangent_free" else None
                with (
                    concat_activation(model, pos, anchors if mode != "native_NW" else None) as cap,
                    helper.concatenation_cuts(model, pos, targets),
                ):
                    m, h = helper.public_readout(model, bases[bit])
                forwards += 1
                check(mode, bit, m, h, cap, anchor_error)
        print(f"183 fresh numerical cell{a}/{t}: {forwards}/32", flush=True)
    assert forwards == len(checks) == 32
    result = {
        "fingerprint": bundle["fingerprint"],
        "source_sha256": native.hashed(Path(__file__)),
        "audit_sha256": native.hashed(Path(audit.__file__)),
        "helper_sha256": native.hashed(Path(helper.__file__)),
        "forwards": forwards,
        "passed": all(c["passed"] for c in checks),
        "all_scores_exact": all(c["exact_scores"] for c in checks),
        "all_states_exact": all(c["exact_states"] for c in checks),
        "maximum_score_error": max(c["score_error"] for c in checks),
        "maximum_state_error": max(c["state_error"] for c in checks),
        "maximum_capture_error": max(c["capture_error"] for c in checks),
        "checks": checks,
        "method": "Fresh native activation inputs and analytic center derivatives; separate concatenation activation/factor cuts; public logits. No183 runner import.",
    }
    write_json(OUT, result)
    print(json.dumps({k: v for k, v in result.items() if k != "checks"}, indent=2))
    del model, tok
    gc.collect()
    torch.mps.empty_cache()


if __name__ == "__main__":
    main()
