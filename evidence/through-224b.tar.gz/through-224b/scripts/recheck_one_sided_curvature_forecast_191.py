"""Fresh false-only coefficients, independent concat polynomials and64public calls."""

import gc
import itertools
import json
from contextlib import contextmanager
from pathlib import Path

import audit_one_sided_curvature_forecast_191 as audit
import numpy as np
import recheck_natural_bit_shared_reader_181 as public
import torch

from latent_decisions.evidence_policy import digest, write_json
from latent_decisions.target import load_target

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "docs/analysis/191-numerical-recheck.json"


@contextmanager
def concat(model, pos, maps=None, arm=None):
    cap, handles = {}, []
    try:
        for site, layer in enumerate(model.model.layers, 1):
            targets = (
                {
                    k: torch.tensor(v, device=next(model.parameters()).device)
                    for k, v in maps[site].items()
                }
                if maps is not None
                else None
            )

            def hook(module, args, out, site=site, targets=targets):
                x = args[0][0, pos + 1 :]
                if targets is not None:
                    delta = x - targets["center"]
                    square = delta * delta
                    y = targets["intercept"] + delta * targets["slope"]
                    if arm in ("Q2", "C3"):
                        y = y + square * targets["second"]
                    if arm == "C3":
                        y = y + (square * delta) * targets["third"]
                    out = torch.cat((out[:, : pos + 1], y[None]), dim=1)
                cap[f"{site}_input"] = x.detach().cpu().numpy().copy()
                cap[f"{site}_output"] = out[0, pos + 1 :].detach().cpu().numpy().copy()
                return out

            handles.append(layer.mlp.act_fn.register_forward_hook(hook))
        yield cap
        assert len(cap) == 56
    finally:
        for handle in handles:
            handle.remove()


def main():
    native = audit.native
    b = json.loads((audit.RUN / "design.json").read_text())
    assert (
        b["design"]["source_hash"] == audit.source_hash()
        and json.loads((audit.RUN / "pipeline-status.json").read_text())["status"] == "complete"
    )
    model, tok, _ = load_target(b["design"]["models"]["qwen15"], "mps", offline=True)
    rt = json.loads((audit.RUN / "qwen15/runtime.json").read_text())
    assert (
        digest(model.config.to_dict()) == rt["config_hash"]
        and digest(tok.get_vocab()) == rt["tokenizer_hash"]
        and not model.training
    )
    calls, checks = 0, []
    block = audit.blocks()[0]
    for schema, a, t in itertools.product(("generic", "descriptive"), range(2), range(2)):
        g = native.fixture.group(block, a, t, 0, schema)
        key = digest(g)
        fr = native.read_record(audit.RUN / "qwen15/forecasts" / f"{key}.json")["record"]
        pr = native.read_record(audit.RUN / "qwen15/records" / f"{key}.json")["record"]
        fp, pp = (
            audit.RUN / "qwen15/forecasts" / f"{key}.npz",
            audit.RUN / "qwen15/states" / f"{key}.npz",
        )
        assert native.hashed(fp) == fr["states_sha256"] and native.hashed(pp) == pr["states_sha256"]
        bases = [
            native.fixture.reconstruct(tok, block, native.fixture.job(g, bit)) for bit in range(2)
        ]
        assert bases == fr["bases"]
        pos = fr["position"]
        with np.load(fp, allow_pickle=False) as z, np.load(pp, allow_pickle=False) as tz:
            raw = []

            def check(m, h, cap, table, prefix, expected, arm, bit, extra=0.0):
                se = max(abs(m[k] - expected[k]) for k in m)
                he = float(np.max(abs(h - table[f"{prefix}_final"])))
                ce = max(
                    extra,
                    max(
                        float(np.max(abs(v - table[f"{prefix}_{name}"]))) for name, v in cap.items()
                    ),
                )
                checks.append(
                    {
                        **g,
                        "arm": arm,
                        "bit": bit,
                        "score_error": se,
                        "state_error": he,
                        "capture_error": ce,
                        "exact_scores": m == expected,
                        "exact_states": np.array_equal(h, table[f"{prefix}_final"]),
                        "passed": se <= 0.005 and he <= 1e-4 and ce <= 1e-5,
                    }
                )

            for bit in range(2):
                with concat(model, pos) as cap:
                    m, h = public.public_readout(model, bases[bit])
                calls += 1
                raw.append(cap)
                table = z if bit == 0 else tz
                prefix = "native_false" if bit == 0 else "native_true"
                expected = fr["native_false"]["margin"] if bit == 0 else pr["native_true"]["margin"]
                check(m, h, cap, table, prefix, expected, "native", bit)
            maps = {
                site: audit.coefficients(raw[0][f"{site}_input"], raw[0][f"{site}_output"])
                for site in range(1, 29)
            }
            coefficients_error = max(
                float(np.max(abs(v - z[f"map_{arm}_{site}_{name}"])))
                for arm in audit.ARMS
                for site, fields in maps.items()
                for name, v in fields.items()
            )
            for arm, bit in itertools.product(audit.ARMS, range(2)):
                with concat(model, pos, maps, arm) as cap:
                    m, h = public.public_readout(model, bases[bit])
                calls += 1
                expected = next(
                    q["margin"] for q in fr["patches"] if (q["arm"], q["bit"]) == (arm, bit)
                )
                check(m, h, cap, z, f"{arm}_{bit}", expected, arm, bit, coefficients_error)
        print(f"191numerical{schema} cell{a}/{t}: {calls}/64", flush=True)
    assert calls == len(checks) == 64
    result = {
        "fingerprint": b["fingerprint"],
        "source_sha256": native.hashed(Path(__file__)),
        "audit_sha256": native.hashed(Path(audit.__file__)),
        "public_helper_sha256": native.hashed(Path(public.__file__)),
        "forwards": calls,
        "passed": all(c["passed"] for c in checks),
        "all_scores_exact": all(c["exact_scores"] for c in checks),
        "all_states_exact": all(c["exact_states"] for c in checks),
        "maximum_score_error": max(c["score_error"] for c in checks),
        "maximum_state_error": max(c["state_error"] for c in checks),
        "maximum_capture_error": max(c["capture_error"] for c in checks),
        "checks": checks,
        "method": "Fresh nativeFalse-only analytic coefficients; separate concat polynomial hooks/public model. NativeTrue captures only used to verify raw replay, never map construction. Bothschemas/allfourcells atfirstsource/order0.",
    }
    write_json(OUT, result)
    print(json.dumps({k: v for k, v in result.items() if k != "checks"}, indent=2))
    del model, tok
    gc.collect()
    torch.mps.empty_cache()


if __name__ == "__main__":
    main()
