"""Fresh one-sided/refined maps, separate concatenation hooks and40 public forwards."""

import gc
import itertools
import json
from pathlib import Path

import audit_one_sided_gain_forecast_186 as audit
import numpy as np
import recheck_natural_bit_shared_reader_181 as public
import recheck_natural_silu_tangent_183 as activation
import torch

from latent_decisions.evidence_policy import digest, write_json
from latent_decisions.target import load_target

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "docs/analysis/186-numerical-recheck.json"


def anchors(false_cap, previous_true=None):
    result = {}
    for site in range(1, 29):
        x = false_cap[f"{site}_input"]
        c = (
            x.astype(np.float64)
            if previous_true is None
            else (x.astype(np.float64) + previous_true[f"{site}_input"].astype(np.float64)) / 2
        )
        result[site] = {
            "center": x.copy(),
            "intercept": false_cap[f"{site}_output"].copy(),
            "slope": audit.slope_at(c),
        }
    return result


def main():
    native = audit.native
    b = json.loads((audit.RUN / "design.json").read_text())
    assert (
        json.loads((audit.RUN / "pipeline-status.json").read_text())["status"] == "complete"
        and b["design"]["source_hash"] == audit.source_hash()
    )
    model, tok, _ = load_target(b["design"]["models"]["qwen15"], "mps", offline=True)
    rt = json.loads((audit.RUN / "qwen15/runtime.json").read_text())
    assert (
        digest(model.config.to_dict()) == rt["config_hash"]
        and digest(tok.get_vocab()) == rt["tokenizer_hash"]
        and not model.training
    )
    forwards, checks = 0, []
    block = audit.blocks()[0]
    for a, t in itertools.product(range(2), repeat=2):
        g = native.fixture.group(block, a, t, 0, "descriptive")
        key = digest(g)
        fr = native.read_record(audit.RUN / "qwen15/forecasts" / f"{key}.json")["record"]
        r = native.read_record(audit.RUN / "qwen15/records" / f"{key}.json")["record"]
        fp, p = (
            audit.RUN / "qwen15/forecasts" / f"{key}.npz",
            audit.RUN / "qwen15/states" / f"{key}.npz",
        )
        assert native.hashed(fp) == fr["states_sha256"] and native.hashed(p) == r["states_sha256"]
        bases = [
            native.fixture.reconstruct(tok, block, native.fixture.job(g, bit)) for bit in range(2)
        ]
        assert bases == fr["bases"]
        pos = r["position"]
        with np.load(fp, allow_pickle=False) as fz, np.load(p, allow_pickle=False) as z:

            def check(label, bit, m, h, cap, expected, table, map_targets=None):
                se = max(abs(m[k] - expected[k]) for k in m)
                he = float(np.max(abs(h - table[f"{label}_final"])))
                errors = [
                    float(np.max(abs(v - table[f"{label}_{name}"]))) for name, v in cap.items()
                ]
                if map_targets is not None:
                    arm = label.rsplit("_", 1)[0]
                    errors.extend(
                        float(np.max(abs(v - table[f"map_{arm}_{site}_{name}"])))
                        for site, entry in map_targets.items()
                        for name, v in entry.items()
                    )
                ce = max(errors)
                checks.append(
                    {
                        **g,
                        "label": label,
                        "bit": bit,
                        "score_error": se,
                        "state_error": he,
                        "capture_error": ce,
                        "exact_scores": m == expected,
                        "exact_states": np.array_equal(h, table[f"{label}_final"]),
                        "passed": se <= 0.005 and he <= 1e-4 and ce <= 1e-5,
                    }
                )

            with activation.concat_activation(model, pos) as fc:
                fm, fh = public.public_readout(model, bases[0])
            forwards += 1
            check("native_false", 0, fm, fh, fc, fr["native_false"]["margin"], fz)
            previous = None
            for arm in audit.ARMS[:3]:
                targets = anchors(fc, previous)
                for bit in range(2):
                    with activation.concat_activation(model, pos, targets) as cap:
                        m, h = public.public_readout(model, bases[bit])
                    forwards += 1
                    expected = next(
                        q["margin"] for q in fr["patches"] if (q["arm"], q["bit"]) == (arm, bit)
                    )
                    check(f"{arm}_{bit}", bit, m, h, cap, expected, fz, targets)
                    if bit == 1:
                        previous = cap
            with activation.concat_activation(model, pos) as tc:
                tm, th = public.public_readout(model, bases[1])
            forwards += 1
            check("native_true", 1, tm, th, tc, r["native_true"]["margin"], z)
            targets = anchors(fc, tc)
            for bit in range(2):
                with activation.concat_activation(model, pos, targets) as cap:
                    m, h = public.public_readout(model, bases[bit])
                forwards += 1
                expected = next(q["margin"] for q in r["patches"] if q["bit"] == bit)
                check(f"oracle_{bit}", bit, m, h, cap, expected, z, targets)
        print(f"186 fresh numerical cell{a}/{t}: {forwards}/40", flush=True)
    assert forwards == len(checks) == 40
    result = {
        "fingerprint": b["fingerprint"],
        "source_sha256": native.hashed(Path(__file__)),
        "audit_sha256": native.hashed(Path(audit.__file__)),
        "activation_helper_sha256": native.hashed(Path(activation.__file__)),
        "public_helper_sha256": native.hashed(Path(public.__file__)),
        "forwards": forwards,
        "passed": all(c["passed"] for c in checks),
        "all_scores_exact": all(c["exact_scores"] for c in checks),
        "all_states_exact": all(c["exact_states"] for c in checks),
        "maximum_score_error": max(c["score_error"] for c in checks),
        "maximum_state_error": max(c["state_error"] for c in checks),
        "maximum_capture_error": max(c["capture_error"] for c in checks),
        "checks": checks,
        "method": "Fresh false baseline, three sequential forecast-derived gain maps, then fresh native true and diagnostic oracle; separate concat hooks and public logits. Numerical replay is after completed main forecasts, not additional prospective evidence.",
    }
    write_json(OUT, result)
    print(json.dumps({k: v for k, v in result.items() if k != "checks"}, indent=2))
    del model, tok
    gc.collect()
    torch.mps.empty_cache()


if __name__ == "__main__":
    main()
