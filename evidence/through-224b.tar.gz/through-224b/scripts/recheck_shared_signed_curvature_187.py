"""Fresh C/E components, independent concatenation implementation,48 calls."""

import gc
import itertools
import json
from contextlib import contextmanager
from pathlib import Path

import audit_shared_signed_curvature_187 as audit
import numpy as np
import recheck_natural_bit_shared_reader_181 as public
import torch

from latent_decisions.evidence_policy import digest, write_json
from latent_decisions.target import load_target

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "docs/analysis/187-numerical-recheck.json"


@contextmanager
def concat(model, pos, maps=None, arm=None, bit=None):
    cap, handles, fires = {}, [], []
    try:
        for site in range(1, 29):
            target = (
                {
                    k: torch.tensor(v, device=next(model.parameters()).device)
                    for k, v in maps[site].items()
                }
                if maps is not None
                else None
            )

            def hook(module, args, out, site=site, target=target):
                x = args[0][0, pos + 1 :]
                if target is not None:
                    if arm == "false_anchor":
                        y = target["yf"] + (x - target["xf"]) * target["slope"]
                    else:
                        y = target["intercept"] + (x - target["center"]) * target["slope"]
                        if arm in ("even", "both"):
                            y = y + target["even"]
                        if arm in ("odd", "both"):
                            y = y + (2 * bit - 1) * target["odd"]
                        if arm == "both":
                            y = torch.where(x == target["xf"], target["yf"], y)
                            y = torch.where(x == target["xt"], target["yt"], y)
                    out = torch.cat((out[:, : pos + 1], y[None]), dim=1)
                cap[f"{site}_input"] = x.detach().cpu().numpy().copy()
                cap[f"{site}_output"] = out[0, pos + 1 :].detach().cpu().numpy().copy()
                fires.append(site)
                return out

            handles.append(model.model.layers[site - 1].mlp.act_fn.register_forward_hook(hook))
        yield cap
        assert fires == list(range(1, 29))
    finally:
        for h in handles:
            h.remove()


def main():
    parent = audit.parent
    native = parent.native
    b = json.loads((audit.RUN / "design.json").read_text())
    assert (
        json.loads((audit.RUN / "pipeline-status.json").read_text())["status"] == "complete"
        and b["design"]["source_hash"] == audit.source_hash()
    )
    model, tok, _ = load_target(b["design"]["models"]["qwen15"], "mps", offline=True)
    rt = json.loads((audit.RUN / "qwen15/runtime.json").read_text())
    assert (
        digest(model.config.to_dict()) == rt["config_hash"]
        and digest(tok.get_vocab()) == rt["tokenizer_hash"]
        and not model.training
    )
    checks, forwards = [], 0
    block = parent.blocks()[0]
    for a, t in itertools.product(range(2), repeat=2):
        g = native.fixture.group(block, a, t, 0, "descriptive")
        key = digest(g)
        fr = native.read_record(parent.RUN / "qwen15/forecasts" / f"{key}.json")["record"]
        pr = native.read_record(parent.RUN / "qwen15/records" / f"{key}.json")["record"]
        r = native.read_record(audit.RUN / "qwen15/records" / f"{key}.json")["record"]
        fp, pp, p = (
            parent.RUN / "qwen15/forecasts" / f"{key}.npz",
            parent.RUN / "qwen15/states" / f"{key}.npz",
            audit.RUN / "qwen15/states" / f"{key}.npz",
        )
        assert (
            native.hashed(fp) == fr["states_sha256"]
            and native.hashed(pp) == pr["states_sha256"]
            and native.hashed(p) == r["states_sha256"]
        )
        bases = [
            native.fixture.reconstruct(tok, block, native.fixture.job(g, bit)) for bit in range(2)
        ]
        assert bases == fr["bases"]
        with (
            np.load(fp, allow_pickle=False) as fz,
            np.load(pp, allow_pickle=False) as pz,
            np.load(p, allow_pickle=False) as z,
        ):
            raw = []
            for bit in range(2):
                with concat(model, r["position"]) as cap:
                    m, h = public.public_readout(model, bases[bit])
                forwards += 1
                raw.append(cap)
                table = fz if bit == 0 else pz
                label = "native_false" if bit == 0 else "native_true"
                expected = fr["native_false"]["margin"] if bit == 0 else pr["native_true"]["margin"]
                se = max(abs(m[k] - expected[k]) for k in m)
                he = float(np.max(abs(h - table[f"{label}_final"])))
                ce = max(
                    float(np.max(abs(v - table[f"{label}_{name}"]))) for name, v in cap.items()
                )
                checks.append(
                    {
                        **g,
                        "arm": "native",
                        "bit": bit,
                        "score_error": se,
                        "state_error": he,
                        "capture_error": ce,
                        "exact_scores": m == expected,
                        "exact_states": np.array_equal(h, table[f"{label}_final"]),
                        "passed": se <= 0.005 and he <= 1e-4 and ce <= 1e-5,
                    }
                )
            maps = {
                site: audit.components(
                    raw[0][f"{site}_input"],
                    raw[1][f"{site}_input"],
                    raw[0][f"{site}_output"],
                    raw[1][f"{site}_output"],
                )
                for site in range(1, 29)
            }
            component_error = max(
                float(np.max(abs(v - z[f"map_{site}_{name}"])))
                for site, c in maps.items()
                for name, v in c.items()
            )
            for arm, bit in itertools.product(audit.ARMS, range(2)):
                with concat(model, r["position"], maps, arm, bit) as cap:
                    m, h = public.public_readout(model, bases[bit])
                forwards += 1
                expected = next(
                    q["margin"] for q in r["patches"] if (q["arm"], q["bit"]) == (arm, bit)
                )
                prefix = f"{arm}_{bit}"
                se = max(abs(m[k] - expected[k]) for k in m)
                he = float(np.max(abs(h - z[f"{prefix}_final"])))
                ce = max(
                    component_error,
                    max(float(np.max(abs(v - z[f"{prefix}_{name}"]))) for name, v in cap.items()),
                )
                checks.append(
                    {
                        **g,
                        "arm": arm,
                        "bit": bit,
                        "score_error": se,
                        "state_error": he,
                        "capture_error": ce,
                        "exact_scores": m == expected,
                        "exact_states": np.array_equal(h, z[f"{prefix}_final"]),
                        "passed": se <= 0.005 and he <= 1e-4 and ce <= 1e-5,
                    }
                )
        print(f"187 fresh numerical cell{a}/{t}: {forwards}/48", flush=True)
    assert forwards == len(checks) == 48
    result = {
        "fingerprint": b["fingerprint"],
        "source_sha256": native.hashed(Path(__file__)),
        "audit_sha256": native.hashed(Path(audit.__file__)),
        "public_helper_sha256": native.hashed(Path(public.__file__)),
        "forwards": forwards,
        "passed": all(c["passed"] for c in checks),
        "all_scores_exact": all(c["exact_scores"] for c in checks),
        "all_states_exact": all(c["exact_states"] for c in checks),
        "maximum_score_error": max(c["score_error"] for c in checks),
        "maximum_state_error": max(c["state_error"] for c in checks),
        "maximum_capture_error": max(c["capture_error"] for c in checks),
        "checks": checks,
        "method": "Fresh native input/output pairs and independent analytic C/E maps, separate concatenation interventions/public logits; no187 runner import. Both is an endpoint-corrected identity control only.",
    }
    write_json(OUT, result)
    print(json.dumps({k: v for k, v in result.items() if k != "checks"}, indent=2))
    del model, tok
    gc.collect()
    torch.mps.empty_cache()


if __name__ == "__main__":
    main()
