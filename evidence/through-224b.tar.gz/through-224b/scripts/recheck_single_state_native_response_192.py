"""Independent reverse AD contractions and fresh public native trajectories."""

import gc
import itertools
import json
import math
from contextlib import contextmanager
from pathlib import Path

import audit_single_state_native_response_192 as audit
import numpy as np
import recheck_natural_bit_shared_reader_181 as public
import torch

from latent_decisions.evidence_policy import digest, write_json
from latent_decisions.target import block_tensor, load_target

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "docs/analysis/192-numerical-recheck.json"


@contextmanager
def blocks(model, detach):
    values, handles = [], []

    def save(module, args, out):
        value = block_tensor(out)[0]
        values.append(value.detach().cpu().numpy().copy() if detach else value)

    try:
        for layer in model.model.layers:
            handles.append(layer.register_forward_hook(save))
        yield values
        assert len(values) == 28
    finally:
        for handle in handles:
            handle.remove()


def main():
    b = json.loads((audit.RUN / "design.json").read_text())
    assert b["design"]["source_hash"] == audit.source_hash()
    assert json.loads((audit.RUN / "pipeline-status.json").read_text())["status"] == "complete"
    model, tok, device = load_target(b["design"]["models"]["qwen15"], "mps", offline=True)
    rt = json.loads((audit.RUN / "qwen15/runtime.json").read_text())
    assert (
        digest(tok.get_vocab()) == rt["tokenizer_hash"]
        and digest(model.config.to_dict()) == rt["config_hash"]
        and not model.training
    )
    checks = []
    for schema, a, t in itertools.product(("generic", "descriptive"), range(2), range(2)):
        block = audit.blocks()[0]
        g = audit.native.fixture.group(block, a, t, 0, schema)
        key = digest(g)
        fr = audit.native.read_record(audit.RUN / "qwen15/forecasts" / f"{key}.json")["record"]
        obs = audit.native.read_record(audit.RUN / "qwen15/observations" / f"{key}.json")["record"]
        fp = audit.RUN / "qwen15/forecasts" / f"{key}.npz"
        op = audit.RUN / "qwen15/observations" / f"{key}.npz"
        assert (
            audit.native.hashed(fp) == fr["states_sha256"]
            and audit.native.hashed(op) == obs["states_sha256"]
        )
        bases = [
            audit.native.fixture.reconstruct(tok, block, audit.native.fixture.job(g, bit))
            for bit in range(2)
        ]
        assert bases == fr["bases"]
        with np.load(fp, allow_pickle=False) as z, np.load(op, allow_pickle=False) as oz:
            for bit in range(2):
                with blocks(model, True) as hs:
                    margin, h = public.public_readout(model, bases[bit])
                expected = fr["native_false"] if bit == 0 else obs["margins"]["1.0"]
                saved = z["native_false_states"] if bit == 0 else oz["actual_1.0_states"]
                se = max(abs(margin[k] - expected[k]) for k in margin)
                he = float(np.max(abs(np.stack(hs) - saved)))
                checks.append(
                    {
                        **g,
                        "kind": f"native{bit}",
                        "score_error": se,
                        "state_error": he,
                        "exact_scores": margin == expected,
                        "exact_states": np.array_equal(np.stack(hs), saved),
                        "passed": se <= 0.005 and he <= 1e-4,
                    }
                )
            ids = torch.tensor([bases[0]["free_input_ids"]], device=device)
            other = torch.tensor([bases[1]["free_input_ids"]], device=device)
            with torch.no_grad():
                x0 = model.model.embed_tokens(ids).detach()
                direction = model.model.embed_tokens(other).detach() - x0
            lam = torch.zeros((), device=device, requires_grad=True)
            with blocks(model, False) as states:
                result = model(
                    inputs_embeds=x0 + lam * direction,
                    attention_mask=torch.ones_like(ids),
                    use_cache=False,
                    logits_to_keep=1,
                )
            stacked = torch.stack(states)
            scalars = [result.logits[0, -1, 830] - result.logits[0, -1, 895]]
            weights = []
            for which in range(2):
                shape = stacked[:, -1].shape if which == 0 else stacked.shape
                count = math.prod(shape)
                vector = (
                    torch.sin(torch.arange(count, device=device, dtype=torch.float32) / 17)
                    / math.sqrt(count)
                ).reshape(shape)
                scalars.append(((stacked[:, -1] if which == 0 else stacked) * vector).sum())
                weights.append(vector.detach().cpu().numpy().astype(np.float64))
            refs = []
            for scalar in scalars:
                first = torch.autograd.grad(scalar, lam, create_graph=True, retain_graph=True)[0]
                second = torch.autograd.grad(first, lam, retain_graph=True)[0]
                refs.append((float(first), float(second)))
            predicted = [
                tuple(
                    float(z[f"d{order}_scores"][1] - z[f"d{order}_scores"][0]) for order in (1, 2)
                )
            ]
            for which, vector in enumerate(weights):
                predicted.append(
                    tuple(
                        float(
                            np.sum(
                                (
                                    z[f"d{order}_states"][:, -1]
                                    if which == 0
                                    else z[f"d{order}_states"]
                                ).astype(np.float64)
                                * vector
                            )
                        )
                        for order in (1, 2)
                    )
                )
            errors = [
                abs(p - r)
                for pair, reference in zip(predicted, refs)
                for p, r in zip(pair, reference)
            ]
            passed = all(
                abs(p - r) <= 0.001 + 0.0001 * abs(r)
                for pair, reference in zip(predicted, refs)
                for p, r in zip(pair, reference)
            )
            checks.append(
                {
                    **g,
                    "kind": "reverse_derivative_contractions",
                    "reference": refs,
                    "forward_ad_contractions": predicted,
                    "maximum_absolute_error": max(errors),
                    "passed": passed,
                }
            )
            print(
                f"192 independent reverse AD {schema} {a}/{t}: {len(checks)}/24 invocations",
                flush=True,
            )
            del result, stacked, states, scalars, lam, x0, direction
            gc.collect()
    assert len(checks) == 24
    result = {
        "fingerprint": b["fingerprint"],
        "source_sha256": audit.native.hashed(Path(__file__)),
        "audit_sha256": audit.native.hashed(Path(audit.__file__)),
        "public_helper_sha256": audit.native.hashed(Path(public.__file__)),
        "ordinary_model_invocations": 16,
        "reverse_differentiated_invocations": 8,
        "passed": all(c["passed"] for c in checks),
        "all_native_scores_exact": all(
            c["exact_scores"] for c in checks if c["kind"].startswith("native")
        ),
        "all_native_states_exact": all(
            c["exact_states"] for c in checks if c["kind"].startswith("native")
        ),
        "maximum_derivative_contraction_error": max(
            c.get("maximum_absolute_error", 0) for c in checks
        ),
        "checks": checks,
        "scope": "Separate reverse-over-reverse false-only AD and fresh public native scores/full28states; no192 forward-AD helper or runner import. Two full-trajectory linear projections and margin derivatives, not every derivative coordinate.",
    }
    write_json(OUT, result)
    print(json.dumps({k: v for k, v in result.items() if k != "checks"}, indent=2))
    del model, tok
    gc.collect()
    torch.mps.empty_cache()


if __name__ == "__main__":
    main()
