"""All failed heldout repair accounts, retaining the successful diagnostic's scope."""

import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
ARMS = (
    "source_linear",
    "exact_readout",
    "residual_blocks",
    "margin_blocks",
    "union_blocks",
    "control_blocks",
)


def main():
    audit = json.loads((ROOT / "docs/analysis/201-independent-audit.json").read_text())
    numerical = json.loads((ROOT / "docs/analysis/201-numerical-recheck.json").read_text())
    assert (
        audit["numerical_qualified"]
        and all(audit["controls"].values())
        and numerical["passed"]
        and audit["fingerprint"] == numerical["fingerprint"]
    )
    summaries = {}
    for arm in ARMS:
        rows = [c for c in audit["cells"] if c["arm"] == arm]
        summaries[arm] = {
            key: {
                "min": float(np.min(values)),
                "median": float(np.median(values)),
                "max": float(np.max(values)),
            }
            for key, values in (
                ("final_relative_error", [c["final"]["relative_error"] for c in rows]),
                ("absolute_margin_error", [abs(c["margin_error"]) for c in rows]),
            )
        }
    summary = {
        "fingerprint": audit["fingerprint"],
        "numerical_qualified": True,
        "selection": audit["selection"],
        "all_arms": summaries,
        "accounts": audit["accounts"],
        "scope": "64newdependentpairs; allFalseforecastsgloballysealedbeforeTrue. DiscoveryTrueonlychoosesblockIDs, not repairvectors. Allsixprimary andjointprogressaccounts fail. Original196primitive disagreement unresolved; alternateforwardstructure+standardreversechecks do notreconcileit.",
    }
    (ROOT / "docs/analysis/201-ranked-repair-summary.json").write_text(
        json.dumps(summary, indent=2) + "\n"
    )
    fig, axes = plt.subplots(1, 2, figsize=(12, 6))
    labels = [
        "Source finite; rest linear",
        "Finite readout",
        "Residual ranks:18,21",
        "Margin ranks:16,18",
        "Union:16,18,21",
        "Matched controls:3,7,27",
    ]
    for ax, key, title, unit, bound in (
        (
            axes[0],
            "final_relative_error",
            "Final verdict-row displacement",
            "Median relative L2 error (ratio)",
            0.05,
        ),
        (
            axes[1],
            "absolute_margin_error",
            "Native Boolean-response preference",
            "Median absolute margin error (nats)",
            0.1,
        ),
    ):
        ax.barh(range(6), [summaries[a][key]["median"] for a in ARMS], color="#3c5366")
        ax.set_yticks(range(6), labels)
        ax.invert_yaxis()
        ax.set_title(title)
        ax.set_xlabel(unit)
        ax.set_ylabel("False-only repair arm")
        ax.axvline(bound, color="black", linestyle=":", label="Registered individual bound")
        ax.legend(fontsize=8, loc="lower right")
        ax.grid(axis="x", alpha=0.15)
        ax.set_axisbelow(True)
    fig.suptitle("Discovery-ranked finite blocks did not recover the native response", fontsize=15)
    fig.text(
        0.5,
        0.015,
        "Source:201 ·64new dependent pairs ·14Oct2026UTC /15OctIST · forecasts sealed before nativeTrue observations.\nAllsix arms:0/16 individual-margin panels,0/16 final-residual panels,0/16 joint-progress panels. Whole success requires everycell and≥3/4sources in each schema/order.",
        ha="center",
        fontsize=9,
    )
    fig.tight_layout(rect=(0, 0.1, 1, 0.93), w_pad=3.5)
    figure = ROOT / "docs/figures/201-ranked-repair.png"
    fig.savefig(figure, dpi=180)
    fig.savefig(figure.with_suffix(".svg"))
    plt.close(fig)
    paragraphs = [
        "# A remainder ranking did not produce an accurate heldout repair",
        "The code's independent numerical checks passed, while allscientific native matching and joint-progress accounts failed. This distinction is essential: a trustworthy computation can test an unsuccessful explanation.",
        "On199's old paired193discovery data, residual-error projection ranked blocks18/21highest; marginerror ranked16/18highest. The registered union16/18/21and equally sized low-ranked controls3/7/27were fixed before any new nativeTrue trajectory. On64newpairs across cobalt/indium,pebble/stone,fresco/stencil,reef/shoal, the forecast always computed the first block finitely using the known embedding edit; only selected laterblocks retained finite known functions. Allotherblock transitions used nativeFalse Jacobians. Final readout was finite except in the source_linear baseline. Up to4wholeblocks, including the first, were finite; this is a known-weight surrogate with substantial local computation, not a small learned circuit or simulation-free prediction.",
        "Allsix arms scored0/16panels for individual native margin error≤0.10nats,0/16for final residual relativeL2≤0.05/cosine≥0.99, and0/16for the registered joint-progress criterion of halving both final residual and absolute margin error. Everypanel contains fourdependent cells; whole pass requires≥3/4blocks in every schema/order. The source matching control passed16/16for everyarm.",
    ]
    for arm in ARMS:
        values = summaries[arm]
        paragraphs.append(
            f"**{arm}**: median final relativeerror {values['final_relative_error']['median']:.6g}; median absolute marginerror {values['absolute_margin_error']['median']:.6g}nats. Allprimary native andjointprogress wholeaccounts FAIL."
        )
    paragraphs += [
        "![Every prospective repair retained](../figures/201-ranked-repair.png)",
        "The union lowered median residualerror from1.08595to1.02955, but this small change did not meet the declared progress criterion or recover individual behavior. Matchedcontrols worsened residualerror to1.14643 while their median absolute marginerror was11.805nats, compared with12.0377for the union. We cannot infer a useful sparse mechanism from this ranking.",
        "A plausible unresolved explanation is input-state dependence:199's local remainders were evaluated at the actual native counterfactual inputs, whereas201's finite block repairs receive predicted inputs that may already be wrong. The test does not establish this explanation or identify an operation causing the discrepancy. Another boundary is that fixing the first block does not fix subsequent nonlinear encoding at the Boolean source. Source encoding across depth, source-to-receiver attention and receiving-position nonlinear computation still need separation; no claim that the source has been ruled out entirely.",
        f"Numerical evidence:16freshpublicnative replays and48independent whole-model hook forecasts matched savedstate rows exactly; maximum score discrepancy {numerical['maximum_hook_score_error']:.6g}. Eightstandardreverse baseline checks passed, maximum contraction discrepancy {numerical['maximum_reverse_contraction_error']:.6g}. Hookconstruction shares the forwardADbackend with forecasting but differs structurally; standardreverse checks cover the source_linear arm. The original196primitive reverse-over-reverse coordinate discrepancy remains unresolved and is not retroactively certified by these checks.",
        "200's initialpreflight had a fixture-wiring error before any model evaluation; the initial201import preflight failed before model loading. Originalfailedsources/logs remain preserved.201provides byte-identical numerical helper aliases and the correct paired-prefix fixture import. The corrected checkpoint preflight passed all12arm/schema comparisons before the study. No bound or method changed in either correction.",
        "Evidence: [artifact audit](201-independent-audit.json), [numerical verification](201-numerical-recheck.json), [all-arm summary](201-ranked-repair-summary.json), [fixed selection/method registration](../experiments/200-discovery-ranked-finite-block-repair.md), [wiring correction protocol](../experiments/201-discovery-ranked-finite-block-repair.md), [paired diagnostic](199-layerwise-nonlinear-remainder-result.md). One small checkpoint, dependent synthetic templates, no independent team and earlier failed grounding controls constrain allclaims. No commit,push orLessWrong publication has been made.",
    ]
    (ROOT / "docs/analysis/201-discovery-ranked-repair-result.md").write_text(
        "\n\n".join(paragraphs) + "\n"
    )
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
