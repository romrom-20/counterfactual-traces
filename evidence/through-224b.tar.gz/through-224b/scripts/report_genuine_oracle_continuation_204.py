"""Frozen numerical summarization of qualified-reset204 and corrected201 metrics."""

import argparse
import json
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--scope", choices=["sample", "full"], required=True)
    args = parser.parse_args()
    audit = json.loads(
        (ROOT / f"docs/analysis/204-{args.scope}-oracle-vector-audit.json").read_text()
    )
    assert audit["reset_qualified"]
    out = ROOT / f"docs/analysis/204-{args.scope}-oracle-summary.json"
    assert not out.exists()
    source201 = json.loads((ROOT / "docs/analysis/202-replacement-metric-audit.json").read_text())
    layers201 = []
    for arm in ("source_linear", "union_blocks"):
        rows = [r for r in source201["rows"] if r["arm"] == arm]
        layers201.append(
            dict(
                arm=arm,
                source_median_q=[
                    float(np.median([r["source_layers"][i]["relative_error"] for r in rows]))
                    for i in range(28)
                ],
                verdict_median_q=[
                    float(np.median([r["verdict_layers"][i]["relative_error"] for r in rows]))
                    for i in range(28)
                ],
            )
        )
    run = ROOT / f"runs/genuine-oracle-continuation-204-{args.scope}"
    cases = []
    for p in sorted((run / "pairs").glob("*.json")):
        r = json.loads(p.read_text())
        with np.load(p.with_suffix(".npz"), allow_pickle=False) as z:
            actual = z["native_delta_suffix"].astype(np.float64)
            for arm in ("source_linear", "union_blocks"):
                for k in (None, 1, 3, 8, 11, 16, 21, 27):
                    label, b = ("ordinary", 0) if k is None else (f"before{k}", k - 1)
                    pred = z[f"{label}_{arm}_delta_suffix"].astype(np.float64)
                    offset = 1 if b == 0 else 0
                    a = actual[b + offset :]
                    pred = pred[offset:]
                    q_verdict = np.linalg.norm(a[:, -1] - pred[:, -1], axis=1) / np.linalg.norm(
                        a[:, -1], axis=1
                    )
                    q_source = np.linalg.norm(a[:, 0] - pred[:, 0], axis=1) / np.linalg.norm(
                        a[:, 0], axis=1
                    )
                    cases.append(
                        dict(
                            key=r["key"],
                            **r["group"],
                            arm=arm,
                            next_block=k,
                            input_completed_blocks=b,
                            curve_start_completed_blocks=b + offset,
                            source_relative_errors=q_source.tolist(),
                            verdict_relative_errors=q_verdict.tolist(),
                        )
                    )
    trajectories = []
    for arm in ("source_linear", "union_blocks"):
        for k in (None, 1, 3, 8, 11, 16, 21, 27):
            rows = [r for r in cases if r["arm"] == arm and r["next_block"] == k]
            for label in ("source", "verdict"):
                field = f"{label}_relative_errors"
                trajectories.append(
                    dict(
                        arm=arm,
                        next_block=k,
                        position=label,
                        completed_blocks=list(range(rows[0]["curve_start_completed_blocks"], 29)),
                        median_q=np.median(np.array([r[field] for r in rows]), axis=0).tolist(),
                    )
                )
    result = dict(
        scope=args.scope,
        reset_qualified=True,
        direct_identity_qualified=audit["direct_identity_qualified"],
        direct_identity_failures=audit["direct_identity_failures"],
        direct_identity_checks=audit["direct_identity_checks"],
        controls=audit["controls_summary"],
        maximum_errors=audit["maximum_errors"],
        reset_summary=audit["summary"],
        original201=source201["summary"],
        original201_layerwise=layers201,
        trajectories=trajectories,
        cases=cases,
        outcomes=audit["outcomes"],
        counts=audit["counts"],
    )
    out.write_text(json.dumps(result, indent=2))
    lines = [
        f"# Genuine oracle resets: {args.scope} scope",
        "",
        "Retrospective model continuations executed; this is not a prospective forecast. Reset k means BEFORE public block k, with k−1 completed blocks. Full-sequence states, causal mask/RoPE and original201 arms are retained.",
        "",
        f"All mandatory reset replay/boundary/exact-native controls passed. Direct J(error) coordinate identity failed {audit['direct_identity_failures']}/{audit['direct_identity_checks']} checks at the unchanged1e-4 bound. Stage1 is NOT fully numerically qualified. Two-evaluated-JVP algebraic closure is separately checked and is not independent derivative validation. Original196 derivative disagreement remains open.",
        "",
    ]
    for row in audit["summary"]:
        lines.append(
            f"- {row['arm']}, before block {row['next_block']}: median final verdict residual relative error {row['median_relative_error']:.6g}, cosine {row['median_cosine']:.6g}, absolute margin error {row['median_absolute_margin_error']:.6g}nats; residual improves {row['residual_improved_count']}/{row['count']}, margin improves {row['margin_improved_count']}/{row['count']} versus the SAME unreset arm."
        )
    lines += [
        "",
        "These interventions remove prior full-state error once; any later discrepancy is measured by actual hybrid computation. They do not identify a primitive operation, show a dominant learned mechanism, or provide a false-only heldout success. Medians over dependent templates are descriptive; stratified and individual results remain in the JSON. Numerical additivity failures prevent claiming a fully validated direct vector transport decomposition.",
        "",
        "Evidence: [vector audit](204-"
        + args.scope
        + "-oracle-vector-audit.json), [summary and trajectories](204-"
        + args.scope
        + "-oracle-summary.json), [replacement audit](202-replacement-implementation-audit.md), [fixed reset protocol](../experiments/203-genuine-oracle-continuation.md), [explicit additivity separation](../experiments/204-separated-reset-and-additivity-checks.md). No browsing, training, commits, pushes or publication.",
    ]
    (ROOT / f"docs/analysis/204-{args.scope}-genuine-oracle-result.md").write_text(
        "\n".join(lines) + "\n"
    )
    print(
        json.dumps(
            {
                "scope": args.scope,
                "summary": str(out),
                "cases": len(cases),
                "trajectories": len(trajectories),
                "reset_qualified": True,
                "direct_identity_qualified": audit["direct_identity_qualified"],
            }
        )
    )


if __name__ == "__main__":
    main()
