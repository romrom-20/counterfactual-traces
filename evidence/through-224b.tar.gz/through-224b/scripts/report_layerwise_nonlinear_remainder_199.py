"""Qualified discovery diagnostics: local size, directional gain, and projection contribution."""

import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).resolve().parents[1]


def main():
    audit = json.loads((ROOT / "docs/analysis/199-independent-audit.json").read_text())
    assert audit["numerical_qualified"] and all(audit["controls"].values())
    records = audit["records"]
    summary = []
    for block in range(2, 29):
        rows = [r["rows"][block - 2] for r in records]
        summary.append(
            {
                "block": block,
                "median_local_remainder_full_norm": float(
                    np.median([r["remainder_full_norm"] for r in rows])
                ),
                "median_margin_projected_gain": float(
                    np.median([r["margin_projected_gain"] for r in rows])
                ),
                "median_residual_projected_gain": float(
                    np.median([r["error_direction_projected_gain"] for r in rows])
                ),
                "mean_abs_normalized_residual_contribution": float(
                    np.mean(
                        [
                            abs(row["error_direction_contribution"])
                            / rec["budget"]["observed_final_error_norm"]
                            for row, rec in zip(rows, records)
                        ]
                    )
                ),
                "mean_abs_normalized_margin_contribution": float(
                    np.mean(
                        [
                            abs(row["margin_contribution"])
                            / max(abs(rec["budget"]["actual_margin_error"]), 0.1)
                            for row, rec in zip(rows, records)
                        ]
                    )
                ),
            }
        )
    result = {
        "fingerprint": audit["fingerprint"],
        "diagnostic_only": True,
        "all_blocks": summary,
        "maximum_margin_budget_error": max(
            abs(r["budget"]["reconstructed_margin_error"] - r["budget"]["actual_margin_error"])
            for r in records
        ),
        "maximum_residual_projection_budget_error": max(
            abs(
                r["budget"]["reconstructed_final_error_projection"]
                - r["budget"]["observed_final_error_norm"]
            )
            for r in records
        ),
        "maximum_duality_error": max(
            d["absolute_error"] for r in records for row in r["rows"] for d in row["duality"]
        ),
        "median_readout_remainder_nats": float(
            np.median([r["budget"]["readout_remainder"] for r in records])
        ),
        "scope": "Fullstatepairedremainder diagnosis; error-directionprojection oracle; normalized absolute contribution rankings notcausal fractions, projectedgainnotfulloperatornorm. Old193dependentcases; noheldoutprediction success.",
    }
    (ROOT / "docs/analysis/199-layerwise-remainder-summary.json").write_text(
        json.dumps(result, indent=2) + "\n"
    )
    fig, axes = plt.subplots(2, 2, figsize=(13, 8))
    x = [r["block"] for r in summary]
    for ax, key, title, label in (
        (
            axes[0, 0],
            "median_local_remainder_full_norm",
            "Local nonlinear remainder size",
            "Median full-sequence L2 norm (hidden units)",
        ),
        (
            axes[0, 1],
            "median_residual_projected_gain",
            "False-state downstream directional gain",
            "Median |error projection| / local norm (ratio)",
        ),
        (
            axes[1, 0],
            "mean_abs_normalized_residual_contribution",
            "Contribution to final residual-error projection",
            "Mean absolute contribution / final error norm",
        ),
        (
            axes[1, 1],
            "mean_abs_normalized_margin_contribution",
            "Contribution to later verdict margin error",
            "Mean absolute contribution / max(|margin error|, 0.1 nats)",
        ),
    ):
        ax.bar(x, [r[key] for r in summary], color="#3c5366")
        ax.set_xlabel("Transformer block (one-indexed)")
        ax.set_ylabel(label)
        ax.set_title(title)
        ax.set_xticks(list(range(2, 29, 2)))
        ax.grid(axis="y", alpha=0.15)
        ax.set_axisbelow(True)
    fig.suptitle("Where does false-state linear transport miss a native Boolean edit?", fontsize=15)
    fig.text(
        0.5,
        0.015,
        "Source:199paired diagnosis on193's64dependent cases ·14Oct2026UTC · exact initial displacement is ORACLE here.\nContributions can cancel; bars are ranking statistics, not causal fractions. Directional gain is not the full operator norm. Final readout remainder is separate.",
        ha="center",
        fontsize=9,
    )
    fig.tight_layout(rect=(0, 0.095, 1, 0.95))
    path = ROOT / "docs/figures/199-local-remainder-amplification.png"
    fig.savefig(path, dpi=175)
    fig.savefig(path.with_suffix(".svg"))
    plt.close(fig)
    residual = sorted(
        summary, key=lambda r: (-r["mean_abs_normalized_residual_contribution"], r["block"])
    )
    margin = sorted(
        summary, key=lambda r: (-r["mean_abs_normalized_margin_contribution"], r["block"])
    )
    paragraphs = [
        "# Nonlinear injection versus false-state amplification",
        "Discovery-only diagnosis on the64old qualified193pairs. NativeTrue trajectories supply local remainders and an oracle first-block start; the error-direction projection also uses observed error. This is not a new prospective forecast or identification of a learned semantic feature.",
        "State means the full sequence matrix. With e=actual displacement−predicted displacement and an exact starting displacement, e_(l+1)=J_l e_l+R_l. Standard first-order reverse adjoints transport each local remainder to two scalar objectives. Final margin error additionally includes the nonlinear final readout remainder. Projection onto the actual final error direction reconstructs the final verdict-row error norm; this is one projection, not every transported vector.",
        f"All64margin budgets and64residual projection budgets passed the fixed.001+.0001abs(observed error) bound; all3456local forward/reverse contractions passed. Maximum margin budget discrepancy {result['maximum_margin_budget_error']:.6g}nats; residual projection budget discrepancy {result['maximum_residual_projection_budget_error']:.6g}hiddenunits. Original196primitive reverse-over-reverse disagreement remains unresolved; no second full-network derivatives are used.",
        f"Residual-error ranking top2blocks: {[r['block'] for r in residual[:2]]}. Margin-error ranking top2blocks: {[r['block'] for r in margin[:2]]}. These are mean absolute projected contributions normalized by error size, with cancellation possible; they are not additive causal percentages. Median final readout remainder {result['median_readout_remainder_nats']:.6g}nats. The two objectives do not pick exactly the same blocks.",
        "![Local remainders and projected transport](../figures/199-local-remainder-amplification.png)",
        "The rankings can select a testable repair, but only a repair computed from false-state information on new contexts can establish prospective progress. The next registered budget retains finite known functions at discovery-ranked blocks16/18/21 and the first block, with other block transitions linearized atFalse; equally sized low-ranked controls are3/7/27. DiscoveryTrue remainders are never inserted into heldout predictions. A successful macro-block repair would still leave the operation inside those blocks unidentified.",
        "Evidence: [full audit](199-independent-audit.json), [summary](199-layerwise-remainder-summary.json), [protocol](../experiments/199-layerwise-nonlinear-remainder.md), [prospective repair registration](../experiments/201-discovery-ranked-finite-block-repair.md). 64ordinaryFalse fullcalls,64False forwardAD fullcalls,64False reverse fullcalls,1728local blockJVPs; no nativeTrue fullcalls, training, or generation in this diagnostic.",
    ]
    (ROOT / "docs/analysis/199-layerwise-nonlinear-remainder-result.md").write_text(
        "\n\n".join(paragraphs) + "\n"
    )
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
