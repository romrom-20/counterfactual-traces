"""Frozen layerwise summaries of actual native, forecast and evaluated remainder vectors."""

import argparse
import json
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--scope", choices=["sample", "full"], required=True)
    scope = parser.parse_args().scope
    out = ROOT / f"docs/analysis/207-{scope}-layerwise-norms.json"
    assert not out.exists()
    audit = json.loads((ROOT / f"docs/analysis/204-{scope}-oracle-vector-audit.json").read_text())
    source = json.loads((ROOT / "docs/analysis/202-replacement-metric-audit.json").read_text())
    assert audit["reset_qualified"]
    keys = {r["key"] for r in audit["outcomes"]}
    norms = []
    for arm in ["source_linear", "union_blocks"]:
        for position, field in [("source", "source_layers"), ("verdict", "verdict_layers")]:
            cases = [r for r in source["rows"] if r["arm"] == arm and r["key"] in keys]
            for block in range(1, 29):
                budgets = [
                    r
                    for r in audit["layerwise"]
                    if r["arm"] == arm
                    and r["continuation"] == "ordinary"
                    and r["next_block"] == block
                ]
                assert len(cases) == len(budgets) == len(keys)
                metrics = [r[field][block - 1] for r in cases]
                norms.append(
                    dict(
                        arm=arm,
                        position=position,
                        completed_blocks=block,
                        count=len(keys),
                        median_native_norm=float(np.median([r["native_norm"] for r in metrics])),
                        median_prediction_norm=float(
                            np.median([r["prediction_norm"] for r in metrics])
                        ),
                        median_error_norm=float(np.median([r["absolute_error"] for r in metrics])),
                        median_native_remainder_norm=float(
                            np.median([r[position]["native_remainder_norm"] for r in budgets])
                        ),
                        median_direct_transported_error_norm=float(
                            np.median([r[position]["transported_error_norm"] for r in budgets])
                        ),
                        median_represented_transported_error_norm=float(
                            np.median(
                                [
                                    r["represented_transport"][position]["transported_error_norm"]
                                    for r in budgets
                                ]
                            )
                        ),
                    )
                )
    out.write_text(
        json.dumps(
            dict(
                scope=scope,
                rows=norms,
                direct_identity_qualified=audit["direct_identity_qualified"],
                limits="Descriptive norms, not additive error fractions. Local native remainders are retrospective model-JVP quantities; direct additivity failed at recorded transitions. Represented transport is two-JVP algebraic accounting, not independent derivative validation.",
            ),
            indent=2,
        )
    )
    print(out)


if __name__ == "__main__":
    main()
