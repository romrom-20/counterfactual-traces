"""Every conditional path, frozen-account failure and saved-state cancellation."""

import json
from pathlib import Path

import matplotlib
import numpy as np

matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
ANALYSIS = ROOT / "docs/analysis"


def main():
    for experiment in (189, 190):
        p = ANALYSIS / f"{experiment}-independent-audit.json"
        if not p.exists():
            continue
        a = json.loads(p.read_text())
        n = json.loads((ANALYSIS / f"{experiment}-numerical-recheck.json").read_text())
        assert a["numerical_qualified"] and all(a["controls"].values()) and n["passed"]
        cuts = (
            ("live", "N", "W", "U", "NW", "NU", "WU", "NWU")
            if experiment == 189
            else ("live", "U", "FU", "IU", "NU")
        )
        fig, axis = plt.subplots(figsize=(12, 5.9))
        for i, cut in enumerate(cuts):
            for schema, color, marker in (
                ("generic", "#777777", "o"),
                ("descriptive", "#1764a4", "s"),
            ):
                vals = [c["kappa"][cut] for c in a["cells"] if c["schema"] == schema]
                axis.scatter(
                    [i + (j - 15.5) * 0.007 for j in range(len(vals))],
                    vals,
                    color=color,
                    marker=marker,
                    s=18,
                    alpha=0.8,
                    label=schema.capitalize() if i == 0 else None,
                )
        axis.axhline(0, color="#555555", linestyle=":")
        axis.set_xticks(range(len(cuts)), cuts)
        axis.set_xlabel("Receiving factors held to identical paired means; live = none")
        axis.set_ylabel("Shared-C change to Boolean response, kappa (nats)")
        axis.set_title(f"{experiment}: shared correction under operation cuts", loc="left")
        axis.legend(frameon=False)
        axis.spines[["top", "right"]].set_visible(False)
        axis.grid(axis="y", alpha=0.12)
        fig.subplots_adjust(bottom=0.25)
        text = (
            "N=all 57 RMS factors; W=all 28 attention matrices; U=all 28 up outputs. live/NW/NWU are immutable 188 references."
            if experiment == 189
            else "U=up fixed; F=final RMS fixed; I=56 internal RMS factors fixed; N=all 57 RMS factors fixed. Attention is live."
        )
        fig.text(
            0.5,
            0.01,
            f"Source: qualified {experiment} artifacts/numerical replay, 14 October 2026 UTC. All 64 paired contexts per cut.\n{text}\nDense paired maps/means change the baseline. Accounts include all four cells per panel and every schema/order stratum.",
            ha="center",
            fontsize=8,
        )
        for suffix in ("png", "svg"):
            fig.savefig(
                ANALYSIS / f"figures/{experiment}-norm-feedback-cuts.{suffix}",
                dpi=170,
                bbox_inches="tight",
            )
        plt.close(fig)
        stats = {
            schema: {
                cut: {
                    "minimum": min(c["kappa"][cut] for c in a["cells"] if c["schema"] == schema),
                    "maximum": max(c["kappa"][cut] for c in a["cells"] if c["schema"] == schema),
                    "mean": float(
                        np.mean([c["kappa"][cut] for c in a["cells"] if c["schema"] == schema])
                    ),
                }
                for cut in cuts
            }
            for schema in ("generic", "descriptive")
        }
        lines = [
            f"# {experiment}: shared-curvature effects under matched receiver cuts",
            "",
            f"Completed{a['main_forwards']} main+{n['forwards']} separate numerical full-model forwards. All{len(a['controls'])} artifact controls pass. Selected public score/full-state exactness: {n['all_scores_exact']}/{n['all_states_exact']}; maximum capture error{n['maximum_capture_error']:.3g}.",
            "",
            "Kappa is the sharedC change in the false-to-true verdict-margin response, comparing P+C to P UNDER THE SAMECUT. All maps use paired native trajectories; no false-only predictor, semantic feature, unique learned circuit, competence recovery or priority claim.",
            "",
        ]
        for name, v in a["accounts"].items():
            count = v.get("compatible_panels", v.get("compatible_comparisons"))
            den = 8 if "compatible_comparisons" in v else 16
            lines.append(
                f"- **{name}**: {count}/{den}; whole {'PASS' if v['whole_passed'] else 'FAIL'}; strata {v['strata']}."
            )
        lines.extend(
            [
                "",
                "The whole rule is at least3of4 sources in EVERYschema/order (or EVERYorder for paired-schema comparisons). Ineligible or favorable subgroups cannot rescue a failed account. All prior188 failures remain failures.",
                "",
            ]
        )
        if experiment == 189:
            lines.extend(
                [
                    "New cuts U,N,W,NU,WU were executed;768parent patch rows from188 are referenced by validated immutable hashes, not counted as new executions or independent replications. Reused186–188cohort. Operation interaction kappa_U-kappa_NU-kappa_WU+kappa_NWU is saved for every case; it is not an additive attribution to native pathways.",
                    "",
                ]
            )
        else:
            lines.extend(
                [
                    "Four new day blocks were held out of hypothesis specification, with fresh per-context paired calibration. All256 comparisons of final-only cuts leave the FULLblock28 residual EXACT (FU=U, NU=IU). Any score change in those matched pairs occurs after that residual, in the final scale/readout. Both native bit states calibrate the intervention, so this is new-context mechanism confirmation, not forecasting.",
                    "",
                ]
            )
        gp = ANALYSIS / f"{experiment}-norm-readout-cancellation.json"
        if gp.exists():
            geo = json.loads(gp.read_text())
            assert geo["fingerprint"] == a["fingerprint"]
            lines.append(
                f"Saved-state CPUfloat64 geometry uses pinned output/norm rows, zero full-model forwards. Maximum public-score reconstruction error{geo['maximum_public_score_reconstruction_error']:.6g}; finite product identity error{geo['maximum_finite_product_identity_error']:.6g}; actual190 final-only counterfactual error{geo['maximum190_fixed_final_counterfactual_error']:.6g}. These arithmetic identities cannot rescue a failed scientific explanation."
            )
            for schema in ("generic", "descriptive"):
                cs = [c for c in geo["cells"] if c["schema"] == schema]
                pk = [c["decomposition"]["U"]["projection_kappa"] for c in cs]
                sk = [c["decomposition"]["U"]["scale_kappa"] for c in cs]
                lines.append(
                    f"{schema}: mean U projection term{float(np.mean(pk)):.6f}nats, mean scale term{float(np.mean(sk)):.6f}; terms oppose in{sum(x * y < 0 for x, y in zip(pk, sk))}/{len(cs)}cases. Every individual term is in the saved JSON; averages are descriptive, not a success rule."
                )
        lines.extend(
            [
                "",
                f"![All paired context effects](figures/{experiment}-norm-feedback-cuts.png)",
                "",
                "One checkpoint, dependent day templates, dense paired maps and altered receiver baselines limit interpretation. Random/shuffled correction specificity and reliable incomplete-state forecasting remain open.",
            ]
        )
        (ANALYSIS / f"{experiment}-norm-feedback-result.md").write_text("\n".join(lines) + "\n")
        (ANALYSIS / f"{experiment}-norm-feedback-summary.json").write_text(
            json.dumps(
                {
                    "posthoc": True,
                    "target_model_forwards": 0,
                    "fingerprint": a["fingerprint"],
                    "schema_cut_ranges": stats,
                },
                indent=2,
            )
            + "\n"
        )


if __name__ == "__main__":
    main()
