"""Qualified source/transport atlas and prospective polynomial results; no model calls."""

import json
from pathlib import Path

import matplotlib
import numpy as np

matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "docs/analysis"


def qualified(i):
    a = json.loads((OUT / f"{i}-independent-audit.json").read_text())
    n = json.loads((OUT / f"{i}-numerical-recheck.json").read_text())
    assert a["numerical_qualified"] and all(a["controls"].values()) and n["passed"]
    assert a["fingerprint"] == n["fingerprint"]
    return a, n


def main():
    a, n = qualified(190)
    atlas = json.loads((OUT / "190-residual-source-atlas.json").read_text())
    assert atlas["fingerprint"] == a["fingerprint"] and len(atlas["rows"]) == 3584
    layer_stats = []
    for schema in ("generic", "descriptive"):
        for cut in ("U", "IU"):
            for layer in range(1, 29):
                rows = [
                    r
                    for r in atlas["rows"]
                    if (r["schema"], r["cut"], r["layer"]) == (schema, cut, layer)
                ]
                values = [r["last_token_bit_differential_shift_norm"] for r in rows]
                cos = [
                    r["last_token_differential_displacement_cosine_internal_norm_free_vs_fixed"]
                    for r in rows
                    if cut == "U"
                    and r["last_token_differential_displacement_cosine_internal_norm_free_vs_fixed"]
                    is not None
                ]
                layer_stats.append(
                    {
                        "schema": schema,
                        "cut": cut,
                        "layer": layer,
                        "contexts": len(rows),
                        "last_token_differential_norm_min": min(values),
                        "last_token_differential_norm_median": float(np.median(values)),
                        "last_token_differential_norm_max": max(values),
                        "last_token_U_IU_differential_cosine_min": min(cos) if cos else None,
                        "last_token_U_IU_differential_cosine_median": float(np.median(cos))
                        if cos
                        else None,
                        "last_token_U_IU_differential_cosine_max": max(cos) if cos else None,
                    }
                )
    fig, axes = plt.subplots(1, 2, figsize=(12, 5))
    for schema, color in (("generic", "#777777"), ("descriptive", "#1764a4")):
        for cut, ls in (("U", "-"), ("IU", "--")):
            rows = [r for r in layer_stats if (r["schema"], r["cut"]) == (schema, cut)]
            axes[0].plot(
                [r["layer"] for r in rows],
                [r["last_token_differential_norm_median"] for r in rows],
                color=color,
                linestyle=ls,
                label=f"{schema.capitalize()}, {cut}",
            )
        rows = [
            r for r in layer_stats if (r["schema"], r["cut"]) == (schema, "U") and r["layer"] > 1
        ]
        axes[1].plot(
            [r["layer"] for r in rows],
            [r["last_token_U_IU_differential_cosine_median"] for r in rows],
            color=color,
            label=schema.capitalize(),
        )
    axes[0].set_yscale("log")
    axes[0].set_ylabel("Median bit-differential displacement norm (residual units)")
    axes[0].set_title("Same local correction, different Boolean responses", loc="left", fontsize=11)
    axes[1].set_ylabel("Median U versus IU displacement cosine (unitless)")
    axes[1].set_ylim(-1.05, 1.05)
    axes[1].set_title("Internal normalization changes the displacement", loc="left", fontsize=11)
    for ax in axes:
        ax.set_xlabel("Receiving block (1–28)")
        ax.spines[["top", "right"]].set_visible(False)
        ax.grid(alpha=0.15)
        ax.legend(frameon=False, fontsize=8)
    fig.tight_layout(rect=(0, 0.14, 1, 1))
    fig.text(
        0.5,
        0.015,
        "Source: qualified 190 saved trajectories, 14 October 2026 UTC; 32 contexts/schema, final verdict position.\n"
        "Even-minus-paired residual shifts; true shift minus false shift. U=up fixed; IU=up + internal RMS fixed.\n"
        "Medians are descriptive. Layer-1 differences include floating-point noise; no independent transport prediction.",
        ha="center",
        fontsize=8,
    )
    for ext in ("png", "svg"):
        fig.savefig(
            OUT / f"figures/190-residual-generation-atlas.{ext}", dpi=170, bbox_inches="tight"
        )
    plt.close(fig)
    lines = [
        "# What generates the displacement, and what remains unexplained",
        "",
        "The diagnostic correction and its transmission are different explanatory targets. At a fixed gate input, adding C with the up branch fixed injects S_l = D_l(C_l * meanUP_l). This exact local write is common to both bits. C itself is the paired curvature remainder mean(phi(c-h),phi(c+h))-phi(c); it uses both native activation trajectories. It is not a separately discovered learned signal or a prospective source prediction.",
        "",
        "SiLU curvature supplies C in this diagnostic construction. The down-projection and multiplying up factor determine its local residual direction. Once earlier writes change later inputs, the additional MLP write includes both that fixed source and a propagated-input response. Attention, internal RMS scaling and the live gate input can transform it differently in the two bit states. Multiple source effects cannot be assumed additive under the live computation.",
        "",
        f"190 executed {a['main_forwards']} main and {n['forwards']} separate numerical full-model calls. All {len(a['controls'])} artifact controls pass; selected scores/full states replay exactly. In addition, there were 1,792 component down-projection evaluations and 224 separate component matrix reconstructions; these are not full-model calls. The atlas uses saved arrays and zero further model calls.",
        "",
        f"Across both internal-normalization conditions, the first block's measured residual write differs from the literal common source by at most {atlas['first_layer_source_vs_observed_max_error']:.9g} residual units per coordinate. Its false/true displacement difference is at most {atlas['first_layer_bit_differential_max_error']:.9g}. This is an implementation/geometry observation, not an identified semantic feature. The 3,584 atlas rows retain all 64 contexts, 28 blocks and both conditions, with both full-receiver and final-position measurements.",
        "",
    ]
    for name, account in a["accounts"].items():
        lines.append(
            f"- {name}: {account['compatible_panels']}/16 panels; whole {'PASS' if account['whole_passed'] else 'FAIL'}; every stratum {account['strata']}."
        )
    lines += [
        "",
        "Every panel includes all four relation cells. The whole criterion is at least 3/4 sources in EVERY schema/order. Arithmetic identities and favorable subgroups cannot rescue a failed account.",
        "",
        "Changing only the final RMS scale leaves the earlier residual exactly unchanged. Projection/scale cancellation is ordinary geometry of a single normalization operation, not evidence of two competing mechanisms. The internal-normalization cut changes the generated trajectory with the diagnostic sources held identical; that is stronger than a final-readout decomposition but remains a distributed intervention, not identification of one native circuit.",
        "",
        "![Measured residual propagation and normalization cut](figures/190-residual-generation-atlas.png)",
        "",
    ]
    interactions = []
    for c in a["cells"]:
        k = c["kappa"]
        interactions.append(
            {
                **{
                    name: c[name] for name in ("block", "schema", "reverse", "assignment", "target")
                },
                "internal_final_interaction": k["NU"] - k["IU"] - k["FU"] + k["U"],
            }
        )
    for schema in ("generic", "descriptive"):
        values = [r["internal_final_interaction"] for r in interactions if r["schema"] == schema]
        lines.append(
            f"The internal/final interaction kappa_NU-kappa_IU-kappa_FU+kappa_U spans {min(values):.6f}–{max(values):.6f} nats in {schema} cells. This is descriptive, not an additive native-pathway attribution."
        )
    lines += [
        "",
        "The final scale has little effect with internal normalization live (U versus FU), but a much larger effect after the internal cut (IU versus NU). The joint response needs both the changed upstream residual and its normalization at readout. Calling either cut alone the explanation misses that conditional relationship. In IU the receiving MLPs and internal RMS operations are affine; attention-weight computation remains nonlinear. A common source can still have different responses through the two state-dependent receivers.",
        "",
    ]
    for schema in ("generic", "descriptive"):
        row = next(
            r for r in layer_stats if (r["schema"], r["cut"], r["layer"]) == (schema, "U", 28)
        )
        lines.append(
            f"At the final position/block, {schema} U-versus-IU bit-differential displacement cosine spans {row['last_token_U_IU_differential_cosine_min']:.6f}–{row['last_token_U_IU_differential_cosine_max']:.6f}, median {row['last_token_U_IU_differential_cosine_median']:.6f}. These are posthoc geometric summaries, not frozen hypothesis tests."
        )
    forecast_summary = None
    if (OUT / "191-independent-audit.json").exists():
        b, bn = qualified(191)
        lines += [
            "",
            "## A source account calibrated from only one native state",
            "",
            f"191 executed {b['main_forwards']} main + {bn['forwards']} separate numerical calls. All {len(b['controls'])} controls pass. All 448 false measurements and mapped forecasts were saved/hashed before ANY native true measurement. Analytic T1/Q2/C3 coefficients use false-state SiLU inputs/outputs alone. The target input literal and all receiving gate inputs, up factors, attention and normalization remain live: this forecasts the result of the polynomial replacement, not the entire true trajectory from a static false vector.",
            "",
        ]
        errors = {}
        fig, axes = plt.subplots(1, 2, figsize=(11.5, 4.5))
        for arm in ("T1", "Q2", "C3"):
            vals = [c["errors"][arm] for c in b["cells"]]
            errors[arm] = {
                "maximum_true_endpoint_error": max(abs(v) for v in vals),
                "endpoint_squared_error": sum(v * v for v in vals),
            }
            index = ("T1", "Q2", "C3").index(arm)
            for schema, color in (("generic", "#777777"), ("descriptive", "#1764a4")):
                cs = [c for c in b["cells"] if c["schema"] == schema]
                ps = [p for p in b["panels"] if p["schema"] == schema]
                axes[0].scatter(
                    [index + (j - 15.5) * 0.005 for j in range(32)],
                    [abs(c["errors"][arm]) for c in cs],
                    color=color,
                    s=14,
                    label=schema.capitalize() if index == 0 else None,
                )
                axes[1].scatter(
                    [index + (j - 3.5) * 0.012 for j in range(8)],
                    [abs(p["balanced_true_errors"][arm]) for p in ps],
                    color=color,
                    s=18,
                    label=schema.capitalize() if index == 0 else None,
                )
            for metric in ("individual_matching", "balanced_matching"):
                account = b["accounts"][metric][arm]
                lines.append(
                    f"- {arm} {metric}: {account['compatible_panels']}/16; whole {'PASS' if account['whole_passed'] else 'FAIL'}; strata {account['strata']}."
                )
            lines.append(
                f"- {arm} descriptive maximum true-endpoint error: {errors[arm]['maximum_true_endpoint_error']:.6f} nats; squared error sum {errors[arm]['endpoint_squared_error']:.6f} nats squared."
            )
        lines += [
            "",
            "True-endpoint error equals bit-effect error because the false endpoint is exact; those are the same success/failure, not independent confirmations. Half-retention is descriptive and does not rescue precise matching. The complete audit includes all retention strata, endpoints and failures. Higher polynomial order has no guaranteed convergence over the finite shifts or recursively altered inputs.",
        ]
        forecast_summary = {
            "fingerprint": b["fingerprint"],
            "accounts": b["accounts"],
            "errors": errors,
        }
        for ax in axes:
            ax.set_xticks(range(3), ("T1", "Q2", "C3"))
            ax.set_xlabel("False-state SiLU polynomial order; receiver stays live")
            ax.axhline(0.1, color="#555555", linestyle=":")
            ax.spines[["top", "right"]].set_visible(False)
            ax.legend(frameon=False)
            ax.grid(axis="y", alpha=0.12)
        axes[0].set_ylabel("Individual true-preference absolute error (nats)")
        axes[1].set_ylabel("Balanced evidence-response absolute error (nats)")
        axes[0].set_title("Individual preferences still fail", loc="left", fontsize=11)
        axes[1].set_title("Cubic map matches every evidence panel", loc="left", fontsize=11)
        fig.tight_layout(rect=(0, 0.13, 1, 1))
        fig.text(
            0.5,
            0.01,
            "Source: qualified 191 prospective forecasts, 14 October 2026 UTC. All64 individual cells and16 evidence panels/order.\nDotted line = frozen0.10-nat tolerance. All448 forecasts/false calls precede ANY native true observation.\nFalse-calibrated pointwise coefficients; full receiving computation remains live. This is not the strict192 native forecast.",
            ha="center",
            fontsize=8,
        )
        for ext in ("png", "svg"):
            fig.savefig(
                OUT / f"figures/191-false-state-curvature-errors.{ext}",
                dpi=170,
                bbox_inches="tight",
            )
        plt.close(fig)
    lines += [
        "",
        "What remains unresolved: prediction of the particular finite residual displacement through a compact, causally validated state-dependent transport account; generation of a useful curvature/source account without paired native activation calibration; and why training gives the schemas these responses. A measured atlas is not a transport forecast. The paired diagnostic is not an endogenous feature. One small Qwen checkpoint, dependent synthetic day prompts, dense interventions, and earlier grounding/specificity failures remain. No novelty priority, deployment failure or complete mechanism claim follows. Attached literature claims were not independently verified; no browsing was used.",
    ]
    (OUT / "190-191-residual-generation-result.md").write_text("\n".join(lines) + "\n")
    (OUT / "190-191-residual-generation-summary.json").write_text(
        json.dumps(
            {
                "posthoc": True,
                "target_model_forwards": 0,
                "layer_stats": layer_stats,
                "internal_final_interactions": interactions,
                "forecast": forecast_summary,
            },
            indent=2,
        )
        + "\n"
    )
    print("Wrote source/transport report, 112 layer summaries and standalone figure.")


if __name__ == "__main__":
    main()
