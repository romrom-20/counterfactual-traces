"""Persist all registered primitive-repair results without selecting a winning mechanism."""

import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
ARMS = (
    "linear",
    "input_rms",
    "qk_product",
    "softmax",
    "weight_value",
    "post_rms",
    "silu",
    "gate_up",
    "exact_block",
    "exact_source",
)


def main():
    audit = json.loads((ROOT / "docs/analysis/198-revalidated-196-audit.json").read_text())
    numerical = json.loads((ROOT / "docs/analysis/198-dual-primitive-recheck.json").read_text())
    assert audit["fingerprint"] == numerical["fingerprint"]
    qualified = (
        audit["numerical_qualified"] and numerical["passed"] and all(audit["controls"].values())
    )
    summary = {}
    for arm in ARMS:
        rows = [c for c in audit["cells"] if c["arm"] == arm]
        assert len(rows) == 64
        summary[arm] = {
            kind: {
                "minimum": float(np.min(values)),
                "median": float(np.median(values)),
                "maximum": float(np.max(values)),
            }
            for kind, values in (
                ("source_relative_error", [c["source"]["relative_error"] for c in rows]),
                ("final_relative_error", [c["final"]["relative_error"] for c in rows]),
                ("absolute_margin_error", [abs(c["margin_error"]) for c in rows]),
            )
        }
    report = {
        "fingerprint": audit["fingerprint"],
        "qualified": bool(qualified),
        "all_arms": summary,
        "scope": "Descriptive min/median/max of64dependent pairs, not independent-sample uncertainty or a causal fraction. Exact controls are local finite simulation.195 remains failed. All registered196accounts are authoritative in198-revalidated-196-audit.json.",
    }
    path = ROOT / "docs/analysis/198-first-block-repair-summary.json"
    path.write_text(json.dumps(report, indent=2) + "\n")
    fig, axes = plt.subplots(1, 3, figsize=(16, 7))
    labels = [a.replace("_", " ") + (" [control]" if a.startswith("exact_") else "") for a in ARMS]
    for ax, key, title, unit in zip(
        axes,
        ("source_relative_error", "final_relative_error", "absolute_margin_error"),
        (
            "Boolean source after block one",
            "Verdict residual after block 28",
            "Later verdict preference error",
        ),
        (
            "Relative L2 displacement error (ratio)",
            "Relative L2 displacement error (ratio)",
            "Absolute bit-response margin error (nats)",
        ),
    ):
        xs = [summary[arm][key]["median"] for arm in ARMS]
        ax.barh(np.arange(10), xs, color=["#3c5366"] * 8 + ["#9d9d9d"] * 2)
        ax.set_yticks(np.arange(10), labels)
        ax.invert_yaxis()
        ax.set_xlabel(unit)
        ax.set_ylabel("First-block approximation or control")
        ax.set_title(title)
        ax.axvline(
            0.1 if key == "absolute_margin_error" else 0.05,
            color="black",
            linestyle=":",
            linewidth=1,
            label="Registered individual bound",
        )
        ax.legend(fontsize=8, loc="lower right")
        ax.grid(axis="x", alpha=0.15)
        ax.set_axisbelow(True)
    fig.suptitle(
        "Finite first-block repairs with false-state linear transport"
        + ("" if qualified else " — NUMERICALLY UNQUALIFIED"),
        fontsize=16,
    )
    fig.text(
        0.5,
        0.02,
        "Source:196 forecasts / separate198 verification · 14Oct2026 · medians across64 dependent pairs; all10arms retained.\nExact controls compute the finite first block; no finite counterfactual tail. Primary results require everycell and ≥3/4blocks in every schema/order.",
        ha="center",
        fontsize=10,
    )
    fig.tight_layout(rect=(0, 0.09, 1, 0.94))
    figure = ROOT / "docs/figures/198-first-block-repair.png"
    figure.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(figure, dpi=170)
    fig.savefig(figure.with_suffix(".svg"))
    plt.close(fig)
    paragraphs = [
        "# First-block operation repairs with false-state transport",
        "Separate198mixed-check revalidation of unchanged196forecasts: "
        + ("PASS" if qualified else "FAIL; results are not qualified scientific conclusions.")
        + ". Fingerprint: `"
        + audit["fingerprint"]
        + "`.",
        "The two supplied Boolean prefixes differ only at the known embedding. Seven individual first-block operations are repaired using their finite known functions; the remaining operations and entire downstream computation use false-state derivatives. All forecasts were sealed globally before nativeTrue observation. Exact-block and exact-source arms are controls, not discoveries.",
        "The original196numerical check failed in48/80local primitive coordinate comparisons(max2.28405e-4) and remains failed.198public first-block hook reconstruction passes the SAME1e-4bound(max5.96e-6), and retained196whole-tail reverse scalar checks/native replays pass. Local reconstruction shares the forward-ADbackend with forecasts: structural independence only. The original primitive reverse-over-reverse discrepancy remains unresolved;198does not retroactively certify196's original check. [Revalidation protocol](../experiments/198-dual-revalidation.md). The displacement error denominator is the norm of the actual native displacement. Individual preference bound0.10nats; residual bound relativeL2≤0.05 and cosine≥0.99, native norm≥0.001. Whole account needs≥3/4blocks in every schema/order. Comparative progress means halving source error and either final residual or absolute preference error, in all four cells. Progress cannot substitute for native matching.",
    ]
    for arm in ARMS:
        s = summary[arm]
        counts = ", ".join(
            f"{metric.replace('_', ' ')} {audit['accounts'][metric][arm]['compatible_panels']}/16 (whole {'PASS' if audit['accounts'][metric][arm]['whole_passed'] else 'FAIL'})"
            for metric in (
                "source_matching",
                "individual_matching",
                "residual_matching",
                "prospective_progress",
            )
        )
        paragraphs.append(
            f"**{arm}**{' — local finite-computation control' if arm.startswith('exact_') else ''}: {counts}. Median source error {s['source_relative_error']['median']:.6g}, final error {s['final_relative_error']['median']:.6g}; absolute preference error median {s['absolute_margin_error']['median']:.6g}nats, max {s['absolute_margin_error']['maximum']:.6g}nats."
        )
    paragraphs.extend(
        [
            "![All registered repairs](../figures/198-first-block-repair.png)",
            "Revalidation results: [independent artifact audit](198-revalidated-196-audit.json), [numerical verification](198-dual-primitive-recheck.json), [summary](198-first-block-repair-summary.json), [registered protocol](../experiments/196-first-block-primitive-repair.md), [methods/additional accounting](../experiments/196-methods-addendum.md).",
            "195 stopped on its derivative coordinate tolerance before any nativeTrue observation and remains [a preserved technical failure](195-technical-failure.json).196 uses automatic primitive derivatives; every check bound is unchanged. One small checkpoint, dependent synthetic templates and failed earlier grounding controls constrain all claims. No unique learned mechanism, universal model result, deployment failure, or novelty priority is established. Local correction does not explain downstream behavior unless that prospective prediction improves.",
            "Reproduce from the qualified193 parent in the same offline environment: run196runner, artifactauditor, numerical recheck, then artifactauditor again. Study output directories must be absent; do not overwrite an executed run. Full-model counts128ordinary+640False-tailAD; numerical verification16ordinary+80reverseAD. Local computations and engineering/failed195 costs are separate in the methods addendum. No training/generation; raw arrays/modelweights are excluded from Git.",
        ]
    )
    paragraphs.append(
        "Original failures retained: [196original numerical verification](196-numerical-recheck.json), [196original artifact qualification](196-independent-audit.json);197raw-dual MPS Linear support failed before completing a local validation. Revalidate unchanged196outputs using check_dual_primitive_reconstruction_198.py then audit_dual_revalidation_198.py.198is verification/reanalysis of the same forecasts, not fresh prospective prompts."
    )
    (ROOT / "docs/analysis/198-first-block-primitive-repair-result.md").write_text(
        "\n\n".join(paragraphs) + "\n"
    )
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
