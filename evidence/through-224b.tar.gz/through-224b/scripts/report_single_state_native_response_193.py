"""Native counterfactual forecasts versus small-dose diagnostics, with every failed account."""

import json
from pathlib import Path

import matplotlib
import numpy as np

matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "docs/analysis"


def main():
    a = json.loads((OUT / "193-independent-audit.json").read_text())
    n = json.loads((OUT / "193-numerical-recheck.json").read_text())
    assert a["numerical_qualified"] and all(a["controls"].values()) and n["passed"]
    assert a["fingerprint"] == n["fingerprint"]
    summary = []
    fig, axes = plt.subplots(1, 2, figsize=(12, 5))
    for schema, color in (("generic", "#777777"), ("descriptive", "#1764a4")):
        for order, ls in ((1, "-"),):
            rows = []
            for dose in (0.125, 0.25, 0.5, 1.0):
                cs = [
                    c
                    for c in a["cells"]
                    if (c["schema"], c["order"], c["dose"]) == (schema, order, dose)
                ]
                errors = [abs(c["margin_error"]) for c in cs]
                rels = [c["last_relative_error"] for c in cs]
                row = {
                    "schema": schema,
                    "order": order,
                    "dose": dose,
                    "maximum_margin_error": max(errors),
                    "median_margin_error": float(np.median(errors)),
                    "maximum_last_relative_error": max(rels),
                    "median_last_relative_error": float(np.median(rels)),
                }
                rows.append(row)
                summary.append(row)
            axes[0].plot(
                [r["dose"] for r in rows],
                [r["maximum_margin_error"] for r in rows],
                linestyle=ls,
                color=color,
                marker="o",
                label=f"{schema.capitalize()}, order {order}",
            )
            axes[1].plot(
                [r["dose"] for r in rows],
                [r["maximum_last_relative_error"] for r in rows],
                linestyle=ls,
                color=color,
                marker="o",
                label=f"{schema.capitalize()}, order {order}",
            )
    axes[0].axhline(0.1, color="#555555", linestyle=":", label="0.10-nat matching bound")
    axes[1].axhline(0.05, color="#555555", linestyle=":", label="5% residual-error bound")
    axes[0].set_ylabel("Maximum Boolean-response margin error (nats)")
    axes[1].set_ylabel("Maximum final-position displacement relative error (unitless)")
    axes[0].set_title("Behavioral forecast from the false computation", fontsize=11, loc="left")
    axes[1].set_title("Prediction of the native residual displacement", fontsize=11, loc="left")
    for ax in axes:
        ax.set_xlabel("Known embedding-change dose (unitless); 1 = native Boolean flip")
        ax.set_yscale("log")
        ax.spines[["top", "right"]].set_visible(False)
        ax.legend(frameon=False, fontsize=8)
        ax.grid(alpha=0.15)
    fig.tight_layout(rect=(0, 0.14, 1, 1))
    fig.text(
        0.5,
        0.015,
        "Source: qualified 193 forecasts / observations, 14 October 2026 UTC; 32 contexts per schema.\nAll forecasts globally sealed before native true or dose responses. Curves show maxima, not selected examples.\nOrder 1 = full-network first directional response at false. Small doses are diagnostic embedding interventions.",
        ha="center",
        fontsize=8,
    )
    for ext in ("png", "svg"):
        fig.savefig(
            OUT / f"figures/193-single-state-native-forecast.{ext}", dpi=170, bbox_inches="tight"
        )
    plt.close(fig)
    lines = [
        "# Can one false computation predict the native Boolean flip?",
        "",
        "This is the first continuation here that seals full-network native-response predictions without any target-state computation in the forecasting phase. The known input literal and model weights are available. The input direction is the embedding difference at the single Boolean position. Native RMS, attention, SiLU and multiplying branches all enter first directional derivatives at the false state. That is a white-box AD baseline, not a compact identified mechanism or training explanation.",
        "",
        "All 64 ordinary false readouts and 64 differentiated false invocations were saved before ANY native true or finite-dose observation. There are 320 ordinary main model invocations, 64 differentiated invocations with one forward-AD level, 16 separate numerical ordinary invocations and 8 reverse-differentiated numerical invocations. Differentiated invocations have different costs and are counted separately. The earlier192 engineering preflights separately add two ordinary false and two differentiated false invocations; the reporting-only hash failure and its separate correction are preserved. No true-state preflight observation occurred. The192second-order attempt failed its fixed numerical qualification and is preserved; none of its second-order numbers is interpreted as a scientific finding here.",
        "",
        f"All {len(a['controls'])} artifact controls pass. Native numerical score/state exactness: {n['all_native_scores_exact']}/{n['all_native_states_exact']}. Maximum reverse-versus-forward derivative contraction error {n['maximum_derivative_contraction_error']:.6g}; fixed bound 0.001 + 0.0001*abs(reverse reference). These margin and two trajectory-projection checks do not establish coordinatewise equality of every derivative tensor.",
        "",
    ]
    for name, account in a["accounts"].items():
        lines.append(
            f"- {'PRIMARY ' if account['primary'] else 'secondary/diagnostic '}{name}: {account['compatible_panels']}/16 panels; whole {'PASS' if account['whole_passed'] else 'FAIL'}; strata {account['strata']}."
        )
    lines += [
        "",
        "The native primary margin rule is <=0.10 nats error in ALL four relation cells/panel; residual rule is <=5% relative error AND >=0.99 cosine, with actual displacement >=0.001. The whole rule needs at least 3/4 sources in EVERY schema/order. Evidence balancing and successful small doses cannot rescue failed native individual or residual accounts. The first-order forecast was frozen in advance, with no fitted coefficients or refinement.",
        "",
        "![Single-state forecast versus dose](figures/193-single-state-native-forecast.png)",
        "",
    ]
    for order in (1,):
        cs = [c for c in a["cells"] if (c["dose"], c["order"]) == (1.0, order)]
        lines.append(
            f"Native dose, order {order}: maximum individual margin error {max(abs(c['margin_error']) for c in cs):.6f} nats; maximum final-position relative displacement error {max(c['last_relative_error'] for c in cs):.6f}; cosine range {min(c['last_cosine'] for c in cs):.6f}–{max(c['last_cosine'] for c in cs):.6f}."
        )
    lines += [
        "",
        "Interpretation: prospective accuracy would establish a bounded single-state prediction result for these dependent prompts, with derivatives through known weights. Failure would show that local first-order response is insufficient at the finite Boolean change, not that counterfactual prediction in general is impossible. Layerwise held-out errors locate breakdown after forecast sealing; they cannot be used to refit and claim another prospective success on the same cases. Identification of a small set of causal nonlinear source/transport components remains a separate next test. Earlier grounding/specificity failures, one checkpoint, synthetic dependent day tasks and absence of an independent team remain. No novelty priority or complete mechanism claim.",
    ]
    (OUT / "193-single-state-native-response-result.md").write_text("\n".join(lines) + "\n")
    (OUT / "193-single-state-native-response-summary.json").write_text(
        json.dumps(
            {
                "posthoc": True,
                "target_model_invocations": 0,
                "fingerprint": a["fingerprint"],
                "schema_dose_error_summaries": summary,
            },
            indent=2,
        )
        + "\n"
    )
    print("Wrote qualified single-state forecast report and figures.")


if __name__ == "__main__":
    main()
