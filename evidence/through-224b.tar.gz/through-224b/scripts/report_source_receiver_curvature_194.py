"""Qualified source/receiver forecast failures and an explicitly posthoc pointwise check."""

import json
from pathlib import Path

import matplotlib
import numpy as np

matplotlib.use("Agg")
import matplotlib.pyplot as plt

from latent_decisions.evidence_policy import digest

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "docs/analysis"


def main():
    a = json.loads((OUT / "194-independent-audit.json").read_text())
    n = json.loads((OUT / "194-numerical-recheck.json").read_text())
    assert a["numerical_qualified"] and all(a["controls"].values()) and n["passed"]
    arms = ("all_T1", "all_Q2", "all_C3", "source_C3", "receiver_C3")
    fig, axes = plt.subplots(1, 2, figsize=(12.5, 5))
    summary = {}
    for index, arm in enumerate(arms):
        summary[arm] = {
            "maximum_margin_error": max(abs(c["errors"][arm]) for c in a["cells"]),
            "maximum_balanced_error": max(abs(p["balanced_true_errors"][arm]) for p in a["panels"]),
            "maximum_residual_relative_error": max(
                r["relative_error"] for r in a["residual_cells"] if r["arm"] == arm
            ),
        }
        for schema, color in (("generic", "#777777"), ("descriptive", "#1764a4")):
            ps = [p for p in a["panels"] if p["schema"] == schema]
            rs = [r for r in a["residual_cells"] if r["schema"] == schema and r["arm"] == arm]
            axes[0].scatter(
                [index + (j - 3.5) * 0.01 for j in range(8)],
                [abs(p["balanced_true_errors"][arm]) for p in ps],
                color=color,
                s=18,
                label=schema.capitalize() if index == 0 else None,
            )
            axes[1].scatter(
                [index + (j - 15.5) * 0.005 for j in range(32)],
                [r["relative_error"] for r in rs],
                color=color,
                s=14,
                label=schema.capitalize() if index == 0 else None,
            )
    for axis, bound in zip(axes, (0.1, 0.05)):
        axis.axhline(bound, color="#555555", linestyle=":")
        axis.set_xticks(
            range(5), ("All T1", "All Q2", "All C3", "Source C3", "Receiver C3"), rotation=12
        )
        axis.set_xlabel("False-calibrated SiLU approximation / affected positions")
        axis.spines[["top", "right"]].set_visible(False)
        axis.legend(frameon=False)
        axis.grid(axis="y", alpha=0.12)
    axes[0].set_ylabel("Balanced evidence-response absolute error (nats)")
    axes[1].set_ylabel("Final-position displacement relative error (unitless)")
    axes[0].set_title(
        "Source approximation loses generic evidence precision", loc="left", fontsize=11
    )
    axes[1].set_title("No whole residual matching account passes", loc="left", fontsize=11)
    fig.tight_layout(rect=(0, 0.14, 1, 1))
    fig.text(
        0.5,
        0.01,
        "Source: qualified194 forecasts,14October2026UTC. All16 evidence panels and64 residual pairs per arm.\nSource=Boolean row; Receiver=strictly later rows; All=both.704forecasts/False calls precede ANY nativeTrue.\nNormalization,attention and multiplication are computed at surrogate counterfactual inputs; no true-state calibration.",
        ha="center",
        fontsize=8,
    )
    for ext in ("png", "svg"):
        fig.savefig(
            OUT / f"figures/194-source-receiver-curvature.{ext}", dpi=170, bbox_inches="tight"
        )
    plt.close(fig)
    lines = [
        "# Native source generation remains a forecasting boundary",
        "",
        f"194 completed768main+96separate numerical ordinary full-model calls. All{len(a['controls'])}controls pass; selected public scores/full28trajectories replay EXACTLY, maximum capture discrepancy{n['maximum_capture_error']:.3g}. A scoped false-anchor/prefix test passed before launch.",
        "",
        "Every coefficient uses only nativeFalse. All704forecasts/False calls are globally sealed before ANY nativeTrue measurement. This is a nonlinear surrogate that evaluates finite normalization,attention and branch multiplication on predicted counterfactual inputs; it is not derivative-only transport or a compact circuit model. Source_C3 changes only the Boolean's SiLU sites; receiver_C3 changes only later positions; all_C3 changes both. No nativeTrue trajectory calibrates coefficients.",
        "",
    ]
    for metric in ("individual_matching", "residual_matching", "balanced_matching"):
        for arm in arms:
            account = a["accounts"][metric][arm]
            lines.append(
                f"- {metric} / {arm}: {account['compatible_panels']}/16; whole{'PASS' if account['whole_passed'] else 'FAIL'}; strata{account['strata']}."
            )
    lines += [
        "",
        "Both PRIMARY whole accounts (individual preference and full final-position displacement) fail in every arm:0/16panels. The receiver-only cubic approximation retains the SECONDARY evidence contrast in14/16panels and meets the whole3/4EVERYstratum rule. Moving that approximation to the Boolean source loses all generic evidence panels; source-only passes8/16, all descriptive, and all-C3passes7/16, all descriptive. Those whole accounts fail. This is a source/receiver asymmetry conditional on the particular approximation, not a unique native pathway attribution.",
        "",
        "The residual rule remains<=5%relativeL2 AND>=0.99cosine; individual/evidence margin bound0.10nats. Every panel includes allfour relation cells. Evidence matching cannot rescue either native primary account. Counterfactual known-function evaluations are substantial; a single false calibration is different from doing no counterfactual computation.",
        "",
        "![Every source/receiver outcome](figures/194-source-receiver-curvature.png)",
        "",
    ]
    for arm, v in summary.items():
        lines.append(
            f"{arm}: worst individual margin error{v['maximum_margin_error']:.6f}nats, evidence error{v['maximum_balanced_error']:.6f}nats, residual relative error{v['maximum_residual_relative_error']:.6f}."
        )
    # Actual TRUE inputs are used here only AFTER prediction/observation, as a diagnostic.
    diagnostic = []
    for c in a["cells"]:
        g = {k: c[k] for k in ("block", "schema", "reverse", "assignment", "target")}
        key = digest(g)
        run = ROOT / "runs/source-receiver-curvature-194/qwen15"
        with (
            np.load(run / "forecasts" / f"{key}.npz", allow_pickle=False) as f,
            np.load(run / "states" / f"{key}.npz", allow_pickle=False) as t,
        ):
            for site in range(1, 29):
                xf = f[f"native_false_{site}_input"].astype(np.float64)
                xt = t[f"native_true_{site}_input"].astype(np.float64)
                delta = xt - xf
                pred = (
                    f[f"map_all_C3_{site}_intercept"].astype(np.float64)
                    + f[f"map_all_C3_{site}_slope"].astype(np.float64) * delta
                    + f[f"map_all_C3_{site}_second"].astype(np.float64) * delta**2
                    + f[f"map_all_C3_{site}_third"].astype(np.float64) * delta**3
                )
                error = pred - t[f"native_true_{site}_output"].astype(np.float64)
                # SiLU has complex poles at (2k+1)i*pi; this is its Taylor radius from real xf.
                ratio = np.abs(delta) / np.sqrt(xf * xf + np.pi * np.pi)
                diagnostic.append(
                    {
                        **g,
                        "layer": site,
                        "source_cubic_pointwise_max_error": float(np.max(abs(error[0]))),
                        "receiver_cubic_pointwise_max_error": float(np.max(abs(error[1:]))),
                        "source_step_over_taylor_radius_max": float(np.max(ratio[0])),
                        "receiver_step_over_taylor_radius_max": float(np.max(ratio[1:])),
                        "source_outside_radius_fraction": float(np.mean(ratio[0] > 1)),
                        "receiver_outside_radius_fraction": float(np.mean(ratio[1:] > 1)),
                    }
                )
    assert len(diagnostic) == 1792
    lines += [
        "",
        "A separate1792-row post-observation diagnostic evaluates the false cubic at actual nativeTrue preactivations. It distinguishes pointwise truncation error at source/later rows and reports whether the step exceeds the SiLU Taylor-series radius sqrt(xF²+pi²). These nativeTrue inputs are ORACLE diagnostic information, never forecast calibration; pointwise counts/error do not identify a causal feature or explain all propagated response. A third-order polynomial can fail even within that radius; outside it, the infinite Taylor series centered at false does not converge at the native true input.",
        "",
        "The primary Question B remains unresolved. We have now falsified a strict native first-order predictor and source-inclusive low-order SiLU surrogates, while a weaker evidence response survives when the source encoder stays native. A useful next account must predict source generation, not only transport a fitted paired correction. One checkpoint/dependent tasks/dense maps/failed grounding and specificity remain. No priority or complete mechanism claim.",
    ]
    (OUT / "194-source-receiver-curvature-result.md").write_text("\n".join(lines) + "\n")
    (OUT / "194-source-receiver-curvature-summary.json").write_text(
        json.dumps(
            {
                "fingerprint": a["fingerprint"],
                "model_invocations": 0,
                "posthoc": True,
                "arm_errors": summary,
                "native_true_pointwise_diagnostic": diagnostic,
            },
            indent=2,
        )
        + "\n"
    )
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
