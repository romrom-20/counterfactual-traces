"""Verify archived primitive evidence or reproduce it in a fresh offline checkout."""

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
COMMANDS = [
    "qualify_block28_derivative_210.py",
    "qualify_local_primitives_210b.py",
    "qualify_actual_node_primitives_210c.py",
    "run_block28_primitive_211.py",
    "audit_block28_primitive_211b.py",
    "crosscheck_saved_primitive_vectors_211c.py",
    "plot_block28_primitives_211.py",
    "build_block28_primitive_canvas_211.py",
]


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--verify-only", action="store_true")
    p.add_argument("--plan", action="store_true")
    args = p.parse_args()
    bundle = json.loads((ROOT / "results/block28-primitives-210-211/manifest.json").read_text())
    for name, h in bundle["files"].items():
        assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == h, name
    print(
        f"Verified {len(bundle['files'])}preserved files; zero model calls for verification.",
        flush=True,
    )
    if args.plan:
        print(
            json.dumps(
                dict(
                    prerequisite="Qualified209crawpairs and204fullmask/RoPE; existing204reproducer+209conly regenerate ifabsent. No208run.",
                    commands=COMMANDS,
                    expected_scientific_failures="210originalcompatibility and211creference/surgeryequality remain failures; pipeline completion does not certifythem.",
                ),
                indent=2,
            )
        )
    if args.plan or args.verify_only:
        return
    for name in (
        "block28-derivative-210",
        "block28-derivative-210b",
        "block28-derivative-210c",
        "block28-primitive-211",
    ):
        assert not (ROOT / "runs" / name).exists(), "Use a fresh checkout; preserve original runs."
    env = dict(
        os.environ,
        HF_HUB_OFFLINE="1",
        TRANSFORMERS_OFFLINE="1",
        OMP_NUM_THREADS="1",
        VECLIB_MAXIMUM_THREADS="1",
        PYTHONPATH="src:scripts",
    )
    archive = ROOT / ".context/reproduction-210-211-archive"
    assert not archive.exists()
    archive.mkdir(parents=True)
    for pattern in ("210*.json", "211*.json"):
        for path in (ROOT / "docs/analysis").glob(pattern):
            shutil.move(path, archive / path.name)
    if not (ROOT / "runs/genuine-oracle-continuation-204-full/pairs").exists():
        subprocess.run(
            [sys.executable, "scripts/reproduce_genuine_oracle_202_204.py", "--full"],
            cwd=ROOT,
            env=env,
            check=True,
        )
    if not (ROOT / "runs/two-block-factorial-209c/pairs").exists():
        for name in ("209c-two-block-factorial.json", "209c-factorial-effects.json"):
            path = ROOT / "docs/analysis" / name
            if path.exists():
                shutil.move(path, archive / name)
        for name in (
            "run_two_block_factorial_209c.py",
            "audit_two_block_factorial_209c.py",
            "summarize_factorial_effects_209d.py",
        ):
            subprocess.run([sys.executable, "scripts/" + name], cwd=ROOT, env=env, check=True)
    for name in COMMANDS:
        subprocess.run([sys.executable, "scripts/" + name], cwd=ROOT, env=env, check=True)


if __name__ == "__main__":
    main()
