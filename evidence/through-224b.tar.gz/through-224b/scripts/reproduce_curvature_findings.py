"""Run unchanged registered experiments serially from explicit historical prerequisites."""

import argparse
import hashlib
import importlib
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BUNDLE = ROOT / "results/norm-curvature-189-194"
STAGES = {
    186: ("one-sided-gain-forecast-186", "one_sided_gain_forecast"),
    187: ("shared-signed-curvature-187", "shared_signed_curvature"),
    188: ("curvature-multiplication-188", "curvature_multiplication"),
    189: ("factorial-curvature-routes-189", "factorial_curvature_routes"),
    190: ("fresh-norm-split-190", "fresh_norm_split"),
    191: ("one-sided-curvature-forecast-191", "one_sided_curvature_forecast"),
    192: ("single-state-native-response-192", "single_state_native_response"),
    193: ("single-state-native-response-193", "single_state_native_response"),
    194: ("source-receiver-curvature-194", "source_receiver_curvature"),
}


def verify():
    manifest = json.loads((BUNDLE / "manifest.json").read_text())
    for path, expected in manifest["files"].items():
        actual = hashlib.sha256((ROOT / path).read_bytes()).hexdigest()
        if actual != expected:
            raise RuntimeError(f"Published source/artifact changed: {path}")
    for stage, (_, stem) in STAGES.items():
        module = importlib.import_module(f"run_{stem}_{stage}")
        design = json.loads((BUNDLE / f"provenance/{stage}-design.json").read_text())
        assert module.source_hash() == design["design"]["source_hash"]
    print(
        f"Verified {len(manifest['files'])} published file hashes and all registered source fingerprints."
    )


def seed(mode):
    folder = BUNDLE / "prerequisites" / ("185" if mode == "from-186" else "189")
    index = json.loads((folder / "index.json").read_text())
    for source, destination in index.items():
        src, dst = folder / source, ROOT / destination
        if dst.exists():
            if dst.read_bytes() != src.read_bytes():
                raise RuntimeError(f"Refusing to replace a different prerequisite: {destination}")
        else:
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(src, dst)


def commands(mode):
    stages = range(186, 195) if mode == "from-186" else (190, 191, 192, 193, 194)
    rows = []
    for stage in stages:
        _, stem = STAGES[stage]
        # Numerical qualification is ready before the complete artifact audit.
        rows.extend(f"scripts/{prefix}_{stem}_{stage}.py" for prefix in ("run", "recheck", "audit"))
    if mode == "from-186":
        rows.append(("scripts/analyze_norm_readout_cancellation_189_190.py", "--experiment", "189"))
    rows += [
        ("scripts/analyze_norm_readout_cancellation_189_190.py", "--experiment", "190"),
        "scripts/analyze_residual_sources_190.py",
        "scripts/report_norm_feedback_189_190.py",
        "scripts/report_residual_generation_190_191.py",
        "scripts/report_single_state_native_response_193.py",
        "scripts/analyze_boolean_source_breakdown_193.py",
        "scripts/report_source_receiver_curvature_194.py",
    ]
    return [[row] if isinstance(row, str) else list(row) for row in rows]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mode", choices=("fresh-190-194", "from-186"), default="fresh-190-194")
    parser.add_argument("--verify-only", action="store_true")
    parser.add_argument("--plan", action="store_true")
    args = parser.parse_args()
    verify()
    if args.verify_only:
        return
    plan = commands(args.mode)
    if args.plan:
        print(
            json.dumps(
                {
                    "mode": args.mode,
                    "historical_seed": 185 if args.mode == "from-186" else 189,
                    "serial_commands": plan,
                },
                indent=2,
            )
        )
        return
    stages = range(186, 195) if args.mode == "from-186" else (190, 191, 192, 193, 194)
    for stage in stages:
        path = ROOT / "runs" / STAGES[stage][0]
        if path.exists():
            raise RuntimeError(f"Use a clean checkout: refusing to reuse or overwrite {path}")
    seed(args.mode)
    env = {
        **os.environ,
        "PYTHONPATH": os.pathsep.join((str(ROOT / "src"), str(ROOT / "scripts"))),
        "HF_HUB_OFFLINE": "1",
        "TRANSFORMERS_OFFLINE": "1",
    }
    for command in plan:
        print("Executing", " ".join(command), flush=True)
        subprocess.run([sys.executable, "-u", *command], cwd=ROOT, env=env, check=True)


if __name__ == "__main__":
    main()
