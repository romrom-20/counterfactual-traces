"""Verify preserved evidence or run the approved factorial then fresh partition."""

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
COMMANDS = [
    "run_two_block_factorial_209c.py",
    "audit_two_block_factorial_209c.py",
    "summarize_factorial_effects_209d.py",
    "run_source_receiver_partition_208.py",
    "audit_source_receiver_partition_208.py",
    "describe_partition_errors_208d.py",
    "plot_factorial_partition_208_209.py",
    "build_factorial_partition_canvas_208_209.py",
]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--verify-only", action="store_true")
    parser.add_argument("--plan", action="store_true")
    args = parser.parse_args()
    bundle = json.loads(
        (ROOT / "results/source-receiver-factorial-208-209/manifest.json").read_text()
    )
    for path, expected in bundle["files"].items():
        assert hashlib.sha256((ROOT / path).read_bytes()).hexdigest() == expected, path
    print(
        f"Verified {len(bundle['files'])}preserved files; zero model calls for verification.",
        flush=True,
    )
    if args.plan:
        print(
            json.dumps(
                dict(
                    prerequisite="Qualified204full rawpairs; if absent, existing offline202–207fullreproducer regenerates193/199/201/204 first in freshcheckout.",
                    historical_failures="209/209b source, status, logs and partial metadata preserved; not rerun or treated as successes.",
                    commands=[f"scripts/{p}" for p in COMMANDS],
                    interpretation="Oraclefactorial then globallysealedfreshFalse-onlypartition; nolearnedcircuit claim.",
                ),
                indent=2,
            )
        )
    if args.verify_only or args.plan:
        return
    assert not (ROOT / "runs/two-block-factorial-209c").exists()
    assert not (ROOT / "runs/source-receiver-partition-208").exists()
    env = dict(
        os.environ,
        HF_HUB_OFFLINE="1",
        TRANSFORMERS_OFFLINE="1",
        PYTHONPATH="src:scripts",
        OMP_NUM_THREADS="1",
        VECLIB_MAXIMUM_THREADS="1",
    )
    if not (ROOT / "runs/genuine-oracle-continuation-204-full/pairs").exists():
        subprocess.run(
            [sys.executable, "scripts/reproduce_genuine_oracle_202_204.py", "--full"],
            cwd=ROOT,
            env=env,
            check=True,
        )
    archive = ROOT / ".context/reproduction-208-209-archive"
    assert not archive.exists()
    archive.mkdir(parents=True)
    for name in [
        "209c-two-block-factorial.json",
        "209c-factorial-effects.json",
        "208-source-receiver-partition.json",
        "208-error-comparisons.json",
    ]:
        path = ROOT / "docs/analysis" / name
        if path.exists():
            shutil.move(path, archive / name)
    for name in COMMANDS:
        subprocess.run([sys.executable, f"scripts/{name}"], cwd=ROOT, env=env, check=True)


if __name__ == "__main__":
    main()
