"""Run the immutable corrected primitive-repair experiment from explicit193 prerequisites."""

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BUNDLE = ROOT / "results/norm-curvature-195-196"
COMMANDS = (
    "run_first_block_primitive_repair_196.py",
    "audit_first_block_primitive_repair_196.py",
    "recheck_first_block_primitive_repair_196.py",
    "audit_first_block_primitive_repair_196.py",
    "report_first_block_primitive_repair_196.py",
    "check_dual_primitive_reconstruction_198.py",
    "audit_dual_revalidation_198.py",
    "report_revalidated_first_block_repair_198.py",
    "build_first_block_repair_canvas_196.py",
)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--verify-only", action="store_true")
    parser.add_argument("--plan", action="store_true")
    args = parser.parse_args()
    manifest = json.loads((BUNDLE / "manifest.json").read_text())
    for path, sha in manifest["files"].items():
        assert hashlib.sha256((ROOT / path).read_bytes()).hexdigest() == sha, path
    import run_first_block_primitive_repair_196 as runner

    design = json.loads((BUNDLE / "provenance/196-design.json").read_text())
    assert runner.source_hash() == design["design"]["source_hash"]
    print(
        f"Verified {len(manifest['files'])} files and196 source fingerprint; historical193 seed is not a fresh qualification."
    )
    if args.verify_only:
        return
    if args.plan:
        print(
            json.dumps(
                {
                    "historical_seed": 193,
                    "commands": list(COMMANDS),
                    "ordinary_model_invocations": 152,
                    "directional_ad_model_invocations": 720,
                    "local_computations_separate": True,
                },
                indent=2,
            )
        )
        return
    if runner.RUN.exists():
        raise RuntimeError("Use a clean checkout: refusing to overwrite an executed196 run.")
    seed = BUNDLE / "prerequisites/193"
    for source, destination in json.loads((seed / "index.json").read_text()).items():
        src, dst = seed / source, ROOT / destination
        if dst.exists():
            if dst.read_bytes() != src.read_bytes():
                raise RuntimeError(f"Different prerequisite already exists: {destination}")
        else:
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(src, dst)
    env = {
        **os.environ,
        "PYTHONPATH": os.pathsep.join((str(ROOT / "src"), str(ROOT / "scripts"))),
        "HF_HUB_OFFLINE": "1",
        "TRANSFORMERS_OFFLINE": "1",
    }
    for script in COMMANDS:
        print(f"Executing {script}", flush=True)
        subprocess.run(
            [sys.executable, "-u", str(ROOT / "scripts" / script)], cwd=ROOT, env=env, check=True
        )


if __name__ == "__main__":
    main()
