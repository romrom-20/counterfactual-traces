"""Verify the scoped offline evidence package or reproduce in a fresh research checkout."""

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--verify-only", action="store_true")
    parser.add_argument("--plan", action="store_true")
    parser.add_argument(
        "--full", action="store_true", help="Extend the predetermined8-case sample to64 old pairs"
    )
    args = parser.parse_args()
    manifest = json.loads((ROOT / "results/genuine-oracle-202-204/manifest.json").read_text())
    for f, expected in manifest["files"].items():
        assert hashlib.sha256((ROOT / f).read_bytes()).hexdigest() == expected, f
    print(
        f"Verified {len(manifest['files'])} files; no model calls during verification.", flush=True
    )
    commands = [
        (["scripts/audit_replacement_metrics_202.py"], False),
        (["scripts/run_genuine_oracle_continuation_203.py", "--scope", "sample"], True),
        (["scripts/run_genuine_oracle_continuation_204.py", "--scope", "sample"], False),
        (["scripts/audit_genuine_oracle_continuation_204.py", "--scope", "sample"], False),
        (["scripts/report_genuine_oracle_continuation_204.py", "--scope", "sample"], False),
        (["scripts/separate_measured_reset_errors_205.py", "--scope", "sample"], False),
        (["scripts/report_layerwise_reset_norms_207.py", "--scope", "sample"], False),
        (["scripts/check_local_derivative_precision_206.py"], False),
        (["scripts/plot_genuine_oracle_204.py", "--scope", "sample"], False),
        (["scripts/build_genuine_oracle_canvas_204.py", "--scope", "sample"], False),
    ]
    if args.full:
        commands.extend(
            (([f"scripts/{name}", "--scope", "full"], False))
            for name in [
                "run_genuine_oracle_continuation_204.py",
                "audit_genuine_oracle_continuation_204.py",
                "report_genuine_oracle_continuation_204.py",
                "separate_measured_reset_errors_205.py",
                "report_layerwise_reset_norms_207.py",
                "plot_genuine_oracle_204.py",
                "build_genuine_oracle_canvas_204.py",
            ]
        )
    if args.plan:
        print(
            json.dumps(
                dict(
                    prerequisite="Fresh checkout; wrapper regenerates193/199/201with previouspipeline if raw201 arrays absent, after verifying historical manifest.",
                    historical_results="Preserved in recorded-runs and a non-overwriting reproduction archive before fresh numerical outputs are written.",
                    commands=[dict(argv=c, expected203_failure=f) for c, f in commands],
                ),
                indent=2,
            )
        )
    if args.verify_only or args.plan:
        return
    assert not (ROOT / "runs/genuine-oracle-continuation-203-sample").exists()
    assert not (ROOT / "runs/genuine-oracle-continuation-204-sample").exists()
    env = dict(os.environ, HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1", PYTHONPATH="src:scripts")
    if not (ROOT / "runs/discovery-ranked-repair-201/forecast-manifest.json").exists():
        subprocess.run(
            [sys.executable, "scripts/reproduce_remainder_repair_199_201.py"],
            cwd=ROOT,
            env=env,
            check=True,
        )
    archive = ROOT / ".context/reproduction-202-207-archive"
    assert not archive.exists()
    for pattern in [
        "202-replacement-metric-audit.json",
        "204-*-oracle-vector-audit.json",
        "204-*-oracle-summary.json",
        "205-*-measured-reset-separation.json",
        "206-local-derivative-precision.json",
        "207-*-layerwise-norms.json",
    ]:
        for path in (ROOT / "docs/analysis").glob(pattern):
            target = archive / path.relative_to(ROOT)
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.move(path, target)
    for argv, expected in commands:
        result = subprocess.run([sys.executable, *argv], cwd=ROOT, env=env, check=False)
        if expected:
            # Preserve a registered failure, never convert it into a successful qualification.
            status = json.loads(
                (ROOT / "runs/genuine-oracle-continuation-203-sample/status.json").read_text()
            )
            assert result.returncode != 0 and status["status"] == "technical_failure"
            assert "signed_vector_identity" in status["error"], status
        else:
            assert result.returncode == 0, argv


if __name__ == "__main__":
    main()
