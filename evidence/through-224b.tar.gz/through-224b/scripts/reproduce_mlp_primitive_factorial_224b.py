"""Preservation checks or the frozen224b endpoint/audit/hybrid/audit sequence."""
import argparse,hashlib,json,os,shutil,subprocess,sys
from pathlib import Path
R=Path(__file__).resolve().parents[1]
COMMANDS=[['run_mlp_primitive_factorial_224b.py','--phase','endpoints'],['audit_mlp_primitive_factorial_224b.py','--phase','endpoints'],
 ['run_mlp_primitive_factorial_224b.py','--phase','hybrids'],['audit_mlp_primitive_factorial_224b.py','--phase','hybrids'],['describe_mlp_primitive_factorial_224b.py'],['audit_silu_product_contrast_224b.py'],['plot_mlp_primitive_factorial_224b.py']]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    p=argparse.ArgumentParser();p.add_argument('--verify-only',action='store_true');p.add_argument('--verify-local-arrays',action='store_true');p.add_argument('--plan',action='store_true');a=p.parse_args()
    package=R/'results/mlp-primitive-factorial-224b';man=json.loads((package/'manifest.json').read_text())
    for rel,h in man['files'].items():assert sha(R/rel)==h,rel
    print(f"Verified {len(man['files'])} preserved files; zero model calls for verification.",flush=True)
    if a.verify_local_arrays:
        inventory=json.loads((package/'local-raw-inventory.json').read_text());raw=inventory['arrays']
        assert sha(R/inventory['reused_weights_path'])==inventory['reused_weights_sha256']
        for x in raw:assert sha(R/x['path'])==x['sha256'],x['path']
        print(f'Verified all {len(raw)} local224b raw archives.',flush=True)
    if a.plan:print(json.dumps(dict(commands=[['scripts/'+c[0],*c[1:]] for c in COMMANDS],prerequisites='Pinned offline Qwen/MPS runtime; original hash-bound223 qualification/intervention/weight arrays and222 metadata. Failed224 remains an archived provenance record, not a successful endpoint bridge.',
        expected='64 ordinary models;1,152 finite suffix continuations;6,336 remaining public blocks;1,152 finite heads;3,456 local primitive directions with AD/FD checks.',
        scope='Retrospective native-input actual-node factorial. Frozen224b gates differ explicitly from failed224; no coordinate-bridge recovery, learned circuit, prospective prediction or general QuestionB solution.',
        verification_is_not='A second executed model replication.'),indent=2))
    if a.plan or a.verify_only or a.verify_local_arrays:return
    assert not (R/'runs/mlp-primitive-factorial-224b').exists(),'Preserve canonical run; use a fresh checkout.'
    for name in ('runs/native-mlp-remainder-223/qualification','runs/native-mlp-remainder-223/interventions','runs/native-mlp-remainder-223/weights.npz','runs/native-write-ledger-222/ledger'):
        assert (R/name).exists(),'Restore hash-bound prerequisites: '+name
    failed=R/'runs/mlp-primitive-factorial-224'
    if not failed.exists():shutil.copytree(package/'recorded-runs/mlp-primitive-factorial-224',failed)
    archive=R/'.context/reproduction-224b-archive';assert not archive.exists();archive.mkdir(parents=True)
    for path in (R/'docs/analysis').glob('224b*.json'):shutil.move(path,archive/path.name)
    env=dict(os.environ,HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',OMP_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1',PYTHONPATH='src:scripts')
    for command in COMMANDS:subprocess.run([sys.executable,'scripts/'+command[0],*command[1:]],cwd=R,env=env,check=True)
    print('Frozen224b sequence complete. Failed224 and earlier numerical caveats remain distinct.')
if __name__=='__main__':main()
