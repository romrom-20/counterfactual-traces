"""Zero-model preservation check, or registered local-qualification/causal sequence."""

import argparse,hashlib,json,os,shutil,subprocess,sys
from pathlib import Path
R=Path(__file__).resolve().parents[1]
COMMANDS=[['run_native_mlp_remainder_223.py','--phase','qualify'],['audit_native_mlp_remainder_223.py','--phase','qualification'],
 ['run_native_mlp_remainder_223.py','--phase','intervene'],['audit_native_mlp_remainder_223.py','--phase','interventions'],['describe_native_mlp_remainder_223.py'],['plot_native_mlp_remainder_223.py']]
def main():
    p=argparse.ArgumentParser();p.add_argument('--verify-only',action='store_true');p.add_argument('--plan',action='store_true');a=p.parse_args()
    man=json.loads((R/'results/native-mlp-remainder-223/manifest.json').read_text())
    for rel,h in man['files'].items():assert hashlib.sha256((R/rel).read_bytes()).hexdigest()==h,rel
    print(f"Verified {len(man['files'])} preserved files; zero model calls for verification.",flush=True)
    if a.plan:print(json.dumps(dict(commands=[['scripts/'+c[0],*c[1:]] for c in COMMANDS],
        prerequisites='Pinned offline Qwen/MPS runtime, original hash-bound208/222 arrays and metadata,219 mask, and all preserved prerequisite files.',
        expected='32 ordinary qualification models;320 intervention-phase models;768 local derivative directions plus local reverse/finite-difference checks; secondary product diagnostics.',
        scope='Retrospective necessity of two local MLP remainders with native finite tails. Natural verdict residual/margin primary. No prospective or learned-circuit claim.',
        verification_is_not='A second executed model replication.'),indent=2))
    if a.plan or a.verify_only:return
    assert not (R/'runs/native-mlp-remainder-223').exists(),'Use a fresh checkout; preserve the canonical run.'
    for name in ('runs/source-receiver-partition-208/forecasts','runs/native-write-ledger-222/ledger','runs/native-write-ledger-222/interventions','runs/neuron-mixed-interventions-219/selection.json'):
        assert (R/name).exists(),'Restore original hash-bound inputs: '+name
    archive=R/'.context/reproduction-223-archive';assert not archive.exists();archive.mkdir(parents=True)
    for path in (R/'docs/analysis').glob('223*.json'):shutil.move(path,archive/path.name)
    env=dict(os.environ,HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',OMP_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1',PYTHONPATH='src:scripts')
    for command in COMMANDS:subprocess.run([sys.executable,'scripts/'+command[0],*command[1:]],cwd=R,env=env,check=True)
    print('Registered sequence complete. Preserve every gate failure and earlier numerical caveat.')
if __name__=='__main__':main()
