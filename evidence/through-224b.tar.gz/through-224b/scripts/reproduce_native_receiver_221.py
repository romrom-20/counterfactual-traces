"""Verify the preservation closure or repeat the retrospective factorial on original inputs."""

import argparse,hashlib,json,os,shutil,subprocess,sys
from pathlib import Path
R=Path(__file__).resolve().parents[1]
def main():
    p=argparse.ArgumentParser();p.add_argument("--verify-only",action="store_true");p.add_argument("--plan",action="store_true");a=p.parse_args()
    obj=json.loads((R/"results/native-receiver-factorial-221/manifest.json").read_text())
    for rel,h in obj["files"].items():assert hashlib.sha256((R/rel).read_bytes()).hexdigest()==h,rel
    print(f"Verified {len(obj['files'])} preserved files; zero model calls for verification.",flush=True)
    commands=[("run_native_receiver_factorial_221.py",[]),("audit_native_receiver_factorial_221c.py",[]),
        ("describe_gate_up_geometry_221b.py",[]),("describe_gate_up_geometry_221b.py",["--states"]),
        ("plot_native_receiver_factorial_221.py",[]),("draw_receiver_flow_221.py",[])]
    if a.plan:print(json.dumps(dict(commands=[dict(script="scripts/"+c,args=v) for c,v in commands],contexts=64,
        prerequisite="Pinned offline model/compatible MPS runtime and original hash-bound 208/215/218/219 parent arrays and selection metadata.",
        correction="Use separately named221c auditor: one Float64 projection operand cast, original failure preserved, original1e-9 bound unchanged. No model repair.",
        scope="Retrospective native carry/write/RMS factorial and neuron controls; not fresh prediction, earlier-layer attribution or a learned circuit.",
        verification_is_not="A second executed model replication."),indent=2))
    if a.plan or a.verify_only:return
    assert not (R/"runs/native-receiver-factorial-221").exists(),"Use a fresh checkout; preserve the original run."
    for folder in ("source-receiver-partition-208/forecasts","matched-incoming-control-215/pairs","silu-range-falsification-218/pairs","neuron-mixed-interventions-219/captures"):
        assert (R/"runs"/folder).exists(),"Restore original hash-bound inputs: "+folder
    archive=R/".context/reproduction-221-archive";assert not archive.exists();archive.mkdir(parents=True)
    for path in (R/"docs/analysis").glob("221*.json"):shutil.move(path,archive/path.name)
    env=dict(os.environ,HF_HUB_OFFLINE="1",TRANSFORMERS_OFFLINE="1",OMP_NUM_THREADS="1",VECLIB_MAXIMUM_THREADS="1",PYTHONPATH="src:scripts")
    for c,v in commands:subprocess.run([sys.executable,"scripts/"+c,*v],cwd=R,env=env,check=True)
    print("Registered retrospective sequence completed. Retain raw ideal failures, numerical caveats and the scope of each intervention.")
if __name__=="__main__":main()
