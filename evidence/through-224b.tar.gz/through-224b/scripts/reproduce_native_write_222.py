"""Verify the preserved write ledger, or repeat its registered retrospective sequence."""

import argparse,hashlib,json,os,shutil,subprocess,sys
from pathlib import Path
R=Path(__file__).resolve().parents[1]
def main():
    p=argparse.ArgumentParser();p.add_argument("--verify-only",action="store_true");p.add_argument("--plan",action="store_true");a=p.parse_args()
    obj=json.loads((R/"results/native-write-ledger-222/manifest.json").read_text())
    for rel,h in obj["files"].items():assert hashlib.sha256((R/rel).read_bytes()).hexdigest()==h,rel
    print(f"Verified {len(obj['files'])} preserved files; zero model calls for verification.",flush=True)
    commands=["run_native_write_ledger_222.py","audit_native_write_ledger_222.py","plot_native_write_222.py"]
    if a.plan:print(json.dumps(dict(commands=["scripts/"+c for c in commands],contexts_ledger=64,contexts_causal=32,
        prerequisites="Pinned offline Qwen/MPS runtime and all original hash-bound 208 forecasts, 221 pairs, 219 frozen selection and prerequisite closure files.",
        selection="Two operations ranked on chalice/gimbal; selection sealed before causal models on larch/marzipan. All are old examples.",
        scope="Native finite write knockouts and fixed-plane rescues; no original whole-block JVP, prospective prediction or learned-circuit identification.",
        verification_is_not="A second executed model replication."),indent=2))
    if a.plan or a.verify_only:return
    assert not (R/"runs/native-write-ledger-222").exists(),"Use a fresh checkout; preserve the canonical run."
    for rel in ("runs/source-receiver-partition-208/forecasts","runs/native-receiver-factorial-221/pairs","runs/neuron-mixed-interventions-219/selection.json"):
        assert (R/rel).exists(),"Restore original hash-bound inputs: "+rel
    archive=R/".context/reproduction-222-archive";assert not archive.exists();archive.mkdir(parents=True)
    for path in (R/"docs/analysis").glob("222*.json"):shutil.move(path,archive/path.name)
    env=dict(os.environ,HF_HUB_OFFLINE="1",TRANSFORMERS_OFFLINE="1",OMP_NUM_THREADS="1",VECLIB_MAXIMUM_THREADS="1",PYTHONPATH="src:scripts")
    for c in commands:subprocess.run([sys.executable,"scripts/"+c],cwd=R,env=env,check=True)
    print("Registered native sequence completed. Keep every failed causal gate, original derivative caveats and measured-rounding qualification.")
if __name__=="__main__":main()
