"""Verify the bundle or repeat 219 against its original hash-bound retrospective inputs."""

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]


def main():
    p=argparse.ArgumentParser();p.add_argument("--verify-only",action="store_true");p.add_argument("--plan",action="store_true");args=p.parse_args()
    obj=json.loads((ROOT/"results/neuron-mixed-interventions-219/manifest.json").read_text())
    for rel,h in obj["files"].items():assert hashlib.sha256((ROOT/rel).read_bytes()).hexdigest()==h,rel
    print(f"Verified {len(obj['files'])} preserved files; zero model calls for verification.",flush=True)
    commands=["run_neuron_mixed_219.py","audit_neuron_mixed_219.py","plot_neuron_mixed_219.py"]
    if args.plan:
        print(json.dumps(dict(commands=["scripts/"+c for c in commands],contexts=64,
            prerequisites="Compatible pinned offline model/runtime AND original hash-bound raw 208, 215 and 218 input dataset. Restore original parents before this replay; this wrapper does not regenerate or silently rebind historical inputs.",
            scope="Retrospective native/forecast neuron products, gate/up crosses and fixed-mask product interventions. Original whole-block Jacobian remains unqualified. No fresh prediction or learned feature claim.",
            operations=dict(blocks=704,direct_down=2048,finite_heads=4864,reverse_heads=64),
            presentation="Build_neuron_mixed_canvas_219.py is an optional separate managed-workspace presentation step.",
            verification_is_not="A second executed model replication."),indent=2))
    if args.plan or args.verify_only:return
    assert not (ROOT/"runs/neuron-mixed-interventions-219").exists(),"Use a fresh checkout; preserve the original run."
    for rel in ("runs/source-receiver-partition-208/forecasts","runs/matched-incoming-control-215/pairs","runs/silu-range-falsification-218/pairs"):
        assert (ROOT/rel).exists(),"Restore the original hash-bound input dataset: "+rel
    archive=ROOT/".context/reproduction-219-archive";assert not archive.exists();archive.mkdir(parents=True)
    for path in (ROOT/"docs/analysis").glob("219*.json"):shutil.move(path,archive/path.name)
    env=dict(os.environ,HF_HUB_OFFLINE="1",TRANSFORMERS_OFFLINE="1",OMP_NUM_THREADS="1",VECLIB_MAXIMUM_THREADS="1",PYTHONPATH="src:scripts")
    for name in commands:subprocess.run([sys.executable,"scripts/"+name],cwd=ROOT,env=env,check=True)
    print("219 repeat completed against the original dataset. Inspect numerical qualification and the compact-account gate; completion is not prospective prediction.")


if __name__=="__main__":main()
