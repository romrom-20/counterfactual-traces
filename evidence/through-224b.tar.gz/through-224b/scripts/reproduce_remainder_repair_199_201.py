"""Regenerate full193trajectories, then immutable199diagnosis and201heldout repair."""

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BUNDLE = ROOT / "results/remainder-repair-199-201"
COMMANDS = (
    "run_single_state_native_response_193.py",
    "recheck_single_state_native_response_193.py",
    "audit_single_state_native_response_193.py",
    "run_layerwise_nonlinear_remainder_199.py",
    "audit_layerwise_nonlinear_remainder_199.py",
    "report_layerwise_nonlinear_remainder_199.py",
    "plot_layerwise_remainder_199.py",
    "run_discovery_ranked_repair_201.py",
    "recheck_discovery_ranked_repair_201.py",
    "audit_discovery_ranked_repair_201.py",
    "report_discovery_ranked_repair_201.py",
    "build_remainder_repair_canvas_199_201.py",
)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--verify-only", action="store_true")
    parser.add_argument("--plan", action="store_true")
    args = parser.parse_args()
    manifest = json.loads((BUNDLE / "manifest.json").read_text())
    for path, expected in manifest["files"].items():
        assert hashlib.sha256((ROOT / path).read_bytes()).hexdigest() == expected, path
    import run_discovery_ranked_repair_201 as repair
    import run_layerwise_nonlinear_remainder_199 as discovery

    for stage, module in ((199, discovery), (201, repair)):
        design = json.loads((BUNDLE / f"provenance/{stage}-design.json").read_text())
        assert module.source_hash() == design["design"]["source_hash"]
    for stem in ("ranked_block_response", "public_ranked_block_response"):
        assert (ROOT / f"scripts/{stem}_200.py").read_bytes() == (
            ROOT / f"scripts/{stem}_201.py"
        ).read_bytes()
    print(
        f"Verified {len(manifest['files'])} files, scientific source hashes and helper aliases; no model calls."
    )
    if args.verify_only:
        return
    if args.plan:
        print(
            json.dumps(
                {
                    "historical_seed": 191,
                    "commands": list(COMMANDS),
                    "ordinary_full_model_calls": 544,
                    "differentiated_full_model_calls": 256,
                    "local_block_ad_calls": 11456,
                    "local_head_and_finite_calls_separate": True,
                    "new201fingerprint_can_change": "Parent audit SHA includes fresh execution timestamps; sources/selection/methods fixed.",
                },
                indent=2,
            )
        )
        return
    for folder in (
        "single-state-native-response-193",
        "layerwise-nonlinear-remainder-199",
        "discovery-ranked-repair-201",
    ):
        if (ROOT / "runs" / folder).exists():
            raise RuntimeError(f"Use a clean checkout; refusing to overwrite {folder}.")
    seed = BUNDLE / "prerequisites/191"
    for src, rel in json.loads((seed / "index.json").read_text()).items():
        source, destination = seed / src, ROOT / rel
        if destination.exists():
            if destination.read_bytes() != source.read_bytes():
                raise RuntimeError(f"Different historical prerequisite already exists: {rel}")
        else:
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(source, destination)
    env = {
        **os.environ,
        "PYTHONPATH": os.pathsep.join((str(ROOT / "src"), str(ROOT / "scripts"))),
        "HF_HUB_OFFLINE": "1",
        "TRANSFORMERS_OFFLINE": "1",
    }
    for filename in COMMANDS:
        print(f"Executing {filename}", flush=True)
        subprocess.run(
            [sys.executable, "-u", str(ROOT / "scripts" / filename)], cwd=ROOT, env=env, check=True
        )


if __name__ == "__main__":
    main()
