"""Verify the preservation closure, or regenerate the bounded offline pipeline."""

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
COMMANDS=["run_gate_up_arithmetic_213.py","audit_gate_up_arithmetic_213.py",
          "run_rms_product_factorial_212b.py","audit_rms_product_factorial_212b.py",
          "run_last_block_transfer_214.py","audit_last_block_transfer_214b.py",
          "run_matched_incoming_control_215.py","audit_matched_incoming_control_215.py",
          "describe_matched_state_signs_215b.py","describe_schema_regimes_215c.py","plot_rms_product_transfer_212_214.py"]
RUNS=["gate-up-arithmetic-213","rms-product-factorial-212b","last-block-transfer-214","matched-incoming-control-215"]


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--verify-only",action="store_true")
    parser.add_argument("--plan",action="store_true")
    args=parser.parse_args()
    bundle=json.loads((ROOT/"results/rms-product-transfer-212-215/manifest.json").read_text())
    for name,expected in bundle["files"].items():
        assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==expected,name
    print(f"Verified {len(bundle['files'])} preserved files; zero model calls for verification.",flush=True)
    if args.plan:
        print(json.dumps(dict(
            commands=["scripts/"+c for c in COMMANDS],
            prerequisite="Pinned offline weights plus genuine204/qualified209c/211rawpairs and old208forecasts/observations; absentparentsregeneratedbythepreservedearlierpipeline.",
            historical_failures="Original212serialization and214auditorcount failures archived, notrerunassuccess. AlloriginalJacobianandrawmixedequalityfailuresremainfailures.",
            scope="Retrospective/oracletests; only213arithmeticanddefinedfiniteinterventionsqualified. Noaccuracy,circuitorQuestionBsolutionclaim.",
            presentation="Run build_rms_product_canvas_212_215.py separately in the original managed workspace if desired.",
            verification_is_not="Asecondexecutedendtoendmodelreplication."),indent=2))
    if args.plan or args.verify_only:return
    assert all(not (ROOT/"runs"/n).exists() for n in RUNS),"Use a fresh checkout; preserve original runs."
    env=dict(os.environ,HF_HUB_OFFLINE="1",TRANSFORMERS_OFFLINE="1",OMP_NUM_THREADS="1",VECLIB_MAXIMUM_THREADS="1",PYTHONPATH="src:scripts")
    def call(name,*arguments):
        subprocess.run([sys.executable,"scripts/"+name,*arguments],cwd=ROOT,env=env,check=True)
    archive=ROOT/".context/reproduction-212-215-archive"
    assert not archive.exists();archive.mkdir(parents=True)
    # Preserve recorded reports before fresh computations create files with the same names.
    for pattern in ("212*.json","213*.json","214*.json","215*.json"):
        for path in (ROOT/"docs/analysis").glob(pattern):shutil.move(path,archive/path.name)
    if not (ROOT/"runs/block28-primitive-211/pairs").exists():
        call("reproduce_block28_primitives_210_211.py")
    if not (ROOT/"runs/source-receiver-partition-208/forecasts").exists():
        # The previous step establishes genuine204 and qualified209c prerequisites.
        for name in ("208-source-receiver-partition.json","208-error-comparisons.json"):
            p=ROOT/"docs/analysis"/name
            if p.exists():shutil.move(p,archive/name)
        call("run_source_receiver_partition_208.py")
        call("audit_source_receiver_partition_208.py")
        call("describe_partition_errors_208d.py")
    for name in COMMANDS:call(name)
    print("Bounded pipeline completed. Inspect every numerical qualification and failed accuracy endpoint; completion does not turn failures into successes.")


if __name__=="__main__":main()
