"""Verify the preservation closure or regenerate the registered SiLU test offline."""

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--verify-only", action="store_true")
    p.add_argument("--plan", action="store_true")
    args = p.parse_args()
    obj = json.loads((ROOT / "results/silu-range-falsification-218/manifest.json").read_text())
    for rel, expected in obj["files"].items():
        assert hashlib.sha256((ROOT / rel).read_bytes()).hexdigest() == expected, rel
    print(f"Verified {len(obj['files'])} preserved files; zero model calls for verification.", flush=True)
    commands = ["run_silu_range_falsification_218.py", "audit_silu_range_falsification_218.py", "plot_silu_range_218.py"]
    if args.plan:
        print(json.dumps(dict(commands=["scripts/" + c for c in commands], contexts=64,
            conditions="Native/forecast input × affine/finite SiLU × affine/finite product; finite MLP-input RMSNorm, attention False-affine.",
            prerequisite="Pinned offline weights and raw 208/215 parents; missing parents regenerated using the preserved 212–215 pipeline.",
            boundary="Retrospective SiLU replacement. Not range clipping alone, a native learned circuit or a prospective predictor.",
            verification_is_not="A second executed end-to-end model replication.",
            presentation="Run build_silu_range_canvas_218.py separately in the original managed workspace."), indent=2))
    if args.plan or args.verify_only:
        return
    assert not (ROOT / "runs/silu-range-falsification-218").exists(), "Use a fresh checkout; preserve the original run."
    env = dict(os.environ, HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1", OMP_NUM_THREADS="1",
               VECLIB_MAXIMUM_THREADS="1", PYTHONPATH="src:scripts")
    def call(name):
        subprocess.run([sys.executable, "scripts/" + name], cwd=ROOT, env=env, check=True)
    archive = ROOT / ".context/reproduction-218-archive"
    assert not archive.exists()
    archive.mkdir(parents=True)
    for path in (ROOT / "docs/analysis").glob("218*.json"):
        shutil.move(path, archive / path.name)
    if not (ROOT / "runs/matched-incoming-control-215/pairs").exists():
        call("reproduce_rms_product_212_215.py")
    assert (ROOT / "runs/source-receiver-partition-208/forecasts").exists(), "Restore or reproduce 208 parents."
    for command in commands:
        call(command)
    print("Registered test and saved-array audit completed. Preserve all failed accuracy and raw mixed-term checks.")


if __name__ == "__main__":
    main()
