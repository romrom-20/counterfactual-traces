"""Verify preservation or repeat the sealed fresh-context local hypothesis test."""

import argparse,hashlib,json,os,shutil,subprocess,sys
from pathlib import Path
R=Path(__file__).resolve().parents[1]
def main():
    p=argparse.ArgumentParser();p.add_argument("--verify-only",action="store_true");p.add_argument("--plan",action="store_true");a=p.parse_args()
    obj=json.loads((R/"results/source-only-neurons-220/manifest.json").read_text())
    for rel,h in obj["files"].items():assert hashlib.sha256((R/rel).read_bytes()).hexdigest()==h,rel
    print(f"Verified {len(obj['files'])} preserved files; zero model calls for verification.",flush=True)
    commands=["run_source_only_neurons_220.py","audit_source_only_neurons_220.py","plot_source_only_neurons_220.py"]
    if a.plan:print(json.dumps(dict(commands=["scripts/"+c for c in commands],contexts=16,
        prerequisites="Compatible MPS dependencies and pinned offline model; restore original 219 selection.json and historical paired-forecast metadata for the freshness catalog. No historical raw True array is needed by this new predictor.",
        ordering="ALL False-only S/P forecasts and numerical checks seal before ANY ordinary True forward. No full-finite True control during prediction.",
        scope="Selected-group local response in an attention-affine surrogate; not full native behavioral prediction or a learned feature.",
        verification_is_not="A second end-to-end model replication."),indent=2))
    if a.plan or a.verify_only:return
    assert not (R/"runs/source-only-neurons-220").exists(),"Use a fresh checkout; preserve the original run."
    assert (R/"runs/neuron-mixed-interventions-219/selection.json").exists(),"Restore the original frozen mask as input metadata."
    assert (R/"runs/source-receiver-partition-208/forecasts").exists(),"Restore historical paired-forecast metadata for the input catalog."
    archive=R/".context/reproduction-220-archive";assert not archive.exists();archive.mkdir(parents=True)
    for path in (R/"docs/analysis").glob("220*.json"):shutil.move(path,archive/path.name)
    env=dict(os.environ,HF_HUB_OFFLINE="1",TRANSFORMERS_OFFLINE="1",OMP_NUM_THREADS="1",VECLIB_MAXIMUM_THREADS="1",PYTHONPATH="src:scripts")
    for name in commands:subprocess.run([sys.executable,"scripts/"+name],cwd=R,env=env,check=True)
    print("Registered fresh local test repeated. Keep hypothesis rejection and all numerical failures; do not interpret execution as success.")
if __name__=="__main__":main()
