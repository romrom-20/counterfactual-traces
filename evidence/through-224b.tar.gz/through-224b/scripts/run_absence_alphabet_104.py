#!/usr/bin/env python3
"""104/105: factorial absence markers, with a simultaneously frozen confirmation."""
import argparse
import gc
import json
import os
import platform
import re
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

import torch
import transformers

from latent_decisions import evidence_policy as core
from latent_decisions.target import load_target

ROOT = Path(__file__).resolve().parents[1]
DEFAULT = ROOT / 'runs/absence-alphabet-104-105'
LABELS = ('negative', 'neutral', 'positive', 'insufficient')
RULE = ("Classify the author's expressed opinion about the target aspect. "
        "Praise is positive; criticism is negative; an explicitly neutral opinion is neutral. "
        "A mere fact about the target or an opinion about another aspect is insufficient. "
        "Insufficient evidence is different from an explicitly neutral opinion. "
        "Use only the supplied review.")
MODELS = {
    'granite2': {'model': 'ibm-granite/granite-3.1-2b-instruct', 'revision': 'bbc2aed595bd38bd770263dc3ab831db9794441d'},
    'qwen15': {'model': 'Qwen/Qwen2.5-1.5B-Instruct', 'revision': '989aa7980e4cf806f80c7fef2b1adb7bc71aa306'},
}
BOOKS = {f'{alphabet}-{absence}': dict(zip(LABELS, (*values, marker)))
         for alphabet, values in [('semantic', LABELS[:3]), ('numeric', (1., 5., 9.))]
         for absence, marker in [('json_null', None), ('string_null', 'null'), ('insufficient', 'insufficient')]}
BOOKS.update(legacy_numeric=dict(zip(LABELS, (1., 5., 9., None))),
             legacy_semantic=dict(zip(LABELS, LABELS)))


def now():
    return datetime.now(timezone.utc).isoformat()


def arms(stage):
    return list(BOOKS) if stage == '104' else [a for a in BOOKS if not a.startswith('legacy')]


def dataset():
    rows = []
    for i, (aspect, other) in enumerate([('zipper', 'seam'), ('battery', 'charger'),
                                       ('sauce', 'crust'), ('screen', 'bezel')]):
        texts = {'negative': f'I dislike the {aspect}; it is bad.',
                 'neutral': f'My opinion of the {aspect} is neutral, neither good nor bad.',
                 'positive': f'I like the {aspect}; it is good.',
                 'fact': f'The {aspect} has an entry in the item list.'}
        for state, text in texts.items():
            if i % 2:
                text = f'My opinion of the {other} is neutral. ' + text
            rows.append({'id': f'104-{i}-{state}', 'stage': '104', 'block': f'104-{i}',
                         'aspect': aspect, 'state': state, 'review': text,
                         'gold_category': state if state in LABELS[:3] else 'insufficient'})
    pairs = [('handle', 'lid'), ('bridge', 'fretboard'), ('collar', 'cuff'), ('cover', 'spine'),
             ('drawer', 'knob'), ('deck', 'railing'), ('kernel', 'husk'), ('frame', 'mat')]
    facts = ['The parts index assigns the {a} reference K27.', 'The diagram labels the {a} with a letter.',
             'The inventory includes a separate line for the {a}.', 'The {a} appears on page twelve of the guide.',
             'The printed list names the {a} after the fasteners.', 'A pointer in the drawing identifies the {a}.',
             'The index places the {a} in section three.', 'The catalogue gives the {a} an identification number.']
    for i, (aspect, other) in enumerate(pairs):
        texts = {'negative': f'The {aspect} disappointed me; I am unhappy with it.' if i % 2 else f'I object to the {aspect} and think poorly of it.',
                 'neutral': f'I feel neither favorably nor unfavorably about the {aspect}.' if i % 2 else f'As for the {aspect}, my assessment is neutral.',
                 'positive': f'The {aspect} pleased me; I am happy with it.' if i % 2 else f'I approve of the {aspect} and think highly of it.',
                 'empty': '[No review supplied]', 'fact': facts[i].format(a=aspect),
                 'other_opinion': f'I am delighted with the {other}.' if i % 2 else f'I am disappointed with the {other}.'}
        for state, text in texts.items():
            rows.append({'id': f'105-{i}-{state}', 'stage': '105', 'block': f'105-{i}',
                         'aspect': aspect, 'state': state, 'review': text,
                         'gold_category': state if state in LABELS[:3] else 'insufficient'})
    return rows


def messages(row, arm):
    if arm == 'legacy_numeric':
        instruction = ('Convert the category to its code: negative=1.0, neutral=5.0, positive=9.0, '
                       'insufficient=null. Return exactly one JSON object with key answer and that code.')
    elif arm == 'legacy_semantic':
        instruction = ('Return exactly one JSON object with key answer and one of the string values '
                       '"negative", "neutral", "positive", or "insufficient".')
    else:
        instruction = ('Map the category to its output value using this JSON mapping: ' +
                       json.dumps(BOOKS[arm]) + '. Return exactly one JSON object with key answer and that value.')
    return [{'role': 'system', 'content': RULE}, {'role': 'user', 'content':
            f"Target aspect: {row['aspect']}\nReview: {row['review']}\n{instruction}"}]


def unique_pairs(pairs):
    obj = {}
    for key, value in pairs:
        if key in obj:
            raise ValueError('Duplicate JSON key')
        obj[key] = value
    return obj


def reject_constant(value):
    raise ValueError(value)


def parse(raw, arm):
    match = re.fullmatch(r'```(?:json)?\s*(.*?)\s*```', raw.strip(), re.S)
    try:
        obj = json.loads(match[1] if match else raw, object_pairs_hook=unique_pairs, parse_constant=reject_constant)
    except ValueError:
        return False, None, None
    if not isinstance(obj, dict) or set(obj) != {'answer'}:
        return False, None, None
    value = obj['answer']
    for label, expected in BOOKS[arm].items():
        same_type = (type(value) is type(expected) or
                     type(value) in (int, float) and type(expected) in (int, float))
        if same_type and value == expected:
            return True, label, value
    return False, None, value


def source_hash():
    paths = [Path(__file__), ROOT / 'docs/experiments/104-105-absence-alphabet.md',
             ROOT / 'src/latent_decisions/evidence_policy.py', ROOT / 'src/latent_decisions/target.py']
    return core.digest({str(p.relative_to(ROOT)): p.read_text() for p in paths})


def prepare(run):
    path = run / 'design.json'
    if path.exists():
        result = json.loads(path.read_text())
        if result['fingerprint'] != core.digest(result['design']) or result['design']['source_hash'] != source_hash():
            raise ValueError('Frozen source/design changed')
        return result
    design = {'created_utc': now(), 'rows': dataset(), 'books': BOOKS, 'models': MODELS,
              'source_hash': source_hash(), 'bootstrap_samples': 5000, 'bootstrap_seed': 10401,
              'max_new_tokens': 80, 'max_prompt_tokens': 2048,
              'absence_gain': .25, 'within_alphabet_gain': .15, 'opinion_floor': .90,
              'opinion_drop_limit': .05, 'secondary_gain': .15}
    result = {'design': design, 'fingerprint': core.digest(design)}
    core.write_json(path, result)
    return result


def read_records(run, name, bundle):
    expected = {r['id'] for r in bundle['design']['rows']}
    records = {}
    runtime_path = run / name / 'runtime.json'
    runtime_hash = core.digest(json.loads(runtime_path.read_text())) if runtime_path.exists() else None
    for path in (run / name / 'records').glob('*.json'):
        envelope = json.loads(path.read_text())
        r = envelope['record']
        if (envelope['sha256'] != core.digest(r) or r['fingerprint'] != bundle['fingerprint'] or
                r['runtime_hash'] != runtime_hash or r['id'] not in expected or r['id'] in records):
            raise ValueError('Record integrity failure')
        records[r['id']] = r
    return records


def mean(values):
    return sum(values) / len(values)


def summarize(rows, records, design):
    stage = rows[0]['stage']
    def correct(row, arm):
        output = records[row['id']]['outputs'][arm]
        return output['valid'] and output['category'] == row['gold_category']
    stats = {}
    for arm in arms(stage):
        stats[arm] = {'accuracy': mean([correct(r, arm) for r in rows]),
                      'invalid': sum(not records[r['id']]['outputs'][arm]['valid'] for r in rows),
                      'by_state': {s: mean([correct(r, arm) for r in rows if r['state'] == s])
                                   for s in sorted({r['state'] for r in rows})}}
        for kind in ('absence', 'opinion'):
            subset = [r for r in rows if (r['gold_category'] == 'insufficient') == (kind == 'absence')]
            stats[arm][kind + '_accuracy'] = mean([correct(r, arm) for r in subset])
    contrasts = {}
    for kind in ('absence', 'opinion'):
        for first, second in [('json_null', 'insufficient'), ('json_null', 'string_null'), ('string_null', 'insufficient')]:
            key = f'{kind}:{first}-minus-{second}'
            blocks = []
            for block in sorted({r['block'] for r in rows}):
                subset = [r for r in rows if r['block'] == block and
                          (r['gold_category'] == 'insufficient') == (kind == 'absence')]
                blocks.append(mean([int(correct(r, f'{a}-{first}')) - int(correct(r, f'{a}-{second}'))
                                    for r in subset for a in ('semantic', 'numeric')]))
            contrasts[key] = core.bootstrap(blocks, design)
    primary = contrasts['absence:json_null-minus-insufficient']
    opinion_delta = contrasts['opinion:json_null-minus-insufficient']['estimate']
    null_opinion = mean([stats[a+'-json_null']['opinion_accuracy'] for a in ('semantic', 'numeric')])
    gains = {a: stats[a+'-json_null']['absence_accuracy'] - stats[a+'-insufficient']['absence_accuracy']
             for a in ('semantic', 'numeric')}
    supports = (primary['estimate'] >= design['absence_gain'] and primary['ci95'][0] > 0 and
                min(gains.values()) >= design['within_alphabet_gain'] and null_opinion >= design['opinion_floor'] and
                opinion_delta >= -design['opinion_drop_limit'])
    hybrid = stats['semantic-json_null']
    baseline = max(stats['numeric-json_null']['accuracy'], stats['semantic-insufficient']['accuracy'])
    return {'reviews': len(rows), 'by_arm': stats, 'contrasts': contrasts, 'absence_gain_by_alphabet': gains,
            'supports_absence_representation_effect': bool(supports),
            'hybrid_gain_over_stronger_baseline': hybrid['accuracy'] - baseline,
            'hybrid_practical_pass': bool(hybrid['accuracy'] >= .90 and min(hybrid['by_state'].values()) >= .75 and
                                         hybrid['accuracy'] - baseline >= .10)}


def analyze_and_audit(run, name, stage, bundle):
    records = read_records(run, name, bundle)
    rows = [r for r in bundle['design']['rows'] if r['stage'] == stage]
    if not all(r['id'] in records for r in rows):
        raise ValueError('Stage incomplete')
    count = invalid = 0
    for row in rows:
        outputs = records[row['id']]['outputs']
        if set(outputs) != set(arms(stage)):
            raise ValueError('Arm coverage mismatch')
        for arm, output in outputs.items():
            valid, category, value = parse(output['raw'], arm)
            assert (valid and not output['hit_limit'], category, value) == (output['valid'], output['category'], output['value'])
            assert output['messages'] == messages(row, arm)
            count += 1
            invalid += not output['valid']
    result = summarize(rows, records, bundle['design'])
    result.update(model=name, stage=stage, fingerprint=bundle['fingerprint'], complete=True,
                  audit={'checks': 'passed', 'records': len(rows), 'queries': count, 'invalid_outputs': invalid})
    core.write_json(run / name / f'analysis-{stage}.json', result)
    return result


def run_model(run, name, device, bundle, status):
    records = read_records(run, name, bundle)
    pending = [r for r in bundle['design']['rows'] if r['id'] not in records]
    if not pending:
        return {stage: analyze_and_audit(run, name, stage, bundle) for stage in ('104', '105')}
    model, tokenizer, actual = load_target(MODELS[name], device, offline=True)
    runtime = {'model': MODELS[name], 'device': actual, 'dtype': str(next(model.parameters()).dtype),
               'training': model.training, 'python': platform.python_version(), 'torch': torch.__version__,
               'transformers': transformers.__version__, 'penalty': 1., 'tokenizer_hash': core.digest(tokenizer.get_vocab()),
               'model_config_hash': core.digest(model.config.to_dict()), 'chat_template': tokenizer.chat_template}
    assert runtime['dtype'] == 'torch.float32' and runtime['training'] is False
    path = run / name / 'runtime.json'
    if path.exists() and json.loads(path.read_text()) != runtime:
        raise ValueError('Runtime changed')
    core.write_json(path, runtime)
    stages = {}
    for stage in ('104', '105'):
        stage_rows = [r for r in bundle['design']['rows'] if r['stage'] == stage]
        for row in stage_rows:
            if row['id'] in records:
                continue
            keys = arms(stage)
            offset = int(core.digest(row['id'])[:8], 16) % len(keys)
            outputs = {}
            for arm in keys[offset:] + keys[:offset]:
                msg = messages(row, arm)
                prefix = tokenizer.apply_chat_template(msg, tokenize=True, add_generation_prompt=True)
                if len(prefix) > bundle['design']['max_prompt_tokens']:
                    raise ValueError('Prompt exceeds budget')
                ids, raw = core.generate(model, tokenizer, prefix, 1., bundle['design']['max_new_tokens'])
                valid, category, value = parse(raw, arm)
                hit_limit = len(ids) == bundle['design']['max_new_tokens'] and ids[-1] != tokenizer.eos_token_id
                outputs[arm] = {'raw': raw, 'ids': ids, 'prompt_ids': prefix, 'messages': msg,
                                'valid': valid and not hit_limit, 'category': category, 'value': value, 'hit_limit': hit_limit}
                status.update(model=name, stage=stage, row=row['id'], arm=arm, completed_rows=len(records), updated_utc=now())
                core.write_json(run / 'pipeline-status.json', status)
            record = {'id': row['id'], 'fingerprint': bundle['fingerprint'], 'runtime_hash': core.digest(runtime), 'outputs': outputs}
            core.write_json(run / name / 'records' / f"{core.digest(row['id'])}.json", {'record': record, 'sha256': core.digest(record)})
            records[row['id']] = record
            print(f"{name} {stage} {len(records)}/{len(bundle['design']['rows'])} {row['id']}", flush=True)
        stages[stage] = analyze_and_audit(run, name, stage, bundle)
        status['results'].setdefault(name, {})[stage] = stages[stage]
        core.write_json(run / 'pipeline-status.json', status)
    del model, tokenizer
    gc.collect()
    if device == 'mps':
        torch.mps.empty_cache()
    return stages


def launch(run, device):
    with core.exclusive_lock(run / '.launch.lock'):
        bundle = prepare(run)
        path = run / 'launch.json'
        if path.exists():
            try:
                os.kill(json.loads(path.read_text())['pid'], 0)
            except ProcessLookupError:
                pass
            else:
                raise RuntimeError('Recorded process is alive; refusing duplicate launch')
        command = ['/usr/bin/caffeinate', '-i', sys.executable, '-u', str(Path(__file__).resolve()),
                   '--run', str(run.resolve()), '--device', device]
        with (run / 'pipeline.log').open('a') as log:
            process = subprocess.Popen(command, cwd=ROOT, env={**os.environ, 'PYTHONPATH': str(ROOT / 'src')},
                                       stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        receipt = {'pid': process.pid, 'command': command, 'launched_utc': now(), 'fingerprint': bundle['fingerprint']}
        core.write_json(path, receipt)
        return receipt


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', type=Path, default=DEFAULT)
    parser.add_argument('--device', choices=('mps', 'cpu'), default='mps')
    parser.add_argument('--launch', action='store_true')
    args = parser.parse_args()
    if args.launch:
        print(json.dumps(launch(args.run, args.device), indent=2))
        return
    with core.exclusive_lock(args.run / '.pipeline.lock'):
        bundle = prepare(args.run)
        status = {'status': 'running', 'started_utc': now(), 'fingerprint': bundle['fingerprint'], 'results': {},
                  'expected_queries': sum(len(arms(r['stage'])) for r in bundle['design']['rows']) * len(MODELS)}
        try:
            for name in MODELS:
                status['results'][name] = run_model(args.run, name, args.device, bundle, status)
            status.update(status='complete', updated_utc=now(),
                          replicated_effect={name: all(stage['supports_absence_representation_effect'] for stage in results.values())
                                             for name, results in status['results'].items()})
        except BaseException as exc:
            status.update(status='technical_failure', updated_utc=now(), error=repr(exc))
            core.write_json(args.run / 'pipeline-status.json', status)
            raise
        core.write_json(args.run / 'pipeline-status.json', status)
        print(json.dumps(status, indent=2), flush=True)


if __name__ == '__main__':
    main()
