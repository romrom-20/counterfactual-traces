#!/usr/bin/env python3
"""Frozen fully crossed relational binding and candidate-position score experiment."""

import argparse
import gc
import itertools
import json
import os
import subprocess
import sys
from pathlib import Path

import run_order_competence_151 as parent
import torch
from run_absence_alphabet_104 import MODELS, now

from latent_decisions import evidence_policy as core
from latent_decisions.target import load_target

ROOT = Path(__file__).resolve().parents[1]
DEFAULT = ROOT / "runs/counterbalanced-binding-155-156"
SCHEMAS = parent.SCHEMAS
BLOCKS = [
    {
        "id": "amber",
        "stage": "155",
        "subjects": ["amber", "violet"],
        "days": ["Wednesday", "Friday"],
        "old_block": "day_0",
    },
    {
        "id": "coral",
        "stage": "155",
        "subjects": ["coral", "indigo"],
        "days": ["Friday", "Monday"],
        "old_block": "day_4",
    },
    {
        "id": "azure",
        "stage": "156",
        "subjects": ["azure", "ochre"],
        "days": ["Tuesday", "Sunday"],
        "old_block": None,
    },
    {
        "id": "elm",
        "stage": "156",
        "subjects": ["elm", "ash"],
        "days": ["Saturday", "Wednesday"],
        "old_block": None,
    },
]


def jobs(block):
    result = []
    for assignment, target, candidate, reverse, schema in itertools.product(
        range(2), range(2), range(2), range(2), SCHEMAS
    ):
        base = {
            "assignment": assignment,
            "target": target,
            "candidate": candidate,
            "reverse": reverse,
            "schema": schema,
        }
        result.append({**base, "kind": "singleton"})
        result += [
            {**base, "kind": "evidence", "order": order, "clamp": bit}
            for order, bit in itertools.product(("metadata_first", "verdict_first"), (False, True))
        ]
    if block["id"] == "amber":
        result += [
            {"kind": "given", "supported": support, "schema": schema, "order": order, "clamp": bit}
            for support, schema, order, bit in itertools.product(
                (False, True), SCHEMAS, ("metadata_first", "verdict_first"), (False, True)
            )
        ]
    return sorted(result, key=core.digest)


def fixture(block, job):
    assigned = [block["days"][subject ^ job["assignment"]] for subject in (0, 1)]
    sentences = [
        f"The {subject} exhibit opened on {day}."
        for subject, day in zip(block["subjects"], assigned)
    ]
    if job["reverse"]:
        sentences.reverse()
    candidate_subject = job["candidate"] ^ job["assignment"]
    return {
        "contexts": [" ".join(sentences)] * 2,
        "candidate": block["days"][job["candidate"]],
        "questions": [f"On which day did the {block['subjects'][job['target']]} exhibit open?"],
    }, {
        "supported": candidate_subject == job["target"],
        "candidate_last": candidate_subject != job["reverse"],
    }


def messages(block, job):
    if job["kind"] == "given":
        return parent.messages({}, job)
    data, facts = fixture(block, job)
    return parent.messages(data, {**job, "supported": facts["supported"]})


def selected_generation(job):
    if job["kind"] == "given":
        return True
    canonical = job["assignment"] == job["target"] == job["reverse"] == 0 and job["candidate"] == 1
    return canonical and (
        job["kind"] == "singleton" or job["order"] == "metadata_first" or job["clamp"] is False
    )


def source_hash():
    return core.digest(
        {
            "runner": Path(__file__).read_text(),
            "protocol": (ROOT / "docs/experiments/155-156-counterbalanced-binding.md").read_text(),
            "dependencies": parent.source_hash(),
        }
    )


def prepare(run):
    pb = parent.prepare(parent.DEFAULT)
    audit = json.loads((ROOT / "docs/analysis/151-152-independent-audit.json").read_text())
    numerical = json.loads((ROOT / "docs/analysis/151-152-numerical-recheck.json").read_text())
    assert (
        audit["complete"]
        and numerical["passed"]
        and audit["fingerprint"] == numerical["fingerprint"] == pb["fingerprint"]
    )
    assert json.loads((parent.DEFAULT / "pipeline-status.json").read_text())["status"] == "complete"
    d = {
        "models": MODELS,
        "blocks": BLOCKS,
        "schemas": SCHEMAS,
        "source_hash": source_hash(),
        "parent_fingerprint": pb["fingerprint"],
        "records_per_model": 656,
        "forwards_per_model": 524,
        "generations_per_model": 48,
        "effect_tolerance": 0.25,
        "dominance": 0.75,
        "bridge_tolerance": 0.05,
        "recheck_tolerance": 0.005,
    }
    path = run / "design.json"
    if path.exists():
        b = json.loads(path.read_text())
        assert b["design"] == d and core.digest(d) == b["fingerprint"]
        return b
    b = {"design": d, "fingerprint": core.digest(d), "created_utc": now()}
    core.write_json(path, b)
    return b


def cache_key(ids, false_id, true_id):
    return core.digest([ids, false_id, true_id])


def run_model(run, name, bundle, status):
    model, tok, device = load_target(MODELS[name], "mps", offline=True)
    rt = parent.runtime(model, tok, device, name)
    assert rt == json.loads((parent.DEFAULT / name / "runtime.json").read_text())
    core.write_json(run / name / "runtime.json", rt)
    old = {}
    for path in (parent.DEFAULT / name / "records").glob("*.json"):
        e = json.loads(path.read_text())
        r = e["record"]
        assert (
            core.digest(r) == e["sha256"]
            and r["fingerprint"] == bundle["design"]["parent_fingerprint"]
        )
        old[r["block"], core.digest(r["job"])] = r
    cache, forwards, generations, replay_count, done = {}, 0, 0, 0, 0
    for block in BLOCKS:
        for job in jobs(block):
            rid = core.digest([block["id"], job])
            path = run / name / "records" / f"{rid}.json"
            if path.exists():
                e = json.loads(path.read_text())
                r = e["record"]
                assert core.digest(r) == e["sha256"] and r["fingerprint"] == bundle["fingerprint"]
                assert r["runtime_hash"] == core.digest(rt)
            else:
                msgs = messages(block, job)
                prefix = tok.apply_chat_template(msgs, tokenize=True, add_generation_prompt=True)
                assert len(prefix) <= 2048
                cs = [list(c) for c in parent.choices(job)]
                seqs = core.token_sequences(tok, cs)
                assert len(seqs[0]) == len(seqs[1])
                free = [i for i, (f, t) in enumerate(zip(*seqs)) if f != t]
                assert len(free) == 1
                index = free[0]
                fid, tid = seqs[0][index], seqs[1][index]
                inputs = prefix + seqs[0][:index]
                ck = cache_key(inputs, fid, tid)
                if ck in cache:
                    margin, first_record = cache[ck]
                    executed = False
                else:
                    margin = parent.forward(model, inputs, fid, tid)
                    first_record = rid
                    executed = True
                verdict = margin["true_score"] > margin["false_score"] or (
                    margin["true_score"] == margin["false_score"] and tid < fid
                )
                completion = seqs[int(verdict)]
                public = None
                if selected_generation(job):
                    ids, raw, gm = parent.scorer.generate_scores(model, tok, prefix, seqs)
                    assert ids == completion and max(abs(gm[k] - margin[k]) for k in margin) <= 0.05
                    public = {"ids": ids, "raw": raw, "margin": gm}
                    if job["kind"] == "given":
                        assert verdict == job["supported"]
                replay = None
                if (
                    block["old_block"]
                    and job["kind"] != "given"
                    and job["target"] == job["reverse"] == 0
                    and job["candidate"] == 1
                ):
                    oj = {
                        "kind": job["kind"],
                        "supported": bool(job["assignment"]),
                        "schema": job["schema"],
                    }
                    if job["kind"] != "singleton":
                        oj.update(order=job["order"], clamp=job["clamp"])
                    o = old[block["old_block"], core.digest(oj)]
                    assert (
                        msgs == o["messages"]
                        and inputs == o["free_input_ids"]
                        and margin == o["forward_margin"]
                    )
                    replay = {
                        "block": block["old_block"],
                        "job": oj,
                        "record_sha256": core.digest(o),
                    }
                facts = (
                    {"supported": job["supported"]}
                    if job["kind"] == "given"
                    else fixture(block, job)[1]
                )
                r = {
                    "block": block["id"],
                    "stage": block["stage"],
                    "job": job,
                    "facts": facts,
                    "messages": msgs,
                    "prompt_ids": prefix,
                    "choices": cs,
                    "sequences": seqs,
                    "free_index": index,
                    "free_input_ids": inputs,
                    "false_token": fid,
                    "true_token": tid,
                    "margin": margin,
                    "forward_choice": bool(verdict),
                    "derived_ids": completion,
                    "derived_raw": tok.decode(completion, skip_special_tokens=True),
                    "cache_key": ck,
                    "first_forward_record": first_record,
                    "forward_executed": executed,
                    "public_generation": public,
                    "old_replay": replay,
                    "runtime_hash": core.digest(rt),
                    "fingerprint": bundle["fingerprint"],
                }
                core.write_json(path, {"record": r, "sha256": core.digest(r)})
            ck = r["cache_key"]
            if r["forward_executed"]:
                assert ck not in cache
                cache[ck] = (r["margin"], rid)
                forwards += 1
            else:
                assert cache[ck] == (r["margin"], r["first_forward_record"])
            generations += int(r["public_generation"] is not None)
            replay_count += int(r["old_replay"] is not None)
            done += 1
            status.update(
                model=name,
                records=done,
                forwards=forwards,
                generations=generations,
                old_replays=replay_count,
                updated_utc=now(),
            )
            core.write_json(run / "pipeline-status.json", status)
            if done % 16 == 0:
                print(name, done, "/656", forwards, "forwards", flush=True)
    assert (done, forwards, generations, replay_count) == (656, 524, 48, 40)
    del model, tok
    gc.collect()
    torch.mps.empty_cache()


def launch(run):
    with core.exclusive_lock(run / ".launch.lock"):
        bundle = prepare(run)
        receipt = run / "launch.json"
        if receipt.exists():
            try:
                os.kill(json.loads(receipt.read_text())["pid"], 0)
            except ProcessLookupError:
                pass
            else:
                raise RuntimeError("Already running")
        with (run / "pipeline.log").open("a") as log:
            p = subprocess.Popen(
                [
                    "/usr/bin/caffeinate",
                    "-i",
                    sys.executable,
                    "-u",
                    str(Path(__file__).resolve()),
                    "--run",
                    str(run.resolve()),
                ],
                cwd=ROOT,
                env={**os.environ, "PYTHONPATH": str(ROOT / "src")},
                stdin=subprocess.DEVNULL,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
        value = {"pid": p.pid, "fingerprint": bundle["fingerprint"], "launched_utc": now()}
        core.write_json(receipt, value)
        return value


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--run", type=Path, default=DEFAULT)
    p.add_argument("--launch", action="store_true")
    args = p.parse_args()
    if args.launch:
        print(json.dumps(launch(args.run)))
        return
    with core.exclusive_lock(args.run / ".pipeline.lock"):
        b = prepare(args.run)
        status = {"status": "running", "started_utc": now(), "fingerprint": b["fingerprint"]}
        try:
            for name in MODELS:
                run_model(args.run, name, b, status)
            status.update(status="complete", updated_utc=now())
        except BaseException as exc:
            status.update(status="technical_failure", error=repr(exc), updated_utc=now())
            core.write_json(args.run / "pipeline-status.json", status)
            raise
        core.write_json(args.run / "pipeline-status.json", status)


if __name__ == "__main__":
    main()
