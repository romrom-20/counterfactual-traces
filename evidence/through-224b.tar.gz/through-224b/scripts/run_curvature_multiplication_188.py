"""Shared-C bit gain with receiving weights/norms/up branches progressively fixed."""

import argparse
import gc
import itertools
import json
import os
import subprocess
import sys
from contextlib import contextmanager
from pathlib import Path

import numpy as np
import run_natural_bit_shared_reader_181 as native
import run_shared_signed_curvature_187 as parent
import torch
from run_absence_alphabet_104 import now
from run_order_competence_151 import runtime

from latent_decisions.evidence_policy import digest, exclusive_lock, write_json
from latent_decisions.target import load_target

ROOT = Path(__file__).resolve().parents[1]
DEFAULT = ROOT / "runs/curvature-multiplication-188"
CUTS = ("live", "NW", "NWU")


def source_hash():
    return digest(
        {
            "runner": Path(__file__).read_text(),
            "protocol": (
                ROOT / "docs/experiments/188-shared-curvature-multiplication.md"
            ).read_text(),
            "parent": parent.source_hash(),
        }
    )


def prepare(run):
    pb = json.loads((parent.DEFAULT / "design.json").read_text())
    a = json.loads((ROOT / "docs/analysis/187-independent-audit.json").read_text())
    n = json.loads((ROOT / "docs/analysis/187-numerical-recheck.json").read_text())
    assert (
        a["complete"]
        and all(a["controls"].values())
        and a["numerical_qualified"]
        and n["passed"]
        and a["fingerprint"] == n["fingerprint"] == pb["fingerprint"]
        and pb["design"]["source_hash"] == parent.source_hash()
    )
    d = {
        "source_hash": source_hash(),
        "parent_fingerprint": pb["fingerprint"],
        "models": pb["design"]["models"],
        "blocks": parent.parent.blocks(),
        "cuts": list(CUTS),
        "main_forwards": 1024,
        "numerical_forwards": 64,
        "coupling_floor": 0.2,
        "retained_fraction": 0.5,
        "dominance": 0.75,
        "architectural_score_tolerance": 0.005,
        "architectural_state_shift_tolerance": 0.005,
    }
    p = run / "design.json"
    if p.exists():
        b = json.loads(p.read_text())
        assert b["design"] == d and digest(d) == b["fingerprint"]
        return b
    b = {"design": d, "fingerprint": digest(d), "created_utc": now()}
    write_json(p, b)
    return b


@contextmanager
def up_hooks(model, pos, fixed=None):
    cap, trace, handles = {}, [], []
    try:
        for site in range(1, 29):

            def hook(module, args, out, site=site):
                if fixed is not None:
                    target = torch.as_tensor(fixed[site], device=out.device)
                    assert target.shape == out[0, pos + 1 :].shape
                    changed = out.clone()
                    changed[0, pos + 1 :] = target
                    assert torch.equal(changed[:, : pos + 1], out[:, : pos + 1])
                    out = changed
                cap[f"U_{site}"] = out[0, pos + 1 :].detach().cpu().numpy().copy()
                trace.append(
                    {
                        "site": site,
                        "fixed": fixed is not None,
                        "start": pos + 1,
                        "end": out.shape[1],
                        "other_rows_identical": True,
                        "output_sha256": native.array_hash(cap[f"U_{site}"]),
                    }
                )
                return out

            handles.append(model.model.layers[site - 1].mlp.up_proj.register_forward_hook(hook))
        yield cap, trace
        assert [r["site"] for r in trace] == list(range(1, 29))
    finally:
        for handle in handles:
            handle.remove()


def run_model(run, bundle, status):
    model, tok, device = load_target(bundle["design"]["models"]["qwen15"], "mps", offline=True)
    rt = runtime(model, tok, device, "qwen15")
    assert rt == json.loads((parent.DEFAULT / "qwen15/runtime.json").read_text())
    write_json(run / "qwen15/runtime.json", rt)
    done = 0
    for index, (block, a, t, rev, schema) in enumerate(
        itertools.product(
            parent.parent.blocks(), range(2), range(2), range(2), ("generic", "descriptive")
        )
    ):
        g = native.fixture.group(block, a, t, rev, schema)
        key = digest(g)
        e = json.loads((parent.DEFAULT / "qwen15/records" / f"{key}.json").read_text())
        pr = e["record"]
        p = parent.DEFAULT / "qwen15/states" / f"{key}.npz"
        assert digest(pr) == e["sha256"] and parent.parent.hashed(p) == pr["states_sha256"]
        bases, pos = native.paired_bases(tok, block, g)
        assert pos == pr["position"]
        arrays, raw, identities, patches, caps, ups, states = {}, [], [], [], [], [], []
        with np.load(p, allow_pickle=False) as z:
            maps = {
                site: {
                    name: z[f"map_{site}_{name}"].copy()
                    for name in (
                        "center",
                        "intercept",
                        "slope",
                        "even",
                        "odd",
                        "xf",
                        "xt",
                        "yf",
                        "yt",
                    )
                }
                for site in range(1, 29)
            }
            for bit in range(2):
                with native.operators(model, pos) as (cap, ct), up_hooks(model, pos) as (uc, ut):
                    m, h = native.score(model, bases[bit])
                expected = next(
                    q["margin"] for q in pr["patches"] if (q["arm"], q["bit"]) == ("both", bit)
                )
                assert m == expected and np.array_equal(h, z[f"both_{bit}_final"])
                arrays[f"raw_{bit}_final"] = h
                arrays.update({f"raw_{bit}_{name}": v for name, v in {**cap, **uc}.items()})
                caps.append(cap)
                ups.append(uc)
                states.append(h)
                raw.append(
                    {"bit": bit, "base": bases[bit], "margin": m, "class_trace": ct, "up_trace": ut}
                )
                done += 1
            shared = {
                name: native.mean(caps[0][name], caps[1][name])
                for name in caps[0]
                if name[0] in "NW"
            }
            shared_u = {
                site: native.mean(ups[0][f"U_{site}"], ups[1][f"U_{site}"]) for site in range(1, 29)
            }
            arrays.update({f"shared_{name}": v for name, v in shared.items()})
            arrays.update({f"shared_U_{site}": v for site, v in shared_u.items()})
            for bit in range(2):
                own = {name: v for name, v in caps[bit].items() if name[0] in "NW"}
                own_u = {site: ups[bit][f"U_{site}"] for site in range(1, 29)}
                with (
                    native.operators(model, pos, own) as (cap, ct),
                    up_hooks(model, pos, own_u) as (uc, ut),
                ):
                    m, h = native.score(model, bases[bit])
                assert m == raw[bit]["margin"] and np.array_equal(h, states[bit])
                arrays[f"own_{bit}_final"] = h
                identities.append({"bit": bit, "margin": m, "class_trace": ct, "up_trace": ut})
                done += 1
            for cut, arm, bit in itertools.product(CUTS, ("paired", "even"), range(2)):
                with (
                    parent.intervene(model, pos, maps, arm, bit) as (ac, at),
                    native.operators(model, pos, shared if cut != "live" else None) as (cap, ct),
                    up_hooks(model, pos, shared_u if cut == "NWU" else None) as (uc, ut),
                ):
                    m, h = native.score(model, bases[bit])
                assert (
                    np.array_equal(h[: pos + 1], states[bit][: pos + 1])
                    and all(
                        np.array_equal(cap[f"V_{site}"], caps[bit][f"V_{site}"])
                        for site in range(1, 29)
                    )
                    and all(
                        np.array_equal(cap[f"G_{site}"], ac[f"{site}_output"])
                        for site in range(1, 29)
                    )
                )
                if cut == "live":
                    expected = next(
                        q["margin"] for q in pr["patches"] if (q["arm"], q["bit"]) == (arm, bit)
                    )
                    assert m == expected and np.array_equal(h, z[f"{arm}_{bit}_final"])
                prefix = f"{cut}_{arm}_{bit}"
                arrays[f"{prefix}_final"] = h
                arrays.update({f"{prefix}_{name}": v for name, v in ac.items()})
                arrays.update({f"{prefix}_{name}": v for name, v in uc.items()})
                patches.append(
                    {
                        "cut": cut,
                        "arm": arm,
                        "bit": bit,
                        "margin": m,
                        "activation_trace": at,
                        "class_trace": ct,
                        "up_trace": ut,
                    }
                )
                done += 1
        sp = run / "qwen15/states" / f"{key}.npz"
        sp.parent.mkdir(parents=True, exist_ok=True)
        np.savez_compressed(sp, **arrays)
        record = {
            "fingerprint": bundle["fingerprint"],
            **g,
            "position": pos,
            "parent_record_sha256": e["sha256"],
            "raw": raw,
            "identities": identities,
            "patches": patches,
            "states_sha256": parent.parent.hashed(sp),
        }
        write_json(
            run / "qwen15/records" / f"{key}.json", {"record": record, "sha256": digest(record)}
        )
        status.update(completed_forwards=done, completed_pairs=index + 1, updated_utc=now())
        write_json(run / "pipeline-status.json", status)
        print(f"188 pairs {index + 1}/64; {done}/1024 forwards", flush=True)
        del arrays, caps, ups, states, shared, shared_u
        gc.collect()
    assert done == 1024
    del model, tok
    gc.collect()
    torch.mps.empty_cache()


def launch(run):
    with exclusive_lock(run / ".launch.lock"):
        b = prepare(run)
        assert not (run / "launch.json").exists()
        with (run / "pipeline.log").open("a") as log:
            p = subprocess.Popen(
                [
                    "/usr/bin/caffeinate",
                    "-i",
                    sys.executable,
                    "-u",
                    str(Path(__file__).resolve()),
                    "--run",
                    str(run.resolve()),
                ],
                cwd=ROOT,
                env={**os.environ, "PYTHONPATH": str(ROOT / "src")},
                stdin=subprocess.DEVNULL,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
        out = {"pid": p.pid, "fingerprint": b["fingerprint"], "launched_utc": now()}
        write_json(run / "launch.json", out)
        return out


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--run", type=Path, default=DEFAULT)
    parser.add_argument("--launch", action="store_true")
    args = parser.parse_args()
    if args.launch:
        print(json.dumps(launch(args.run)))
        return
    with exclusive_lock(args.run / ".pipeline.lock"):
        b = prepare(args.run)
        status = {"status": "running", "fingerprint": b["fingerprint"], "started_utc": now()}
        write_json(args.run / "pipeline-status.json", status)
        try:
            run_model(args.run, b, status)
            status.update(status="complete", updated_utc=now())
        except BaseException as exc:
            status.update(status="technical_failure", error=repr(exc), updated_utc=now())
            write_json(args.run / "pipeline-status.json", status)
            raise
        write_json(args.run / "pipeline-status.json", status)


if __name__ == "__main__":
    main()
