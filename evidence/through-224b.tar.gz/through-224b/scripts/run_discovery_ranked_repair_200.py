"""Globally seal False-only finite-block repairs chosen from independent discovery199."""

import gc
import hashlib
import itertools
import json
from pathlib import Path

import audit_layerwise_nonlinear_remainder_199 as parent
import numpy as np
import ranked_block_response_200 as response
import torch
from run_absence_alphabet_104 import now

from latent_decisions.evidence_policy import digest, exclusive_lock, write_json
from latent_decisions.target import load_target

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / "runs/discovery-ranked-repair-200"
FILES = (
    "scripts/run_discovery_ranked_repair_200.py",
    "scripts/audit_discovery_ranked_repair_200.py",
    "scripts/recheck_discovery_ranked_repair_200.py",
    "scripts/ranked_block_response_200.py",
    "scripts/public_ranked_block_response_200.py",
    "docs/experiments/200-discovery-ranked-finite-block-repair.md",
)
LITERALS = (
    ("cobalt", "indium", "Tuesday", "Sunday"),
    ("pebble", "stone", "Wednesday", "Friday"),
    ("fresco", "stencil", "Monday", "Thursday"),
    ("reef", "shoal", "Saturday", "Tuesday"),
)
native = parent.parent.native


def blocks():
    return [
        {"id": a, "stage": "200", "subjects": [a, b], "days": [x, y], "old_block": None}
        for a, b, x, y in LITERALS
    ]


def source_hash():
    return digest(
        {"files": {p: (ROOT / p).read_text() for p in FILES}, "parent": parent.source_hash()}
    )


def hashed(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def selections(discovery):
    scores = []
    for block in range(2, 29):
        rows = [r["rows"][block - 2] for r in discovery["records"]]
        residual = np.mean(
            [
                abs(row["error_direction_contribution"])
                / record["budget"]["observed_final_error_norm"]
                for row, record in zip(rows, discovery["records"])
            ]
        )
        margin = np.mean(
            [
                abs(row["margin_contribution"])
                / max(abs(record["budget"]["actual_margin_error"]), 0.1)
                for row, record in zip(rows, discovery["records"])
            ]
        )
        scores.append(
            {"block": block, "residual_score": float(residual), "margin_score": float(margin)}
        )
    residual = sorted(scores, key=lambda row: (-row["residual_score"], row["block"]))
    margin = sorted(scores, key=lambda row: (-row["margin_score"], row["block"]))
    rb, mb = [r["block"] for r in residual[:2]], [r["block"] for r in margin[:2]]
    union = sorted(set(rb + mb))
    rr, mr = (
        {r["block"]: i for i, r in enumerate(residual)},
        {r["block"]: i for i, r in enumerate(margin)},
    )
    control = sorted(
        (b for b in range(2, 29) if b not in union), key=lambda b: (-(rr[b] + mr[b]), b)
    )[: len(union)]
    return {
        "residual": sorted(rb),
        "margin": sorted(mb),
        "union": union,
        "control": sorted(control),
        "scores": scores,
        "discovery_fingerprint": discovery["fingerprint"],
    }


def array(t):
    return t.detach().cpu().numpy().copy()


def store(path, arrays, record):
    path.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(path, **arrays)
    record["states_sha256"] = hashed(path)
    write_json(path.with_suffix(".json"), {"record": record, "sha256": digest(record)})


def main():
    with exclusive_lock(RUN / ".pipeline.lock"):
        assert not (RUN / "design.json").exists()
        pa = json.loads(parent.OUT.read_text())
        pb = json.loads((parent.RUN / "design.json").read_text())
        assert (
            pa["numerical_qualified"]
            and all(pa["controls"].values())
            and pa["fingerprint"] == pb["fingerprint"]
        )
        selected = selections(pa)
        k = len(selected["union"])
        design = {
            "source_hash": source_hash(),
            "models": pb["design"]["models"],
            "parent_fingerprint": pb["fingerprint"],
            "parent_audit_sha256": hashed(parent.OUT),
            "selection": selected,
            "selection_sha256": digest(selected),
            "blocks": blocks(),
            "arms": response.ARMS,
            "ordinary_model_invocations": 128,
            "local_source_finite_calls": 64,
            "local_block_ad_calls": 64 * (158 - 2 * k),
            "local_finite_block_calls": 64 * (4 + 2 * k),
            "local_head_ad_calls": 64,
            "local_finite_head_evaluations": 640,
            "local_head_anchor_evaluations": 64,
        }
        bundle = {"design": design, "fingerprint": digest(design), "created_utc": now()}
        write_json(RUN / "design.json", bundle)
        status = {
            "status": "running",
            "fingerprint": bundle["fingerprint"],
            "started_utc": now(),
            **{
                key: 0
                for key in design
                if key.endswith("calls")
                or key.endswith("evaluations")
                or key == "ordinary_model_invocations"
            },
        }
        try:
            execute(bundle, status)
            status.update(status="complete", completed_utc=now())
        except BaseException as exc:
            status.update(status="technical_failure", error=repr(exc), updated_utc=now())
            write_json(RUN / "pipeline-status.json", status)
            raise
        write_json(RUN / "pipeline-status.json", status)


def execute(bundle, status):
    model, tok, device = load_target(bundle["design"]["models"]["qwen15"], "mps", offline=True)
    assert len(model.model.layers) == 28
    rt = json.loads((parent.RUN / "runtime.json").read_text())
    assert (
        digest(tok.get_vocab()) == rt["tokenizer_hash"]
        and digest(model.config.to_dict()) == rt["config_hash"]
    )
    write_json(RUN / "runtime.json", rt)
    entries, manifest = [], []
    for block, a, t, rev, schema in itertools.product(
        blocks(), range(2), range(2), range(2), ("generic", "descriptive")
    ):
        g = native.fixture.group(block, a, t, rev, schema)
        bases, pos = native.paired_bases(tok, block, g)
        key, started = digest(g), now()
        ids = torch.tensor([bases[0]["free_input_ids"]], device=device)
        other = torch.tensor([bases[1]["free_input_ids"]], device=device)
        states, context, scores = response.observe(model, ids)
        status["ordinary_model_invocations"] += 1
        with torch.no_grad():
            edit = model.model.embed_tokens(other) - context["input"]
            initial = response.source(model, context, states, edit)
            own_head = response.head(model, states[-1])
        status["local_source_finite_calls"] += 1
        status["local_head_anchor_evaluations"] += 1
        head_error = float(torch.max(abs(own_head - scores)))
        assert head_error <= 0.005
        arrays = {
            "false_rows": array(torch.stack(states)[:, 0, [pos, -1]]),
            "false_scores": array(scores),
            "false_first": array(states[0][0]),
            "source_first_delta": array(initial[0]),
        }
        traces = {}
        for arm in response.ARMS:
            finite, finite_head = response.placements(bundle["design"]["selection"], arm)
            predicted, predicted_scores, metrics = response.forecast(
                model, context, states, initial, finite, finite_head
            )
            status["local_block_ad_calls"] += metrics["local_block_ad_calls"]
            status["local_finite_block_calls"] += metrics["local_finite_block_calls"]
            if finite_head:
                status["local_finite_head_evaluations"] += 2
            else:
                status["local_head_ad_calls"] += 1
            assert torch.count_nonzero(predicted[:, :pos]) == 0
            arrays[f"{arm}_delta_rows"] = array(predicted[:, [pos, -1]])
            arrays[f"{arm}_delta_scores"] = array(predicted_scores)
            traces[arm] = {
                "finite_blocks": sorted({1, *finite}),
                "finite_head": finite_head,
                **metrics,
            }
        assert all(np.isfinite(v).all() for v in arrays.values())
        record = {
            "fingerprint": bundle["fingerprint"],
            **g,
            "bases": bases,
            "position": pos,
            "selection_sha256": bundle["design"]["selection_sha256"],
            "head_anchor_error": head_error,
            "arms": traces,
            "started_utc": started,
            "completed_utc": now(),
        }
        path = RUN / "forecasts" / f"{key}.npz"
        store(path, arrays, record)
        manifest.append(
            {"key": key, "record_sha256": digest(record), "states_sha256": record["states_sha256"]}
        )
        entries.append((key, record))
        status.update(forecast_pairs=len(entries), updated_utc=now())
        write_json(RUN / "pipeline-status.json", status)
        print(f"200 new False-only ranked-repair forecasts {len(entries)}/64", flush=True)
        del states, context, scores, edit, initial, predicted, predicted_scores, arrays
        gc.collect()
    write_json(
        RUN / "forecast-manifest.json",
        {
            "manifest": manifest,
            "sha256": digest(manifest),
            "completed_utc": now(),
            "ordinary_false_model_invocations": 64,
        },
    )
    for count, (key, fr) in enumerate(entries, 1):
        started = now()
        ids = torch.tensor([fr["bases"][1]["free_input_ids"]], device=device)
        states, _, scores = response.observe(model, ids)
        status["ordinary_model_invocations"] += 1
        pos = fr["position"]
        arrays = {
            "true_rows": array(torch.stack(states)[:, 0, [pos, -1]]),
            "true_scores": array(scores),
            "true_first": array(states[0][0]),
        }
        record = {
            "fingerprint": bundle["fingerprint"],
            "forecast_record_sha256": digest(fr),
            "started_utc": started,
            "completed_utc": now(),
        }
        store(RUN / "observations" / f"{key}.npz", arrays, record)
        status.update(observed_pairs=count, updated_utc=now())
        write_json(RUN / "pipeline-status.json", status)
        print(f"200 nativeTrue evaluation {count}/64", flush=True)
        del states, scores, arrays
        gc.collect()
    assert all(
        status[k] == v for k, v in bundle["design"].items() if k in status and isinstance(v, int)
    )


if __name__ == "__main__":
    main()
