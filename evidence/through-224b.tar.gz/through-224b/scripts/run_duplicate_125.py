#!/usr/bin/env python3
"""125/126: identical-question consistency and matched singleton controls."""

import argparse
import gc
import json
import os
import platform
import subprocess
import sys
from pathlib import Path

import run_joint_support_119 as prior
import run_serialization_123 as serial
import torch
import transformers
from run_absence_alphabet_104 import MODELS, now
from run_natural_relation_117 import VERIFY_RULE

from latent_decisions import evidence_policy as core
from latent_decisions.target import load_target

ROOT = Path(__file__).resolve().parents[1]
DEFAULT = ROOT / "runs/duplicate-125-126"


def fresh_blocks():
    excluded = {b["id"] for b in prior.dataset() + serial.fresh_blocks()}
    articles = []
    for article in json.loads(prior.DATA.read_text())["data"]:
        if article["title"] in excluded:
            continue
        eligible = []
        for pi, p in enumerate(article["paragraphs"]):
            context = p["context"]
            if not 150 <= len(context) <= 1600:
                continue
            groups = {}
            for q in p["qas"]:
                if len(q["question"]) > 200:
                    continue
                for ans in q.get("plausible_answers" if q["is_impossible"] else "answers", []):
                    candidate = ans["text"]
                    if not 1 <= len(candidate) <= 100:
                        continue
                    assert (
                        context[ans["answer_start"] : ans["answer_start"] + len(candidate)]
                        == candidate
                    )
                    groups.setdefault(candidate, {False: {}, True: {}})[q["is_impossible"]][
                        q["id"]
                    ] = q
            for candidate, g in groups.items():
                if min(len(x) for x in g.values()) < 1:
                    continue
                qs = [
                    min(g[s].values(), key=lambda q: prior.sha("126:" + q["id"]))
                    for s in (False, True)
                ]
                if qs[0]["question"].strip().casefold() == qs[1]["question"].strip().casefold():
                    continue
                eligible.append(
                    (
                        prior.sha("126:" + ":".join(q["id"] for q in qs) + ":" + candidate),
                        pi,
                        context,
                        candidate,
                        qs,
                    )
                )
        if eligible:
            articles.append((prior.sha("126:" + article["title"]), article["title"], min(eligible)))
    return [
        {
            "id": title,
            "stage": "126",
            "paragraph_index": pi,
            "context": context,
            "candidate": candidate,
            "questions": qs,
        }
        for _, title, (_, pi, context, candidate, qs) in sorted(articles)[:4]
    ]


def messages(block, q, arm):
    if arm == "single":
        rule = VERIFY_RULE
        content = {
            "passage": block["context"],
            "question": q["question"],
            "proposed_answer": block["candidate"],
        }
    else:
        assert arm == "duplicate"
        rule = prior.JOINT_RULE
        content = {
            "passage": block["context"],
            "proposed_answer": block["candidate"],
            "first_question": q["question"],
            "second_question": q["question"],
        }
    return [
        {"role": "system", "content": rule},
        {"role": "user", "content": json.dumps(content, ensure_ascii=False)},
    ]


def source_hash():
    return core.digest(
        {
            "runner": Path(__file__).read_text(),
            "protocol": (ROOT / "docs/experiments/125-126-duplicate-questions.md").read_text(),
            "serial_dependency": serial.source_hash(),
        }
    )


def prepare(run):
    assert prior.sha(prior.DATA.read_text()) == prior.DATA_HASH
    blocks = [
        {**b, "stage": "125", "questions": [b["questions"][0], b["questions"][2]]}
        for b in prior.dataset()[:4]
    ] + fresh_blocks()
    path = run / "design.json"
    if path.exists():
        b = json.loads(path.read_text())
        assert (
            core.digest(b["design"]) == b["fingerprint"]
            and b["design"]["source_hash"] == source_hash()
        )
        assert b["design"]["blocks"] == blocks
        return b
    d = {
        "created_utc": now(),
        "source_hash": source_hash(),
        "data_hash": prior.DATA_HASH,
        "blocks": blocks,
        "models": MODELS,
        "max_new_tokens": 80,
        "max_prompt_tokens": 2048,
        "contradiction_threshold": 0.75,
    }
    b = {"design": d, "fingerprint": core.digest(d)}
    core.write_json(path, b)
    return b


def run_model(run, name, bundle, status):
    folder = run / name
    saved = {}
    for path in (folder / "records").glob("*.json"):
        e = json.loads(path.read_text())
        r = e["record"]
        key = (r["block"], r["question_id"], r["arm"])
        assert (
            key not in saved
            and e["sha256"] == core.digest(r)
            and r["fingerprint"] == bundle["fingerprint"]
        )
        saved[key] = r
    if len(saved) == 32:
        return
    model, tok, device = load_target(MODELS[name], "mps", offline=True)
    rt = {
        "model": MODELS[name],
        "device": device,
        "dtype": str(next(model.parameters()).dtype),
        "training": model.training,
        "python": platform.python_version(),
        "torch": torch.__version__,
        "transformers": transformers.__version__,
        "penalty": 1.0,
        "tokenizer_hash": core.digest(tok.get_vocab()),
        "config_hash": core.digest(model.config.to_dict()),
        "chat_template": tok.chat_template,
    }
    assert rt == json.loads((prior.DEFAULT / name / "runtime.json").read_text())
    if (folder / "runtime.json").exists():
        assert rt == json.loads((folder / "runtime.json").read_text())
    assert all(r["runtime_hash"] == core.digest(rt) for r in saved.values())
    core.write_json(folder / "runtime.json", rt)
    for b in bundle["design"]["blocks"]:
        jobs = sorted(
            [(q, a) for q in b["questions"] for a in ("single", "duplicate")],
            key=lambda x: core.digest([x[0]["id"], x[1]]),
        )
        for q, arm in jobs:
            key = (b["id"], q["id"], arm)
            if key in saved:
                continue
            msg = messages(b, q, arm)
            prefix = tok.apply_chat_template(msg, tokenize=True, add_generation_prompt=True)
            assert len(prefix) <= 2048
            ids, raw = core.generate(model, tok, prefix, 1.0, 80)
            hit = len(ids) == 80 and ids[-1] != tok.eos_token_id
            valid, pred = prior.parse(raw, "single" if arm == "single" else "joint")
            o = {
                "messages": msg,
                "prompt_ids": prefix,
                "ids": ids,
                "raw": raw,
                "valid": valid and not hit,
                "prediction": pred,
                "hit_limit": hit,
            }
            r = {
                "block": b["id"],
                "stage": b["stage"],
                "question_id": q["id"],
                "arm": arm,
                "output": o,
                "fingerprint": bundle["fingerprint"],
                "runtime_hash": core.digest(rt),
            }
            core.write_json(
                folder / "records" / f"{core.digest(key)}.json",
                {"record": r, "sha256": core.digest(r)},
            )
            saved[key] = r
            status.update(
                model=name, stage=b["stage"], completed_queries=len(saved), updated_utc=now()
            )
            core.write_json(run / "pipeline-status.json", status)
            print(f"{name} {b['stage']} {len(saved)}/32", flush=True)
    del model, tok
    gc.collect()
    torch.mps.empty_cache()


def launch(run):
    with core.exclusive_lock(run / ".launch.lock"):
        b = prepare(run)
        path = run / "launch.json"
        if path.exists():
            try:
                os.kill(json.loads(path.read_text())["pid"], 0)
            except ProcessLookupError:
                pass
            else:
                raise RuntimeError("Already running")
        with (run / "pipeline.log").open("a") as log:
            p = subprocess.Popen(
                [
                    "/usr/bin/caffeinate",
                    "-i",
                    sys.executable,
                    "-u",
                    str(Path(__file__).resolve()),
                    "--run",
                    str(run.resolve()),
                ],
                cwd=ROOT,
                env={**os.environ, "PYTHONPATH": str(ROOT / "src")},
                stdin=subprocess.DEVNULL,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
        receipt = {"pid": p.pid, "fingerprint": b["fingerprint"], "launched_utc": now()}
        core.write_json(path, receipt)
        return receipt


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--run", type=Path, default=DEFAULT)
    p.add_argument("--prepare", action="store_true")
    p.add_argument("--launch", action="store_true")
    a = p.parse_args()
    if a.prepare:
        print(prepare(a.run)["fingerprint"])
        return
    if a.launch:
        print(json.dumps(launch(a.run)))
        return
    with core.exclusive_lock(a.run / ".pipeline.lock"):
        b = prepare(a.run)
        status = {"status": "running", "started_utc": now(), "fingerprint": b["fingerprint"]}
        try:
            for name in MODELS:
                run_model(a.run, name, b, status)
            status.update(status="complete", updated_utc=now())
        except BaseException as exc:
            status.update(status="technical_failure", error=repr(exc), updated_utc=now())
            core.write_json(a.run / "pipeline-status.json", status)
            raise
        core.write_json(a.run / "pipeline-status.json", status)
        print("Complete", flush=True)


if __name__ == "__main__":
    main()
