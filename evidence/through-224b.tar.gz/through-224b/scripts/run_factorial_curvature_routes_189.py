"""Complete the receiving N/W/U factorial using the same paired curvature maps."""

import argparse
import gc
import itertools
import json
import os
import subprocess
import sys
from pathlib import Path

import numpy as np
import run_curvature_multiplication_188 as parent
import run_natural_bit_shared_reader_181 as native
import torch
from run_absence_alphabet_104 import now
from run_order_competence_151 import runtime

from latent_decisions.evidence_policy import digest, exclusive_lock, write_json
from latent_decisions.target import load_target

ROOT = Path(__file__).resolve().parents[1]
DEFAULT = ROOT / "runs/factorial-curvature-routes-189"
CUTS = ("U", "N", "W", "NU", "WU")


def source_hash():
    return digest(
        {
            "runner": Path(__file__).read_text(),
            "protocol": (ROOT / "docs/experiments/189-factorial-curvature-routes.md").read_text(),
            "parent": parent.source_hash(),
        }
    )


def prepare(run):
    pb = json.loads((parent.DEFAULT / "design.json").read_text())
    a = json.loads((ROOT / "docs/analysis/188-independent-audit.json").read_text())
    n = json.loads((ROOT / "docs/analysis/188-numerical-recheck.json").read_text())
    assert (
        a["complete"]
        and all(a["controls"].values())
        and a["numerical_qualified"]
        and n["passed"]
        and a["fingerprint"] == n["fingerprint"] == pb["fingerprint"]
        and pb["design"]["source_hash"] == parent.source_hash()
    )
    d = {
        "source_hash": source_hash(),
        "parent_fingerprint": pb["fingerprint"],
        "models": pb["design"]["models"],
        "blocks": parent.parent.parent.blocks(),
        "cuts": list(CUTS),
        "main_forwards": 1536,
        "numerical_forwards": 192,
        "coupling_floor": 0.2,
        "retained_fraction": 0.5,
        "dominance": 0.75,
        "precision_tolerance": 0.1,
        "generic_fraction_advantage": 0.1,
        "inherited_cuts": ["live", "NW", "NWU"],
    }
    p = run / "design.json"
    if p.exists():
        b = json.loads(p.read_text())
        assert b["design"] == d and digest(d) == b["fingerprint"]
        return b
    b = {"design": d, "fingerprint": digest(d), "created_utc": now()}
    write_json(p, b)
    return b


def run_model(run, bundle, status):
    model, tok, device = load_target(bundle["design"]["models"]["qwen15"], "mps", offline=True)
    rt = runtime(model, tok, device, "qwen15")
    assert rt == json.loads((parent.DEFAULT / "qwen15/runtime.json").read_text())
    write_json(run / "qwen15/runtime.json", rt)
    done = 0
    for index, (block, a, t, rev, schema) in enumerate(
        itertools.product(
            parent.parent.parent.blocks(), range(2), range(2), range(2), ("generic", "descriptive")
        )
    ):
        g = native.fixture.group(block, a, t, rev, schema)
        key = digest(g)
        e = json.loads((parent.DEFAULT / "qwen15/records" / f"{key}.json").read_text())
        pr = e["record"]
        p = parent.DEFAULT / "qwen15/states" / f"{key}.npz"
        assert digest(pr) == e["sha256"] and parent.parent.parent.hashed(p) == pr["states_sha256"]
        me = json.loads((parent.parent.DEFAULT / "qwen15/records" / f"{key}.json").read_text())
        mp = parent.parent.DEFAULT / "qwen15/states" / f"{key}.npz"
        assert me["sha256"] == pr["parent_record_sha256"] and digest(me["record"]) == me["sha256"]
        assert parent.parent.parent.hashed(mp) == me["record"]["states_sha256"]
        bases, pos = native.paired_bases(tok, block, g)
        assert pos == pr["position"]
        arrays, raw, identities, patches, caps, ups, states = {}, [], [], [], [], [], []
        with np.load(p, allow_pickle=False) as z, np.load(mp, allow_pickle=False) as mz:
            maps = {
                site: {
                    name: mz[f"map_{site}_{name}"].copy()
                    for name in (
                        "center",
                        "intercept",
                        "slope",
                        "even",
                        "odd",
                        "xf",
                        "xt",
                        "yf",
                        "yt",
                    )
                }
                for site in range(1, 29)
            }
            for bit in range(2):
                with (
                    native.operators(model, pos) as (cap, ct),
                    parent.up_hooks(model, pos) as (uc, ut),
                ):
                    m, h = native.score(model, bases[bit])
                assert m == pr["raw"][bit]["margin"] and np.array_equal(h, z[f"raw_{bit}_final"])
                assert all(
                    np.array_equal(v, z[f"raw_{bit}_{name}"]) for name, v in {**cap, **uc}.items()
                )
                arrays[f"raw_{bit}_final"] = h
                arrays.update({f"raw_{bit}_{name}": v for name, v in {**cap, **uc}.items()})
                caps.append(cap)
                ups.append(uc)
                states.append(h)
                raw.append(
                    {"bit": bit, "base": bases[bit], "margin": m, "class_trace": ct, "up_trace": ut}
                )
                done += 1
            shared = {
                name: native.mean(caps[0][name], caps[1][name])
                for name in caps[0]
                if name[0] in "NW"
            }
            shared_u = {
                site: native.mean(ups[0][f"U_{site}"], ups[1][f"U_{site}"]) for site in range(1, 29)
            }
            arrays.update({f"shared_{name}": v for name, v in shared.items()})
            arrays.update({f"shared_U_{site}": v for site, v in shared_u.items()})
            for bit in range(2):
                own = {name: v for name, v in caps[bit].items() if name[0] in "NW"}
                own_u = {site: ups[bit][f"U_{site}"] for site in range(1, 29)}
                with (
                    native.operators(model, pos, own) as (cap, ct),
                    parent.up_hooks(model, pos, own_u) as (uc, ut),
                ):
                    m, h = native.score(model, bases[bit])
                assert m == raw[bit]["margin"] and np.array_equal(h, states[bit])
                arrays[f"own_{bit}_final"] = h
                identities.append({"bit": bit, "margin": m, "class_trace": ct, "up_trace": ut})
                done += 1
            for cut, arm, bit in itertools.product(CUTS, ("paired", "even"), range(2)):
                with (
                    parent.parent.intervene(model, pos, maps, arm, bit) as (ac, at),
                    native.operators(
                        model, pos, {name: v for name, v in shared.items() if name[0] in cut}
                    ) as (cap, ct),
                    parent.up_hooks(model, pos, shared_u if "U" in cut else None) as (uc, ut),
                ):
                    m, h = native.score(model, bases[bit])
                assert (
                    np.array_equal(h[: pos + 1], states[bit][: pos + 1])
                    and all(
                        np.array_equal(cap[f"V_{site}"], caps[bit][f"V_{site}"])
                        for site in range(1, 29)
                    )
                    and all(
                        np.array_equal(cap[f"G_{site}"], ac[f"{site}_output"])
                        for site in range(1, 29)
                    )
                )
                prefix = f"{cut}_{arm}_{bit}"
                arrays[f"{prefix}_final"] = h
                arrays.update({f"{prefix}_{name}": v for name, v in ac.items()})
                arrays.update({f"{prefix}_{name}": v for name, v in uc.items()})
                patches.append(
                    {
                        "cut": cut,
                        "arm": arm,
                        "bit": bit,
                        "margin": m,
                        "activation_trace": at,
                        "class_trace": ct,
                        "up_trace": ut,
                    }
                )
                done += 1
        sp = run / "qwen15/states" / f"{key}.npz"
        sp.parent.mkdir(parents=True, exist_ok=True)
        np.savez_compressed(sp, **arrays)
        record = {
            "fingerprint": bundle["fingerprint"],
            **g,
            "position": pos,
            "parent_record_sha256": e["sha256"],
            "map_record_sha256": me["sha256"],
            "raw": raw,
            "identities": identities,
            "patches": patches,
            "states_sha256": parent.parent.parent.hashed(sp),
        }
        write_json(
            run / "qwen15/records" / f"{key}.json", {"record": record, "sha256": digest(record)}
        )
        status.update(completed_forwards=done, completed_pairs=index + 1, updated_utc=now())
        write_json(run / "pipeline-status.json", status)
        print(f"189 pairs {index + 1}/64; {done}/1536 forwards", flush=True)
        del arrays, caps, ups, states, shared, shared_u
        gc.collect()
    assert done == 1536
    del model, tok
    gc.collect()
    torch.mps.empty_cache()


def launch(run):
    with exclusive_lock(run / ".launch.lock"):
        b = prepare(run)
        assert not (run / "launch.json").exists()
        with (run / "pipeline.log").open("a") as log:
            p = subprocess.Popen(
                [
                    "/usr/bin/caffeinate",
                    "-i",
                    sys.executable,
                    "-u",
                    str(Path(__file__).resolve()),
                    "--run",
                    str(run.resolve()),
                ],
                cwd=ROOT,
                env={**os.environ, "PYTHONPATH": str(ROOT / "src")},
                stdin=subprocess.DEVNULL,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
        out = {"pid": p.pid, "fingerprint": b["fingerprint"], "launched_utc": now()}
        write_json(run / "launch.json", out)
        return out


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--run", type=Path, default=DEFAULT)
    parser.add_argument("--launch", action="store_true")
    args = parser.parse_args()
    if args.launch:
        print(json.dumps(launch(args.run)))
        return
    with exclusive_lock(args.run / ".pipeline.lock"):
        b = prepare(args.run)
        status = {"status": "running", "fingerprint": b["fingerprint"], "started_utc": now()}
        write_json(args.run / "pipeline-status.json", status)
        try:
            run_model(args.run, b, status)
            status.update(status="complete", updated_utc=now())
        except BaseException as exc:
            status.update(status="technical_failure", error=repr(exc), updated_utc=now())
            write_json(args.run / "pipeline-status.json", status)
            raise
        write_json(args.run / "pipeline-status.json", status)


if __name__ == "__main__":
    main()
