"""Prospective first-block primitive corrections; seal before any native true observation."""

import gc
import hashlib
import itertools
import json
from pathlib import Path

import first_block_response_195 as response
import numpy as np
import run_natural_bit_shared_reader_181 as native
import torch
from run_absence_alphabet_104 import now
from run_order_competence_151 import runtime

from latent_decisions.evidence_policy import digest, exclusive_lock, write_json
from latent_decisions.target import load_target

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / "runs/first-block-primitive-repair-195"
LITERALS = (
    ("velvet", "satin", "Tuesday", "Friday"),
    ("harbor", "inlet", "Monday", "Saturday"),
    ("mosaic", "mural", "Wednesday", "Sunday"),
    ("glacier", "tundra", "Thursday", "Monday"),
)
FILES = (
    "scripts/run_first_block_primitive_repair_195.py",
    "scripts/first_block_response_195.py",
    "scripts/audit_first_block_primitive_repair_195.py",
    "scripts/recheck_first_block_primitive_repair_195.py",
    "docs/experiments/195-first-block-primitive-repair.md",
)


def blocks():
    return [
        {"id": a, "stage": "195", "subjects": [a, b], "days": [x, y], "old_block": None}
        for a, b, x, y in LITERALS
    ]


def hashed(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def source_hash():
    import audit_single_state_native_response_193 as parent

    return digest(
        {"files": {p: (ROOT / p).read_text() for p in FILES}, "parent": parent.source_hash()}
    )


def array(value):
    return value.detach().cpu().numpy().copy()


def observed(model, base):
    ids = torch.tensor([base["free_input_ids"]], device=next(model.parameters()).device)
    with torch.no_grad(), response.capture(model) as (states, context):
        result = model(
            input_ids=ids, attention_mask=torch.ones_like(ids), use_cache=False, logits_to_keep=1
        )
    return states, context, result.logits[0, -1, [895, 830]].detach().clone()


def store(path, arrays, record):
    path.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(path, **arrays)
    record["states_sha256"] = hashed(path)
    write_json(path.with_suffix(".json"), {"record": record, "sha256": digest(record)})


def main():
    with exclusive_lock(RUN / ".pipeline.lock"):
        assert not (RUN / "design.json").exists()
        pa = json.loads((ROOT / "docs/analysis/193-independent-audit.json").read_text())
        pn = json.loads((ROOT / "docs/analysis/193-numerical-recheck.json").read_text())
        pb = json.loads((ROOT / "runs/single-state-native-response-193/design.json").read_text())
        assert pa["numerical_qualified"] and all(pa["controls"].values()) and pn["passed"]
        assert pa["fingerprint"] == pn["fingerprint"] == pb["fingerprint"]
        design = {
            "source_hash": source_hash(),
            "parent_fingerprint": pb["fingerprint"],
            "models": pb["design"]["models"],
            "blocks": blocks(),
            "arms": response.ARMS,
            "ordinary_model_invocations": 128,
            "false_tail_ad_invocations": 640,
            "local_first_ad_invocations": 64,
            "local_analytical_responses": 576,
        }
        bundle = {"design": design, "fingerprint": digest(design), "created_utc": now()}
        write_json(RUN / "design.json", bundle)
        status = {
            "status": "running",
            "fingerprint": bundle["fingerprint"],
            "ordinary_model_invocations": 0,
            "false_tail_ad_invocations": 0,
            "local_first_ad_invocations": 0,
            "local_analytical_responses": 0,
            "started_utc": now(),
        }
        try:
            execute(bundle, status)
            status.update(status="complete", completed_utc=now())
        except BaseException as exc:
            status.update(status="technical_failure", error=repr(exc), updated_utc=now())
            write_json(RUN / "pipeline-status.json", status)
            raise
        write_json(RUN / "pipeline-status.json", status)


def execute(bundle, status):
    model, tok, device = load_target(bundle["design"]["models"]["qwen15"], "mps", offline=True)
    rt = runtime(model, tok, device, "qwen15")
    assert rt == json.loads(
        (ROOT / "runs/single-state-native-response-193/qwen15/runtime.json").read_text()
    )
    write_json(RUN / "qwen15/runtime.json", rt)
    entries, manifest = [], []
    for block, a, t, rev, schema in itertools.product(
        blocks(), range(2), range(2), range(2), ("generic", "descriptive")
    ):
        g = native.fixture.group(block, a, t, rev, schema)
        bases, pos = native.paired_bases(tok, block, g)
        key, started = digest(g), now()
        states, context, scores = observed(model, bases[0])
        status["ordinary_model_invocations"] += 1
        ids = torch.tensor([bases[0]["free_input_ids"]], device=device)
        other = torch.tensor([bases[1]["free_input_ids"]], device=device)
        with torch.no_grad():
            dx = model.model.embed_tokens(other) - context["x"]
        directions, traces = response.local_directions(model.model.layers[0], context, dx, pos)
        status["local_analytical_responses"] += 9
        _, local_ad = torch.func.jvp(
            lambda x: model.model.layers[0](
                x,
                attention_mask=context["attention_mask"],
                position_embeddings=context["position_embeddings"],
            ),
            (context["x"],),
            (dx,),
        )
        local_error = float(torch.max(abs(local_ad - directions["linear"])))
        status["local_first_ad_invocations"] += 1
        assert local_error <= 1e-4
        assert float(torch.max(abs(traces["linear"]["output"][0] - states[0]))) <= 1e-4
        arrays = {
            "false_rows": array(torch.stack(states)[:, [pos, -1]]),
            "false_first": array(states[0]),
            "false_scores": array(scores),
            "embedding_delta": array(dx[0]),
        }
        # Only compact Boolean/verdict component rows are persisted; full first-block directions retained.
        for name, value in traces["linear"].items():
            arrays[f"base_{name}"] = array(value[0, [pos, -1]])
        primal_error = 0.0
        for arm in response.ARMS:
            direction = directions[arm].detach()
            arrays[f"{arm}_first_delta"] = array(direction[0])
            zero = torch.zeros((), device=device)
            primal, tangent = torch.func.jvp(
                lambda lam: response.tail(model, ids, states[0][None], direction, lam),
                (zero,),
                (torch.ones_like(zero),),
            )
            status["false_tail_ad_invocations"] += 1
            pe = float(torch.max(abs(primal[0] - torch.stack(states))))
            pse = float(torch.max(abs(primal[1] - scores)))
            primal_error = max(primal_error, pe)
            assert pe <= 1e-4 and pse <= 0.005
            arrays[f"{arm}_delta_rows"] = array(tangent[0][:, [pos, -1]])
            arrays[f"{arm}_delta_scores"] = array(tangent[1])
            assert torch.count_nonzero(tangent[0][:, :pos]) == 0
            assert float(torch.max(abs(tangent[0][0] - direction[0]))) <= 1e-4
            del primal, tangent
        assert all(np.isfinite(v).all() for v in arrays.values())
        record = {
            "fingerprint": bundle["fingerprint"],
            **g,
            "bases": bases,
            "position": pos,
            "local_ad_error": local_error,
            "tail_primal_error": primal_error,
            "norm_eps": model.config.rms_norm_eps,
            "started_utc": started,
            "completed_utc": now(),
        }
        path = RUN / "qwen15/forecasts" / f"{key}.npz"
        store(path, arrays, record)
        manifest.append(
            {"key": key, "record_sha256": digest(record), "states_sha256": record["states_sha256"]}
        )
        entries.append((key, record))
        status.update(forecast_pairs=len(entries), updated_utc=now())
        write_json(RUN / "pipeline-status.json", status)
        print(f"195 prospective first-block repairs {len(entries)}/64", flush=True)
        del states, context, directions, traces, arrays, local_ad, dx, direction
        gc.collect()
    write_json(
        RUN / "forecast-manifest.json",
        {
            "manifest": manifest,
            "manifest_sha256": digest(manifest),
            "completed_utc": now(),
            "ordinary_model_invocations": 64,
            "false_tail_ad_invocations": 640,
        },
    )
    for count, (key, fr) in enumerate(entries, 1):
        started = now()
        states, context, scores = observed(model, fr["bases"][1])
        status["ordinary_model_invocations"] += 1
        pos = fr["position"]
        arrays = {
            "true_rows": array(torch.stack(states)[:, [pos, -1]]),
            "true_first": array(states[0]),
            "true_scores": array(scores),
        }
        with torch.no_grad():
            _, trace = response.source_forecast(
                model.model.layers[0], context, torch.zeros_like(context["x"])
            )
        for name, value in trace.items():
            if not name.endswith("delta"):
                arrays[f"native_{name}"] = array(value[0, [pos, -1]])
        record = {
            "fingerprint": bundle["fingerprint"],
            "forecast_record_sha256": digest(fr),
            "started_utc": started,
            "completed_utc": now(),
        }
        store(RUN / "qwen15/observations" / f"{key}.npz", arrays, record)
        status.update(observed_pairs=count, updated_utc=now())
        write_json(RUN / "pipeline-status.json", status)
        print(f"195 native observations {count}/64", flush=True)
        del states, context, scores, arrays, trace
        gc.collect()
    assert all(
        status[k] == bundle["design"][k]
        for k in (
            "ordinary_model_invocations",
            "false_tail_ad_invocations",
            "local_first_ad_invocations",
            "local_analytical_responses",
        )
    )
    del model, tok
    gc.collect()
    torch.mps.empty_cache()


if __name__ == "__main__":
    main()
