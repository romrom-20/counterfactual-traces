"""Bound gate-up mixed term versus matched actualMPS finite product lesions."""
import json,hashlib
from pathlib import Path
import numpy as np,torch
import ranked_block_response_201 as original
import primitive_diagnostic_211 as surgery
from frozen_block28_derivative_210 import trace
from gate_up_arithmetic_213 import capture,decompose
from latent_decisions.target import load_target
R=Path(__file__).resolve().parents[1];RUN=R/'runs/gate-up-arithmetic-213'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,o):p.write_text(json.dumps(o,indent=2))
def forward(layer,x,context,c,enabled):
 with surgery.surgeries(layer,c,context,enabled) as checks,capture(layer) as got,torch.no_grad():
  out=original.block(layer,x,context)
 got['output']=out.detach().cpu().double();assert all(z['passed'] for z in checks),checks
 return got,checks

def main():
 assert not RUN.exists();RUN.mkdir();(RUN/'pairs').mkdir()
 files=['scripts/gate_up_arithmetic_213.py','scripts/run_gate_up_arithmetic_213.py','docs/experiments/213-gate-up-arithmetic.md','scripts/primitive_diagnostic_211.py','scripts/frozen_block28_derivative_210.py','scripts/local_primitive_derivative_210c.py']
 runtimepath=R/'runs/genuine-oracle-continuation-204-full/runtime.json';runtime=json.loads(runtimepath.read_text());design=dict(source_hashes={f:sha(R/f) for f in files},runtime_sha256=sha(runtimepath),expected_cases=256,coordinate_bound=1e-4)
 write(RUN/'design.json',design);write(RUN/'runtime.json',runtime)
 model,_,device=load_target(runtime['model'],'mps',offline=True);torch.set_num_threads(2);layer=model.model.layers[27];rows=[]
 for path in sorted((R/'runs/two-block-factorial-209c/pairs').glob('*.npz')):
  parent=R/'runs/genuine-oracle-continuation-204-full/pairs'/path.name;arrays={};pair=[]
  with np.load(path) as z,np.load(parent) as p:
   x=torch.tensor(p['false_boundaries'][27][None],device=device);context={'mask':torch.tensor(p['mask'],device=device),'rope':tuple(torch.tensor(p[k],device=device) for k in ['rope_cos','rope_sin'])};c=trace(layer,x,context);pos=int(z['source_position'])
   for branch in ['native','linear27']:
    operand=x.clone()
    if branch=='native':operand[:,pos:]=torch.tensor(z['native_true_suffix'][1][None],device=device)
    else:
     d=torch.zeros_like(x);d[:,pos:]=torch.tensor(z['LL_delta_suffix'][0][None],device=device);operand=x+d
    for norm in ['finite','affine']:
     enabled=[] if norm=='finite' else ['post_rms'];finite,fc=forward(layer,operand,context,c,enabled);affine,ac=forward(layer,operand,context,c,[*enabled,'gate_up']);vectors,errors=decompose(c,finite,affine)
     prefix=max(float(v[:,:pos].abs().max()) if pos else 0. for v in vectors.values())
     # False shams for every exact configuration, separate from realinput derivatives.
     shamf,sc1=forward(layer,x,context,c,enabled);shama,sc2=forward(layer,x,context,c,[*enabled,'gate_up'])
     sham=max(float((s['output']-c['output']).abs().max()) for s in [shamf,shama])
     localchecks=fc+ac+sc1+sc2
     row=dict(key=path.stem,branch=branch,post_rms=norm,errors=errors,prefix_bound=prefix,false_sham_error=sham,local_checks=localchecks,strict_mixed_agreement=errors['finite_effect_vs_mixed']<=1e-4,arithmetic_qualified=all(e<=1e-4 for n,e in errors.items() if n!='finite_effect_vs_mixed') and sham<=1e-4 and prefix<=1e-4,parent209c_sha256=sha(path),parent204_sha256=sha(parent))
     pair.append(row);rows.append(row)
     for name,v in vectors.items():arrays[f'{branch}_{norm}_{name}']=v[0,pos:].numpy()
  out=RUN/'pairs'/path.name;np.savez_compressed(out,**arrays);write(out.with_suffix('.json'),dict(rows=pair,arrays_sha256=sha(out)));write(RUN/'status.json',dict(status='running',completed_cases=len(rows)));print(path.stem,len(rows),flush=True)
 assert len(rows)==256 and all(sha(R/f)==h for f,h in design['source_hashes'].items())
 report=dict(rows=rows,cases=len(rows),arithmetic_qualified=all(r['arithmetic_qualified'] for r in rows),strict_mixed_agreement=all(r['strict_mixed_agreement'] for r in rows),original_wholeblock_jacobian_qualified=False,source_hashes_unchanged=True,limits='CapturedpostSiLUphi andup; fixedCPU64downweight arithmetic plus measuredMPSrounding, conditionalfiniteinterventiononly. No learnedcircuit/208/prospectiveclaim.')
 write(R/'docs/analysis/213-gate-up-arithmetic.json',report);write(RUN/'status.json',dict(status='complete',**{k:v for k,v in report.items() if k!='rows'}))
if __name__=='__main__':main()
