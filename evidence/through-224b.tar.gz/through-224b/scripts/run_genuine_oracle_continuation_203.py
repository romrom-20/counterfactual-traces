"""Execute the registered203 model resets, replay controls and genuine Jacobian budgets."""

import argparse
import gc
import hashlib
import json
from collections import defaultdict
from pathlib import Path

import numpy as np
import oracle_continuation_203 as c
import ranked_block_response_201 as original
import torch
import transformers
from audit_replacement_metrics_202 import measure
from run_absence_alphabet_104 import now

from latent_decisions.evidence_policy import digest, write_json
from latent_decisions.target import load_target

ROOT = Path(__file__).resolve().parents[1]
PARENT = ROOT / "runs/discovery-ranked-repair-201"
NEXT_BLOCKS = [1, 3, 8, 11, 16, 21, 27]
ARMS = ["source_linear", "union_blocks"]
FILES = [
    "scripts/run_genuine_oracle_continuation_203.py",
    "scripts/oracle_continuation_203.py",
    "docs/experiments/203-genuine-oracle-continuation.md",
]


def hashed(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def check_state(a, b):
    return float(torch.max(abs(a - b)))


def saved_error(a, b):
    return float(np.max(abs(c.cpu(a).astype(np.float64) - b.astype(np.float64))))


def checks_passed(checks):
    return all(r["passed"] for r in checks)


def record_check(checks, kind, state=0.0, score=0.0, **extra):
    row = dict(
        kind=kind,
        maximum_coordinate_error=state,
        maximum_score_error=score,
        passed=state <= 1e-4 and score <= 0.005,
        **extra,
    )
    checks.append(row)
    assert row["passed"], row


def run_pair(model, tok, device, path, run, counts, scope):
    fr = json.loads(path.with_suffix(".json").read_text())["record"]
    pos, key = fr["position"], path.stem
    checks, outcomes, budgets, arrays = [], [], [], {}
    with (
        np.load(path, allow_pickle=False) as z,
        np.load(PARENT / "observations" / path.name, allow_pickle=False) as oz,
    ):
        ids = torch.tensor([fr["bases"][0]["free_input_ids"]], device=device)
        tids = torch.tensor([fr["bases"][1]["free_input_ids"]], device=device)
        assert ids.shape == tids.shape and torch.nonzero(ids != tids).tolist() == [[0, pos]]
        fs, ctx, fscore = original.observe(model, ids)
        ts, tctx, tscore = original.observe(model, tids)
        counts["ordinary_public_model"] += 2
        fb, tb = [ctx["input"], *fs], [tctx["input"], *ts]
        actual = [(t - f).detach() for t, f in zip(tb, fb)]
        assert all(torch.count_nonzero(d[:, :pos]) == 0 for d in actual)
        assert torch.equal(ctx["mask"], tctx["mask"]) and all(
            torch.equal(a, b) for a, b in zip(ctx["rope"], tctx["rope"])
        )
        for label, states, scores, saved in [("false", fs, fscore, z), ("true", ts, tscore, oz)]:
            row_error = saved_error(torch.stack(states)[:, 0, [pos, -1]], saved[f"{label}_rows"])
            first_error = saved_error(states[0][0], saved[f"{label}_first"])
            record_check(
                checks,
                f"native_{label}_replay",
                max(row_error, first_error),
                saved_error(scores, saved[f"{label}_scores"]),
            )
        source = c.finite(model, 0, fb[0] + actual[0], ctx, counts) - fb[1]
        record_check(
            checks,
            "finite_first_block",
            max(check_state(source, actual[1]), saved_error(source[0], z["source_first_delta"])),
        )
        with torch.no_grad():
            record_check(
                checks,
                "native_head_anchor",
                score=max(
                    check_state(original.head(model, fs[-1]), fscore),
                    check_state(original.head(model, ts[-1]), tscore),
                ),
            )
        counts["finite_head_evaluations"] += 2
        selection = json.loads((PARENT / "design.json").read_text())["design"]["selection"]
        ordinary = {}
        for arm in ARMS:
            finite, finite_head = original.placements(selection, arm)
            finite = {1, *finite}
            trace, ds, pe = c.continuation(
                model, fb, ctx, 0, actual[0], finite, finite_head, counts
            )
            row_error = saved_error(torch.stack(trace[1:])[:, 0, [pos, -1]], z[f"{arm}_delta_rows"])
            record_check(
                checks,
                "ordinary201_replay",
                row_error,
                saved_error(ds, z[f"{arm}_delta_scores"]),
                arm=arm,
                primal_error=pe,
            )
            ordinary[arm] = (trace, ds, finite, finite_head)

        # All mandatory controls qualify before interpreting any new oracle outcome.
        for k in NEXT_BLOCKS:
            b = k - 1
            native_tail, exact_score = c.public_native_tail(model, ids, k, tb[b])
            counts["ordinary_public_model"] += 1
            record_check(
                checks,
                "C_exact_native_public_tail",
                max(check_state(a, d) for a, d in zip(native_tail[b:], ts[b:])),
                check_state(exact_score, tscore),
                next_block=k,
                completed_blocks=b,
            )
            for arm, (base, base_score, finite, finite_head) in ordinary.items():
                trace, ds, pe = c.continuation(
                    model, fb, ctx, b, base[b], finite, finite_head, counts
                )
                record_check(
                    checks,
                    "A_predicted_state_reset_tail",
                    max(check_state(a, d) for a, d in zip(trace, base[b:])),
                    check_state(ds, base_score),
                    arm=arm,
                    next_block=k,
                    completed_blocks=b,
                    primal_error=pe,
                )
                if scope == "sample":
                    primal, tangent = c.public_hybrid(
                        model, fb[0], actual[0], b, base[b], finite, finite_head
                    )
                    counts["differentiated_public_model"] += 1
                    pe = check_state(primal[0], torch.stack(fs))
                    te = check_state(tangent[0], torch.stack(base[1:]))
                    record_check(
                        checks,
                        "A_public_hook_predicted_reset",
                        max(pe, te),
                        check_state(tangent[1], base_score),
                        arm=arm,
                        next_block=k,
                    )
                    del primal, tangent
            del native_tail

        # Independently computed native-direction Jacobians shared across all continuations.
        native_j = []
        for index in range(28):
            primal, tangent = c.jvp(model, index, fb[index], actual[index], ctx, counts)
            record_check(
                checks,
                "native_jvp_false_primal",
                check_state(primal, fb[index + 1]),
                block=index + 1,
            )
            native_j.append(tangent)

        arrays.update(
            false_boundaries=c.cpu(torch.stack(fb)[:, 0]),
            native_true_suffix=c.cpu(torch.stack(tb)[:, 0, pos:]),
            native_delta_suffix=c.cpu(torch.stack(actual)[:, 0, pos:]),
            native_j_delta_suffix=c.cpu(torch.stack(native_j)[:, 0, pos:]),
            false_scores=c.cpu(fscore),
            true_scores=c.cpu(tscore),
            source_position=np.array(pos),
            original_next_blocks=np.array(NEXT_BLOCKS),
            mask=c.cpu(ctx["mask"]),
            rope_cos=c.cpu(ctx["rope"][0]),
            rope_sin=c.cpu(ctx["rope"][1]),
        )

        def account(label, arm, b, trace):
            terms, records = [], []
            finite = ordinary[arm][2]
            for offset, index in enumerate(range(b, 28)):
                pred, next_pred = trace[offset], trace[offset + 1]
                error = actual[index] - pred
                primal, je = c.jvp(model, index, fb[index], error, ctx, counts)
                _, jp = c.jvp(model, index, fb[index], pred, ctx, counts)
                record_check(
                    checks,
                    "budget_false_primal",
                    check_state(primal, fb[index + 1]),
                    arm=arm,
                    continuation=label,
                    block=index + 1,
                )
                rn = actual[index + 1].cpu().double() - native_j[index].cpu().double()
                rp = (
                    next_pred.cpu().double() - jp.cpu().double()
                    if index + 1 in finite
                    else torch.zeros_like(rn)
                )
                en = actual[index + 1].cpu().double() - next_pred.cpu().double()
                row = c.vector_budget(error, je, rn, rp, en, pos)
                record_check(
                    checks,
                    "signed_vector_identity",
                    row["maximum_identity_coordinate_error"],
                    arm=arm,
                    continuation=label,
                    block=index + 1,
                )
                row.update(
                    continuation=label, arm=arm, next_block=index + 1, input_completed_blocks=index
                )
                records.append(row)
                terms.append(
                    np.stack([c.cpu(t)[0, pos:].astype(np.float64) for t in (je, rn, rp, en)])
                )
            arrays[f"{label}_{arm}_budget_suffix"] = np.stack(terms)
            budgets.extend(records)

        for arm, (trace, ds, finite, finite_head) in ordinary.items():
            arrays[f"ordinary_{arm}_delta_suffix"] = c.cpu(torch.stack(trace)[:, 0, pos:])
            arrays[f"ordinary_{arm}_delta_scores"] = c.cpu(ds)
            account("ordinary", arm, 0, trace)
            for k in NEXT_BLOCKS:
                b = k - 1
                incoming = actual[b].detach().clone()
                record_check(
                    checks,
                    "B_full_native_reset_boundary",
                    check_state(incoming, actual[b]),
                    arm=arm,
                    next_block=k,
                    completed_blocks=b,
                )
                reset, rs, pe = c.continuation(
                    model, fb, ctx, b, incoming, finite, finite_head, counts
                )
                assert all(torch.count_nonzero(d[:, :pos]) == 0 for d in reset)
                if scope == "sample":
                    primal, tangent = c.public_hybrid(
                        model, fb[0], actual[0], b, incoming, finite, finite_head
                    )
                    counts["differentiated_public_model"] += 1
                    record_check(
                        checks,
                        "oracle_public_hook_replay",
                        max(
                            check_state(primal[0], torch.stack(fs)),
                            check_state(tangent[0][b:], torch.stack(reset[1:])),
                        ),
                        check_state(tangent[1], rs),
                        arm=arm,
                        next_block=k,
                    )
                    del primal, tangent
                name = f"before{k}"
                arrays[f"{name}_{arm}_delta_suffix"] = c.cpu(torch.stack(reset)[:, 0, pos:])
                arrays[f"{name}_{arm}_delta_scores"] = c.cpu(rs)
                account(name, arm, b, reset)
                dm = float((tscore[1] - tscore[0]) - (fscore[1] - fscore[0]))
                base_m = float(ds[1] - ds[0])
                reset_m = float(rs[1] - rs[0])
                incoming_metrics = {
                    label: measure(c.cpu(actual[b][sl]), c.cpu(trace[b][sl]))
                    for label, sl in c.slices(pos).items()
                }
                final_metrics = {
                    label: measure(c.cpu(actual[-1][sl]), c.cpu(reset[-1][sl]))
                    for label, sl in c.slices(pos).items()
                }
                ordinary_final = {
                    label: measure(c.cpu(actual[-1][sl]), c.cpu(trace[-1][sl]))
                    for label, sl in c.slices(pos).items()
                }
                outcomes.append(
                    dict(
                        arm=arm,
                        next_block=k,
                        completed_blocks=b,
                        incoming=incoming_metrics,
                        final=final_metrics,
                        ordinary_final=ordinary_final,
                        native_delta_margin=dm,
                        reset_delta_margin=reset_m,
                        ordinary_delta_margin=base_m,
                        reset_margin_error=reset_m - dm,
                        ordinary_margin_error=base_m - dm,
                        boundary_error=0.0,
                        maximum_primal_error=pe,
                    )
                )
                del reset
        assert checks_passed(checks)
        out = run / "pairs" / f"{key}.npz"
        out.parent.mkdir(parents=True, exist_ok=True)
        assert not out.exists()
        np.savez_compressed(out, **arrays)
        record = dict(
            key=key,
            group={k: fr[k] for k in ("block", "schema", "reverse", "assignment", "target")},
            position=pos,
            length=ids.shape[1],
            checks=checks,
            outcomes=outcomes,
            budgets=budgets,
            arrays_sha256=hashed(out),
            parent_forecast_sha256=hashed(path),
            parent_observation_sha256=hashed(PARENT / "observations" / path.name),
        )
        write_json(out.with_suffix(".json"), record)
    gc.collect()
    return record


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--scope", choices=["sample", "full"], required=True)
    args = parser.parse_args()
    run = ROOT / f"runs/genuine-oracle-continuation-203-{args.scope}"
    assert not run.exists(), "Never overwrite a failed or completed scientific run"
    parent = json.loads((PARENT / "design.json").read_text())
    source = {f: hashed(ROOT / f) for f in FILES}
    if args.scope == "full":
        sample = json.loads(
            (ROOT / "runs/genuine-oracle-continuation-203-sample/status.json").read_text()
        )
        assert (
            sample["status"] == "complete"
            and sample["qualified"]
            and sample["source_hashes"] == source
        )
    paths = sorted((PARENT / "forecasts").glob("*.npz"))
    if args.scope == "sample":
        paths = [
            p
            for p in paths
            if (lambda r: r["block"] == "cobalt" and r["reverse"] == 0)(
                json.loads(p.with_suffix(".json").read_text())["record"]
            )
        ]
    assert len(paths) == (8 if args.scope == "sample" else 64)
    design = dict(
        scope=args.scope,
        source_hashes=source,
        parent_fingerprint=parent["fingerprint"],
        parent_audit_sha256=hashed(ROOT / "docs/analysis/201-independent-audit.json"),
        keys=[p.stem for p in paths],
        next_blocks=NEXT_BLOCKS,
        arms=ARMS,
        indexing="reset BEFORE public block k; completed blocks b=k-1",
        created_utc=now(),
    )
    run.mkdir(parents=True)
    write_json(run / "design.json", dict(design=design, fingerprint=digest(design)))
    counts = defaultdict(int)
    status = dict(
        status="running",
        qualified=False,
        source_hashes=source,
        completed_pairs=0,
        counts={},
        started_utc=now(),
    )
    write_json(run / "status.json", status)
    try:
        model, tok, device = load_target(parent["design"]["models"]["qwen15"], "mps", offline=True)
        runtime = json.loads((PARENT / "runtime.json").read_text())
        assert digest(tok.get_vocab()) == runtime["tokenizer_hash"]
        assert digest(model.config.to_dict()) == runtime["config_hash"]
        assert (
            str(torch.__version__) == runtime["torch"]
            and transformers.__version__ == runtime["transformers"]
        )
        assert (
            len(model.model.layers) == 28
            and not model.training
            and model.config._attn_implementation == "eager"
        )
        assert (
            next(model.parameters()).dtype == torch.float32
            and next(model.parameters()).device.type == "mps"
        )
        write_json(
            run / "runtime.json",
            {
                **runtime,
                "actual_config_hash": digest(model.config.to_dict()),
                "actual_tokenizer_hash": digest(tok.get_vocab()),
                "actual_revision": model.config._commit_hash,
                "actual_attention": model.config._attn_implementation,
            },
        )
        for p in paths:
            record = run_pair(model, tok, device, p, run, counts, args.scope)
            status.update(
                completed_pairs=status["completed_pairs"] + 1,
                counts=dict(counts),
                updated_utc=now(),
            )
            write_json(run / "status.json", status)
            print(
                f"203 {args.scope} qualified pair {status['completed_pairs']}/{len(paths)} {record['group']}",
                flush=True,
            )
        assert source == {f: hashed(ROOT / f) for f in FILES}
        status.update(status="complete", qualified=True, completed_utc=now())
    except BaseException as exc:
        status.update(
            status="technical_failure", error=repr(exc), counts=dict(counts), updated_utc=now()
        )
        write_json(run / "status.json", status)
        raise
    write_json(run / "status.json", status)
    print(json.dumps(status, indent=2))


if __name__ == "__main__":
    main()
