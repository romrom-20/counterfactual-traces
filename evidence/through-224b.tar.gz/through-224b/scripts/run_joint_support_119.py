#!/usr/bin/env python3
"""119/120: independent, joint and oracle-forced support judgments."""

import argparse
import gc
import hashlib
import itertools
import json
import os
import platform
import subprocess
import sys
from pathlib import Path

import torch
import transformers
from run_absence_alphabet_104 import MODELS, now
from run_natural_relation_117 import VERIFY_RULE

from latent_decisions import evidence_policy as core
from latent_decisions.target import load_target

ROOT = Path(__file__).resolve().parents[1]
DEFAULT = ROOT / "runs/joint-support-119-120"
DATA = ROOT / ".context/datasets/squad2/train-v2.0.json"
DATA_HASH = "68dcfbb971bd3e96d5b46c7177b16c1a4e7d4bdef19fb204502738552dede002"
JOINT_RULE = (
    "Decide separately for each of the two questions whether the passage establishes the proposed answer as an answer to that exact question. "
    "A phrase appearing in the passage is not sufficient: the entities, relationship, dates and qualifiers asked about must be supported. "
    "Use only the passage. Both questions, neither question, or just one question may be supported. "
    'Return only a JSON object with boolean values for keys "first_supported" and "second_supported".'
)
FORCED_RULE = (
    "Exactly one of the two questions is answered by the proposed answer according to the passage. Select that question. "
    "A phrase appearing in the passage is not sufficient: the entities, relationship, dates and qualifiers asked about must be supported. "
    'Use only the passage. Return only {"which": 1} for the first question or {"which": 2} for the second.'
)


def sha(s):
    return hashlib.sha256(s.encode()).hexdigest()


def dataset():
    assert hashlib.sha256(DATA.read_bytes()).hexdigest() == DATA_HASH
    eligible_articles = []
    for article in json.loads(DATA.read_text())["data"]:
        eligible = []
        for pi, paragraph in enumerate(article["paragraphs"]):
            context = paragraph["context"]
            if not 150 <= len(context) <= 1600:
                continue
            groups = {}
            for q in paragraph["qas"]:
                if len(q["question"]) > 200:
                    continue
                for a in q.get("plausible_answers" if q["is_impossible"] else "answers", []):
                    candidate = a["text"]
                    if not 1 <= len(candidate) <= 100:
                        continue
                    assert (
                        context[a["answer_start"] : a["answer_start"] + len(candidate)] == candidate
                    )
                    group = groups.setdefault(candidate, {True: {}, False: {}})
                    group[q["is_impossible"]][q["id"]] = q
            for candidate, group in groups.items():
                if any(len(group[x]) < 2 for x in (False, True)):
                    continue
                qs = [
                    q
                    for state in (False, True)
                    for q in sorted(group[state].values(), key=lambda q: sha("119:" + q["id"]))[:2]
                ]
                if len({q["question"].strip().casefold() for q in qs}) != 4:
                    continue
                key = sha("119:" + ":".join(q["id"] for q in qs) + ":" + candidate)
                eligible.append((key, pi, context, candidate, qs))
        if eligible:
            eligible_articles.append(
                (
                    sha("119:" + article["title"]),
                    article["title"],
                    min(eligible, key=lambda x: x[0]),
                )
            )
    selected = sorted(eligible_articles)[:8]
    assert len(selected) == 8
    return [
        {
            "id": title,
            "stage": "119" if i < 4 else "120",
            "paragraph_index": pi,
            "context": context,
            "candidate": candidate,
            "questions": qs,
        }
        for i, (_, title, (_, pi, context, candidate, qs)) in enumerate(selected)
    ]


def queries(block):
    result = []
    for q in block["questions"]:
        result.append({"id": f"single:{q['id']}", "kind": "single", "question_ids": [q["id"]]})
    for a, b in itertools.combinations(block["questions"], 2):
        for order in ((a, b), (b, a)):
            ids = [q["id"] for q in order]
            result.append({"id": "joint:" + ":".join(ids), "kind": "joint", "question_ids": ids})
            if a["is_impossible"] != b["is_impossible"]:
                result.append(
                    {"id": "forced:" + ":".join(ids), "kind": "forced", "question_ids": ids}
                )
    assert len(result) == 24
    return result


def messages(block, query):
    qs = {q["id"]: q for q in block["questions"]}
    content = {"passage": block["context"], "proposed_answer": block["candidate"]}
    if query["kind"] == "single":
        content = {
            "passage": block["context"],
            "question": qs[query["question_ids"][0]]["question"],
            "proposed_answer": block["candidate"],
        }
        rule = VERIFY_RULE
    else:
        content["first_question"], content["second_question"] = [
            qs[i]["question"] for i in query["question_ids"]
        ]
        rule = JOINT_RULE if query["kind"] == "joint" else FORCED_RULE
    return [
        {"role": "system", "content": rule},
        {"role": "user", "content": json.dumps(content, ensure_ascii=False)},
    ]


def parse(raw, kind):
    def unique(items):
        if len(dict(items)) != len(items):
            raise ValueError("duplicate field")
        return dict(items)

    try:
        obj = json.loads(raw, object_pairs_hook=unique)
        if type(obj) is not dict:
            return False, None
        if kind == "single" and set(obj) == {"supported"} and type(obj["supported"]) is bool:
            return True, [obj["supported"]]
        if (
            kind == "joint"
            and set(obj) == {"first_supported", "second_supported"}
            and all(type(v) is bool for v in obj.values())
        ):
            return True, [obj["first_supported"], obj["second_supported"]]
        if (
            kind == "forced"
            and set(obj) == {"which"}
            and type(obj["which"]) is int
            and obj["which"] in (1, 2)
        ):
            return True, [obj["which"] == 1, obj["which"] == 2]
    except (ValueError, TypeError):
        pass
    return False, None


def source_hash():
    paths = [
        Path(__file__),
        ROOT / "docs/experiments/119-120-joint-support.md",
        ROOT / "scripts/run_natural_relation_117.py",
        ROOT / "scripts/run_absence_alphabet_104.py",
        ROOT / "src/latent_decisions/evidence_policy.py",
        ROOT / "src/latent_decisions/target.py",
    ]
    return core.digest({str(p.relative_to(ROOT)): sha(p.read_text()) for p in paths})


def prepare(run):
    path = run / "design.json"
    if path.exists():
        b = json.loads(path.read_text())
        assert (
            core.digest(b["design"]) == b["fingerprint"]
            and b["design"]["source_hash"] == source_hash()
        )
        assert b["design"]["blocks"] == dataset()
        return b
    d = {
        "created_utc": now(),
        "blocks": dataset(),
        "source_hash": source_hash(),
        "data_hash": DATA_HASH,
        "models": MODELS,
        "max_new_tokens": 80,
        "max_prompt_tokens": 2048,
    }
    b = {"design": d, "fingerprint": core.digest(d)}
    core.write_json(path, b)
    return b


def records(run, name, bundle):
    got = {}
    runtime = run / name / "runtime.json"
    rh = core.digest(json.loads(runtime.read_text())) if runtime.exists() else None
    expected = {(b["id"], q["id"]) for b in bundle["design"]["blocks"] for q in queries(b)}
    for p in (run / name / "records").glob("*.json"):
        env = json.loads(p.read_text())
        r = env["record"]
        key = (r["block"], r["query"]["id"])
        assert env["sha256"] == core.digest(r) and r["fingerprint"] == bundle["fingerprint"]
        assert r["runtime_hash"] == rh and key in expected and key not in got
        got[key] = r
    return got


def summarize(blocks, saved):
    rows = []
    for b in blocks:
        qs = {q["id"]: q for q in b["questions"]}
        for q in queries(b):
            o = saved[(b["id"], q["id"])]["output"]
            gold = [not qs[i]["is_impossible"] for i in q["question_ids"]]
            pred = o["prediction"]
            rows.append(
                {
                    "block": b["id"],
                    "query": q,
                    "gold": gold,
                    "valid": o["valid"],
                    "prediction": pred,
                    "correct": o["valid"] and pred == gold,
                }
            )
    single = [r for r in rows if r["query"]["kind"] == "single"]
    singles = {(r["block"], r["query"]["question_ids"][0]): r for r in single}
    stats = {}
    for kind in ("joint", "forced"):
        subsets = {}
        for label, support_count in [("mixed", 1), ("both", 2), ("neither", 0)]:
            group = [
                r for r in rows if r["query"]["kind"] == kind and sum(r["gold"]) == support_count
            ]
            if not group:
                continue
            pair_groups = {}
            for r in group:
                pair_groups.setdefault(
                    (r["block"], tuple(sorted(r["query"]["question_ids"]))), []
                ).append(r)
            robust = sum(all(r["correct"] for r in pair) for pair in pair_groups.values())
            baseline = sum(
                all(singles[(block, qid)]["correct"] for qid in qids) for block, qids in pair_groups
            )
            consistent = sum(
                all(r["valid"] for r in pair)
                and pair[0]["prediction"] == pair[1]["prediction"][::-1]
                for pair in pair_groups.values()
            )
            subsets[label] = {
                "queries": len(group),
                "correct": sum(r["correct"] for r in group),
                "invalid": sum(not r["valid"] for r in group),
                "pairs": len(pair_groups),
                "both_orders_correct": robust,
                "order_consistent": consistent,
                "singleton_both_correct": baseline,
            }
        stats[kind] = subsets
    rates = {
        label: {
            "n": sum(r["gold"][0] == state for r in single),
            "correct": sum(r["correct"] for r in single if r["gold"][0] == state),
        }
        for label, state in [("supported", True), ("unsupported", False)]
    }
    j = stats["joint"]
    mixed = j["mixed"]
    criteria = {
        "mixed_accuracy": mixed["both_orders_correct"] >= 12,
        "improvement": mixed["both_orders_correct"] - mixed["singleton_both_correct"] >= 4,
        "both_control": j["both"]["both_orders_correct"] >= 3,
        "neither_control": j["neither"]["both_orders_correct"] >= 3,
        "order_consistency": mixed["order_consistent"] >= 15,
    }
    return {
        "single": rates,
        "pair": stats,
        "criteria": criteria,
        "pass": all(criteria.values()),
        "outcomes": rows,
    }


def run_model(run, name, bundle, status):
    saved = records(run, name, bundle)
    blocks = bundle["design"]["blocks"]
    expected = sum(len(queries(b)) for b in blocks)
    if len(saved) < expected:
        model, tok, device = load_target(MODELS[name], "mps", offline=True)
        rt = {
            "model": MODELS[name],
            "device": device,
            "dtype": str(next(model.parameters()).dtype),
            "training": model.training,
            "python": platform.python_version(),
            "torch": torch.__version__,
            "transformers": transformers.__version__,
            "penalty": 1.0,
            "tokenizer_hash": core.digest(tok.get_vocab()),
            "config_hash": core.digest(model.config.to_dict()),
            "chat_template": tok.chat_template,
        }
        assert rt["dtype"] == "torch.float32" and not rt["training"]
        path = run / name / "runtime.json"
        if path.exists():
            assert json.loads(path.read_text()) == rt
        core.write_json(path, rt)
        for b in blocks:
            # Hash order prevents all singleton/pair modes being tied to elapsed time.
            for q in sorted(queries(b), key=lambda x: sha(x["id"])):
                key = (b["id"], q["id"])
                if key in saved:
                    continue
                msg = messages(b, q)
                prefix = tok.apply_chat_template(msg, tokenize=True, add_generation_prompt=True)
                assert len(prefix) <= bundle["design"]["max_prompt_tokens"]
                ids, raw = core.generate(
                    model, tok, prefix, 1.0, bundle["design"]["max_new_tokens"]
                )
                hit = len(ids) == bundle["design"]["max_new_tokens"] and ids[-1] != tok.eos_token_id
                valid, prediction = parse(raw, q["kind"])
                output = {
                    "messages": msg,
                    "prompt_ids": prefix,
                    "ids": ids,
                    "raw": raw,
                    "valid": valid and not hit,
                    "prediction": prediction,
                    "hit_limit": hit,
                }
                r = {
                    "block": b["id"],
                    "query": q,
                    "output": output,
                    "fingerprint": bundle["fingerprint"],
                    "runtime_hash": core.digest(rt),
                }
                core.write_json(
                    run / name / "records" / f"{core.digest(key)}.json",
                    {"record": r, "sha256": core.digest(r)},
                )
                saved[key] = r
                status.update(
                    model=name, stage=b["stage"], completed_queries=len(saved), updated_utc=now()
                )
                core.write_json(run / "pipeline-status.json", status)
                print(f"{name} {b['stage']} {len(saved)}/{expected}", flush=True)
        del model, tok
        gc.collect()
        torch.mps.empty_cache()
    results = {}
    for stage in ("119", "120"):
        a = summarize([b for b in blocks if b["stage"] == stage], saved)
        a.update(fingerprint=bundle["fingerprint"], model=name, stage=stage, complete=True)
        core.write_json(run / name / f"analysis-{stage}.json", a)
        results[stage] = a
    return results


def launch(run):
    with core.exclusive_lock(run / ".launch.lock"):
        bundle = prepare(run)
        path = run / "launch.json"
        if path.exists():
            try:
                os.kill(json.loads(path.read_text())["pid"], 0)
            except ProcessLookupError:
                pass
            else:
                raise RuntimeError("Already running")
        cmd = [
            "/usr/bin/caffeinate",
            "-i",
            sys.executable,
            "-u",
            str(Path(__file__).resolve()),
            "--run",
            str(run.resolve()),
        ]
        with (run / "pipeline.log").open("a") as log:
            p = subprocess.Popen(
                cmd,
                cwd=ROOT,
                env={**os.environ, "PYTHONPATH": str(ROOT / "src")},
                stdin=subprocess.DEVNULL,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
        receipt = {"pid": p.pid, "fingerprint": bundle["fingerprint"], "launched_utc": now()}
        core.write_json(path, receipt)
        return receipt


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run", type=Path, default=DEFAULT)
    parser.add_argument("--prepare", action="store_true")
    parser.add_argument("--launch", action="store_true")
    args = parser.parse_args()
    if args.prepare:
        print(prepare(args.run)["fingerprint"])
        return
    if args.launch:
        print(json.dumps(launch(args.run)))
        return
    with core.exclusive_lock(args.run / ".pipeline.lock"):
        b = prepare(args.run)
        status = {
            "status": "running",
            "started_utc": now(),
            "fingerprint": b["fingerprint"],
            "results": {},
        }
        try:
            for name in MODELS:
                status["results"][name] = run_model(args.run, name, b, status)
            status.update(status="complete", updated_utc=now())
        except BaseException as exc:
            status.update(status="technical_failure", error=repr(exc), updated_utc=now())
            core.write_json(args.run / "pipeline-status.json", status)
            raise
        core.write_json(args.run / "pipeline-status.json", status)
        print("Complete", flush=True)


if __name__ == "__main__":
    main()
