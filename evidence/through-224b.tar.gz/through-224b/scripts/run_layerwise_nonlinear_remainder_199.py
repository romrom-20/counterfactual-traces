"""Retrospective full-state remainder injection and False-adjoint amplification."""

import gc
import hashlib
import itertools
import json
from contextlib import contextmanager
from pathlib import Path

import audit_single_state_native_response_193 as parent
import first_block_response_196 as transport
import numpy as np
import torch
from run_absence_alphabet_104 import now

from latent_decisions.evidence_policy import digest, exclusive_lock, write_json
from latent_decisions.target import block_tensor, load_target

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / "runs/layerwise-nonlinear-remainder-199"
FILES = (
    "scripts/run_layerwise_nonlinear_remainder_199.py",
    "scripts/audit_layerwise_nonlinear_remainder_199.py",
    "docs/experiments/199-layerwise-nonlinear-remainder.md",
)


def hashed(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def source_hash():
    return digest(
        {
            "files": {p: (ROOT / p).read_text() for p in FILES},
            "parent": parent.source_hash(),
            "transport_helper": Path(transport.__file__).read_text(),
        }
    )


@contextmanager
def capture(model):
    states, context, handles = [], {}, []

    def input_context(module, args, kwargs):
        context.update(x=args[0], mask=kwargs["attention_mask"], rope=kwargs["position_embeddings"])

    def output(module, args, result):
        states.append(block_tensor(result))

    try:
        handles.append(
            model.model.layers[0].register_forward_pre_hook(input_context, with_kwargs=True)
        )
        for layer in model.model.layers:
            handles.append(layer.register_forward_hook(output))
        yield states, context
    finally:
        for handle in handles:
            handle.remove()


def dot(a, b):
    return float(np.sum(a.astype(np.float64) * b.astype(np.float64)))


def close(a, b):
    return abs(a - b) <= 0.001 + 0.0001 * abs(b)


def array(t):
    return t.detach().cpu().numpy().copy()


def main():
    with exclusive_lock(RUN / ".pipeline.lock"):
        assert not (RUN / "design.json").exists()
        pa = json.loads(parent.OUT.read_text())
        pn = json.loads((ROOT / "docs/analysis/193-numerical-recheck.json").read_text())
        pb = json.loads((parent.RUN / "design.json").read_text())
        assert pa["numerical_qualified"] and all(pa["controls"].values()) and pn["passed"]
        assert pa["fingerprint"] == pn["fingerprint"] == pb["fingerprint"]
        design = {
            "source_hash": source_hash(),
            "parent_fingerprint": pb["fingerprint"],
            "models": pb["design"]["models"],
            "blocks": parent.blocks(),
            "post_observation_diagnostic": True,
            "ordinary_false_model_invocations": 64,
            "forward_false_model_invocations": 64,
            "reverse_false_model_invocations": 64,
            "local_block_forward_ad_invocations": 1728,
        }
        bundle = {"design": design, "fingerprint": digest(design), "created_utc": now()}
        write_json(RUN / "design.json", bundle)
        status = {
            "status": "running",
            "fingerprint": bundle["fingerprint"],
            "ordinary_false_model_invocations": 0,
            "forward_false_model_invocations": 0,
            "reverse_false_model_invocations": 0,
            "local_block_forward_ad_invocations": 0,
            "started_utc": now(),
        }
        try:
            execute(bundle, status)
            status.update(status="complete", completed_utc=now())
        except BaseException as exc:
            status.update(status="technical_failure", error=repr(exc), updated_utc=now())
            write_json(RUN / "pipeline-status.json", status)
            raise
        write_json(RUN / "pipeline-status.json", status)


def execute(bundle, status):
    model, tok, device = load_target(bundle["design"]["models"]["qwen15"], "mps", offline=True)
    runtime = json.loads((parent.RUN / "qwen15/runtime.json").read_text())
    assert (
        digest(tok.get_vocab()) == runtime["tokenizer_hash"]
        and digest(model.config.to_dict()) == runtime["config_hash"]
    )
    write_json(RUN / "runtime.json", runtime)
    manifest = []
    for block, a, t, rev, schema in itertools.product(
        parent.blocks(), range(2), range(2), range(2), ("generic", "descriptive")
    ):
        g = parent.native.fixture.group(block, a, t, rev, schema)
        key, started = digest(g), now()
        fp, op = (
            parent.RUN / "qwen15/forecasts" / f"{key}.npz",
            parent.RUN / "qwen15/observations" / f"{key}.npz",
        )
        fr = parent.native.read_record(fp.with_suffix(".json"))["record"]
        obs = parent.native.read_record(op.with_suffix(".json"))["record"]
        assert hashed(fp) == fr["states_sha256"] and hashed(op) == obs["states_sha256"]
        bases = [
            parent.native.fixture.reconstruct(tok, block, parent.native.fixture.job(g, bit))
            for bit in range(2)
        ]
        assert bases == fr["bases"]
        pos = fr["position"]
        with np.load(fp, allow_pickle=False) as fz, np.load(op, allow_pickle=False) as oz:
            hf = fz["native_false_states"].copy()
            ht = oz["actual_1.0_states"].copy()
            sf, st = fz["native_false_scores"].copy(), oz["actual_1.0_scores"].copy()
        # Define the numerical displacement in float32, the differentiated model dtype.
        actual = (ht - hf).astype(np.float64)
        ids = torch.tensor([bases[0]["free_input_ids"]], device=device)
        with torch.no_grad(), capture(model) as (native_states, context):
            public = model(
                input_ids=ids,
                attention_mask=torch.ones_like(ids),
                use_cache=False,
                logits_to_keep=1,
            )
        status["ordinary_false_model_invocations"] += 1
        replay_state_error = float(np.max(abs(array(torch.stack(native_states)[:, 0]) - hf)))
        replay_score_error = float(np.max(abs(array(public.logits[0, -1, [895, 830]]) - sf)))
        assert replay_state_error <= 1e-4 and replay_score_error <= 0.005
        base_first = native_states[0].detach()
        delta_first = torch.tensor(actual[0][None].astype(np.float32), device=device)
        zero = torch.zeros((), device=device)
        primal, tangent = torch.func.jvp(
            lambda lam: transport.tail(model, ids, base_first, delta_first, lam),
            (zero,),
            (torch.ones_like(zero),),
        )
        status["forward_false_model_invocations"] += 1
        prediction = array(tangent[0]).astype(np.float64)
        predicted_scores = array(tangent[1]).astype(np.float64)
        assert np.max(abs(array(primal[0]) - hf)) <= 1e-4
        assert np.max(abs(array(primal[1]) - sf)) <= 0.005
        assert np.count_nonzero(prediction[:, :pos]) == 0
        assert np.array_equal(prediction[0], delta_first[0].cpu().numpy().astype(np.float64))
        error = actual - prediction
        final_error_norm = float(np.linalg.norm(error[-1, -1]))
        assert final_error_norm >= 0.001
        direction = torch.tensor(
            (error[-1, -1] / final_error_norm).astype(np.float32), device=device
        )
        x = context["x"].detach().clone().requires_grad_(True)
        with capture(model) as (reverse_states, _):
            output = model(
                inputs_embeds=x,
                attention_mask=torch.ones_like(ids),
                use_cache=False,
                logits_to_keep=1,
            )
        status["reverse_false_model_invocations"] += 1
        margin = output.logits[0, -1, 830] - output.logits[0, -1, 895]
        projection = (reverse_states[-1][0, -1] * direction).sum()
        adjoints = [
            torch.autograd.grad(scalar, tuple(reverse_states), retain_graph=True)
            for scalar in (margin, projection)
        ]
        weights = [[array(w[0]).astype(np.float64) for w in objective] for objective in adjoints]
        rows, saved = (
            [],
            {
                "actual_delta_rows": actual[:, [pos, -1]].astype(np.float32),
                "predicted_delta_rows": prediction[:, [pos, -1]].astype(np.float32),
            },
        )
        for index in range(1, 28):
            xf = torch.tensor(hf[index - 1][None], device=device)
            delta = torch.tensor(actual[index - 1][None].astype(np.float32), device=device)
            base, local_tangent = torch.func.jvp(
                lambda h: model.model.layers[index](
                    h, attention_mask=context["mask"], position_embeddings=context["rope"]
                ),
                (xf,),
                (delta,),
            )
            status["local_block_forward_ad_invocations"] += 1
            pe = float(np.max(abs(array(base[0]) - hf[index])))
            assert pe <= 1e-4
            local = array(local_tangent[0]).astype(np.float64)
            remainder = actual[index] - local
            assert np.count_nonzero(remainder[:pos]) == 0
            norm = float(np.linalg.norm(remainder))
            contributions = [dot(weight[index], remainder) for weight in weights]
            duality = []
            for weight in weights:
                lhs = dot(weight[index], local)
                rhs = dot(weight[index - 1], actual[index - 1])
                duality.append(
                    {
                        "forward": lhs,
                        "reverse": rhs,
                        "absolute_error": abs(lhs - rhs),
                        "passed": close(lhs, rhs),
                    }
                )
            rows.append(
                {
                    "block": index + 1,
                    "remainder_full_norm": norm,
                    "remainder_source_norm": float(np.linalg.norm(remainder[pos])),
                    "remainder_verdict_norm": float(np.linalg.norm(remainder[-1])),
                    "native_displacement_full_norm": float(np.linalg.norm(actual[index])),
                    "native_displacement_verdict_norm": float(np.linalg.norm(actual[index, -1])),
                    "prediction_error_verdict_norm": float(np.linalg.norm(error[index, -1])),
                    "margin_contribution": contributions[0],
                    "error_direction_contribution": contributions[1],
                    "margin_projected_gain": abs(contributions[0]) / norm if norm else None,
                    "error_direction_projected_gain": abs(contributions[1]) / norm
                    if norm
                    else None,
                    "local_primal_error": pe,
                    "duality": duality,
                }
            )
            saved[f"remainder_{index + 1}_rows"] = remainder[[pos, -1]].astype(np.float32)
        actual_dm = float((st[1] - st[0]) - (sf[1] - sf[0]))
        predicted_dm = float(predicted_scores[1] - predicted_scores[0])
        readout_remainder = actual_dm - dot(weights[0][-1], actual[-1])
        reconstructed_margin_error = sum(r["margin_contribution"] for r in rows) + readout_remainder
        reconstructed_residual_projection = sum(r["error_direction_contribution"] for r in rows)
        budget = {
            "actual_margin_error": actual_dm - predicted_dm,
            "reconstructed_margin_error": reconstructed_margin_error,
            "readout_remainder": readout_remainder,
            "observed_final_error_norm": final_error_norm,
            "reconstructed_final_error_projection": reconstructed_residual_projection,
            "margin_passed": close(reconstructed_margin_error, actual_dm - predicted_dm),
            "residual_passed": close(reconstructed_residual_projection, final_error_norm),
        }
        assert all(np.isfinite(v).all() for v in saved.values())
        path = RUN / "records" / f"{key}.npz"
        path.parent.mkdir(parents=True, exist_ok=True)
        np.savez_compressed(path, **saved)
        record = {
            "fingerprint": bundle["fingerprint"],
            **g,
            "position": pos,
            "forecast_parent_sha256": hashed(fp),
            "observation_parent_sha256": hashed(op),
            "parent_record_sha256": digest(fr),
            "replay_state_error": replay_state_error,
            "replay_score_error": replay_score_error,
            "rows": rows,
            "budget": budget,
            "states_sha256": hashed(path),
            "started_utc": started,
            "completed_utc": now(),
        }
        write_json(path.with_suffix(".json"), {"record": record, "sha256": digest(record)})
        manifest.append(
            {"key": key, "record_sha256": digest(record), "states_sha256": record["states_sha256"]}
        )
        status.update(pairs=len(manifest), updated_utc=now())
        write_json(RUN / "pipeline-status.json", status)
        print(
            f"199 paired remainder diagnosis {len(manifest)}/64; marginbudget {budget['margin_passed']} residualbudget {budget['residual_passed']}",
            flush=True,
        )
        del (
            public,
            primal,
            tangent,
            native_states,
            reverse_states,
            output,
            adjoints,
            weights,
            x,
            actual,
            hf,
            ht,
            prediction,
            error,
            saved,
        )
        gc.collect()
    assert all(
        status[k] == bundle["design"][k]
        for k in (
            "ordinary_false_model_invocations",
            "forward_false_model_invocations",
            "reverse_false_model_invocations",
            "local_block_forward_ad_invocations",
        )
    )
    write_json(
        RUN / "manifest.json",
        {"manifest": manifest, "sha256": digest(manifest), "completed_utc": now()},
    )


if __name__ == "__main__":
    main()
