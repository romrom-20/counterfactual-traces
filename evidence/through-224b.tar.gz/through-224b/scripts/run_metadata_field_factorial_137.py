#!/usr/bin/env python3
"""137/138: independently vary the first and second field names behind metadata copying."""

import argparse
import gc
import itertools
import json
import os
import platform
import subprocess
import sys
from pathlib import Path

import run_joint_support_119 as prior
import run_metadata_evidence_135 as ancestor135
import run_verdict_metadata_133 as previous
import torch
import transformers
from run_absence_alphabet_104 import MODELS, now

from latent_decisions import evidence_policy as core
from latent_decisions.target import load_target

ROOT = Path(__file__).resolve().parents[1]
DEFAULT = ROOT / "runs/metadata-field-factorial-137-138"


SCHEMAS = {
    "vv": ["first_value", "second_value"],
    "rs": ["record_flag", "supported"],
    "vs": ["first_value", "supported"],
    "rv": ["record_flag", "second_value"],
}

RULE = (
    "Use only the passage to judge whether proposed_answer is directly supported as an answer to question. "
    "An occurrence of the proposed answer in an unrelated fact is not sufficient. "
    "Do not use outside knowledge. "
)
NEW_FACTS = [
    {
        "id": "code",
        "stage": "138",
        "candidate": "K7",
        "contexts": [
            "The amber card carries code R2. The violet card carries code K7.",
            "The amber card carries code K7. The violet card carries code R2.",
        ],
        "questions": [
            "Which code does the amber card carry?",
            "What is the code on the amber card?",
        ],
    },
    {
        "id": "capacity",
        "stage": "138",
        "candidate": "three",
        "contexts": [
            "The amber container holds seven marbles. The violet container holds three marbles.",
            "The amber container holds three marbles. The violet container holds seven marbles.",
        ],
        "questions": [
            "How many marbles does the amber container hold?",
            "What is the number of marbles in the amber container?",
        ],
    },
]


def blocks():
    old = [
        {**b, "stage": "137", "given_controls": i == 0} for i, b in enumerate(ancestor135.FACTS[:2])
    ]
    return old + [{**b, "given_controls": False} for b in NEW_FACTS]


def jobs(block):
    result = [
        {
            "kind": "evidence",
            "query": q,
            "supported_context": status,
            "schema": schema,
            "clamp": clamp,
        }
        for q, status, schema, clamp in itertools.product(
            range(2), (False, True), SCHEMAS, (False, True)
        )
    ]
    if block.get("given_controls"):
        result += [
            {"kind": "given", "status": status, "schema": schema, "clamp": clamp}
            for status, schema, clamp in itertools.product((False, True), SCHEMAS, (False, True))
        ]
    return sorted(result, key=core.digest)


def instruction(schema, singleton=False):
    flag, verdict = SCHEMAS[schema]
    if singleton:
        return f'Return only a JSON object with a boolean value for key "{verdict}". For "{verdict}", true means the proposed answer is supported and false means it is unsupported.'
    return (
        f'Return only a JSON object with boolean values for keys "{flag}" and "{verdict}". '
        f'"{flag}" is an arbitrary metadata bit with no meaning about the passage, question or answer correctness. Either true or false is permitted. '
        f'For "{verdict}", true means the proposed answer is supported and false means it is unsupported.'
    )


def messages(block, job):
    if job["kind"] == "anchor":
        return previous.messages(block, {**job, "kind": "metadata"})
    ins = instruction(job["schema"], job["kind"] == "singleton")
    if job["kind"] == "given":
        system = (
            "The answer support status is already given. Do not reassess it. Encode the given status. "
            + ins
        )
        content = {"answer_is_supported": job["status"]}
    else:
        system = RULE + ins
        content = {
            "passage": block["contexts"][int(job["supported_context"])],
            "proposed_answer": block["candidate"],
            "question": block["questions"][job["query"]],
        }
    return [
        {"role": "system", "content": system},
        {"role": "user", "content": json.dumps(content, ensure_ascii=False)},
    ]


def candidates(job):
    if job["kind"] == "anchor":
        return previous.candidates({**job, "kind": "metadata"})
    flag, verdict = SCHEMAS[job["schema"]]
    if job["kind"] == "singleton":
        return [(json.dumps({verdict: v}), [v]) for v in (False, True)]
    return [
        (json.dumps({flag: job["clamp"], verdict: v}), [job["clamp"], v]) for v in (False, True)
    ]


def parse(raw, job):
    if job["kind"] == "anchor":
        return previous.parse(raw, "metadata")
    keys = SCHEMAS[job["schema"]][-1:] if job["kind"] == "singleton" else SCHEMAS[job["schema"]]

    def unique(pairs):
        if len(pairs) != len(dict(pairs)):
            raise ValueError("Duplicate keys")
        return dict(pairs)

    try:
        obj = json.loads(raw, object_pairs_hook=unique)
        if (
            type(obj) is not dict
            or list(obj) != keys
            or any(type(v) is not bool for v in obj.values())
        ):
            return False, None
        return True, [obj[k] for k in keys]
    except (ValueError, TypeError):
        return False, None


def source_hash():
    return core.digest(
        {
            "runner": Path(__file__).read_text(),
            "protocol": (ROOT / "docs/experiments/137-138-metadata-field-factorial.md").read_text(),
            "dependencies": ancestor135.source_hash(),
        }
    )


def prepare(run):
    selected_blocks = blocks()
    path = run / "design.json"
    if path.exists():
        b = json.loads(path.read_text())
        assert (
            core.digest(b["design"]) == b["fingerprint"]
            and b["design"]["source_hash"] == source_hash()
        )
        assert b["design"]["blocks"] == selected_blocks
        return b
    d = {
        "created_utc": now(),
        "source_hash": source_hash(),
        "data_hash": prior.DATA_HASH,
        "models": MODELS,
        "blocks": selected_blocks,
        "clamps": [False, True],
        "schemas": SCHEMAS,
        "max_new_tokens": 80,
        "max_prompt_tokens": 2048,
        "dominance_minimum": 0.75,
        "main_target": "first-field name, second-field name or conjunction controls metadata copying",
        "invariance_minimum": 0.75,
        "encoding_minimum": 1.0,
    }
    b = {"design": d, "fingerprint": core.digest(d)}
    core.write_json(path, b)
    return b


def records(run, name, bundle):
    rt = run / name / "runtime.json"
    rh = core.digest(json.loads(rt.read_text())) if rt.exists() else None
    expected = {(b["id"], core.digest(job)) for b in bundle["design"]["blocks"] for job in jobs(b)}
    got = {}
    for path in (run / name / "records").glob("*.json"):
        e = json.loads(path.read_text())
        r = e["record"]
        key = (r["block"], core.digest(r["job"]))
        assert key in expected and key not in got and core.digest(r) == e["sha256"]
        assert r["fingerprint"] == bundle["fingerprint"] and r["runtime_hash"] == rh
        got[key] = r
    return got


def run_model(run, name, bundle, status):
    saved = records(run, name, bundle)
    blocks = bundle["design"]["blocks"]
    total = sum(len(jobs(b)) for b in blocks)
    if len(saved) == total:
        return
    model, tok, device = load_target(MODELS[name], "mps", offline=True)
    rt = {
        "model": MODELS[name],
        "device": device,
        "dtype": str(next(model.parameters()).dtype),
        "training": model.training,
        "python": platform.python_version(),
        "torch": torch.__version__,
        "transformers": transformers.__version__,
        "penalty": 1.0,
        "tokenizer_hash": core.digest(tok.get_vocab()),
        "config_hash": core.digest(model.config.to_dict()),
        "chat_template": tok.chat_template,
    }
    assert rt == json.loads((prior.DEFAULT / name / "runtime.json").read_text())
    path = run / name / "runtime.json"
    if path.exists():
        assert json.loads(path.read_text()) == rt
    core.write_json(path, rt)
    for block in blocks:
        for job in jobs(block):
            key = (block["id"], core.digest(job))
            if key in saved:
                continue
            msg = messages(block, job)
            prefix = tok.apply_chat_template(msg, tokenize=True, add_generation_prompt=True)
            assert len(prefix) <= 2048
            choices = candidates(job)
            sequences = core.token_sequences(tok, choices)
            assert len(sequences) == 2 and len(sequences[0]) == len(sequences[1])
            assert sum(a != b for a, b in zip(*sequences)) == 1
            ids, raw = core.generate(model, tok, prefix, 1.0, 80, sequences=sequences)
            assert ids in sequences
            valid, pred = parse(raw, job)
            assert valid
            o = {
                "messages": msg,
                "prompt_ids": prefix,
                "ids": ids,
                "raw": raw,
                "prediction": pred,
                "second_supported": pred[-1],
                "valid": valid,
                "choices": choices,
                "sequences": sequences,
            }
            r = {
                "block": block["id"],
                "stage": block["stage"],
                "job": job,
                "output": o,
                "fingerprint": bundle["fingerprint"],
                "runtime_hash": core.digest(rt),
            }
            core.write_json(
                run / name / "records" / f"{core.digest(key)}.json",
                {"record": r, "sha256": core.digest(r)},
            )
            saved[key] = r
            status.update(
                model=name, stage=block["stage"], completed_queries=len(saved), updated_utc=now()
            )
            core.write_json(run / "pipeline-status.json", status)
            print(f"{name} {block['stage']} {len(saved)}/{total}", flush=True)
    del model, tok
    gc.collect()
    torch.mps.empty_cache()


def launch(run):
    with core.exclusive_lock(run / ".launch.lock"):
        b = prepare(run)
        path = run / "launch.json"
        if path.exists():
            try:
                os.kill(json.loads(path.read_text())["pid"], 0)
            except ProcessLookupError:
                pass
            else:
                raise RuntimeError("Already running")
        with (run / "pipeline.log").open("a") as log:
            p = subprocess.Popen(
                [
                    "/usr/bin/caffeinate",
                    "-i",
                    sys.executable,
                    "-u",
                    str(Path(__file__).resolve()),
                    "--run",
                    str(run.resolve()),
                ],
                cwd=ROOT,
                env={**os.environ, "PYTHONPATH": str(ROOT / "src")},
                stdin=subprocess.DEVNULL,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
        receipt = {"pid": p.pid, "fingerprint": b["fingerprint"], "launched_utc": now()}
        core.write_json(path, receipt)
        return receipt


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--run", type=Path, default=DEFAULT)
    p.add_argument("--prepare", action="store_true")
    p.add_argument("--launch", action="store_true")
    args = p.parse_args()
    if args.prepare:
        print(prepare(args.run)["fingerprint"])
        return
    if args.launch:
        print(json.dumps(launch(args.run)))
        return
    with core.exclusive_lock(args.run / ".pipeline.lock"):
        b = prepare(args.run)
        status = {"status": "running", "started_utc": now(), "fingerprint": b["fingerprint"]}
        try:
            for name in MODELS:
                run_model(args.run, name, b, status)
            status.update(status="complete", updated_utc=now())
        except BaseException as exc:
            status.update(status="technical_failure", error=repr(exc), updated_utc=now())
            core.write_json(args.run / "pipeline-status.json", status)
            raise
        core.write_json(args.run / "pipeline-status.json", status)
        print("Complete", flush=True)


if __name__ == "__main__":
    main()
