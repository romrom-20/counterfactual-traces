#!/usr/bin/env python3
"""139/140: capture the sole free Boolean's scores from public greedy generation."""

import argparse
import gc
import json
import os
import platform
import subprocess
import sys
from pathlib import Path

import run_metadata_field_factorial_137 as previous
import torch
import transformers
from run_absence_alphabet_104 import MODELS, now

from latent_decisions import evidence_policy as core
from latent_decisions.target import load_target

ROOT = Path(__file__).resolve().parents[1]
DEFAULT = ROOT / "runs/metadata-token-margin-139-140"
NEW_FACTS = [
    {
        "id": "price",
        "stage": "140",
        "candidate": "five coins",
        "contexts": [
            "The round ticket costs nine coins. The square ticket costs five coins.",
            "The round ticket costs five coins. The square ticket costs nine coins.",
        ],
        "questions": [
            "How much does the round ticket cost?",
            "What is the price of the round ticket?",
        ],
        "given_controls": False,
    },
    {
        "id": "destination",
        "stage": "140",
        "candidate": "Mira",
        "contexts": [
            "The silver parcel is addressed to Oren. The bronze parcel is addressed to Mira.",
            "The silver parcel is addressed to Mira. The bronze parcel is addressed to Oren.",
        ],
        "questions": [
            "To whom is the silver parcel addressed?",
            "Who is the addressee of the silver parcel?",
        ],
        "given_controls": False,
    },
]


def blocks():
    return [{**b, "stage": "139"} for b in previous.blocks()] + NEW_FACTS


def source_hash():
    return core.digest(
        {
            "runner": Path(__file__).read_text(),
            "protocol": (ROOT / "docs/experiments/139-140-metadata-token-margin.md").read_text(),
            "dependencies": previous.source_hash(),
        }
    )


def prepare(run):
    parent = previous.prepare(previous.DEFAULT)
    path = run / "design.json"
    if path.exists():
        b = json.loads(path.read_text())
        assert (
            core.digest(b["design"]) == b["fingerprint"]
            and b["design"]["source_hash"] == source_hash()
        )
        assert (
            b["design"]["parent_fingerprint"] == parent["fingerprint"]
            and b["design"]["blocks"] == blocks()
        )
        return b
    d = {
        "created_utc": now(),
        "source_hash": source_hash(),
        "parent_fingerprint": parent["fingerprint"],
        "models": MODELS,
        "blocks": blocks(),
        "schemas": previous.SCHEMAS,
        "clamps": [False, True],
        "max_new_tokens": 80,
        "max_prompt_tokens": 2048,
        "coupling_tolerance_nats": 0.25,
        "dominance_minimum": 0.75,
        "encoding_minimum": 1.0,
        "main_target": "schema-independent versus schema-dependent flag coupling in the free-token margin",
    }
    b = {"design": d, "fingerprint": core.digest(d)}
    core.write_json(path, b)
    return b


@torch.inference_mode()
def generate_scores(model, tok, prefix, sequences):
    assert len(sequences) == 2 and len(sequences[0]) == len(sequences[1])
    differing = [i for i, (a, b) in enumerate(zip(*sequences)) if a != b]
    assert len(differing) == 1
    free = differing[0]
    branches = core.trie(sequences)

    def allowed(batch_id, ids):
        return branches.get(tuple(ids.tolist()[len(prefix) :]), [tok.eos_token_id])

    inputs = torch.tensor([prefix], device=next(model.parameters()).device)
    out = model.generate(
        input_ids=inputs,
        attention_mask=torch.ones_like(inputs),
        generation_config=core.generation_config(tok, 1.0, 80),
        prefix_allowed_tokens_fn=allowed,
        return_dict_in_generate=True,
        output_scores=True,
    )
    ids = out.sequences[0, len(prefix) :].tolist()
    assert ids in sequences and len(out.scores) == len(ids)
    false_id, true_id = (seq[free] for seq in sequences)
    scores = out.scores[free][0].float()
    finite = sorted(torch.where(torch.isfinite(scores))[0].tolist())
    assert finite == sorted([false_id, true_id])
    fs, ts = float(scores[false_id]), float(scores[true_id])
    selected = ids[free]
    assert float(scores[selected]) == max(fs, ts)
    margin = {
        "free_index": free,
        "false_token": false_id,
        "true_token": true_id,
        "false_score": fs,
        "true_score": ts,
        "log_odds": ts - fs,
        "finite_token_ids": finite,
        "selected_token": selected,
    }
    return ids, tok.decode(ids, skip_special_tokens=True), margin


def saved_records(run, name, bundle):
    runtime = run / name / "runtime.json"
    rh = core.digest(json.loads(runtime.read_text())) if runtime.exists() else None
    expected = {
        (b["id"], core.digest(j)) for b in bundle["design"]["blocks"] for j in previous.jobs(b)
    }
    saved = {}
    for path in (run / name / "records").glob("*.json"):
        e = json.loads(path.read_text())
        r = e["record"]
        key = (r["block"], core.digest(r["job"]))
        assert key in expected and key not in saved and core.digest(r) == e["sha256"]
        assert r["fingerprint"] == bundle["fingerprint"] and r["runtime_hash"] == rh
        saved[key] = r
    return saved


def run_model(run, name, bundle, status):
    saved = saved_records(run, name, bundle)
    total = sum(len(previous.jobs(b)) for b in bundle["design"]["blocks"])
    assert total == 208
    if len(saved) == total:
        return
    old = {}
    for path in (previous.DEFAULT / name / "records").glob("*.json"):
        e = json.loads(path.read_text())
        r = e["record"]
        assert (
            core.digest(r) == e["sha256"]
            and r["fingerprint"] == bundle["design"]["parent_fingerprint"]
        )
        old[(r["block"], core.digest(r["job"]))] = r
    assert len(old) == 144
    model, tok, device = load_target(MODELS[name], "mps", offline=True)
    runtime = {
        "model": MODELS[name],
        "device": device,
        "dtype": str(next(model.parameters()).dtype),
        "training": model.training,
        "python": platform.python_version(),
        "torch": torch.__version__,
        "transformers": transformers.__version__,
        "penalty": 1.0,
        "tokenizer_hash": core.digest(tok.get_vocab()),
        "config_hash": core.digest(model.config.to_dict()),
        "chat_template": tok.chat_template,
    }
    assert runtime == json.loads((previous.DEFAULT / name / "runtime.json").read_text())
    core.write_json(run / name / "runtime.json", runtime)
    for block in bundle["design"]["blocks"]:
        for job in previous.jobs(block):
            key = (block["id"], core.digest(job))
            if key in saved:
                continue
            messages = previous.messages(block, job)
            prefix = tok.apply_chat_template(messages, tokenize=True, add_generation_prompt=True)
            assert len(prefix) <= 2048
            choices = previous.candidates(job)
            seqs = core.token_sequences(tok, choices)
            ids, raw, margin = generate_scores(model, tok, prefix, seqs)
            valid, pred = previous.parse(raw, job)
            assert valid
            output = {
                "messages": messages,
                "prompt_ids": prefix,
                "choices": choices,
                "sequences": seqs,
                "ids": ids,
                "raw": raw,
                "valid": valid,
                "prediction": pred,
                "second_supported": pred[-1],
            }
            if block["stage"] == "139":
                assert output == old[key]["output"], "Score collection changed a replay"
            record = {
                "block": block["id"],
                "stage": block["stage"],
                "job": job,
                "output": output,
                "margin": margin,
                "fingerprint": bundle["fingerprint"],
                "runtime_hash": core.digest(runtime),
            }
            core.write_json(
                run / name / "records" / f"{core.digest(key)}.json",
                {"record": record, "sha256": core.digest(record)},
            )
            saved[key] = record
            status.update(
                model=name, stage=block["stage"], completed_queries=len(saved), updated_utc=now()
            )
            core.write_json(run / "pipeline-status.json", status)
            print(f"{name} {block['stage']} {len(saved)}/{total}", flush=True)
    del model, tok
    gc.collect()
    torch.mps.empty_cache()


def launch(run):
    with core.exclusive_lock(run / ".launch.lock"):
        bundle = prepare(run)
        path = run / "launch.json"
        if path.exists():
            try:
                os.kill(json.loads(path.read_text())["pid"], 0)
            except ProcessLookupError:
                pass
            else:
                raise RuntimeError("Already running")
        with (run / "pipeline.log").open("a") as log:
            p = subprocess.Popen(
                [
                    "/usr/bin/caffeinate",
                    "-i",
                    sys.executable,
                    "-u",
                    str(Path(__file__).resolve()),
                    "--run",
                    str(run.resolve()),
                ],
                cwd=ROOT,
                env={**os.environ, "PYTHONPATH": str(ROOT / "src")},
                stdin=subprocess.DEVNULL,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
        receipt = {"pid": p.pid, "fingerprint": bundle["fingerprint"], "launched_utc": now()}
        core.write_json(path, receipt)
        return receipt


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run", type=Path, default=DEFAULT)
    parser.add_argument("--prepare", action="store_true")
    parser.add_argument("--launch", action="store_true")
    args = parser.parse_args()
    if args.prepare:
        print(prepare(args.run)["fingerprint"])
        return
    if args.launch:
        print(json.dumps(launch(args.run)))
        return
    with core.exclusive_lock(args.run / ".pipeline.lock"):
        bundle = prepare(args.run)
        status = {"status": "running", "started_utc": now(), "fingerprint": bundle["fingerprint"]}
        try:
            for name in MODELS:
                run_model(args.run, name, bundle, status)
            status.update(status="complete", updated_utc=now())
        except BaseException as exc:
            status.update(status="technical_failure", error=repr(exc), updated_utc=now())
            core.write_json(args.run / "pipeline-status.json", status)
            raise
        core.write_json(args.run / "pipeline-status.json", status)
        print("Complete", flush=True)


if __name__ == "__main__":
    main()
