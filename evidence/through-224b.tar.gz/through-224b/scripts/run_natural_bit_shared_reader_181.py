"""All28-layer operator cuts for actual Boolean input pairs, without residual replacement."""

import argparse
import gc
import hashlib
import itertools
import json
import math
import os
import subprocess
import sys
from contextlib import contextmanager
from pathlib import Path

import audit_binding_carrier_partition_160 as fixture
import numpy as np
import torch
from run_absence_alphabet_104 import now
from run_order_competence_151 import runtime
from transformers.models.qwen2 import modeling_qwen2 as impl

from latent_decisions.evidence_policy import digest, exclusive_lock, write_json
from latent_decisions.target import block_tensor, load_target

ROOT = Path(__file__).resolve().parents[1]
DEFAULT = ROOT / "runs/natural-bit-shared-reader-181"
PARENT = ROOT / "runs/layer-curvature-atlas-179"
ARMS = ("native", "own", "N", "W", "G", "NW", "NG", "WG", "NWG", "neutral", "canonical")
LITERALS = (
    ("bronze", "nickel", "Monday", "Thursday"),
    ("willow", "cedar", "Tuesday", "Friday"),
    ("orbit", "comet", "Wednesday", "Saturday"),
    ("saffron", "ochre", "Friday", "Sunday"),
)


def blocks():
    return [
        {"id": a, "stage": "181", "subjects": [a, b], "days": [x, y], "old_block": None}
        for a, b, x, y in LITERALS
    ]


def source_hash():
    return digest(
        {
            "runner": Path(__file__).read_text(),
            "protocol": (ROOT / "docs/experiments/181-natural-bit-shared-reader.md").read_text(),
            "fixture": Path(fixture.__file__).read_text(),
            "fixture_source": (ROOT / "scripts/audit_counterbalanced_binding_155.py").read_text(),
            "fixture_messages": (ROOT / "scripts/audit_order_competence_151.py").read_text(),
            "runtime_helper": (ROOT / "scripts/run_order_competence_151.py").read_text(),
            "evidence_policy": (ROOT / "src/latent_decisions/evidence_policy.py").read_text(),
            "target": (ROOT / "src/latent_decisions/target.py").read_text(),
            "implementation": Path(impl.__file__).read_text(),
        }
    )


def prepare(run):
    parent = json.loads((PARENT / "design.json").read_text())
    audit = json.loads((ROOT / "docs/analysis/179-independent-audit.json").read_text())
    assert (
        audit["complete"]
        and all(audit["controls"].values())
        and audit["qualification"]["numerical_qualified"]
    )
    d = {
        "source_hash": source_hash(),
        "parent_fingerprint": parent["fingerprint"],
        "models": parent["design"]["models"],
        "blocks": blocks(),
        "arms": list(ARMS),
        "main_forwards": 1408,
        "numerical_forwards": 88,
        "tolerance": 0.1,
        "individual_floor": 0.5,
        "balanced_floor": 0.2,
        "retained_fraction": 0.5,
        "dominance": 0.75,
        "architectural_score_tolerance": 0.005,
        "architectural_state_tolerance": 0.005,
    }
    p = run / "design.json"
    if p.exists():
        b = json.loads(p.read_text())
        assert b["design"] == d and digest(d) == b["fingerprint"]
        return b
    b = {"design": d, "fingerprint": digest(d), "created_utc": now()}
    write_json(p, b)
    return b


def mean(a, b):
    assert a.shape == b.shape and a.dtype == b.dtype == np.float32
    return ((a.astype(np.float64) + b.astype(np.float64)) / 2).astype(np.float32)


def norm_sites(model):
    return {
        **{
            f"{layer}_{kind}": getattr(model.model.layers[layer - 1], attr)
            for layer, (kind, attr) in itertools.product(
                range(1, 29), (("pre", "input_layernorm"), ("post", "post_attention_layernorm"))
            )
        },
        "final": model.model.norm,
    }


def array_hash(value):
    return hashlib.sha256(value.tobytes()).hexdigest()


@contextmanager
def operators(model, pos, fixed=None, values=None):
    """Capture effective factors; freeze only receiver rows, V only at bit row."""
    fixed, values = fixed or {}, values or {}
    cap, trace, handles = {}, [], []
    original = impl.eager_attention_forward
    assert len(model.model.layers) == 28 and model.config._attn_implementation == "eager"
    assert len({id(layer.mlp.act_fn) for layer in model.model.layers}) == 28
    try:
        for name, module in norm_sites(model).items():
            label = f"N_{name}"

            def norm(module, args, out, label=label):
                h = args[0]
                inv = torch.rsqrt(h.pow(2).mean(-1, keepdim=True) + module.variance_epsilon)
                assert torch.equal(module.weight * (h * inv), out)
                factor = inv[0, pos + 1 :]
                if label in fixed:
                    factor = torch.as_tensor(fixed[label], device=h.device)
                    assert factor.shape == inv[0, pos + 1 :].shape and (factor > 0).all()
                    changed = out.clone()
                    changed[0, pos + 1 :] = module.weight * (h[0, pos + 1 :] * factor)
                    assert torch.equal(changed[:, : pos + 1], out[:, : pos + 1])
                    out = changed
                cap[label] = factor.detach().cpu().numpy().copy()
                trace.append(
                    {
                        "site": label,
                        "fixed": label in fixed,
                        "start": pos + 1,
                        "end": h.shape[1],
                        "other_rows_identical": True,
                        "applied_sha256": array_hash(cap[label]),
                    }
                )
                return out

            handles.append(module.register_forward_hook(norm))

        def attention(module, query, key, value, attention_mask, scaling, dropout=0.0, **kwargs):
            out, w = original(module, query, key, value, attention_mask, scaling, dropout, **kwargs)
            label = f"W_{module.layer_idx + 1}"
            assert not module.training and dropout == 0 and w.dtype == torch.float32
            if label in fixed:
                target = torch.as_tensor(fixed[label], device=w.device)
                assert target.shape == w[0, :, pos + 1 :].shape
                changed = w.clone()
                changed[0, :, pos + 1 :] = target
                changed_out = (
                    torch.matmul(changed, impl.repeat_kv(value, module.num_key_value_groups))
                    .transpose(1, 2)
                    .contiguous()
                )
                assert torch.equal(changed_out[:, : pos + 1], out[:, : pos + 1])
                out, w = changed_out, changed
            cap[label] = w[0, :, pos + 1 :].detach().cpu().numpy().copy()
            trace.append(
                {
                    "site": label,
                    "fixed": label in fixed,
                    "start": pos + 1,
                    "end": w.shape[2],
                    "other_rows_identical": True,
                    "applied_sha256": array_hash(cap[label]),
                }
            )
            return out, w

        impl.eager_attention_forward = attention
        for layer in range(1, 29):

            def gate(module, args, out, label=f"G_{layer}"):
                if label in fixed:
                    target = torch.as_tensor(fixed[label], device=out.device)
                    assert target.shape == out[0, pos + 1 :].shape
                    changed = out.clone()
                    changed[0, pos + 1 :] = target
                    assert torch.equal(changed[:, : pos + 1], out[:, : pos + 1])
                    out = changed
                cap[label] = out[0, pos + 1 :].detach().cpu().numpy().copy()
                trace.append(
                    {
                        "site": label,
                        "fixed": label in fixed,
                        "start": pos + 1,
                        "end": out.shape[1],
                        "other_rows_identical": True,
                        "applied_sha256": array_hash(cap[label]),
                    }
                )
                return out

            def value(module, args, out, label=f"V_{layer}"):
                if label in values:
                    target = torch.as_tensor(values[label], device=out.device)
                    assert target.shape == out[0, pos].shape
                    changed = out.clone()
                    changed[0, pos] = target
                    assert torch.equal(changed[:, :pos], out[:, :pos]) and torch.equal(
                        changed[:, pos + 1 :], out[:, pos + 1 :]
                    )
                    out = changed
                cap[label] = out[0, pos].detach().cpu().numpy().copy()
                trace.append(
                    {
                        "site": label,
                        "fixed": label in values,
                        "start": pos,
                        "end": pos + 1,
                        "other_rows_identical": True,
                        "applied_sha256": array_hash(cap[label]),
                    }
                )
                return out

            handles.append(model.model.layers[layer - 1].mlp.act_fn.register_forward_hook(gate))
            handles.append(
                model.model.layers[layer - 1].self_attn.v_proj.register_forward_hook(value)
            )
        yield cap, trace
        assert set(cap) == {f"N_{s}" for s in norm_sites(model)} | {
            f"{kind}_{site}" for kind, site in itertools.product(("W", "G", "V"), range(1, 29))
        }
        assert len(trace) == len(cap) == 141 and len({t["site"] for t in trace}) == 141
    finally:
        impl.eager_attention_forward = original
        for handle in handles:
            handle.remove()


@torch.inference_mode()
def score(model, base):
    states, handles = {}, []

    def final(module, args, out):
        states["final"] = block_tensor(out)[0].detach().cpu().numpy().copy()

    handles.append(model.model.layers[27].register_forward_hook(final))
    try:
        ids = torch.tensor([base["free_input_ids"]], device=next(model.parameters()).device)
        out = model(
            input_ids=ids, attention_mask=torch.ones_like(ids), use_cache=False, logits_to_keep=1
        )
        fs, ts = (float(out.logits[0, -1, base[k]]) for k in ("false_token", "true_token"))
        assert math.isfinite(fs) and math.isfinite(ts)
        return {"false_score": fs, "true_score": ts, "log_odds": ts - fs}, states["final"]
    finally:
        for handle in handles:
            handle.remove()


def selected_factors(caps, arm):
    kinds = "NWG" if arm in ("own", "NWG", "neutral", "canonical") else arm
    assert arm in ARMS and arm != "native"
    return {label: v for label, v in caps.items() if label[0] in kinds}


def paired_bases(tok, block, g):
    bases = [fixture.reconstruct(tok, block, fixture.job(g, bit)) for bit in range(2)]
    ids = [b["free_input_ids"] for b in bases]
    assert len(ids[0]) == len(ids[1])
    diffs = [i for i, (a, b) in enumerate(zip(*ids)) if a != b]
    assert (
        len(diffs) == 1
        and bases[0]["messages"] == bases[1]["messages"]
        and bases[0]["facts"] == bases[1]["facts"]
    )
    return bases, diffs[0]


def run_model(run, bundle, status):
    model, tok, device = load_target(bundle["design"]["models"]["qwen15"], "mps", offline=True)
    rt = runtime(model, tok, device, "qwen15")
    assert rt == json.loads((PARENT / "qwen15/runtime.json").read_text())
    write_json(run / "qwen15/runtime.json", rt)
    done, groups = 0, []
    canonical = {}
    for block, a, t, rev, schema in itertools.product(
        blocks(), range(2), range(2), range(2), ("generic", "descriptive")
    ):
        g = fixture.group(block, a, t, rev, schema)
        key = digest(g)
        bases, pos = paired_bases(tok, block, g)
        arrays, natives = {}, []
        for bit, base in enumerate(bases):
            with operators(model, pos) as (cap, trace):
                margin, h = score(model, base)
            arrays.update({f"native_{bit}_{name}": v for name, v in cap.items()})
            arrays[f"native_{bit}_final"] = h
            natives.append({"bit": bit, "base": base, "margin": margin, "trace": trace})
            done += 1
        if block["id"] == "bronze" and a == t == 0:
            canonical[f"{schema}_{rev}"] = {
                f"V_{site}": arrays[f"native_1_V_{site}"] - arrays[f"native_0_V_{site}"]
                for site in range(1, 29)
            }
        statep = run / "qwen15/native" / f"{key}.npz"
        statep.parent.mkdir(parents=True, exist_ok=True)
        np.savez_compressed(statep, **arrays)
        record = {
            "fingerprint": bundle["fingerprint"],
            **g,
            "position": pos,
            "natives": natives,
            "states_sha256": hashlib.sha256(statep.read_bytes()).hexdigest(),
        }
        write_json(
            run / "qwen15/native" / f"{key}.json", {"record": record, "sha256": digest(record)}
        )
        groups.append((g, key))
        status.update(completed_forwards=done, native_pairs=len(groups), updated_utc=now())
        write_json(run / "pipeline-status.json", status)
    assert done == 128 and len(canonical) == 4
    canonicalp = run / "qwen15/canonical-directions.npz"
    np.savez(
        canonicalp,
        **{f"{ctx}_{name}": v for ctx, vs in canonical.items() for name, v in vs.items()},
    )
    write_json(
        run / "qwen15/canonical-provenance.json",
        {
            "created_utc": now(),
            "completed_forwards": done,
            "sha256": hashlib.sha256(canonicalp.read_bytes()).hexdigest(),
            "donor": "bronze/assignment0/question0",
            "same_direction_across_source_question_assignment": True,
        },
    )
    for index, (g, key) in enumerate(groups):
        e = json.loads((run / "qwen15/native" / f"{key}.json").read_text())
        r = e["record"]
        assert digest(r) == e["sha256"]
        path = run / "qwen15/native" / f"{key}.npz"
        assert hashlib.sha256(path.read_bytes()).hexdigest() == r["states_sha256"]
        with np.load(path, allow_pickle=False) as z:
            caps = [
                {
                    name.removeprefix(f"native_{bit}_"): z[name].copy()
                    for name in z.files
                    if name.startswith(f"native_{bit}_") and name != f"native_{bit}_final"
                }
                for bit in range(2)
            ]
            means = {name: mean(caps[0][name], caps[1][name]) for name in caps[0]}
            states = [z[f"native_{bit}_final"].copy() for bit in range(2)]
        pos = r["position"]
        arrays = {f"mean_{name}": v for name, v in means.items()}
        patches = []
        for arm, bit in itertools.product(ARMS[1:], range(2)):
            base = r["natives"][bit]["base"]
            fixed = selected_factors(caps[bit] if arm == "own" else means, arm)
            values = (
                {name: v for name, v in means.items() if name.startswith("V_")}
                if arm == "neutral"
                else {
                    f"V_{site}": (
                        means[f"V_{site}"].astype(np.float64)
                        + (bit - 0.5)
                        * canonical[f"{g['schema']}_{g['reverse']}"][f"V_{site}"].astype(np.float64)
                    ).astype(np.float32)
                    for site in range(1, 29)
                }
                if arm == "canonical"
                else {}
            )
            with operators(model, pos, fixed, values) as (cap, trace):
                margin, h = score(model, base)
            assert np.array_equal(h[:pos], states[bit][:pos])
            if not values:
                assert np.array_equal(h[: pos + 1], states[bit][: pos + 1]) and all(
                    np.array_equal(cap[f"V_{site}"], caps[bit][f"V_{site}"])
                    for site in range(1, 29)
                )
            if arm == "own":
                assert margin == r["natives"][bit]["margin"] and np.array_equal(h, states[bit])
            arrays[f"{arm}_{bit}_final"] = h
            arrays.update(
                {f"{arm}_{bit}_{name}": v for name, v in cap.items() if name.startswith("V_")}
            )
            assert all(
                array_hash(cap[name]) == array_hash(value)
                for name, value in {**fixed, **values}.items()
            )
            patches.append({"arm": arm, "bit": bit, "margin": margin, "trace": trace})
            done += 1
        keep = np.r_[np.arange(pos), np.arange(pos + 1, len(states[0]))]
        assert np.array_equal(arrays["neutral_0_final"][keep], arrays["neutral_1_final"][keep])
        neutral = [
            next(p["margin"] for p in patches if p["arm"] == "neutral" and p["bit"] == b)
            for b in range(2)
        ]
        assert neutral[0] == neutral[1]
        sp = run / "qwen15/states" / f"{key}.npz"
        sp.parent.mkdir(parents=True, exist_ok=True)
        np.savez_compressed(sp, **arrays)
        record = {
            "fingerprint": bundle["fingerprint"],
            **g,
            "position": pos,
            "native_sha256": e["sha256"],
            "patches": patches,
            "states_sha256": hashlib.sha256(sp.read_bytes()).hexdigest(),
        }
        write_json(
            run / "qwen15/records" / f"{key}.json", {"record": record, "sha256": digest(record)}
        )
        status.update(completed_forwards=done, completed_pairs=index + 1, updated_utc=now())
        write_json(run / "pipeline-status.json", status)
        print(f"181 pairs {index + 1}/64; physical forwards {done}/1408", flush=True)
        del arrays, caps, means, states
        gc.collect()
    assert done == 1408
    del model, tok
    gc.collect()
    torch.mps.empty_cache()


def launch(run):
    with exclusive_lock(run / ".launch.lock"):
        b = prepare(run)
        assert not (run / "launch.json").exists()
        with (run / "pipeline.log").open("a") as log:
            p = subprocess.Popen(
                [
                    "/usr/bin/caffeinate",
                    "-i",
                    sys.executable,
                    "-u",
                    str(Path(__file__).resolve()),
                    "--run",
                    str(run.resolve()),
                ],
                cwd=ROOT,
                env={**os.environ, "PYTHONPATH": str(ROOT / "src")},
                stdin=subprocess.DEVNULL,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
        out = {"pid": p.pid, "fingerprint": b["fingerprint"], "launched_utc": now()}
        write_json(run / "launch.json", out)
        return out


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--run", type=Path, default=DEFAULT)
    parser.add_argument("--launch", action="store_true")
    args = parser.parse_args()
    if args.launch:
        print(json.dumps(launch(args.run)))
        return
    with exclusive_lock(args.run / ".pipeline.lock"):
        b = prepare(args.run)
        status = {"status": "running", "started_utc": now(), "fingerprint": b["fingerprint"]}
        write_json(args.run / "pipeline-status.json", status)
        try:
            run_model(args.run, b, status)
            status.update(status="complete", updated_utc=now())
        except BaseException as exc:
            status.update(status="technical_failure", error=repr(exc), updated_utc=now())
            write_json(args.run / "pipeline-status.json", status)
            raise
        write_json(args.run / "pipeline-status.json", status)


if __name__ == "__main__":
    main()
