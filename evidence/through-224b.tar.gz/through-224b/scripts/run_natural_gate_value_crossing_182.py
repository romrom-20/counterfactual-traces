"""Natural receiving gate carrier crossed with metadata values, all28 layers."""

import argparse
import gc
import hashlib
import itertools
import json
import os
import subprocess
import sys
from pathlib import Path

import numpy as np
import run_natural_bit_shared_reader_181 as parent
import torch
from run_absence_alphabet_104 import now
from run_order_competence_151 import runtime

from latent_decisions.evidence_policy import digest, exclusive_lock, write_json
from latent_decisions.target import load_target

ROOT = Path(__file__).resolve().parents[1]
DEFAULT = ROOT / "runs/natural-gate-value-crossing-182"


def source_hash():
    return digest(
        {
            "runner": Path(__file__).read_text(),
            "protocol": (ROOT / "docs/experiments/182-natural-gate-value-crossing.md").read_text(),
            "parent": parent.source_hash(),
        }
    )


def prepare(run):
    pb = json.loads((parent.DEFAULT / "design.json").read_text())
    a = json.loads((ROOT / "docs/analysis/181-independent-audit.json").read_text())
    n = json.loads((ROOT / "docs/analysis/181-numerical-recheck.json").read_text())
    assert (
        a["complete"]
        and all(a["controls"].values())
        and a["numerical_qualified"]
        and n["passed"]
        and a["fingerprint"] == n["fingerprint"] == pb["fingerprint"]
        and pb["design"]["source_hash"] == parent.source_hash()
    )
    d = {
        "source_hash": source_hash(),
        "parent_fingerprint": pb["fingerprint"],
        "models": pb["design"]["models"],
        "blocks": parent.blocks(),
        "main_forwards": 832,
        "numerical_forwards": 60,
        "tolerance": 0.1,
        "individual_floor": 0.5,
        "balanced_floor": 0.2,
        "retained_fraction": 0.5,
        "dominance": 0.75,
        "architectural_score_tolerance": 0.005,
        "architectural_state_tolerance": 0.005,
    }
    p = run / "design.json"
    if p.exists():
        b = json.loads(p.read_text())
        assert b["design"] == d and digest(d) == b["fingerprint"]
        return b
    b = {"design": d, "fingerprint": digest(d), "created_utc": now()}
    write_json(p, b)
    return b


def blend(a, b, index):
    assert index in (0, 1, 2)
    return a.copy() if index == 0 else b.copy() if index == 2 else parent.mean(a, b)


def run_model(run, bundle, status):
    model, tok, device = load_target(bundle["design"]["models"]["qwen15"], "mps", offline=True)
    rt = runtime(model, tok, device, "qwen15")
    assert rt == json.loads((parent.DEFAULT / "qwen15/runtime.json").read_text())
    write_json(run / "qwen15/runtime.json", rt)
    canonical, canonical_sources = {}, {}
    for schema, rev in itertools.product(("generic", "descriptive"), range(2)):
        g = parent.fixture.group(parent.blocks()[0], 0, 0, rev, schema)
        key = digest(g)
        e = json.loads((parent.DEFAULT / "qwen15/native" / f"{key}.json").read_text())
        p = parent.DEFAULT / "qwen15/native" / f"{key}.npz"
        assert (
            digest(e["record"]) == e["sha256"]
            and hashlib.sha256(p.read_bytes()).hexdigest() == e["record"]["states_sha256"]
        )
        with np.load(p, allow_pickle=False) as z:
            canonical[f"{schema}_{rev}"] = {
                f"G_{site}": z[f"native_1_G_{site}"] - z[f"native_0_G_{site}"]
                for site in range(1, 29)
            }
        canonical_sources[f"{schema}_{rev}"] = {
            "record_sha256": e["sha256"],
            "state_sha256": e["record"]["states_sha256"],
        }
    cp = run / "canonical-gate-directions.npz"
    cp.parent.mkdir(parents=True, exist_ok=True)
    np.savez(
        cp,
        **{f"{ctx}_{name}": v for ctx, values in canonical.items() for name, v in values.items()},
    )
    write_json(
        run / "canonical-provenance.json",
        {
            "sha256": hashlib.sha256(cp.read_bytes()).hexdigest(),
            "sources": canonical_sources,
            "before182_forwards": True,
            "created_utc": now(),
        },
    )
    done = 0
    for index, (block, a, t, rev, schema) in enumerate(
        itertools.product(parent.blocks(), range(2), range(2), range(2), ("generic", "descriptive"))
    ):
        g = parent.fixture.group(block, a, t, rev, schema)
        key = digest(g)
        ne = json.loads((parent.DEFAULT / "qwen15/native" / f"{key}.json").read_text())
        pe = json.loads((parent.DEFAULT / "qwen15/records" / f"{key}.json").read_text())
        nr, pr = ne["record"], pe["record"]
        assert digest(nr) == ne["sha256"] and digest(pr) == pe["sha256"]
        nativep = parent.DEFAULT / "qwen15/native" / f"{key}.npz"
        assert hashlib.sha256(nativep.read_bytes()).hexdigest() == nr["states_sha256"]
        with np.load(nativep, allow_pickle=False) as z:
            caps = [
                {
                    name.removeprefix(f"native_{bit}_"): z[name].copy()
                    for name in z.files
                    if name.startswith(f"native_{bit}_") and name != f"native_{bit}_final"
                }
                for bit in range(2)
            ]
            nativeh = [z[f"native_{bit}_final"].copy() for bit in range(2)]
        means = {name: parent.mean(caps[0][name], caps[1][name]) for name in caps[0]}
        pos = nr["position"]
        base0 = nr["natives"][0]["base"]
        arrays, patches = {}, []

        # Bind storage/model explicitly so the per-case closure cannot retain old cases.
        def step(
            label,
            base,
            fixed,
            values,
            family,
            gamma=None,
            alpha=None,
            bit=None,
            target_model=model,
            storage=arrays,
            rows=patches,
            original_states=nativeh,
        ):
            with parent.operators(target_model, pos, fixed, values) as (cap, trace):
                margin, h = parent.score(target_model, base)
            assert np.array_equal(h[:pos], original_states[bit or 0][:pos])
            assert all(
                np.array_equal(cap[name], value) for name, value in {**fixed, **values}.items()
            )
            storage[f"{label}_final"] = h
            rows.append(
                {
                    "label": label,
                    "family": family,
                    "gamma": gamma,
                    "alpha": alpha,
                    "bit": bit,
                    "margin": margin,
                    "trace": trace,
                }
            )
            return margin, h

        for bit in range(2):
            fixed = {name: v for name, v in caps[bit].items() if name[0] in "NWG"}
            values = {name: v for name, v in caps[bit].items() if name[0] == "V"}
            m, h = step(f"own_{bit}", nr["natives"][bit]["base"], fixed, values, "own", bit=bit)
            assert m == nr["natives"][bit]["margin"] and np.array_equal(h, nativeh[bit])
            done += 1
        parentp = parent.DEFAULT / "qwen15/states" / f"{key}.npz"
        assert hashlib.sha256(parentp.read_bytes()).hexdigest() == pr["states_sha256"]
        with np.load(parentp, allow_pickle=False) as pz:
            for gi, vi in itertools.product(range(3), repeat=2):
                fixed = {name: v for name, v in means.items() if name[0] in "NW"}
                fixed.update(
                    {
                        f"G_{site}": blend(caps[0][f"G_{site}"], caps[1][f"G_{site}"], gi)
                        for site in range(1, 29)
                    }
                )
                values = {
                    f"V_{site}": blend(caps[0][f"V_{site}"], caps[1][f"V_{site}"], vi)
                    for site in range(1, 29)
                }
                m, h = step(f"grid_{gi}_{vi}", base0, fixed, values, "grid", gi, vi)
                if gi == 1:
                    arm, refbit = ("neutral", 0) if vi == 1 else ("NWG", vi // 2)
                    expected = next(
                        q["margin"] for q in pr["patches"] if (q["arm"], q["bit"]) == (arm, refbit)
                    )
                    nonmeta = np.r_[np.arange(pos), np.arange(pos + 1, len(h))]
                    assert m == expected and np.array_equal(
                        h[nonmeta], pz[f"{arm}_{refbit}_final"][nonmeta]
                    )
                done += 1
        for bit in range(2):
            fixed = {name: v for name, v in means.items() if name[0] in "NW"}
            for site in range(1, 29):
                direction = canonical[f"{schema}_{rev}"][f"G_{site}"]
                assert direction.shape == means[f"G_{site}"].shape
                fixed[f"G_{site}"] = (
                    means[f"G_{site}"].astype(np.float64)
                    + (bit - 0.5) * direction.astype(np.float64)
                ).astype(np.float32)
            values = {name: v for name, v in means.items() if name[0] == "V"}
            step(f"canonical_{bit}", base0, fixed, values, "canonical", bit=bit)
            done += 1
        sp = run / "qwen15/states" / f"{key}.npz"
        sp.parent.mkdir(parents=True, exist_ok=True)
        np.savez_compressed(sp, **arrays)
        record = {
            "fingerprint": bundle["fingerprint"],
            **g,
            "position": pos,
            "native_sha256": ne["sha256"],
            "parent_record_sha256": pe["sha256"],
            "patches": patches,
            "states_sha256": hashlib.sha256(sp.read_bytes()).hexdigest(),
        }
        write_json(
            run / "qwen15/records" / f"{key}.json", {"record": record, "sha256": digest(record)}
        )
        status.update(completed_forwards=done, completed_pairs=index + 1, updated_utc=now())
        write_json(run / "pipeline-status.json", status)
        print(f"182 pairs {index + 1}/64; {done}/832 forwards", flush=True)
        del step, arrays, caps, means, nativeh
        gc.collect()
    assert done == 832
    del model, tok
    gc.collect()
    torch.mps.empty_cache()


def launch(run):
    with exclusive_lock(run / ".launch.lock"):
        b = prepare(run)
        assert not (run / "launch.json").exists()
        with (run / "pipeline.log").open("a") as log:
            p = subprocess.Popen(
                [
                    "/usr/bin/caffeinate",
                    "-i",
                    sys.executable,
                    "-u",
                    str(Path(__file__).resolve()),
                    "--run",
                    str(run.resolve()),
                ],
                cwd=ROOT,
                env={**os.environ, "PYTHONPATH": str(ROOT / "src")},
                stdin=subprocess.DEVNULL,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
        out = {"pid": p.pid, "fingerprint": b["fingerprint"], "launched_utc": now()}
        write_json(run / "launch.json", out)
        return out


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--run", type=Path, default=DEFAULT)
    parser.add_argument("--launch", action="store_true")
    args = parser.parse_args()
    if args.launch:
        print(json.dumps(launch(args.run)))
        return
    with exclusive_lock(args.run / ".pipeline.lock"):
        b = prepare(args.run)
        status = {"status": "running", "fingerprint": b["fingerprint"], "started_utc": now()}
        write_json(args.run / "pipeline-status.json", status)
        try:
            run_model(args.run, b, status)
            status.update(status="complete", updated_utc=now())
        except BaseException as exc:
            status.update(status="technical_failure", error=repr(exc), updated_utc=now())
            write_json(args.run / "pipeline-status.json", status)
            raise
        write_json(args.run / "pipeline-status.json", status)


if __name__ == "__main__":
    main()
