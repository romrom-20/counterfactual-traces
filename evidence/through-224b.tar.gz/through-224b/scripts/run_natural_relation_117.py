#!/usr/bin/env python3
"""117/118: matched natural answerability, literal grounding versus relations."""
import argparse
import collections
import gc
import hashlib
import json
import os
import platform
import re
import string
import subprocess
import sys
from pathlib import Path

import torch
import transformers
from run_absence_alphabet_104 import MODELS, now

from latent_decisions import evidence_policy as core
from latent_decisions.target import load_target

ROOT = Path(__file__).resolve().parents[1]
DEFAULT = ROOT / 'runs/natural-relation-117-118'
DATA = ROOT / '.context/datasets/squad2/dev-v2.0.json'
DATA_HASH = '80a5225e94905956a6446d296ca1093975c4d3b3260f1d6c8f68bc2ab77182d8'
STOP = set('a an the of to in on for with by from at is are was were be been being what which who whom whose when where why how did does do has have had and or as it its that this these those'.split())
ANSWER_RULE = ('Answer the question using only the supplied passage. Return the shortest exact contiguous passage span that answers the question. '
               'If the passage does not establish an answer to the exact question, return null. Do not use outside knowledge. '
               'Return only a JSON object with one key "answer", whose value is a string or JSON null.')
VERIFY_RULE = ('Decide whether the passage establishes the proposed answer as an answer to the exact question. '
               'A phrase appearing in the passage is not sufficient: the entities, relationship, dates and qualifiers asked about must be supported. '
               'Use only the passage. Return only {"supported": true} or {"supported": false}.')


def sha(text):
    return hashlib.sha256(text.encode()).hexdigest()


def dataset():
    if hashlib.sha256(DATA.read_bytes()).hexdigest() != DATA_HASH:
        raise ValueError('Data checksum changed')
    articles = []
    for article in json.loads(DATA.read_text())['data']:
        candidates = []
        for pi, p in enumerate(article['paragraphs']):
            text = p['context']
            if not 150 <= len(text) <= 1600:
                continue
            pos = [q for q in p['qas'] if not q['is_impossible'] and len(q['question']) <= 200]
            neg = [q for q in p['qas'] if q['is_impossible'] and len(q['question']) <= 200]
            for a in pos:
                for b in neg:
                    common = set(x['text'] for x in a['answers']) & set(x['text'] for x in b.get('plausible_answers', []))
                    for candidate in sorted(common):
                        if not 1 <= len(candidate) <= 100:
                            continue
                        matching = [x for q, key in ((a, 'answers'), (b, 'plausible_answers')) for x in q[key] if x['text'] == candidate]
                        if any(text[x['answer_start']:x['answer_start'] + len(candidate)] != candidate for x in matching):
                            raise ValueError('Annotation offset mismatch')
                        key = sha(f"117:{a['id']}:{b['id']}:{candidate}")
                        candidates.append((key, pi, text, candidate, a, b))
        if candidates:
            articles.append((sha('117:' + article['title']), article['title'], min(candidates, key=lambda x: x[0])))
    selected = sorted(articles)[:24]
    assert len(selected) == 24
    rows = []
    for i, (_, title, (_, pi, context, candidate, a, b)) in enumerate(selected):
        for q in (a, b):
            rows.append({'id': q['id'], 'stage': '117' if i < 12 else '118', 'block': title,
                         'paragraph_index': pi, 'context': context, 'question': q['question'],
                         'candidate': candidate, 'impossible': q['is_impossible'],
                         'answers': q['answers'], 'plausible_answers': q.get('plausible_answers', [])})
    return rows


def retrieve(context, question):
    sentences = re.split(r'(?<=[.!?])\s+', context)
    def words(s):
        return set(re.findall(r'\w+', s.lower())) - STOP
    query = words(question)
    order = sorted(range(len(sentences)), key=lambda i: (-len(words(sentences[i]) & query), i))[:2]
    return ' '.join(sentences[i] for i in sorted(order))


def messages(row, arm, candidate=None):
    if arm == 'verify':
        assert isinstance(candidate, str) and candidate
        return [{'role': 'system', 'content': VERIFY_RULE}, {'role': 'user', 'content': json.dumps(
            {'passage': row['context'], 'question': row['question'], 'proposed_answer': candidate}, ensure_ascii=False)}]
    assert arm in ('direct', 'retrieved')
    context = row['context'] if arm == 'direct' else retrieve(row['context'], row['question'])
    return [{'role': 'system', 'content': ANSWER_RULE}, {'role': 'user', 'content': json.dumps(
        {'passage': context, 'question': row['question']}, ensure_ascii=False)}]


def parse(raw, verify=False):
    def unique(pairs):
        if len(dict(pairs)) != len(pairs):
            raise ValueError('Duplicate fields')
        return dict(pairs)
    try:
        obj = json.loads(raw, object_pairs_hook=unique)
    except (ValueError, TypeError):
        return False, None
    key = 'supported' if verify else 'answer'
    if type(obj) is not dict or set(obj) != {key}:
        return False, None
    value = obj[key]
    valid = type(value) is bool if verify else (value is None or (type(value) is str and bool(value.strip())))
    return valid, value if valid else None


def normalize(s):
    s = ''.join(c for c in s.lower() if c not in string.punctuation)
    return ' '.join(re.sub(r'\b(a|an|the)\b', ' ', s).split())


def score(row, prediction):
    valid, answer = prediction
    if not valid:
        return {'em': 0, 'f1': 0.}
    if row['impossible']:
        return {'em': int(answer is None), 'f1': float(answer is None)}
    if answer is None:
        return {'em': 0, 'f1': 0.}
    predicted = normalize(answer)
    em, f1 = 0, 0.
    for gold in row['answers']:
        reference = normalize(gold['text'])
        em = max(em, int(predicted == reference))
        p, g = predicted.split(), reference.split()
        common = sum((collections.Counter(p) & collections.Counter(g)).values())
        value = float(p == g) if not p or not g else 2 * common / (len(p) + len(g))
        f1 = max(f1, value)
    return {'em': em, 'f1': f1}


def predictions(row, outputs):
    direct = outputs['direct']
    base = (direct['valid'], direct['value'])
    span = base if not base[0] or base[1] is None or base[1] in row['context'] else (True, None)
    verified = span
    if span[0] and span[1] is not None:
        v = outputs['generated_verify']
        verified = (False, None) if not v['valid'] else (True, span[1] if v['value'] else None)
    return {'direct': base, 'retrieved': (outputs['retrieved']['valid'], outputs['retrieved']['value']),
            'span_only': span, 'verified': verified}


def source_hash():
    paths = [Path(__file__), ROOT / 'docs/experiments/117-118-natural-relation-verification.md',
             ROOT / 'src/latent_decisions/evidence_policy.py', ROOT / 'src/latent_decisions/target.py',
             ROOT / 'scripts/run_absence_alphabet_104.py']
    return core.digest({str(p.relative_to(ROOT)): sha(p.read_text()) for p in paths})


def prepare(run):
    path = run / 'design.json'
    if path.exists():
        b = json.loads(path.read_text())
        assert core.digest(b['design']) == b['fingerprint']
        assert b['design']['source_hash'] == source_hash()
        assert b['design']['rows'] == dataset()
        return b
    d = {'created_utc': now(), 'source_hash': source_hash(), 'data_hash': DATA_HASH,
         'rows': dataset(), 'models': MODELS, 'max_new_tokens': 80, 'max_prompt_tokens': 2048}
    b = {'design': d, 'fingerprint': core.digest(d)}
    core.write_json(path, b)
    return b


def read_records(run, name, bundle):
    records = {}
    runtime_path = run / name / 'runtime.json'
    rh = core.digest(json.loads(runtime_path.read_text())) if runtime_path.exists() else None
    for p in (run / name / 'records').glob('*.json'):
        e = json.loads(p.read_text())
        r = e['record']
        assert e['sha256'] == core.digest(r) and r['fingerprint'] == bundle['fingerprint']
        assert r['runtime_hash'] == rh and r['id'] not in records
        records[r['id']] = r
    assert set(records) <= {r['id'] for r in bundle['design']['rows']}
    return records


def summarize(rows, records):
    outcomes = []
    for row in rows:
        outputs = records[row['id']]['outputs']
        pred = predictions(row, outputs)
        outcomes.append({'id': row['id'], 'block': row['block'], 'impossible': row['impossible'],
                         'predictions': pred, 'scores': {m: score(row, p) for m, p in pred.items()},
                         'annotated_verify_correct': outputs['annotated_verify']['valid'] and outputs['annotated_verify']['value'] == (not row['impossible'])})
    methods = {}
    for method in ('direct', 'retrieved', 'span_only', 'verified'):
        groups = {}
        for name, group in [('all', outcomes), ('answerable', [r for r in outcomes if not r['impossible']]), ('impossible', [r for r in outcomes if r['impossible']])]:
            groups[name] = {'n': len(group), 'em': sum(r['scores'][method]['em'] for r in group),
                            'f1_mean': sum(r['scores'][method]['f1'] for r in group) / len(group),
                            'invalid': sum(not r['predictions'][method][0] for r in group)}
        methods[method] = groups
    positive = [r for r in outcomes if not r['impossible']]
    correct = [r for r in positive if r['scores']['direct']['em']]
    lost = sum(not r['scores']['verified']['em'] for r in correct)
    v, d = methods['verified'], methods['direct']
    criteria = {'answerable_floor': v['answerable']['em'] >= 10, 'impossible_floor': v['impossible']['em'] >= 9,
                'correct_retention': bool(correct) and lost / len(correct) <= .05,
                'answerable_loss': (d['answerable']['em'] - v['answerable']['em']) / len(positive) <= .05}
    criteria.update({f'gain_vs_{m}': v['all']['em'] - methods[m]['all']['em'] >= 2 for m in ('direct', 'span_only', 'retrieved')})
    diagnostic = {g: sum(r['annotated_verify_correct'] for r in outcomes if r['impossible'] == state) for g, state in [('answerable', False), ('impossible', True)]}
    diagnostic['both_correct_pairs'] = sum(all(r['annotated_verify_correct'] for r in outcomes if r['block'] == block) for block in {r['block'] for r in outcomes})
    diagnostic['pass'] = diagnostic['answerable'] >= 10 and diagnostic['impossible'] >= 10 and diagnostic['both_correct_pairs'] >= 9
    span_hallucinations = sum(r['impossible'] and r['predictions']['span_only'][0] and r['predictions']['span_only'][1] is not None for r in outcomes)
    retrieval_retained = sum(any(a['text'] in retrieve(r['context'], r['question']) for a in r['answers']) for r in rows if not r['impossible'])
    return {'methods': methods, 'criteria': criteria, 'utility_pass': all(criteria.values()),
            'diagnostic': diagnostic, 'direct_correct_answerable': len(correct), 'lost_correct_answerable': lost,
            'span_grounded_impossible_answers': span_hallucinations, 'retrieval_retained_gold_span': retrieval_retained,
            'outcomes': outcomes}


def run_model(run, name, bundle, status):
    records = read_records(run, name, bundle)
    rows = bundle['design']['rows']
    if len(records) < len(rows):
        model, tokenizer, device = load_target(MODELS[name], 'mps', offline=True)
        runtime = {'model': MODELS[name], 'device': device, 'dtype': str(next(model.parameters()).dtype),
                   'training': model.training, 'python': platform.python_version(), 'torch': torch.__version__,
                   'transformers': transformers.__version__, 'penalty': 1.,
                   'tokenizer_hash': core.digest(tokenizer.get_vocab()), 'config_hash': core.digest(model.config.to_dict()),
                   'chat_template': tokenizer.chat_template}
        assert runtime['dtype'] == 'torch.float32' and not runtime['training']
        path = run / name / 'runtime.json'
        if path.exists():
            assert json.loads(path.read_text()) == runtime
        core.write_json(path, runtime)
        def query(msg, verify=False):
            prefix = tokenizer.apply_chat_template(msg, tokenize=True, add_generation_prompt=True)
            assert len(prefix) <= bundle['design']['max_prompt_tokens']
            ids, raw = core.generate(model, tokenizer, prefix, 1., bundle['design']['max_new_tokens'])
            hit = len(ids) == bundle['design']['max_new_tokens'] and ids[-1] != tokenizer.eos_token_id
            valid, value = parse(raw, verify)
            return {'messages': msg, 'prompt_ids': prefix, 'ids': ids, 'raw': raw,
                    'valid': valid and not hit, 'value': value, 'hit_limit': hit}
        for row in rows:
            if row['id'] in records:
                continue
            outputs = {arm: query(messages(row, arm)) for arm in ('direct', 'retrieved')}
            direct = outputs['direct']
            if direct['valid'] and direct['value'] is not None and direct['value'] in row['context']:
                outputs['generated_verify'] = query(messages(row, 'verify', direct['value']), True)
            outputs['annotated_verify'] = query(messages(row, 'verify', row['candidate']), True)
            record = {'id': row['id'], 'fingerprint': bundle['fingerprint'], 'runtime_hash': core.digest(runtime), 'outputs': outputs}
            core.write_json(run / name / 'records' / f"{row['id']}.json", {'record': record, 'sha256': core.digest(record)})
            records[row['id']] = record
            status.update(model=name, stage=row['stage'], completed_rows=len(records), updated_utc=now())
            core.write_json(run / 'pipeline-status.json', status)
            print(f'{name} {row["stage"]} {len(records)}/{len(rows)}', flush=True)
        del model, tokenizer
        gc.collect()
        torch.mps.empty_cache()
    results = {}
    for stage in ('117', '118'):
        result = summarize([r for r in rows if r['stage'] == stage], records)
        result.update(model=name, stage=stage, complete=True, fingerprint=bundle['fingerprint'])
        core.write_json(run / name / f'analysis-{stage}.json', result)
        results[stage] = result
    return results


def launch(run):
    with core.exclusive_lock(run / '.launch.lock'):
        bundle = prepare(run)
        path = run / 'launch.json'
        if path.exists():
            try:
                os.kill(json.loads(path.read_text())['pid'], 0)
            except ProcessLookupError:
                pass
            else:
                raise RuntimeError('Live process; refusing duplicate launch')
        cmd = ['/usr/bin/caffeinate', '-i', sys.executable, '-u', str(Path(__file__).resolve()), '--run', str(run.resolve())]
        with (run / 'pipeline.log').open('a') as log:
            process = subprocess.Popen(cmd, cwd=ROOT, env={**os.environ, 'PYTHONPATH': str(ROOT / 'src')}, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        receipt = {'pid': process.pid, 'launched_utc': now(), 'fingerprint': bundle['fingerprint'], 'command': cmd}
        core.write_json(path, receipt)
        return receipt


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', type=Path, default=DEFAULT)
    parser.add_argument('--launch', action='store_true')
    parser.add_argument('--prepare', action='store_true')
    args = parser.parse_args()
    if args.prepare:
        print(prepare(args.run)['fingerprint'])
        return
    if args.launch:
        print(json.dumps(launch(args.run), indent=2))
        return
    with core.exclusive_lock(args.run / '.pipeline.lock'):
        bundle = prepare(args.run)
        status = {'status': 'running', 'started_utc': now(), 'fingerprint': bundle['fingerprint'], 'results': {}}
        try:
            for name in MODELS:
                status['results'][name] = run_model(args.run, name, bundle, status)
            status.update(status='complete', updated_utc=now())
        except BaseException as exc:
            status.update(status='technical_failure', error=repr(exc), updated_utc=now())
            core.write_json(args.run / 'pipeline-status.json', status)
            raise
        core.write_json(args.run / 'pipeline-status.json', status)
        print('Complete', flush=True)


if __name__ == '__main__':
    main()
