"""Natural Boolean endpoints with local tangent SiLU, no endpoint preservation."""

import argparse
import gc
import hashlib
import itertools
import json
import os
import subprocess
import sys
from contextlib import contextmanager
from pathlib import Path

import numpy as np
import run_natural_bit_shared_reader_181 as native
import run_natural_gate_value_crossing_182 as parent
import torch
from run_absence_alphabet_104 import now
from run_order_competence_151 import runtime

from latent_decisions.evidence_policy import digest, exclusive_lock, write_json
from latent_decisions.target import load_target

ROOT = Path(__file__).resolve().parents[1]
DEFAULT = ROOT / "runs/natural-silu-tangent-183"


def source_hash():
    return digest(
        {
            "runner": Path(__file__).read_text(),
            "protocol": (ROOT / "docs/experiments/183-natural-silu-tangent.md").read_text(),
            "parent": parent.source_hash(),
        }
    )


def prepare(run):
    pb = json.loads((parent.DEFAULT / "design.json").read_text())
    a = json.loads((ROOT / "docs/analysis/182-independent-audit.json").read_text())
    n = json.loads((ROOT / "docs/analysis/182-numerical-recheck.json").read_text())
    assert (
        a["complete"]
        and all(a["controls"].values())
        and a["numerical_qualified"]
        and n["passed"]
        and a["fingerprint"] == n["fingerprint"] == pb["fingerprint"]
        and pb["design"]["source_hash"] == parent.source_hash()
    )
    d = {
        "source_hash": source_hash(),
        "parent_fingerprint": pb["fingerprint"],
        "native181_fingerprint": json.loads((native.DEFAULT / "design.json").read_text())[
            "fingerprint"
        ],
        "models": pb["design"]["models"],
        "blocks": native.blocks(),
        "main_forwards": 512,
        "numerical_forwards": 32,
        "tolerance": 0.1,
        "individual_floor": 0.5,
        "balanced_floor": 0.2,
        "retained_fraction": 0.5,
        "dominance": 0.75,
        "activation_tolerance": 1e-5,
    }
    p = run / "design.json"
    if p.exists():
        b = json.loads(p.read_text())
        assert b["design"] == d and digest(d) == b["fingerprint"]
        return b
    b = {"design": d, "fingerprint": digest(d), "created_utc": now()}
    write_json(p, b)
    return b


def tangent_anchor(x0, x1):
    assert x0.shape == x1.shape and x0.dtype == x1.dtype == np.float32
    c = (x0.astype(np.float64) + x1.astype(np.float64)) / 2
    sigmoid = np.exp(-np.logaddexp(0, -c))
    return {
        "center": c.astype(np.float32),
        "intercept": (c * sigmoid).astype(np.float32),
        "slope": (sigmoid + c * sigmoid * (1 - sigmoid)).astype(np.float32),
    }


@contextmanager
def activations(model, pos, anchors=None):
    cap, trace, handles = {}, [], []
    try:
        for site in range(1, 29):
            t = (
                {
                    name: torch.as_tensor(v, device=next(model.parameters()).device)
                    for name, v in anchors[site].items()
                }
                if anchors is not None
                else None
            )

            def hook(module, args, result, site=site, t=t):
                x = args[0][0, pos + 1 :]
                original_prefix = result[:, : pos + 1].clone()
                if t is not None:
                    result = result.clone()
                    result[0, pos + 1 :] = t["intercept"] + t["slope"] * (x - t["center"])
                assert torch.equal(result[:, : pos + 1], original_prefix)
                cap[f"{site}_input"] = x.detach().cpu().numpy().copy()
                cap[f"{site}_output"] = result[0, pos + 1 :].detach().cpu().numpy().copy()
                trace.append(
                    {
                        "site": site,
                        "start": pos + 1,
                        "end": result.shape[1],
                        "tangent": t is not None,
                        "other_rows_identical": True,
                        "input_sha256": native.array_hash(cap[f"{site}_input"]),
                        "output_sha256": native.array_hash(cap[f"{site}_output"]),
                    }
                )
                return result

            handles.append(model.model.layers[site - 1].mlp.act_fn.register_forward_hook(hook))
        yield cap, trace
        assert [r["site"] for r in trace] == list(range(1, 29))
    finally:
        for handle in handles:
            handle.remove()


def run_model(run, bundle, status):
    model, tok, device = load_target(bundle["design"]["models"]["qwen15"], "mps", offline=True)
    rt = runtime(model, tok, device, "qwen15")
    assert rt == json.loads((native.DEFAULT / "qwen15/runtime.json").read_text())
    write_json(run / "qwen15/runtime.json", rt)
    done = 0
    for index, (block, a, t, rev, schema) in enumerate(
        itertools.product(native.blocks(), range(2), range(2), range(2), ("generic", "descriptive"))
    ):
        g = native.fixture.group(block, a, t, rev, schema)
        key = digest(g)
        ne = json.loads((native.DEFAULT / "qwen15/native" / f"{key}.json").read_text())
        pe = json.loads((native.DEFAULT / "qwen15/records" / f"{key}.json").read_text())
        nr, pr = ne["record"], pe["record"]
        assert digest(nr) == ne["sha256"] and digest(pr) == pe["sha256"]
        npth, ppth = (
            native.DEFAULT / "qwen15/native" / f"{key}.npz",
            native.DEFAULT / "qwen15/states" / f"{key}.npz",
        )
        assert (
            hashlib.sha256(npth.read_bytes()).hexdigest() == nr["states_sha256"]
            and hashlib.sha256(ppth.read_bytes()).hexdigest() == pr["states_sha256"]
        )
        bases, pos = native.paired_bases(tok, block, g)
        assert pos == nr["position"] and bases == [n["base"] for n in nr["natives"]]
        arrays, patches, inputs, raw_states = {}, [], [], []
        with np.load(npth, allow_pickle=False) as nz, np.load(ppth, allow_pickle=False) as pz:
            means = {
                name.removeprefix("mean_"): pz[name].copy()
                for name in pz.files
                if name.startswith("mean_") and name.removeprefix("mean_")[0] in "NW"
            }
            for bit, base in enumerate(bases):
                with (
                    activations(model, pos) as (ac, at),
                    native.operators(model, pos) as (cap, trace),
                ):
                    m, h = native.score(model, base)
                assert (
                    m == nr["natives"][bit]["margin"]
                    and np.array_equal(h, nz[f"native_{bit}_final"])
                    and all(
                        np.array_equal(v, nz[f"native_{bit}_{name}"]) for name, v in cap.items()
                    )
                )
                assert all(
                    np.array_equal(ac[f"{site}_output"], cap[f"G_{site}"]) for site in range(1, 29)
                )
                arrays[f"raw_{bit}_final"] = h
                arrays.update({f"raw_{bit}_{name}": v for name, v in ac.items()})
                inputs.append({site: ac[f"{site}_input"] for site in range(1, 29)})
                raw_states.append(h)
                patches.append(
                    {"mode": "raw", "bit": bit, "margin": m, "trace": trace, "activation_trace": at}
                )
                done += 1
            anchors = {
                site: tangent_anchor(inputs[0][site], inputs[1][site]) for site in range(1, 29)
            }
            arrays.update(
                {
                    f"anchor_{site}_{name}": v
                    for site, anchor in anchors.items()
                    for name, v in anchor.items()
                }
            )
            for mode, bit in itertools.product(
                ("native_NW", "tangent_free", "tangent_NW"), range(2)
            ):
                fixed = means if mode in ("native_NW", "tangent_NW") else None
                with (
                    activations(model, pos, anchors if mode != "native_NW" else None) as (ac, at),
                    native.operators(model, pos, fixed) as (cap, trace),
                ):
                    m, h = native.score(model, bases[bit])
                assert np.array_equal(h[: pos + 1], raw_states[bit][: pos + 1]) and all(
                    np.array_equal(ac[f"{site}_output"], cap[f"G_{site}"]) for site in range(1, 29)
                )
                if mode == "native_NW":
                    expected = next(
                        q["margin"] for q in pr["patches"] if (q["arm"], q["bit"]) == ("NW", bit)
                    )
                    assert m == expected and np.array_equal(h, pz[f"NW_{bit}_final"])
                arrays[f"{mode}_{bit}_final"] = h
                arrays.update({f"{mode}_{bit}_{name}": v for name, v in ac.items()})
                patches.append(
                    {"mode": mode, "bit": bit, "margin": m, "trace": trace, "activation_trace": at}
                )
                done += 1
        sp = run / "qwen15/states" / f"{key}.npz"
        sp.parent.mkdir(parents=True, exist_ok=True)
        np.savez_compressed(sp, **arrays)
        record = {
            "fingerprint": bundle["fingerprint"],
            **g,
            "position": pos,
            "native_sha256": ne["sha256"],
            "parent_record_sha256": pe["sha256"],
            "patches": patches,
            "states_sha256": hashlib.sha256(sp.read_bytes()).hexdigest(),
        }
        write_json(
            run / "qwen15/records" / f"{key}.json", {"record": record, "sha256": digest(record)}
        )
        status.update(completed_forwards=done, completed_pairs=index + 1, updated_utc=now())
        write_json(run / "pipeline-status.json", status)
        print(f"183 pairs {index + 1}/64; {done}/512 forwards", flush=True)
        del arrays, anchors, inputs, raw_states
        gc.collect()
    assert done == 512
    del model, tok
    gc.collect()
    torch.mps.empty_cache()


def launch(run):
    with exclusive_lock(run / ".launch.lock"):
        b = prepare(run)
        assert not (run / "launch.json").exists()
        with (run / "pipeline.log").open("a") as log:
            p = subprocess.Popen(
                [
                    "/usr/bin/caffeinate",
                    "-i",
                    sys.executable,
                    "-u",
                    str(Path(__file__).resolve()),
                    "--run",
                    str(run.resolve()),
                ],
                cwd=ROOT,
                env={**os.environ, "PYTHONPATH": str(ROOT / "src")},
                stdin=subprocess.DEVNULL,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
        out = {"pid": p.pid, "fingerprint": b["fingerprint"], "launched_utc": now()}
        write_json(run / "launch.json", out)
        return out


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--run", type=Path, default=DEFAULT)
    p.add_argument("--launch", action="store_true")
    args = p.parse_args()
    if args.launch:
        print(json.dumps(launch(args.run)))
        return
    with exclusive_lock(args.run / ".pipeline.lock"):
        b = prepare(args.run)
        status = {"status": "running", "fingerprint": b["fingerprint"], "started_utc": now()}
        write_json(args.run / "pipeline-status.json", status)
        try:
            run_model(args.run, b, status)
            status.update(status="complete", updated_utc=now())
        except BaseException as exc:
            status.update(status="technical_failure", error=repr(exc), updated_utc=now())
            write_json(args.run / "pipeline-status.json", status)
            raise
        write_json(args.run / "pipeline-status.json", status)


if __name__ == "__main__":
    main()
