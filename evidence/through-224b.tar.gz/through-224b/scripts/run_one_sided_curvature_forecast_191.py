"""False-only SiLU Taylor maps, globally frozen before any native true measurement."""

import argparse
import gc
import hashlib
import itertools
import json
import os
import subprocess
import sys
from contextlib import contextmanager
from pathlib import Path

import numpy as np
import run_fresh_norm_split_190 as parent
import run_natural_bit_shared_reader_181 as native
import run_natural_silu_tangent_183 as tangent
import torch
from run_absence_alphabet_104 import now
from run_order_competence_151 import runtime

from latent_decisions.evidence_policy import digest, exclusive_lock, write_json
from latent_decisions.target import load_target

ROOT = Path(__file__).resolve().parents[1]
DEFAULT = ROOT / "runs/one-sided-curvature-forecast-191"
LITERALS = (
    ("cypress", "larch", "Monday", "Friday"),
    ("quartz", "agate", "Tuesday", "Sunday"),
    ("meridian", "zenith", "Thursday", "Saturday"),
    ("tundra", "taiga", "Wednesday", "Monday"),
)
ARMS = ("T1", "Q2", "C3")


def blocks():
    return [
        {"id": a, "stage": "191", "subjects": [a, b], "days": [x, y], "old_block": None}
        for a, b, x, y in LITERALS
    ]


def source_hash():
    return digest(
        {
            "runner": Path(__file__).read_text(),
            "protocol": (ROOT / "docs/experiments/191-one-sided-curvature-forecast.md").read_text(),
            "parent": parent.source_hash(),
        }
    )


def prepare(run):
    pb = json.loads((parent.DEFAULT / "design.json").read_text())
    a = json.loads((ROOT / "docs/analysis/190-independent-audit.json").read_text())
    n = json.loads((ROOT / "docs/analysis/190-numerical-recheck.json").read_text())
    assert (
        a["complete"]
        and all(a["controls"].values())
        and a["numerical_qualified"]
        and n["passed"]
        and a["fingerprint"] == n["fingerprint"] == pb["fingerprint"]
        and pb["design"]["source_hash"] == parent.source_hash()
    )
    d = {
        "source_hash": source_hash(),
        "parent_fingerprint": pb["fingerprint"],
        "models": pb["design"]["models"],
        "blocks": blocks(),
        "arms": list(ARMS),
        "main_forwards": 512,
        "numerical_forwards": 64,
        "polynomial_orders": [1, 2, 3],
        "tolerance": 0.1,
        "individual_floor": 0.5,
        "balanced_floor": 0.2,
        "retained_fraction": 0.5,
        "dominance": 0.75,
        "activation_tolerance": 1e-5,
    }
    p = run / "design.json"
    if p.exists():
        b = json.loads(p.read_text())
        assert b["design"] == d and digest(d) == b["fingerprint"]
        return b
    b = {"design": d, "fingerprint": digest(d), "created_utc": now()}
    write_json(p, b)
    return b


def coefficients(false):
    maps = {}
    for site in range(1, 29):
        x = false[f"{site}_input"].astype(np.float64)
        s = np.exp(-np.logaddexp(0, -x))
        q = s * (1 - s)
        t = 1 - 2 * s
        maps[site] = {
            "center": false[f"{site}_input"].copy(),
            "intercept": false[f"{site}_output"].copy(),
            "slope": (s * (1 + x * (1 - s))).astype(np.float32),
            "second": (q * (2 + x * t) / 2).astype(np.float32),
            "third": (q * (3 * t + x * (t * t - 2 * q)) / 6).astype(np.float32),
        }
    return maps


@contextmanager
def polynomial(model, pos, maps, arm):
    cap, trace, handles = {}, [], []
    try:
        for site in range(1, 29):
            target = {
                k: torch.as_tensor(v, device=next(model.parameters()).device)
                for k, v in maps[site].items()
            }

            def hook(module, args, out, site=site, target=target):
                x = args[0][0, pos + 1 :]
                z = x - target["center"]
                y = target["intercept"] + target["slope"] * z
                if arm in ("Q2", "C3"):
                    y = y + target["second"] * (z * z)
                if arm == "C3":
                    y = y + target["third"] * ((z * z) * z)
                changed = out.clone()
                changed[0, pos + 1 :] = y
                assert torch.equal(changed[:, : pos + 1], out[:, : pos + 1])
                cap[f"{site}_input"] = x.detach().cpu().numpy().copy()
                cap[f"{site}_output"] = y.detach().cpu().numpy().copy()
                trace.append(
                    {
                        "site": site,
                        "start": pos + 1,
                        "end": out.shape[1],
                        "arm": arm,
                        "other_rows_identical": True,
                        "input_sha256": native.array_hash(cap[f"{site}_input"]),
                        "output_sha256": native.array_hash(cap[f"{site}_output"]),
                    }
                )
                return changed

            handles.append(model.model.layers[site - 1].mlp.act_fn.register_forward_hook(hook))
        yield cap, trace
        assert [v["site"] for v in trace] == list(range(1, 29))
    finally:
        for handle in handles:
            handle.remove()


def hashed(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def run_model(run, bundle, status):
    model, tok, device = load_target(bundle["design"]["models"]["qwen15"], "mps", offline=True)
    rt = runtime(model, tok, device, "qwen15")
    assert rt == json.loads((parent.DEFAULT / "qwen15/runtime.json").read_text())
    write_json(run / "qwen15/runtime.json", rt)
    entries, manifest, done = [], [], 0
    for block, a, t, rev, schema in itertools.product(
        blocks(), range(2), range(2), range(2), ("generic", "descriptive")
    ):
        g = native.fixture.group(block, a, t, rev, schema)
        key = digest(g)
        bases, pos = native.paired_bases(tok, block, g)
        false_started = now()
        with tangent.activations(model, pos) as (false_cap, false_trace):
            fm, fh = native.score(model, bases[0])
        false_done = now()
        done += 1
        arrays = {
            "native_false_final": fh,
            **{f"native_false_{name}": v for name, v in false_cap.items()},
        }
        patches = []
        anchors = coefficients(false_cap)
        for arm in ARMS:
            arrays.update(
                {
                    f"map_{arm}_{site}_{name}": v
                    for site, anchor in anchors.items()
                    for name, v in anchor.items()
                }
            )
            for bit in range(2):
                started = now()
                with polynomial(model, pos, anchors, arm) as (cap, trace):
                    m, h = native.score(model, bases[bit])
                if bit == 0:
                    assert m == fm and np.array_equal(h, fh)
                arrays[f"{arm}_{bit}_final"] = h
                arrays.update({f"{arm}_{bit}_{name}": v for name, v in cap.items()})
                patches.append(
                    {
                        "arm": arm,
                        "bit": bit,
                        "margin": m,
                        "activation_trace": trace,
                        "started_utc": started,
                        "completed_utc": now(),
                    }
                )
                done += 1
        sp = run / "qwen15/forecasts" / f"{key}.npz"
        sp.parent.mkdir(parents=True, exist_ok=True)
        np.savez_compressed(sp, **arrays)
        record = {
            "fingerprint": bundle["fingerprint"],
            **g,
            "position": pos,
            "bases": bases,
            "native_false": {
                "margin": fm,
                "activation_trace": false_trace,
                "started_utc": false_started,
                "completed_utc": false_done,
            },
            "patches": patches,
            "states_sha256": hashed(sp),
        }
        write_json(
            run / "qwen15/forecasts" / f"{key}.json", {"record": record, "sha256": digest(record)}
        )
        manifest.append(
            {"key": key, "record_sha256": digest(record), "states_sha256": record["states_sha256"]}
        )
        entries.append((g, key))
        status.update(completed_forwards=done, forecast_pairs=len(entries), updated_utc=now())
        write_json(run / "pipeline-status.json", status)
        print(f"191 forecast pairs {len(entries)}/64; {done}/512 physical forwards", flush=True)
        del arrays, anchors
        gc.collect()
    assert done == 448
    frozen = {
        "completed_utc": now(),
        "completed_forwards": 448,
        "manifest": manifest,
        "manifest_sha256": digest(manifest),
    }
    write_json(run / "forecast-manifest.json", frozen)
    for index, (g, key) in enumerate(entries):
        e = json.loads((run / "qwen15/forecasts" / f"{key}.json").read_text())
        r = e["record"]
        assert digest(r) == e["sha256"]
        fp = run / "qwen15/forecasts" / f"{key}.npz"
        assert hashed(fp) == r["states_sha256"]
        pos = r["position"]
        arrays = {}
        true_started = now()
        with tangent.activations(model, pos) as (true_cap, true_trace):
            tm, th = native.score(model, r["bases"][1])
        true_done = now()
        done += 1
        arrays.update(
            {"native_true_final": th, **{f"native_true_{name}": v for name, v in true_cap.items()}}
        )
        sp = run / "qwen15/states" / f"{key}.npz"
        sp.parent.mkdir(parents=True, exist_ok=True)
        np.savez_compressed(sp, **arrays)
        record = {
            "fingerprint": bundle["fingerprint"],
            **g,
            "position": pos,
            "forecast_record_sha256": e["sha256"],
            "native_true": {
                "margin": tm,
                "activation_trace": true_trace,
                "started_utc": true_started,
                "completed_utc": true_done,
            },
            "patches": [],
            "states_sha256": hashed(sp),
        }
        write_json(
            run / "qwen15/records" / f"{key}.json", {"record": record, "sha256": digest(record)}
        )
        status.update(completed_forwards=done, completed_pairs=index + 1, updated_utc=now())
        write_json(run / "pipeline-status.json", status)
        print(f"191 target pairs {index + 1}/64; {done}/512 physical forwards", flush=True)
        del arrays
        gc.collect()
    assert done == 512
    del model, tok
    gc.collect()
    torch.mps.empty_cache()


def launch(run):
    with exclusive_lock(run / ".launch.lock"):
        b = prepare(run)
        assert not (run / "launch.json").exists()
        with (run / "pipeline.log").open("a") as log:
            p = subprocess.Popen(
                [
                    "/usr/bin/caffeinate",
                    "-i",
                    sys.executable,
                    "-u",
                    str(Path(__file__).resolve()),
                    "--run",
                    str(run.resolve()),
                ],
                cwd=ROOT,
                env={**os.environ, "PYTHONPATH": str(ROOT / "src")},
                stdin=subprocess.DEVNULL,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
        out = {"pid": p.pid, "fingerprint": b["fingerprint"], "launched_utc": now()}
        write_json(run / "launch.json", out)
        return out


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--run", type=Path, default=DEFAULT)
    parser.add_argument("--launch", action="store_true")
    args = parser.parse_args()
    if args.launch:
        print(json.dumps(launch(args.run)))
        return
    with exclusive_lock(args.run / ".pipeline.lock"):
        b = prepare(args.run)
        status = {"status": "running", "fingerprint": b["fingerprint"], "started_utc": now()}
        write_json(args.run / "pipeline-status.json", status)
        try:
            run_model(args.run, b, status)
            status.update(status="complete", updated_utc=now())
        except BaseException as exc:
            status.update(status="technical_failure", error=repr(exc), updated_utc=now())
            write_json(args.run / "pipeline-status.json", status)
            raise
        write_json(args.run / "pipeline-status.json", status)


if __name__ == "__main__":
    main()
