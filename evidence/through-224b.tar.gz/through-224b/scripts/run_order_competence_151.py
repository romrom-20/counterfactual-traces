#!/usr/bin/env python3
"""Frozen competence-qualified order and Boolean-value comparison."""

import argparse
import gc
import itertools
import json
import os
import platform
import subprocess
import sys
from pathlib import Path

import run_metadata_evidence_135 as original
import run_metadata_token_margin_141 as scorer
import torch
import transformers
from run_absence_alphabet_104 import MODELS, now

from latent_decisions import evidence_policy as core
from latent_decisions.target import load_target

ROOT = Path(__file__).resolve().parents[1]
DEFAULT = ROOT / "runs/order-competence-151-152"
SCHEMAS = {"generic": ["first_value", "second_value"], "descriptive": ["record_flag", "supported"]}
LITERALS = [
    ("151", "amber", "violet", "Wednesday", "Friday"),
    ("151", "silver", "bronze", "Thursday", "Sunday"),
    ("151", "birch", "willow", "Saturday", "Tuesday"),
    ("151", "north", "south", "Monday", "Thursday"),
    ("152", "coral", "indigo", "Friday", "Monday"),
    ("152", "oak", "pine", "Sunday", "Wednesday"),
    ("152", "east", "west", "Tuesday", "Saturday"),
    ("152", "copper", "ivory", "Thursday", "Friday"),
]


def blocks():
    return [
        {
            "id": f"day_{i}",
            "stage": stage,
            "candidate": day_b,
            "contexts": [
                f"The {a} exhibit opened on {day_a}. The {b} exhibit opened on {day_b}.",
                f"The {a} exhibit opened on {day_b}. The {b} exhibit opened on {day_a}.",
            ],
            "questions": [f"On which day did the {a} exhibit open?"],
        }
        for i, (stage, a, b, day_a, day_b) in enumerate(LITERALS)
    ]


def jobs(block):
    result = [
        {"kind": "evidence", "supported": support, "schema": schema, "order": order, "clamp": bit}
        for support, schema, order, bit in itertools.product(
            (False, True), SCHEMAS, ("metadata_first", "verdict_first"), (False, True)
        )
    ]
    result += [
        {"kind": "singleton", "supported": support, "schema": schema}
        for support, schema in itertools.product((False, True), SCHEMAS)
    ]
    if block["id"] == "day_0":
        result += [
            {"kind": "given", "supported": support, "schema": schema, "order": order, "clamp": bit}
            for support, schema, order, bit in itertools.product(
                (False, True), SCHEMAS, ("metadata_first", "verdict_first"), (False, True)
            )
        ]
    return sorted(result, key=core.digest)


def messages(block, job):
    ins = original.instruction(job["schema"], job["kind"] == "singleton")
    if job["kind"] == "given":
        system = (
            "The answer support status is already given. Do not reassess it. Encode the given status. "
            + ins
        )
        content = {"answer_is_supported": job["supported"]}
    else:
        system = original.RULE + ins
        content = {
            "passage": block["contexts"][int(job["supported"])],
            "proposed_answer": block["candidate"],
            "question": block["questions"][0],
        }
    return [
        {"role": "system", "content": system},
        {"role": "user", "content": json.dumps(content, ensure_ascii=False)},
    ]


def choices(job):
    flag, verdict = SCHEMAS[job["schema"]]
    if job["kind"] == "singleton":
        return [(json.dumps({verdict: value}), [value]) for value in (False, True)]
    keys = [flag, verdict] if job["order"] == "metadata_first" else [verdict, flag]
    return [
        (json.dumps({key: (value if key == verdict else job["clamp"]) for key in keys}), [value])
        for value in (False, True)
    ]


def source_hash():
    return core.digest(
        {
            "runner": Path(__file__).read_text(),
            "protocol": (ROOT / "docs/experiments/151-152-order-competence.md").read_text(),
            "dependencies": [
                original.source_hash(),
                scorer.source_hash(),
                core.digest((ROOT / "src/latent_decisions/target.py").read_text()),
            ],
        }
    )


def prepare(run):
    d = {
        "source_hash": source_hash(),
        "models": MODELS,
        "blocks": blocks(),
        "schemas": SCHEMAS,
        "per_model_generations": 176,
        "per_model_forward_bridges": 176,
        "competence_minimum": 1.0,
        "disruption_minimum": 0.25,
        "generation_tolerance": 0.05,
        "recheck_tolerance": 0.005,
    }
    path = run / "design.json"
    if path.exists():
        value = json.loads(path.read_text())
        assert core.digest(value["design"]) == value["fingerprint"]
        assert value["design"] == d
        return value
    value = {"design": d, "fingerprint": core.digest(d), "created_utc": now()}
    core.write_json(path, value)
    return value


def runtime(model, tok, device, name):
    return {
        "model": MODELS[name],
        "device": device,
        "dtype": str(next(model.parameters()).dtype),
        "training": model.training,
        "python": platform.python_version(),
        "torch": torch.__version__,
        "transformers": transformers.__version__,
        "penalty": 1.0,
        "tokenizer_hash": core.digest(tok.get_vocab()),
        "config_hash": core.digest(model.config.to_dict()),
        "chat_template": tok.chat_template,
    }


@torch.inference_mode()
def forward(model, ids, false_id, true_id):
    inputs = torch.tensor([ids], device=next(model.parameters()).device)
    out = model(
        input_ids=inputs, attention_mask=torch.ones_like(inputs), use_cache=False, logits_to_keep=1
    )
    scores = out.logits[0, -1].float()
    assert torch.isfinite(scores[[false_id, true_id]]).all()
    fs, ts = float(scores[false_id]), float(scores[true_id])
    return {"false_score": fs, "true_score": ts, "log_odds": ts - fs}


def run_model(run, name, bundle, status):
    model, tok, device = load_target(MODELS[name], "mps", offline=True)
    rt = runtime(model, tok, device, name)
    assert rt == json.loads((scorer.DEFAULT / name / "runtime.json").read_text())
    core.write_json(run / name / "runtime.json", rt)
    done = 0
    for block in blocks():
        for job in jobs(block):
            path = run / name / "records" / f"{core.digest([block['id'], job])}.json"
            if path.exists():
                value = json.loads(path.read_text())
                assert core.digest(value["record"]) == value["sha256"]
                assert value["record"]["fingerprint"] == bundle["fingerprint"]
            else:
                msgs = messages(block, job)
                prefix = tok.apply_chat_template(msgs, tokenize=True, add_generation_prompt=True)
                assert len(prefix) <= 2048
                cs = [list(x) for x in choices(job)]
                sequences = core.token_sequences(tok, cs)
                ids, raw, gm = scorer.generate_scores(model, tok, prefix, sequences)
                obj = json.loads(raw)
                expected_keys = list(json.loads(cs[0][0]))
                assert list(obj) == expected_keys and all(type(v) is bool for v in obj.values())
                verdict = obj[SCHEMAS[job["schema"]][1]]
                if job["kind"] != "singleton":
                    assert obj[SCHEMAS[job["schema"]][0]] == job["clamp"]
                free_ids = prefix + sequences[0][: gm["free_index"]]
                fm = forward(model, free_ids, gm["false_token"], gm["true_token"])
                assert max(abs(fm[k] - gm[k]) for k in fm) <= 0.05
                r = {
                    "block": block["id"],
                    "stage": block["stage"],
                    "job": job,
                    "messages": msgs,
                    "prompt_ids": prefix,
                    "choices": cs,
                    "sequences": sequences,
                    "ids": ids,
                    "raw": raw,
                    "verdict": verdict,
                    "free_input_ids": free_ids,
                    "generation_margin": gm,
                    "forward_margin": fm,
                    "runtime_hash": core.digest(rt),
                    "fingerprint": bundle["fingerprint"],
                }
                core.write_json(path, {"record": r, "sha256": core.digest(r)})
            done += 1
            status.update(model=name, completed_queries=done, updated_utc=now())
            core.write_json(run / "pipeline-status.json", status)
            print(name, done, "/176", flush=True)
    assert done == 176
    del model, tok
    gc.collect()
    torch.mps.empty_cache()


def launch(run):
    with core.exclusive_lock(run / ".launch.lock"):
        bundle = prepare(run)
        receipt = run / "launch.json"
        if receipt.exists():
            try:
                os.kill(json.loads(receipt.read_text())["pid"], 0)
            except ProcessLookupError:
                pass
            else:
                raise RuntimeError("Already running")
        with (run / "pipeline.log").open("a") as log:
            process = subprocess.Popen(
                [
                    "/usr/bin/caffeinate",
                    "-i",
                    sys.executable,
                    "-u",
                    str(Path(__file__).resolve()),
                    "--run",
                    str(run.resolve()),
                ],
                cwd=ROOT,
                env={**os.environ, "PYTHONPATH": str(ROOT / "src")},
                stdin=subprocess.DEVNULL,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
        value = {"pid": process.pid, "fingerprint": bundle["fingerprint"], "launched_utc": now()}
        core.write_json(receipt, value)
        return value


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--run", type=Path, default=DEFAULT)
    parser.add_argument("--launch", action="store_true")
    args = parser.parse_args()
    if args.launch:
        print(json.dumps(launch(args.run)))
        return
    with core.exclusive_lock(args.run / ".pipeline.lock"):
        bundle = prepare(args.run)
        status = {"status": "running", "started_utc": now(), "fingerprint": bundle["fingerprint"]}
        try:
            for name in MODELS:
                run_model(args.run, name, bundle, status)
            status.update(status="complete", updated_utc=now())
        except BaseException as exc:
            status.update(status="technical_failure", error=repr(exc), updated_utc=now())
            core.write_json(args.run / "pipeline-status.json", status)
            raise
        core.write_json(args.run / "pipeline-status.json", status)


if __name__ == "__main__":
    main()
