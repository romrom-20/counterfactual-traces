#!/usr/bin/env python3
"""127/128: separate input position, output position and field-name associations."""

import argparse
import gc
import itertools
import json
import os
import platform
import subprocess
import sys
from pathlib import Path

import run_duplicate_125 as duplicate
import run_joint_support_119 as prior
import run_serialization_123 as serial
import torch
import transformers
from run_absence_alphabet_104 import MODELS, now

from latent_decisions import evidence_policy as core
from latent_decisions.target import load_target

ROOT = Path(__file__).resolve().parents[1]
DEFAULT = ROOT / "runs/position-binding-127-128"
BOOKS = {"ordinal": ("first", "second"), "neutral": ("cedar", "maple")}
STATES = list(itertools.product((False, True), repeat=2))


def fresh_blocks():
    assert prior.sha(prior.DATA.read_text()) == prior.DATA_HASH
    excluded = {b["id"] for b in prior.dataset() + serial.fresh_blocks() + duplicate.fresh_blocks()}
    articles = []
    for article in json.loads(prior.DATA.read_text())["data"]:
        if article["title"] in excluded:
            continue
        eligible = []
        for pi, paragraph in enumerate(article["paragraphs"]):
            context = paragraph["context"]
            if not 150 <= len(context) <= 1600:
                continue
            groups = {}
            for q in paragraph["qas"]:
                if len(q["question"]) > 200:
                    continue
                for a in q.get("plausible_answers" if q["is_impossible"] else "answers", []):
                    candidate = a["text"]
                    if not 1 <= len(candidate) <= 100:
                        continue
                    assert (
                        context[a["answer_start"] : a["answer_start"] + len(candidate)] == candidate
                    )
                    groups.setdefault(candidate, {False: {}, True: {}})[q["is_impossible"]][
                        q["id"]
                    ] = q
            for candidate, group in groups.items():
                if min(len(g) for g in group.values()) < 2:
                    continue
                qs = [
                    q
                    for state in (False, True)
                    for q in sorted(
                        group[state].values(), key=lambda q: prior.sha("128:" + q["id"])
                    )[:2]
                ]
                if len({q["question"].strip().casefold() for q in qs}) != 4:
                    continue
                key = prior.sha("128:" + ":".join(q["id"] for q in qs) + ":" + candidate)
                eligible.append((key, pi, context, candidate, qs))
        if eligible:
            articles.append((prior.sha("128:" + article["title"]), article["title"], min(eligible)))
    return [
        {
            "id": title,
            "stage": "128",
            "paragraph_index": pi,
            "context": context,
            "candidate": candidate,
            "questions": qs,
        }
        for _, title, (_, pi, context, candidate, qs) in sorted(articles)[:4]
    ]


def rule(book):
    a, b = BOOKS[book]
    base = prior.JOINT_RULE.replace("first_supported", a + "_supported").replace(
        "second_supported", b + "_supported"
    )
    return (
        base
        + f' Field "{a}_supported" judges "{a}_question"; field "{b}_supported" judges "{b}_question". Field names define question identity regardless of the order in which fields appear.'
    )


def jobs(block):
    result = [
        {"query": q, "book": book, "input_order": i, "output_order": o, "kind": "factorial"}
        for q, book, i, o in itertools.product(serial.queries(block), BOOKS, (0, 1), (0, 1))
    ]
    if block["stage"] == "127":
        result += [
            {"query": q, "book": "ordinal", "input_order": 0, "output_order": o, "kind": "anchor"}
            for q, o in itertools.product(serial.queries(block), (0, 1))
        ]
    return sorted(result, key=core.digest)


def messages(block, job):
    q = job["query"]
    if job["kind"] == "anchor":
        return prior.messages(block, q)
    names = BOOKS[job["book"]]
    byid = {x["id"]: x["question"] for x in block["questions"]}
    fields = {names[i] + "_question": byid[q["question_ids"][i]] for i in (0, 1)}
    content = {"passage": block["context"], "proposed_answer": block["candidate"]}
    order = names if job["input_order"] == 0 else names[::-1]
    content.update({name + "_question": fields[name + "_question"] for name in order})
    return [
        {"role": "system", "content": rule(job["book"])},
        {"role": "user", "content": json.dumps(content, ensure_ascii=False)},
    ]


def candidates(book, order):
    names = BOOKS[book]
    indices = (0, 1) if order == 0 else (1, 0)
    return [
        (json.dumps({names[i] + "_supported": state[i] for i in indices}), list(state))
        for state in STATES
    ]


def parse(raw, book):
    def unique(pairs):
        if len(pairs) != len(dict(pairs)):
            raise ValueError("Duplicate keys")
        return dict(pairs)

    try:
        obj = json.loads(raw, object_pairs_hook=unique)
        names = [n + "_supported" for n in BOOKS[book]]
        if (
            type(obj) is not dict
            or set(obj) != set(names)
            or any(type(v) is not bool for v in obj.values())
        ):
            return False, None
        return True, [obj[n] for n in names]
    except (ValueError, TypeError):
        return False, None


def source_hash():
    return core.digest(
        {
            "runner": Path(__file__).read_text(),
            "protocol": (ROOT / "docs/experiments/127-128-position-binding.md").read_text(),
            "dependencies": duplicate.source_hash(),
        }
    )


def prepare(run):
    blocks = [{**b, "stage": "127"} for b in prior.dataset()[:2]] + fresh_blocks()
    path = run / "design.json"
    if path.exists():
        b = json.loads(path.read_text())
        assert (
            core.digest(b["design"]) == b["fingerprint"]
            and b["design"]["source_hash"] == source_hash()
        )
        assert b["design"]["blocks"] == blocks
        return b
    d = {
        "created_utc": now(),
        "source_hash": source_hash(),
        "data_hash": prior.DATA_HASH,
        "models": MODELS,
        "blocks": blocks,
        "books": BOOKS,
        "max_new_tokens": 80,
        "max_prompt_tokens": 2048,
        "dominance_minimum": 0.75,
        "stability_minimum": 0.75,
    }
    b = {"design": d, "fingerprint": core.digest(d)}
    core.write_json(path, b)
    return b


def records(run, name, bundle):
    rt = run / name / "runtime.json"
    rh = core.digest(json.loads(rt.read_text())) if rt.exists() else None
    expected = {(b["id"], core.digest(job)) for b in bundle["design"]["blocks"] for job in jobs(b)}
    got = {}
    for path in (run / name / "records").glob("*.json"):
        e = json.loads(path.read_text())
        r = e["record"]
        key = (r["block"], core.digest(r["job"]))
        assert key in expected and key not in got and core.digest(r) == e["sha256"]
        assert r["fingerprint"] == bundle["fingerprint"] and r["runtime_hash"] == rh
        got[key] = r
    return got


def run_model(run, name, bundle, status):
    saved = records(run, name, bundle)
    blocks = bundle["design"]["blocks"]
    total = sum(len(jobs(b)) for b in blocks)
    if len(saved) == total:
        return
    model, tok, device = load_target(MODELS[name], "mps", offline=True)
    rt = {
        "model": MODELS[name],
        "device": device,
        "dtype": str(next(model.parameters()).dtype),
        "training": model.training,
        "python": platform.python_version(),
        "torch": torch.__version__,
        "transformers": transformers.__version__,
        "penalty": 1.0,
        "tokenizer_hash": core.digest(tok.get_vocab()),
        "config_hash": core.digest(model.config.to_dict()),
        "chat_template": tok.chat_template,
    }
    assert rt == json.loads((prior.DEFAULT / name / "runtime.json").read_text())
    path = run / name / "runtime.json"
    if path.exists():
        assert json.loads(path.read_text()) == rt
    core.write_json(path, rt)
    for block in blocks:
        for job in jobs(block):
            key = (block["id"], core.digest(job))
            if key in saved:
                continue
            msg = messages(block, job)
            prefix = tok.apply_chat_template(msg, tokenize=True, add_generation_prompt=True)
            assert len(prefix) <= 2048
            choices = candidates(job["book"], job["output_order"])
            sequences = core.token_sequences(tok, choices)
            ids, raw = core.generate(model, tok, prefix, 1.0, 80, sequences=sequences)
            assert ids in sequences
            valid, pred = parse(raw, job["book"])
            assert valid
            o = {
                "messages": msg,
                "prompt_ids": prefix,
                "ids": ids,
                "raw": raw,
                "prediction": pred,
                "valid": valid,
                "choices": choices,
                "sequences": sequences,
            }
            r = {
                "block": block["id"],
                "stage": block["stage"],
                "job": job,
                "output": o,
                "fingerprint": bundle["fingerprint"],
                "runtime_hash": core.digest(rt),
            }
            core.write_json(
                run / name / "records" / f"{core.digest(key)}.json",
                {"record": r, "sha256": core.digest(r)},
            )
            saved[key] = r
            status.update(
                model=name, stage=block["stage"], completed_queries=len(saved), updated_utc=now()
            )
            core.write_json(run / "pipeline-status.json", status)
            print(f"{name} {block['stage']} {len(saved)}/{total}", flush=True)
    del model, tok
    gc.collect()
    torch.mps.empty_cache()


def launch(run):
    with core.exclusive_lock(run / ".launch.lock"):
        b = prepare(run)
        path = run / "launch.json"
        if path.exists():
            try:
                os.kill(json.loads(path.read_text())["pid"], 0)
            except ProcessLookupError:
                pass
            else:
                raise RuntimeError("Already running")
        with (run / "pipeline.log").open("a") as log:
            p = subprocess.Popen(
                [
                    "/usr/bin/caffeinate",
                    "-i",
                    sys.executable,
                    "-u",
                    str(Path(__file__).resolve()),
                    "--run",
                    str(run.resolve()),
                ],
                cwd=ROOT,
                env={**os.environ, "PYTHONPATH": str(ROOT / "src")},
                stdin=subprocess.DEVNULL,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
        receipt = {"pid": p.pid, "fingerprint": b["fingerprint"], "launched_utc": now()}
        core.write_json(path, receipt)
        return receipt


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--run", type=Path, default=DEFAULT)
    p.add_argument("--prepare", action="store_true")
    p.add_argument("--launch", action="store_true")
    args = p.parse_args()
    if args.prepare:
        print(prepare(args.run)["fingerprint"])
        return
    if args.launch:
        print(json.dumps(launch(args.run)))
        return
    with core.exclusive_lock(args.run / ".pipeline.lock"):
        b = prepare(args.run)
        status = {"status": "running", "started_utc": now(), "fingerprint": b["fingerprint"]}
        try:
            for name in MODELS:
                run_model(args.run, name, b, status)
            status.update(status="complete", updated_utc=now())
        except BaseException as exc:
            status.update(status="technical_failure", error=repr(exc), updated_utc=now())
            core.write_json(args.run / "pipeline-status.json", status)
            raise
        core.write_json(args.run / "pipeline-status.json", status)
        print("Complete", flush=True)


if __name__ == "__main__":
    main()
