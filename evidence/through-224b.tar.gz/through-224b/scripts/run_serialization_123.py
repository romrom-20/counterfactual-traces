#!/usr/bin/env python3
"""123/124: actual serialization order with equivalent four-state output grammars."""

import argparse
import gc
import itertools
import json
import os
import platform
import subprocess
import sys
from pathlib import Path

import run_joint_support_119 as prior
import torch
import transformers
from run_absence_alphabet_104 import MODELS, now

from latent_decisions import evidence_policy as core
from latent_decisions.target import load_target

ROOT = Path(__file__).resolve().parents[1]
DEFAULT = ROOT / "runs/serialization-123-124"
ARMS = ("free", "forward", "reverse")
STATES = list(itertools.product((False, True), repeat=2))
KEYS = ("first_supported", "second_supported")


def fresh_blocks():
    assert prior.sha(prior.DATA.read_text()) == prior.DATA_HASH
    excluded = {b["id"] for b in prior.dataset()}
    articles = []
    for article in json.loads(prior.DATA.read_text())["data"]:
        if article["title"] in excluded:
            continue
        eligible = []
        for pi, paragraph in enumerate(article["paragraphs"]):
            context = paragraph["context"]
            if not 150 <= len(context) <= 1600:
                continue
            groups = {}
            for q in paragraph["qas"]:
                if len(q["question"]) > 200:
                    continue
                for a in q.get("plausible_answers" if q["is_impossible"] else "answers", []):
                    candidate = a["text"]
                    if not 1 <= len(candidate) <= 100:
                        continue
                    assert (
                        context[a["answer_start"] : a["answer_start"] + len(candidate)] == candidate
                    )
                    groups.setdefault(candidate, {False: {}, True: {}})[q["is_impossible"]][
                        q["id"]
                    ] = q
            for candidate, group in groups.items():
                if min(len(g) for g in group.values()) < 2:
                    continue
                qs = [
                    q
                    for state in (False, True)
                    for q in sorted(
                        group[state].values(), key=lambda q: prior.sha("124:" + q["id"])
                    )[:2]
                ]
                if len({q["question"].strip().casefold() for q in qs}) != 4:
                    continue
                key = prior.sha("124:" + ":".join(q["id"] for q in qs) + ":" + candidate)
                eligible.append((key, pi, context, candidate, qs))
        if eligible:
            articles.append((prior.sha("124:" + article["title"]), article["title"], min(eligible)))
    return [
        {
            "id": title,
            "stage": "124",
            "paragraph_index": pi,
            "context": context,
            "candidate": candidate,
            "questions": qs,
        }
        for _, title, (_, pi, context, candidate, qs) in sorted(articles)[:4]
    ]


def queries(block):
    a, b, c, d = block["questions"]
    assert not a["is_impossible"] and not b["is_impossible"]
    assert c["is_impossible"] and d["is_impossible"]
    return [
        {
            "id": "joint:" + x["id"] + ":" + y["id"],
            "kind": "joint",
            "question_ids": [x["id"], y["id"]],
        }
        for pair in [(a, c), (a, b), (c, d)]
        for x, y in [pair, pair[::-1]]
    ]


def candidates(arm):
    assert arm in ("forward", "reverse")
    keys = KEYS if arm == "forward" else KEYS[::-1]
    return [
        (json.dumps({k: dict(zip(KEYS, state))[k] for k in keys}), list(state)) for state in STATES
    ]


def source_hash():
    return core.digest(
        {
            "runner": Path(__file__).read_text(),
            "protocol": (ROOT / "docs/experiments/123-124-serialization.md").read_text(),
            "prior_runner": (ROOT / "scripts/run_joint_support_119.py").read_text(),
            "dependencies": prior.source_hash(),
        }
    )


def prepare(run):
    blocks = [{**b, "stage": "123"} for b in prior.dataset()[:4]] + fresh_blocks()
    path = run / "design.json"
    if path.exists():
        bundle = json.loads(path.read_text())
        assert core.digest(bundle["design"]) == bundle["fingerprint"]
        assert bundle["design"]["source_hash"] == source_hash()
        assert bundle["design"]["blocks"] == blocks
        return bundle
    d = {
        "created_utc": now(),
        "source_hash": source_hash(),
        "data_hash": prior.DATA_HASH,
        "models": MODELS,
        "blocks": blocks,
        "arms": list(ARMS),
        "states": STATES,
        "max_new_tokens": 80,
        "max_prompt_tokens": 2048,
        "reference_tolerance": 0.003,
        "serial_pattern_minimum": 0.75,
        "semantic_swap_minimum": 0.75,
    }
    bundle = {"design": d, "fingerprint": core.digest(d)}
    core.write_json(path, bundle)
    return bundle


def records(run, name, bundle):
    saved = {}
    rt = run / name / "runtime.json"
    rh = core.digest(json.loads(rt.read_text())) if rt.exists() else None
    expected = {
        (b["id"], q["id"], a) for b in bundle["design"]["blocks"] for q in queries(b) for a in ARMS
    }
    for path in (run / name / "records").glob("*.json"):
        e = json.loads(path.read_text())
        r = e["record"]
        key = (r["block"], r["query"]["id"], r["arm"])
        assert key in expected and key not in saved
        assert core.digest(r) == e["sha256"] and r["fingerprint"] == bundle["fingerprint"]
        assert r["runtime_hash"] == rh
        saved[key] = r
    return saved


def run_model(run, name, bundle, status):
    saved = records(run, name, bundle)
    blocks = bundle["design"]["blocks"]
    total = len(blocks) * 6 * 3
    if len(saved) == total:
        return
    model, tok, device = load_target(MODELS[name], "mps", offline=True)
    rt = {
        "model": MODELS[name],
        "device": device,
        "dtype": str(next(model.parameters()).dtype),
        "training": model.training,
        "python": platform.python_version(),
        "torch": torch.__version__,
        "transformers": transformers.__version__,
        "penalty": 1.0,
        "tokenizer_hash": core.digest(tok.get_vocab()),
        "config_hash": core.digest(model.config.to_dict()),
        "chat_template": tok.chat_template,
    }
    assert rt == json.loads((prior.DEFAULT / name / "runtime.json").read_text())
    path = run / name / "runtime.json"
    if path.exists():
        assert json.loads(path.read_text()) == rt
    core.write_json(path, rt)
    for b in blocks:
        jobs = sorted(
            itertools.product(queries(b), ARMS), key=lambda x: core.digest([x[0]["id"], x[1]])
        )
        for q, arm in jobs:
            key = (b["id"], q["id"], arm)
            if key in saved:
                continue
            msg = prior.messages(b, q)
            prefix = tok.apply_chat_template(msg, tokenize=True, add_generation_prompt=True)
            assert len(prefix) <= 2048
            choices = candidates(arm) if arm != "free" else None
            sequences = core.token_sequences(tok, choices) if choices else None
            ids, raw = core.generate(model, tok, prefix, 1.0, 80, sequences=sequences)
            valid, prediction = prior.parse(raw, "joint")
            hit_limit = len(ids) == 80 and ids[-1] != tok.eos_token_id
            scores = None
            reference = None
            if sequences:
                assert ids in sequences
                scores = core.score_candidates(
                    model, prefix, sequences, {"unit": 1.0}, batch_size=1
                )["unit"]
                assert ids == sequences[scores["greedy_index"]]
                if (
                    b["id"] == next(x["id"] for x in blocks if x["stage"] == b["stage"])
                    and q == queries(b)[0]
                ):
                    reference = [
                        core.reference_logprob(model, prefix, seq, 1.0) for seq in sequences
                    ]
                    assert (
                        max(abs(x - y) for x, y in zip(reference, scores["sequence_logprobs"]))
                        < 0.003
                    )
            o = {
                "messages": msg,
                "prompt_ids": prefix,
                "ids": ids,
                "raw": raw,
                "valid": valid and not hit_limit,
                "prediction": prediction,
                "hit_limit": hit_limit,
                "choices": choices,
                "sequences": sequences,
                "scores": scores,
                "reference_logprobs": reference,
            }
            r = {
                "block": b["id"],
                "stage": b["stage"],
                "query": q,
                "arm": arm,
                "output": o,
                "fingerprint": bundle["fingerprint"],
                "runtime_hash": core.digest(rt),
            }
            core.write_json(
                run / name / "records" / f"{core.digest(key)}.json",
                {"record": r, "sha256": core.digest(r)},
            )
            saved[key] = r
            status.update(
                model=name, stage=b["stage"], completed_queries=len(saved), updated_utc=now()
            )
            core.write_json(run / "pipeline-status.json", status)
            print(f"{name} {b['stage']} {len(saved)}/{total}", flush=True)
    del model, tok
    gc.collect()
    torch.mps.empty_cache()


def launch(run):
    with core.exclusive_lock(run / ".launch.lock"):
        b = prepare(run)
        path = run / "launch.json"
        if path.exists():
            try:
                os.kill(json.loads(path.read_text())["pid"], 0)
            except ProcessLookupError:
                pass
            else:
                raise RuntimeError("Already running")
        with (run / "pipeline.log").open("a") as log:
            p = subprocess.Popen(
                [
                    "/usr/bin/caffeinate",
                    "-i",
                    sys.executable,
                    "-u",
                    str(Path(__file__).resolve()),
                    "--run",
                    str(run.resolve()),
                ],
                cwd=ROOT,
                env={**os.environ, "PYTHONPATH": str(ROOT / "src")},
                stdin=subprocess.DEVNULL,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
        receipt = {"pid": p.pid, "fingerprint": b["fingerprint"], "launched_utc": now()}
        core.write_json(path, receipt)
        return receipt


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--run", type=Path, default=DEFAULT)
    p.add_argument("--prepare", action="store_true")
    p.add_argument("--launch", action="store_true")
    args = p.parse_args()
    if args.prepare:
        print(prepare(args.run)["fingerprint"])
        return
    if args.launch:
        print(json.dumps(launch(args.run)))
        return
    with core.exclusive_lock(args.run / ".pipeline.lock"):
        b = prepare(args.run)
        status = {"status": "running", "started_utc": now(), "fingerprint": b["fingerprint"]}
        try:
            for name in MODELS:
                run_model(args.run, name, b, status)
            status.update(status="complete", updated_utc=now())
        except BaseException as exc:
            status.update(status="technical_failure", error=repr(exc), updated_utc=now())
            core.write_json(args.run / "pipeline-status.json", status)
            raise
        core.write_json(args.run / "pipeline-status.json", status)
        print("Complete", flush=True)


if __name__ == "__main__":
    main()
