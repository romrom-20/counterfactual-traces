"""Shared and signed SiLU-curvature interventions at unchanged local derivatives."""

import argparse
import gc
import itertools
import json
import os
import subprocess
import sys
from contextlib import contextmanager
from pathlib import Path

import numpy as np
import run_natural_bit_shared_reader_181 as native
import run_one_sided_gain_forecast_186 as parent
import torch
from run_absence_alphabet_104 import now
from run_order_competence_151 import runtime

from latent_decisions.evidence_policy import digest, exclusive_lock, write_json
from latent_decisions.target import load_target

ROOT = Path(__file__).resolve().parents[1]
DEFAULT = ROOT / "runs/shared-signed-curvature-187"
ARMS = ("paired", "even", "odd", "both", "false_anchor")


def source_hash():
    return digest(
        {
            "runner": Path(__file__).read_text(),
            "protocol": (
                ROOT / "docs/experiments/187-shared-versus-signed-curvature.md"
            ).read_text(),
            "parent": parent.source_hash(),
        }
    )


def prepare(run):
    pb = json.loads((parent.DEFAULT / "design.json").read_text())
    a = json.loads((ROOT / "docs/analysis/186-independent-audit.json").read_text())
    n = json.loads((ROOT / "docs/analysis/186-numerical-recheck.json").read_text())
    assert (
        a["complete"]
        and all(a["controls"].values())
        and a["numerical_qualified"]
        and n["passed"]
        and a["fingerprint"] == n["fingerprint"] == pb["fingerprint"]
        and pb["design"]["source_hash"] == parent.source_hash()
    )
    d = {
        "source_hash": source_hash(),
        "parent_fingerprint": pb["fingerprint"],
        "models": pb["design"]["models"],
        "blocks": parent.blocks(),
        "arms": list(ARMS),
        "main_forwards": 640,
        "numerical_forwards": 48,
        "tolerance": 0.1,
        "individual_floor": 0.5,
        "balanced_floor": 0.2,
        "retained_fraction": 0.5,
        "dominance": 0.75,
        "activation_tolerance": 1e-5,
    }
    p = run / "design.json"
    if p.exists():
        b = json.loads(p.read_text())
        assert b["design"] == d and digest(d) == b["fingerprint"]
        return b
    b = {"design": d, "fingerprint": digest(d), "created_utc": now()}
    write_json(p, b)
    return b


def components(xf, xt, yf, yt):
    x0, x1 = xf.astype(np.float64), xt.astype(np.float64)
    y0, y1 = yf.astype(np.float64), yt.astype(np.float64)
    c = (x0 + x1) / 2
    h = (x1 - x0) / 2
    s = np.exp(-np.logaddexp(0, -c))
    a = c * s
    d = s + c * s * (1 - s)
    return {
        "center": c.astype(np.float32),
        "intercept": a.astype(np.float32),
        "slope": d.astype(np.float32),
        "even": ((y0 + y1) / 2 - a).astype(np.float32),
        "odd": ((y1 - y0) / 2 - d * h).astype(np.float32),
        "xf": xf.copy(),
        "xt": xt.copy(),
        "yf": yf.copy(),
        "yt": yt.copy(),
    }


@contextmanager
def intervene(model, pos, maps, arm, bit):
    cap, trace, handles = {}, [], []
    try:
        for site in range(1, 29):
            target = {
                k: torch.as_tensor(v, device=next(model.parameters()).device)
                for k, v in maps[site].items()
            }

            def hook(module, args, out, site=site, target=target):
                x = args[0][0, pos + 1 :]
                if arm == "false_anchor":
                    y = target["yf"] + target["slope"] * (x - target["xf"])
                else:
                    y = target["intercept"] + target["slope"] * (x - target["center"])
                    if arm in ("even", "both"):
                        y = y + target["even"]
                    if arm in ("odd", "both"):
                        y = y + (2 * bit - 1) * target["odd"]
                    if arm == "both":
                        y = torch.where(x == target["xf"], target["yf"], y)
                        y = torch.where(x == target["xt"], target["yt"], y)
                changed = out.clone()
                changed[0, pos + 1 :] = y
                assert torch.equal(changed[:, : pos + 1], out[:, : pos + 1])
                cap[f"{site}_input"] = x.detach().cpu().numpy().copy()
                cap[f"{site}_output"] = y.detach().cpu().numpy().copy()
                trace.append(
                    {
                        "site": site,
                        "arm": arm,
                        "bit": bit,
                        "start": pos + 1,
                        "end": out.shape[1],
                        "other_rows_identical": True,
                        "endpoint_correction": arm == "both",
                        "input_sha256": native.array_hash(cap[f"{site}_input"]),
                        "output_sha256": native.array_hash(cap[f"{site}_output"]),
                    }
                )
                return changed

            handles.append(model.model.layers[site - 1].mlp.act_fn.register_forward_hook(hook))
        yield cap, trace
        assert [r["site"] for r in trace] == list(range(1, 29))
    finally:
        for handle in handles:
            handle.remove()


def run_model(run, bundle, status):
    model, tok, device = load_target(bundle["design"]["models"]["qwen15"], "mps", offline=True)
    rt = runtime(model, tok, device, "qwen15")
    assert rt == json.loads((parent.DEFAULT / "qwen15/runtime.json").read_text())
    write_json(run / "qwen15/runtime.json", rt)
    done = 0
    for index, (block, a, t, rev, schema) in enumerate(
        itertools.product(parent.blocks(), range(2), range(2), range(2), ("generic", "descriptive"))
    ):
        g = native.fixture.group(block, a, t, rev, schema)
        key = digest(g)
        fe = json.loads((parent.DEFAULT / "qwen15/forecasts" / f"{key}.json").read_text())
        e = json.loads((parent.DEFAULT / "qwen15/records" / f"{key}.json").read_text())
        fr, r = fe["record"], e["record"]
        assert digest(fr) == fe["sha256"] and digest(r) == e["sha256"]
        fp, p = (
            parent.DEFAULT / "qwen15/forecasts" / f"{key}.npz",
            parent.DEFAULT / "qwen15/states" / f"{key}.npz",
        )
        assert parent.hashed(fp) == fr["states_sha256"] and parent.hashed(p) == r["states_sha256"]
        pos = r["position"]
        bases, observed = native.paired_bases(tok, block, g)
        assert observed == pos and bases == fr["bases"]
        arrays, patches = {}, []
        with np.load(fp, allow_pickle=False) as fz, np.load(p, allow_pickle=False) as z:
            maps = {
                site: components(
                    fz[f"native_false_{site}_input"],
                    z[f"native_true_{site}_input"],
                    fz[f"native_false_{site}_output"],
                    z[f"native_true_{site}_output"],
                )
                for site in range(1, 29)
            }
            arrays.update(
                {f"map_{site}_{name}": v for site, m in maps.items() for name, v in m.items()}
            )
            for arm, bit in itertools.product(ARMS, range(2)):
                with intervene(model, pos, maps, arm, bit) as (cap, trace):
                    m, h = native.score(model, bases[bit])
                reference = fz["native_false_final"] if bit == 0 else z["native_true_final"]
                assert np.array_equal(h[: pos + 1], reference[: pos + 1])
                if arm == "both":
                    expected = (
                        fr["native_false"]["margin"] if bit == 0 else r["native_true"]["margin"]
                    )
                    assert m == expected and np.array_equal(h, reference)
                    assert all(
                        np.array_equal(
                            cap[f"{site}_{kind}"],
                            (fz if bit == 0 else z)[
                                f"native_{'false' if bit == 0 else 'true'}_{site}_{kind}"
                            ],
                        )
                        for site, kind in itertools.product(range(1, 29), ("input", "output"))
                    )
                if arm == "false_anchor":
                    expected = next(q["margin"] for q in r["patches"] if q["bit"] == bit)
                    assert m == expected and np.array_equal(h, z[f"oracle_{bit}_final"])
                arrays[f"{arm}_{bit}_final"] = h
                arrays.update({f"{arm}_{bit}_{name}": v for name, v in cap.items()})
                patches.append({"arm": arm, "bit": bit, "margin": m, "activation_trace": trace})
                done += 1
        sp = run / "qwen15/states" / f"{key}.npz"
        sp.parent.mkdir(parents=True, exist_ok=True)
        np.savez_compressed(sp, **arrays)
        record = {
            "fingerprint": bundle["fingerprint"],
            **g,
            "position": pos,
            "forecast_record_sha256": fe["sha256"],
            "native_record_sha256": e["sha256"],
            "patches": patches,
            "states_sha256": parent.hashed(sp),
        }
        write_json(
            run / "qwen15/records" / f"{key}.json", {"record": record, "sha256": digest(record)}
        )
        status.update(completed_forwards=done, completed_pairs=index + 1, updated_utc=now())
        write_json(run / "pipeline-status.json", status)
        print(f"187 pairs {index + 1}/64; {done}/640 forwards", flush=True)
        del arrays, maps
        gc.collect()
    assert done == 640
    del model, tok
    gc.collect()
    torch.mps.empty_cache()


def launch(run):
    with exclusive_lock(run / ".launch.lock"):
        b = prepare(run)
        assert not (run / "launch.json").exists()
        with (run / "pipeline.log").open("a") as log:
            p = subprocess.Popen(
                [
                    "/usr/bin/caffeinate",
                    "-i",
                    sys.executable,
                    "-u",
                    str(Path(__file__).resolve()),
                    "--run",
                    str(run.resolve()),
                ],
                cwd=ROOT,
                env={**os.environ, "PYTHONPATH": str(ROOT / "src")},
                stdin=subprocess.DEVNULL,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
        out = {"pid": p.pid, "fingerprint": b["fingerprint"], "launched_utc": now()}
        write_json(run / "launch.json", out)
        return out


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--run", type=Path, default=DEFAULT)
    parser.add_argument("--launch", action="store_true")
    args = parser.parse_args()
    if args.launch:
        print(json.dumps(launch(args.run)))
        return
    with exclusive_lock(args.run / ".pipeline.lock"):
        b = prepare(args.run)
        status = {"status": "running", "fingerprint": b["fingerprint"], "started_utc": now()}
        write_json(args.run / "pipeline-status.json", status)
        try:
            run_model(args.run, b, status)
            status.update(status="complete", updated_utc=now())
        except BaseException as exc:
            status.update(status="technical_failure", error=repr(exc), updated_utc=now())
            write_json(args.run / "pipeline-status.json", status)
            raise
        write_json(args.run / "pipeline-status.json", status)


if __name__ == "__main__":
    main()
