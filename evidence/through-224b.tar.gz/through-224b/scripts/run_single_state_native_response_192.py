"""Seal all native-response Taylor forecasts at false before any target observation."""

import gc
import hashlib
import itertools
import json
from contextlib import contextmanager
from pathlib import Path

import false_state_response_192 as response
import numpy as np
import run_natural_bit_shared_reader_181 as native
import run_one_sided_curvature_forecast_191 as parent
import torch
from run_absence_alphabet_104 import now
from run_order_competence_151 import runtime

from latent_decisions.evidence_policy import digest, exclusive_lock, write_json
from latent_decisions.target import block_tensor, load_target

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / "runs/single-state-native-response-192"
DOSES = (0.125, 0.25, 0.5, 1.0)
LITERALS = (
    ("saffron", "cumin", "Tuesday", "Saturday"),
    ("neptune", "pluto", "Wednesday", "Sunday"),
    ("riddle", "enigma", "Monday", "Thursday"),
    ("alloy", "ingot", "Friday", "Tuesday"),
)


def blocks():
    return [
        {"id": a, "stage": "192", "subjects": [a, b], "days": [x, y], "old_block": None}
        for a, b, x, y in LITERALS
    ]


def hashed(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def source_hash():
    return digest(
        {
            "runner": Path(__file__).read_text(),
            "helper": Path(response.__file__).read_text(),
            "protocol": (ROOT / "docs/experiments/192-single-state-native-response.md").read_text(),
            "parent": parent.source_hash(),
        }
    )


@contextmanager
def actual_states(model):
    values, handles = [], []

    def hook(module, args, output):
        values.append(block_tensor(output)[0].detach().cpu().numpy().copy())

    try:
        for layer in model.model.layers:
            handles.append(layer.register_forward_hook(hook))
        yield values
        assert len(values) == 28
    finally:
        for handle in handles:
            handle.remove()


def main():
    with exclusive_lock(RUN / ".pipeline.lock"):
        assert not (RUN / "design.json").exists()
        pa = json.loads((ROOT / "docs/analysis/191-independent-audit.json").read_text())
        pn = json.loads((ROOT / "docs/analysis/191-numerical-recheck.json").read_text())
        pb = json.loads((parent.DEFAULT / "design.json").read_text())
        assert pa["numerical_qualified"] and all(pa["controls"].values()) and pn["passed"]
        assert pa["fingerprint"] == pn["fingerprint"] == pb["fingerprint"]
        d = {
            "source_hash": source_hash(),
            "parent_fingerprint": pb["fingerprint"],
            "models": pb["design"]["models"],
            "blocks": blocks(),
            "doses": DOSES,
            "ordinary_model_invocations": 320,
            "differentiated_false_invocations": 64,
            "forward_ad_levels": 2,
        }
        bundle = {"design": d, "fingerprint": digest(d), "created_utc": now()}
        write_json(RUN / "design.json", bundle)
        status = {
            "status": "running",
            "fingerprint": bundle["fingerprint"],
            "ordinary_model_invocations": 0,
            "differentiated_false_invocations": 0,
            "started_utc": now(),
        }
        write_json(RUN / "pipeline-status.json", status)
        try:
            execute(bundle, status)
            status.update(status="complete", completed_utc=now())
        except BaseException as exc:
            status.update(status="technical_failure", error=repr(exc), updated_utc=now())
            write_json(RUN / "pipeline-status.json", status)
            raise
        write_json(RUN / "pipeline-status.json", status)


def execute(bundle, status):
    model, tok, device = load_target(bundle["design"]["models"]["qwen15"], "mps", offline=True)
    rt = runtime(model, tok, device, "qwen15")
    assert rt == json.loads((parent.DEFAULT / "qwen15/runtime.json").read_text())
    write_json(RUN / "qwen15/runtime.json", rt)
    manifest, entries = [], []
    for block, a, t, rev, schema in itertools.product(
        blocks(), range(2), range(2), range(2), ("generic", "descriptive")
    ):
        g = native.fixture.group(block, a, t, rev, schema)
        bases, pos = native.paired_bases(tok, block, g)
        key = digest(g)
        started = now()
        with actual_states(model) as false_h:
            fm, fh = native.score(model, bases[0])
        status["ordinary_model_invocations"] += 1
        assert np.array_equal(false_h[-1], fh)
        inputs = response.embedding_pair(model, *[b["free_input_ids"] for b in bases])
        primal, d1, d2, again = response.second_order(model, *inputs)
        status["differentiated_false_invocations"] += 1
        arrays = {}
        for label, values in (("primal", primal), ("d1", d1), ("d2", d2), ("redundant_d1", again)):
            arrays.update(
                {
                    f"{label}_{name}": v.detach().cpu().numpy().copy()
                    for name, v in zip(("states", "scores"), values)
                }
            )
        arrays["native_false_states"] = np.stack(false_h)
        arrays["native_false_scores"] = np.array(
            [fm["false_score"], fm["true_score"]], dtype=np.float32
        )
        assert all(np.isfinite(v).all() for v in arrays.values())
        assert np.max(abs(arrays["primal_states"] - arrays["native_false_states"])) <= 1e-4
        assert np.max(abs(arrays["primal_scores"] - arrays["native_false_scores"])) <= 0.005
        assert (
            max(
                np.max(abs(arrays[f"d1_{name}"] - arrays[f"redundant_d1_{name}"]))
                for name in ("states", "scores")
            )
            <= 1e-4
        )
        assert all(
            np.count_nonzero(arrays[f"{kind}_states"][:, :pos]) == 0 for kind in ("d1", "d2")
        )
        closure = float(
            torch.max(
                abs(
                    inputs[0]
                    + inputs[1]
                    - model.model.embed_tokens(
                        torch.tensor([bases[1]["free_input_ids"]], device=device)
                    )
                )
            ).item()
        )
        sp = RUN / "qwen15/forecasts" / f"{key}.npz"
        sp.parent.mkdir(parents=True, exist_ok=True)
        np.savez_compressed(sp, **arrays)
        r = {
            "fingerprint": bundle["fingerprint"],
            **g,
            "bases": bases,
            "position": pos,
            "native_false": fm,
            "embedding_closure_error": closure,
            "started_utc": started,
            "completed_utc": now(),
            "states_sha256": hashed(sp),
        }
        write_json(sp.with_suffix(".json"), {"record": r, "sha256": digest(r)})
        manifest.append(
            {"key": key, "record_sha256": digest(r), "states_sha256": r["states_sha256"]}
        )
        entries.append((key, r))
        status.update(forecast_pairs=len(entries), updated_utc=now())
        write_json(RUN / "pipeline-status.json", status)
        print(f"192 false-only forecast pairs {len(entries)}/64", flush=True)
        del arrays, primal, d1, d2, again, false_h, inputs
        gc.collect()
    write_json(
        RUN / "forecast-manifest.json",
        {
            "manifest": manifest,
            "manifest_sha256": digest(manifest),
            "completed_utc": now(),
            "ordinary_model_invocations": 64,
            "differentiated_false_invocations": 64,
        },
    )
    for key, fr in entries:
        started = now()
        arrays, margins = {}, {}
        bases = fr["bases"]
        with actual_states(model) as true_h:
            tm, th = native.score(model, bases[1])
        status["ordinary_model_invocations"] += 1
        assert np.array_equal(true_h[-1], th)
        arrays["actual_1.0_states"] = np.stack(true_h)
        arrays["actual_1.0_scores"] = np.array(
            [tm["false_score"], tm["true_score"]], dtype=np.float32
        )
        margins["1.0"] = tm
        inputs = response.embedding_pair(model, *[b["free_input_ids"] for b in bases])
        with torch.inference_mode():
            for dose in DOSES[:-1]:
                states, scores = response.computation(
                    model, *inputs, torch.tensor(dose, device=device)
                )
                status["ordinary_model_invocations"] += 1
                arrays[f"actual_{dose}_states"] = states.cpu().numpy().copy()
                arrays[f"actual_{dose}_scores"] = scores.cpu().numpy().copy()
                fs, ts = map(float, arrays[f"actual_{dose}_scores"])
                margins[str(dose)] = {"false_score": fs, "true_score": ts, "log_odds": ts - fs}
        assert all(np.isfinite(v).all() for v in arrays.values())
        sp = RUN / "qwen15/observations" / f"{key}.npz"
        sp.parent.mkdir(parents=True, exist_ok=True)
        np.savez_compressed(sp, **arrays)
        r = {
            "fingerprint": bundle["fingerprint"],
            "forecast_record_sha256": digest(fr),
            "margins": margins,
            "started_utc": started,
            "completed_utc": now(),
            "states_sha256": hashed(sp),
        }
        write_json(sp.with_suffix(".json"), {"record": r, "sha256": digest(r)})
        status.update(
            observed_pairs=len(list((RUN / "qwen15/observations").glob("*.json"))),
            updated_utc=now(),
        )
        write_json(RUN / "pipeline-status.json", status)
        print(f"192 observed pairs {status['observed_pairs']}/64", flush=True)
        del arrays, inputs, true_h
        gc.collect()
    assert (
        status["ordinary_model_invocations"] == 320
        and status["differentiated_false_invocations"] == 64
    )
    del model, tok
    gc.collect()
    torch.mps.empty_cache()


if __name__ == "__main__":
    main()
