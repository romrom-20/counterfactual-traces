"""Cross local/donor affine SiLU offsets and slopes under native dynamics."""

import argparse
import gc
import hashlib
import itertools
import json
import os
import subprocess
import sys
from pathlib import Path

import numpy as np
import run_natural_bit_shared_reader_181 as native
import run_natural_silu_tangent_183 as tangent
import run_transferred_silu_tangent_184 as parent
import torch
from run_absence_alphabet_104 import now
from run_order_competence_151 import runtime

from latent_decisions.evidence_policy import digest, exclusive_lock, write_json
from latent_decisions.target import load_target

ROOT = Path(__file__).resolve().parents[1]
DEFAULT = ROOT / "runs/tangent-offset-slope-crossing-185"
ARMS = ("original_local", "LL", "LD", "DL", "DD")


def source_hash():
    return digest(
        {
            "runner": Path(__file__).read_text(),
            "protocol": (
                ROOT / "docs/experiments/185-tangent-offset-slope-crossing.md"
            ).read_text(),
            "parent": parent.source_hash(),
        }
    )


def prepare(run):
    pb = json.loads((parent.DEFAULT / "design.json").read_text())
    a = json.loads((ROOT / "docs/analysis/184-independent-audit.json").read_text())
    n = json.loads((ROOT / "docs/analysis/184-numerical-recheck.json").read_text())
    assert (
        a["complete"]
        and all(a["controls"].values())
        and a["numerical_qualified"]
        and n["passed"]
        and a["fingerprint"] == n["fingerprint"] == pb["fingerprint"]
        and pb["design"]["source_hash"] == parent.source_hash()
    )
    d = {
        "source_hash": source_hash(),
        "parent_fingerprint": pb["fingerprint"],
        "models": pb["design"]["models"],
        "blocks": parent.blocks(),
        "main_forwards": 640,
        "numerical_forwards": 48,
        "arms": list(ARMS),
        "tolerance": 0.1,
        "individual_floor": 0.5,
        "balanced_floor": 0.2,
        "retained_fraction": 0.5,
        "dominance": 0.75,
        "activation_tolerance": 1e-5,
        "architectural_score_tolerance": 0.005,
        "architectural_state_tolerance": 0.001,
    }
    p = run / "design.json"
    if p.exists():
        b = json.loads(p.read_text())
        assert b["design"] == d and digest(d) == b["fingerprint"]
        return b
    b = {"design": d, "fingerprint": digest(d), "created_utc": now()}
    write_json(p, b)
    return b


def coefficients(x0, x1):
    c = (x0.astype(np.float64) + x1.astype(np.float64)) / 2
    s = np.exp(-np.logaddexp(0, -c))
    d = s + c * s * (1 - s)
    return {"slope": d.astype(np.float32), "offset": (c * s - d * c).astype(np.float32)}


def run_model(run, bundle, status):
    model, tok, device = load_target(bundle["design"]["models"]["qwen15"], "mps", offline=True)
    rt = runtime(model, tok, device, "qwen15")
    assert rt == json.loads((parent.DEFAULT / "qwen15/runtime.json").read_text())
    write_json(run / "qwen15/runtime.json", rt)
    donor, provenance = {}, {}
    for schema, rev in itertools.product(("generic", "descriptive"), range(2)):
        g = native.fixture.group(native.blocks()[0], 0, 0, rev, schema)
        key = digest(g)
        e = json.loads((tangent.DEFAULT / "qwen15/records" / f"{key}.json").read_text())
        p = tangent.DEFAULT / "qwen15/states" / f"{key}.npz"
        assert (
            digest(e["record"]) == e["sha256"]
            and hashlib.sha256(p.read_bytes()).hexdigest() == e["record"]["states_sha256"]
        )
        with np.load(p, allow_pickle=False) as z:
            donor[f"{schema}_{rev}"] = {
                site: coefficients(z[f"raw_0_{site}_input"], z[f"raw_1_{site}_input"])
                for site in range(1, 29)
            }
        provenance[f"{schema}_{rev}"] = {
            "record_sha256": e["sha256"],
            "state_sha256": e["record"]["states_sha256"],
        }
    write_json(run / "donor-provenance.json", provenance)
    done = 0
    for index, (block, a, t, rev, schema) in enumerate(
        itertools.product(parent.blocks(), range(2), range(2), range(2), ("generic", "descriptive"))
    ):
        g = native.fixture.group(block, a, t, rev, schema)
        key = digest(g)
        fe = json.loads((parent.DEFAULT / "qwen15/forecasts" / f"{key}.json").read_text())
        e = json.loads((parent.DEFAULT / "qwen15/records" / f"{key}.json").read_text())
        fr, r = fe["record"], e["record"]
        assert digest(fr) == fe["sha256"] and digest(r) == e["sha256"]
        p = parent.DEFAULT / "qwen15/states" / f"{key}.npz"
        fp = parent.DEFAULT / "qwen15/forecasts" / f"{key}.npz"
        assert (
            hashlib.sha256(p.read_bytes()).hexdigest() == r["states_sha256"]
            and hashlib.sha256(fp.read_bytes()).hexdigest() == fr["states_sha256"]
        )
        arrays, patches = {}, []
        pos = r["position"]
        with np.load(p, allow_pickle=False) as z, np.load(fp, allow_pickle=False) as fz:
            local = {
                site: coefficients(z[f"native_0_{site}_input"], z[f"native_1_{site}_input"])
                for site in range(1, 29)
            }
            original = {
                site: tangent.tangent_anchor(
                    z[f"native_0_{site}_input"], z[f"native_1_{site}_input"]
                )
                for site in range(1, 29)
            }
            references = {"L": local, "D": donor[f"{schema}_{rev}"]}
            for arm, bit in itertools.product(ARMS, range(2)):
                anchors = (
                    original
                    if arm == "original_local"
                    else {
                        site: {
                            "center": np.zeros_like(local[site]["slope"]),
                            "intercept": references[arm[0]][site]["offset"],
                            "slope": references[arm[1]][site]["slope"],
                        }
                        for site in range(1, 29)
                    }
                )
                arrays.update(
                    {
                        f"map_{arm}_{site}_{name}": v
                        for site, anchor in anchors.items()
                        for name, v in anchor.items()
                    }
                )
                with tangent.activations(model, pos, anchors) as (cap, trace):
                    m, h = native.score(model, fr["bases"][bit])
                assert np.array_equal(h[: pos + 1], z[f"native_{bit}_final"][: pos + 1])
                arrays[f"{arm}_{bit}_final"] = h
                arrays.update({f"{arm}_{bit}_{name}": v for name, v in cap.items()})
                patches.append({"arm": arm, "bit": bit, "margin": m, "activation_trace": trace})
                done += 1
        sp = run / "qwen15/states" / f"{key}.npz"
        sp.parent.mkdir(parents=True, exist_ok=True)
        np.savez_compressed(sp, **arrays)
        record = {
            "fingerprint": bundle["fingerprint"],
            **g,
            "position": pos,
            "native_record_sha256": e["sha256"],
            "forecast_record_sha256": fe["sha256"],
            "patches": patches,
            "states_sha256": hashlib.sha256(sp.read_bytes()).hexdigest(),
        }
        write_json(
            run / "qwen15/records" / f"{key}.json", {"record": record, "sha256": digest(record)}
        )
        status.update(completed_forwards=done, completed_pairs=index + 1, updated_utc=now())
        write_json(run / "pipeline-status.json", status)
        print(f"185 pairs {index + 1}/64; {done}/640 forwards", flush=True)
        del arrays, local, original, references
        gc.collect()
    assert done == 640
    del model, tok
    gc.collect()
    torch.mps.empty_cache()


def launch(run):
    with exclusive_lock(run / ".launch.lock"):
        b = prepare(run)
        assert not (run / "launch.json").exists()
        with (run / "pipeline.log").open("a") as log:
            p = subprocess.Popen(
                [
                    "/usr/bin/caffeinate",
                    "-i",
                    sys.executable,
                    "-u",
                    str(Path(__file__).resolve()),
                    "--run",
                    str(run.resolve()),
                ],
                cwd=ROOT,
                env={**os.environ, "PYTHONPATH": str(ROOT / "src")},
                stdin=subprocess.DEVNULL,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
        out = {"pid": p.pid, "fingerprint": b["fingerprint"], "launched_utc": now()}
        write_json(run / "launch.json", out)
        return out


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--run", type=Path, default=DEFAULT)
    parser.add_argument("--launch", action="store_true")
    args = parser.parse_args()
    if args.launch:
        print(json.dumps(launch(args.run)))
        return
    with exclusive_lock(args.run / ".pipeline.lock"):
        b = prepare(args.run)
        status = {"status": "running", "fingerprint": b["fingerprint"], "started_utc": now()}
        write_json(args.run / "pipeline-status.json", status)
        try:
            run_model(args.run, b, status)
            status.update(status="complete", updated_utc=now())
        except BaseException as exc:
            status.update(status="technical_failure", error=repr(exc), updated_utc=now())
            write_json(args.run / "pipeline-status.json", status)
            raise
        write_json(args.run / "pipeline-status.json", status)


if __name__ == "__main__":
    main()
