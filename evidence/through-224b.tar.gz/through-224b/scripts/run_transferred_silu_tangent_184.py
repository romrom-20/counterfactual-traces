"""Four fixed donor tangent maps, forecasts frozen before fresh native measurements."""

import argparse
import gc
import hashlib
import itertools
import json
import os
import subprocess
import sys
from pathlib import Path

import numpy as np
import run_natural_bit_shared_reader_181 as native
import run_natural_silu_tangent_183 as parent
import torch
from run_absence_alphabet_104 import now
from run_order_competence_151 import runtime

from latent_decisions.evidence_policy import digest, exclusive_lock, write_json
from latent_decisions.target import load_target

ROOT = Path(__file__).resolve().parents[1]
DEFAULT = ROOT / "runs/transferred-silu-tangent-184"
LITERALS = (
    ("juniper", "magnolia", "Monday", "Sunday"),
    ("zircon", "topaz", "Thursday", "Saturday"),
    ("horizon", "solstice", "Wednesday", "Monday"),
    ("cobalt", "umber", "Saturday", "Tuesday"),
)


def blocks():
    return [
        {"id": a, "stage": "184", "subjects": [a, b], "days": [x, y], "old_block": None}
        for a, b, x, y in LITERALS
    ]


def source_hash():
    return digest(
        {
            "runner": Path(__file__).read_text(),
            "protocol": (ROOT / "docs/experiments/184-transferred-silu-tangent.md").read_text(),
            "parent": parent.source_hash(),
        }
    )


def prepare(run):
    pb = json.loads((parent.DEFAULT / "design.json").read_text())
    a = json.loads((ROOT / "docs/analysis/183-independent-audit.json").read_text())
    n = json.loads((ROOT / "docs/analysis/183-numerical-recheck.json").read_text())
    assert (
        a["complete"]
        and all(a["controls"].values())
        and a["numerical_qualified"]
        and n["passed"]
        and a["fingerprint"] == n["fingerprint"] == pb["fingerprint"]
        and pb["design"]["source_hash"] == parent.source_hash()
    )
    d = {
        "source_hash": source_hash(),
        "parent_fingerprint": pb["fingerprint"],
        "models": pb["design"]["models"],
        "blocks": blocks(),
        "main_forwards": 256,
        "numerical_forwards": 16,
        "tolerance": 0.1,
        "individual_floor": 0.5,
        "balanced_floor": 0.2,
        "retained_fraction": 0.5,
        "dominance": 0.75,
        "activation_tolerance": 1e-5,
    }
    p = run / "design.json"
    if p.exists():
        b = json.loads(p.read_text())
        assert b["design"] == d and digest(d) == b["fingerprint"]
        return b
    b = {"design": d, "fingerprint": digest(d), "created_utc": now()}
    write_json(p, b)
    return b


def run_model(run, bundle, status):
    model, tok, device = load_target(bundle["design"]["models"]["qwen15"], "mps", offline=True)
    rt = runtime(model, tok, device, "qwen15")
    assert rt == json.loads((parent.DEFAULT / "qwen15/runtime.json").read_text())
    write_json(run / "qwen15/runtime.json", rt)
    maps, provenance = {}, {}
    for schema, rev in itertools.product(("generic", "descriptive"), range(2)):
        donor = native.fixture.group(native.blocks()[0], 0, 0, rev, schema)
        key = digest(donor)
        e = json.loads((parent.DEFAULT / "qwen15/records" / f"{key}.json").read_text())
        p = parent.DEFAULT / "qwen15/states" / f"{key}.npz"
        assert (
            digest(e["record"]) == e["sha256"]
            and hashlib.sha256(p.read_bytes()).hexdigest() == e["record"]["states_sha256"]
        )
        with np.load(p, allow_pickle=False) as z:
            maps[f"{schema}_{rev}"] = {
                site: {
                    name: z[f"anchor_{site}_{name}"].copy()
                    for name in ("center", "intercept", "slope")
                }
                for site in range(1, 29)
            }
        provenance[f"{schema}_{rev}"] = {
            "donor": donor,
            "record_sha256": e["sha256"],
            "states_sha256": e["record"]["states_sha256"],
        }
    mp = run / "donor-maps.npz"
    mp.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(
        mp,
        **{
            f"{ctx}_{site}_{name}": v
            for ctx, sites in maps.items()
            for site, anchor in sites.items()
            for name, v in anchor.items()
        },
    )
    write_json(
        run / "donor-provenance.json",
        {
            "maps_sha256": hashlib.sha256(mp.read_bytes()).hexdigest(),
            "donors": provenance,
            "created_utc": now(),
            "before_target_forwards": True,
        },
    )
    entries, manifest, done = [], [], 0
    for block, a, t, rev, schema in itertools.product(
        blocks(), range(2), range(2), range(2), ("generic", "descriptive")
    ):
        g = native.fixture.group(block, a, t, rev, schema)
        key = digest(g)
        bases, pos = native.paired_bases(tok, block, g)
        anchors = maps[f"{schema}_{rev}"]
        assert all(
            v.shape == (len(bases[0]["free_input_ids"]) - pos - 1, 8960)
            for anchor in anchors.values()
            for v in anchor.values()
        )
        arrays, patches = {}, []
        for bit, base in enumerate(bases):
            with parent.activations(model, pos, anchors) as (cap, trace):
                m, h = native.score(model, base)
            arrays[f"forecast_{bit}_final"] = h
            arrays.update({f"forecast_{bit}_{name}": v for name, v in cap.items()})
            patches.append(
                {"bit": bit, "margin": m, "activation_trace": trace, "completed_utc": now()}
            )
            done += 1
        sp = run / "qwen15/forecasts" / f"{key}.npz"
        sp.parent.mkdir(parents=True, exist_ok=True)
        np.savez_compressed(sp, **arrays)
        record = {
            "fingerprint": bundle["fingerprint"],
            **g,
            "position": pos,
            "bases": bases,
            "patches": patches,
            "states_sha256": hashlib.sha256(sp.read_bytes()).hexdigest(),
        }
        write_json(
            run / "qwen15/forecasts" / f"{key}.json", {"record": record, "sha256": digest(record)}
        )
        manifest.append(
            {"key": key, "record_sha256": digest(record), "states_sha256": record["states_sha256"]}
        )
        entries.append((g, key))
        status.update(completed_forwards=done, forecast_pairs=len(entries), updated_utc=now())
        write_json(run / "pipeline-status.json", status)
    assert done == 128
    frozen = {
        "completed_utc": now(),
        "completed_forwards": 128,
        "manifest": manifest,
        "manifest_sha256": digest(manifest),
    }
    write_json(run / "forecast-manifest.json", frozen)
    for index, (g, key) in enumerate(entries):
        e = json.loads((run / "qwen15/forecasts" / f"{key}.json").read_text())
        r = e["record"]
        assert digest(r) == e["sha256"]
        arrays, natives = {}, []
        p = run / "qwen15/forecasts" / f"{key}.npz"
        assert hashlib.sha256(p.read_bytes()).hexdigest() == r["states_sha256"]
        with np.load(p, allow_pickle=False) as z:
            for bit, base in enumerate(r["bases"]):
                started = now()
                with parent.activations(model, r["position"]) as (cap, trace):
                    m, h = native.score(model, base)
                assert np.array_equal(
                    h[: r["position"] + 1], z[f"forecast_{bit}_final"][: r["position"] + 1]
                )
                arrays[f"native_{bit}_final"] = h
                arrays.update({f"native_{bit}_{name}": v for name, v in cap.items()})
                natives.append(
                    {
                        "bit": bit,
                        "margin": m,
                        "activation_trace": trace,
                        "started_utc": started,
                        "completed_utc": now(),
                    }
                )
                done += 1
        sp = run / "qwen15/states" / f"{key}.npz"
        sp.parent.mkdir(parents=True, exist_ok=True)
        np.savez_compressed(sp, **arrays)
        record = {
            "fingerprint": bundle["fingerprint"],
            **g,
            "position": r["position"],
            "forecast_record_sha256": e["sha256"],
            "natives": natives,
            "states_sha256": hashlib.sha256(sp.read_bytes()).hexdigest(),
        }
        write_json(
            run / "qwen15/records" / f"{key}.json", {"record": record, "sha256": digest(record)}
        )
        status.update(completed_forwards=done, completed_pairs=index + 1, updated_utc=now())
        write_json(run / "pipeline-status.json", status)
        print(f"184 targets {index + 1}/64; {done}/256 physical forwards", flush=True)
        del arrays
        gc.collect()
    assert done == 256
    del model, tok
    gc.collect()
    torch.mps.empty_cache()


def launch(run):
    with exclusive_lock(run / ".launch.lock"):
        b = prepare(run)
        assert not (run / "launch.json").exists()
        with (run / "pipeline.log").open("a") as log:
            p = subprocess.Popen(
                [
                    "/usr/bin/caffeinate",
                    "-i",
                    sys.executable,
                    "-u",
                    str(Path(__file__).resolve()),
                    "--run",
                    str(run.resolve()),
                ],
                cwd=ROOT,
                env={**os.environ, "PYTHONPATH": str(ROOT / "src")},
                stdin=subprocess.DEVNULL,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
        out = {"pid": p.pid, "fingerprint": b["fingerprint"], "launched_utc": now()}
        write_json(run / "launch.json", out)
        return out


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--run", type=Path, default=DEFAULT)
    p.add_argument("--launch", action="store_true")
    args = p.parse_args()
    if args.launch:
        print(json.dumps(launch(args.run)))
        return
    with exclusive_lock(args.run / ".pipeline.lock"):
        b = prepare(args.run)
        status = {"status": "running", "fingerprint": b["fingerprint"], "started_utc": now()}
        write_json(args.run / "pipeline-status.json", status)
        try:
            run_model(args.run, b, status)
            status.update(status="complete", updated_utc=now())
        except BaseException as exc:
            status.update(status="technical_failure", error=repr(exc), updated_utc=now())
            write_json(args.run / "pipeline-status.json", status)
            raise
        write_json(args.run / "pipeline-status.json", status)


if __name__ == "__main__":
    main()
