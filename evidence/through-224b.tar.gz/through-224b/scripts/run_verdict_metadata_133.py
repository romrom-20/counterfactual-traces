#!/usr/bin/env python3
"""133/134: distinguish preceding support judgments from unrelated metadata bits."""

import argparse
import gc
import itertools
import json
import os
import platform
import subprocess
import sys
from pathlib import Path

import run_duplicate_125 as duplicate
import run_joint_support_119 as prior
import run_position_binding_127 as binding
import run_serialization_123 as serial
import run_verdict_codebook_131 as codebook
import run_verdict_prefix_129 as ancestor
import torch
import transformers
from run_absence_alphabet_104 import MODELS, now

from latent_decisions import evidence_policy as core
from latent_decisions.target import load_target

ROOT = Path(__file__).resolve().parents[1]
DEFAULT = ROOT / "runs/verdict-metadata-133-134"


def fresh_blocks():
    assert prior.sha(prior.DATA.read_text()) == prior.DATA_HASH
    excluded = {
        b["id"]
        for b in prior.dataset()
        + serial.fresh_blocks()
        + duplicate.fresh_blocks()
        + binding.fresh_blocks()
        + ancestor.fresh_blocks()
        + codebook.fresh_blocks()
    }
    excluded.add("Sahara")  # Prelaunch review: third hottest is mislabeled as supported.
    articles = []
    for article in json.loads(prior.DATA.read_text())["data"]:
        if article["title"] in excluded:
            continue
        eligible = []
        for pi, paragraph in enumerate(article["paragraphs"]):
            context = paragraph["context"]
            if not 150 <= len(context) <= 1600:
                continue
            groups = {}
            for q in paragraph["qas"]:
                if len(q["question"]) > 200:
                    continue
                for a in q.get("plausible_answers" if q["is_impossible"] else "answers", []):
                    candidate = a["text"]
                    if not 1 <= len(candidate) <= 100:
                        continue
                    assert (
                        context[a["answer_start"] : a["answer_start"] + len(candidate)] == candidate
                    )
                    groups.setdefault(candidate, {False: {}, True: {}})[q["is_impossible"]][
                        q["id"]
                    ] = q
            for candidate, group in groups.items():
                if min(len(g) for g in group.values()) < 2:
                    continue
                qs = [
                    q
                    for state in (False, True)
                    for q in sorted(
                        group[state].values(), key=lambda q: prior.sha("134:" + q["id"])
                    )[:2]
                ]
                if len({q["question"].strip().casefold() for q in qs}) != 4:
                    continue
                key = prior.sha("134:" + ":".join(q["id"] for q in qs) + ":" + candidate)
                eligible.append((key, pi, context, candidate, qs))
        if eligible:
            articles.append((prior.sha("134:" + article["title"]), article["title"], min(eligible)))
    return [
        {
            "id": title,
            "stage": "134",
            "paragraph_index": pi,
            "context": context,
            "candidate": candidate,
            "questions": qs,
        }
        for _, title, (_, pi, context, candidate, qs) in sorted(articles)[:4]
    ]


KEYS = ["first_value", "second_value"]
STATES = list(itertools.product((False, True), repeat=2))
ROLE = {
    "judgment": 'The boolean "first_value" judges "first_question": true means supported and false means unsupported.',
    "metadata": 'The boolean "first_value" is an arbitrary metadata bit. It has no meaning about the passage or either question. Either true or false is permitted; do not judge "first_question".',
}
SECOND = 'The boolean "second_value" judges "second_question": true means supported and false means unsupported.'


def jobs(block):
    result = [
        {"kind": kind, "query": q, "clamp": clamp}
        for q, kind, clamp in itertools.product(serial.queries(block), ROLE, (False, True))
    ]
    result += [{"kind": "isolated", "query": q} for q in serial.queries(block)]
    if block["stage"] == "133":
        result += [
            {"kind": "anchor", "query": q, "clamp": clamp}
            for q, clamp in itertools.product(serial.queries(block), (False, True))
        ]
    if block.get("given_controls"):
        result += [
            {"kind": "given_" + kind, "status": status, "clamp": clamp}
            for kind, status, clamp in itertools.product(ROLE, (False, True), (False, True))
        ]
    return sorted(result, key=core.digest)


def messages(block, job):
    kind = job["kind"]
    if kind == "anchor":
        return codebook.messages(
            block, {"kind": "main", "book": "00", "query": job["query"], "clamp": job["clamp"]}
        )
    schema = (
        'Return only a JSON object with a boolean value for key "second_value".'
        if kind == "isolated"
        else 'Return only a JSON object with boolean values for keys "first_value" and "second_value".'
    )
    if kind.startswith("given_"):
        role = kind.removeprefix("given_")
        system = (
            "The support status of second_question is already given. Do not reassess it. "
            + schema
            + " "
            + ROLE[role]
            + " "
            + SECOND
        )
        content = {
            "first_question_is_supported": False,
            "second_question_is_supported": job["status"],
        }
    else:
        system = prior.JOINT_RULE.split("Return only")[0] + schema + " "
        if kind != "isolated":
            system += ROLE[kind] + " "
        system += SECOND
        byid = {q["id"]: q["question"] for q in block["questions"]}
        content = {"passage": block["context"], "proposed_answer": block["candidate"]}
        if kind != "isolated":
            content["first_question"] = byid[job["query"]["question_ids"][0]]
        content["second_question"] = byid[job["query"]["question_ids"][1]]
    return [
        {"role": "system", "content": system},
        {"role": "user", "content": json.dumps(content, ensure_ascii=False)},
    ]


def candidates(job):
    if job["kind"] == "anchor":
        return codebook.candidates({"kind": "main", "clamp": job["clamp"]})
    if job["kind"] == "isolated":
        return [(json.dumps({"second_value": v}), [v]) for v in (False, True)]
    return [
        (json.dumps(dict(zip(KEYS, state))), list(state))
        for state in STATES
        if state[0] is job["clamp"]
    ]


def parse(raw, kind):
    if kind == "anchor":
        return codebook.parse(raw, "main")
    keys = ["second_value"] if kind == "isolated" else KEYS

    def unique(pairs):
        if len(pairs) != len(dict(pairs)):
            raise ValueError("Duplicate keys")
        return dict(pairs)

    try:
        obj = json.loads(raw, object_pairs_hook=unique)
        if (
            type(obj) is not dict
            or set(obj) != set(keys)
            or any(type(v) is not bool for v in obj.values())
        ):
            return False, None
        return True, [obj[k] for k in keys]
    except (ValueError, TypeError):
        return False, None


def source_hash():
    return core.digest(
        {
            "runner": Path(__file__).read_text(),
            "protocol": (ROOT / "docs/experiments/133-134-verdict-metadata.md").read_text(),
            "dependencies": codebook.source_hash(),
        }
    )


def prepare(run):
    blocks = [
        {**b, "stage": "133", "given_controls": i == 0}
        for i, b in enumerate(codebook.fresh_blocks()[:2])
    ] + fresh_blocks()
    path = run / "design.json"
    if path.exists():
        b = json.loads(path.read_text())
        assert (
            core.digest(b["design"]) == b["fingerprint"]
            and b["design"]["source_hash"] == source_hash()
        )
        assert b["design"]["blocks"] == blocks
        return b
    d = {
        "created_utc": now(),
        "source_hash": source_hash(),
        "data_hash": prior.DATA_HASH,
        "models": MODELS,
        "blocks": blocks,
        "clamps": [False, True],
        "roles": ROLE,
        "max_new_tokens": 80,
        "max_prompt_tokens": 2048,
        "dominance_minimum": 0.75,
        "main_target": "judgment-specific versus metadata prefix contrast",
        "invariance_minimum": 0.75,
        "encoding_minimum": 1.0,
    }
    b = {"design": d, "fingerprint": core.digest(d)}
    core.write_json(path, b)
    return b


def records(run, name, bundle):
    rt = run / name / "runtime.json"
    rh = core.digest(json.loads(rt.read_text())) if rt.exists() else None
    expected = {(b["id"], core.digest(job)) for b in bundle["design"]["blocks"] for job in jobs(b)}
    got = {}
    for path in (run / name / "records").glob("*.json"):
        e = json.loads(path.read_text())
        r = e["record"]
        key = (r["block"], core.digest(r["job"]))
        assert key in expected and key not in got and core.digest(r) == e["sha256"]
        assert r["fingerprint"] == bundle["fingerprint"] and r["runtime_hash"] == rh
        got[key] = r
    return got


def run_model(run, name, bundle, status):
    saved = records(run, name, bundle)
    blocks = bundle["design"]["blocks"]
    total = sum(len(jobs(b)) for b in blocks)
    if len(saved) == total:
        return
    model, tok, device = load_target(MODELS[name], "mps", offline=True)
    rt = {
        "model": MODELS[name],
        "device": device,
        "dtype": str(next(model.parameters()).dtype),
        "training": model.training,
        "python": platform.python_version(),
        "torch": torch.__version__,
        "transformers": transformers.__version__,
        "penalty": 1.0,
        "tokenizer_hash": core.digest(tok.get_vocab()),
        "config_hash": core.digest(model.config.to_dict()),
        "chat_template": tok.chat_template,
    }
    assert rt == json.loads((prior.DEFAULT / name / "runtime.json").read_text())
    path = run / name / "runtime.json"
    if path.exists():
        assert json.loads(path.read_text()) == rt
    core.write_json(path, rt)
    for block in blocks:
        for job in jobs(block):
            key = (block["id"], core.digest(job))
            if key in saved:
                continue
            msg = messages(block, job)
            prefix = tok.apply_chat_template(msg, tokenize=True, add_generation_prompt=True)
            assert len(prefix) <= 2048
            choices = candidates(job)
            sequences = core.token_sequences(tok, choices)
            assert len(sequences) == 2 and len(sequences[0]) == len(sequences[1])
            assert sum(a != b for a, b in zip(*sequences)) == 1
            ids, raw = core.generate(model, tok, prefix, 1.0, 80, sequences=sequences)
            assert ids in sequences
            valid, pred = parse(raw, job["kind"])
            assert valid
            o = {
                "messages": msg,
                "prompt_ids": prefix,
                "ids": ids,
                "raw": raw,
                "prediction": pred,
                "second_supported": pred[-1],
                "valid": valid,
                "choices": choices,
                "sequences": sequences,
            }
            r = {
                "block": block["id"],
                "stage": block["stage"],
                "job": job,
                "output": o,
                "fingerprint": bundle["fingerprint"],
                "runtime_hash": core.digest(rt),
            }
            core.write_json(
                run / name / "records" / f"{core.digest(key)}.json",
                {"record": r, "sha256": core.digest(r)},
            )
            saved[key] = r
            status.update(
                model=name, stage=block["stage"], completed_queries=len(saved), updated_utc=now()
            )
            core.write_json(run / "pipeline-status.json", status)
            print(f"{name} {block['stage']} {len(saved)}/{total}", flush=True)
    del model, tok
    gc.collect()
    torch.mps.empty_cache()


def launch(run):
    with core.exclusive_lock(run / ".launch.lock"):
        b = prepare(run)
        path = run / "launch.json"
        if path.exists():
            try:
                os.kill(json.loads(path.read_text())["pid"], 0)
            except ProcessLookupError:
                pass
            else:
                raise RuntimeError("Already running")
        with (run / "pipeline.log").open("a") as log:
            p = subprocess.Popen(
                [
                    "/usr/bin/caffeinate",
                    "-i",
                    sys.executable,
                    "-u",
                    str(Path(__file__).resolve()),
                    "--run",
                    str(run.resolve()),
                ],
                cwd=ROOT,
                env={**os.environ, "PYTHONPATH": str(ROOT / "src")},
                stdin=subprocess.DEVNULL,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
        receipt = {"pid": p.pid, "fingerprint": b["fingerprint"], "launched_utc": now()}
        core.write_json(path, receipt)
        return receipt


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--run", type=Path, default=DEFAULT)
    p.add_argument("--prepare", action="store_true")
    p.add_argument("--launch", action="store_true")
    args = p.parse_args()
    if args.prepare:
        print(prepare(args.run)["fingerprint"])
        return
    if args.launch:
        print(json.dumps(launch(args.run)))
        return
    with core.exclusive_lock(args.run / ".pipeline.lock"):
        b = prepare(args.run)
        status = {"status": "running", "started_utc": now(), "fingerprint": b["fingerprint"]}
        try:
            for name in MODELS:
                run_model(args.run, name, b, status)
            status.update(status="complete", updated_utc=now())
        except BaseException as exc:
            status.update(status="technical_failure", error=repr(exc), updated_utc=now())
            core.write_json(args.run / "pipeline-status.json", status)
            raise
        core.write_json(args.run / "pipeline-status.json", status)
        print("Complete", flush=True)


if __name__ == "__main__":
    main()
