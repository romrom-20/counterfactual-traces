"""Use actually computed oracle tails to separate a reset's effect from remaining error.

This is not the invalid subtraction of error norms. Both forecast vectors were
computed by the model. The vector identity itself is algebraic, not an extra
derivative validation or a unique mechanistic decomposition.
"""

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--scope", choices=["sample", "full"], required=True)
    scope = parser.parse_args().scope
    out = ROOT / f"docs/analysis/205-{scope}-measured-reset-separation.json"
    assert not out.exists()
    audit_path = ROOT / f"docs/analysis/204-{scope}-oracle-vector-audit.json"
    audit = json.loads(audit_path.read_text())
    assert audit["reset_qualified"]
    run = ROOT / f"runs/genuine-oracle-continuation-204-{scope}"
    rows, maximum = [], 0.0
    for p in sorted((run / "pairs").glob("*.json")):
        record = json.loads(p.read_text())
        with np.load(p.with_suffix(".npz"), allow_pickle=False) as z:
            actual = z["native_delta_suffix"].astype(np.float64)
            for arm in ("source_linear", "union_blocks"):
                ordinary = z[f"ordinary_{arm}_delta_suffix"].astype(np.float64)
                for k in [1, 3, 8, 11, 16, 21, 27]:
                    b = k - 1
                    reset = z[f"before{k}_{arm}_delta_suffix"].astype(np.float64)
                    error_original = actual[-1] - ordinary[-1]
                    error_reset = actual[-1] - reset[-1]
                    effect = reset[-1] - ordinary[-1]
                    discrepancy = float(np.max(abs(error_original - error_reset - effect)))
                    maximum = max(maximum, discrepancy)
                    entries = {}
                    for label, sl in [
                        ("full", slice(None)),
                        ("source", slice(0, 1)),
                        ("receivers", slice(1, None)),
                        ("verdict", slice(-1, None)),
                    ]:
                        e, r, t = [v[sl].ravel() for v in (error_original, error_reset, effect)]
                        norm = np.linalg.norm(e)
                        entries[label] = dict(
                            original_error_norm=float(norm),
                            remaining_reset_error_norm=float(np.linalg.norm(r)),
                            reset_effect_norm=float(np.linalg.norm(t)),
                            signed_remaining_error_projection=float(np.dot(r, e) / norm)
                            if norm
                            else None,
                            signed_reset_effect_projection=float(np.dot(t, e) / norm)
                            if norm
                            else None,
                            remaining_effect_dot=float(np.dot(r, t)),
                        )
                    first_fail = {}
                    for label, position in [("source", 0), ("verdict", -1)]:
                        a = actual[b:, position]
                        pred = reset[:, position]
                        norms = np.linalg.norm(a, axis=1)
                        q = np.divide(
                            np.linalg.norm(a - pred, axis=1),
                            norms,
                            out=np.zeros_like(norms),
                            where=norms > 0,
                        )
                        failures = np.flatnonzero(q > 0.05)
                        first_fail[label] = int(b + failures[0]) if len(failures) else None
                    rows.append(
                        dict(
                            key=record["key"],
                            **record["group"],
                            arm=arm,
                            next_block=k,
                            completed_blocks=b,
                            components=entries,
                            first_completed_block_over_05=first_fail,
                            maximum_vector_identity_error=discrepancy,
                        )
                    )
    assert maximum <= 1e-4
    summary = []
    for arm in ("source_linear", "union_blocks"):
        for k in [1, 3, 8, 11, 16, 21, 27]:
            rs = [r for r in rows if r["arm"] == arm and r["next_block"] == k]
            summary.append(
                dict(
                    arm=arm,
                    next_block=k,
                    count=len(rs),
                    median_remaining_error_norm=float(
                        np.median(
                            [r["components"]["verdict"]["remaining_reset_error_norm"] for r in rs]
                        )
                    ),
                    median_signed_reset_effect=float(
                        np.median(
                            [
                                r["components"]["verdict"]["signed_reset_effect_projection"]
                                for r in rs
                            ]
                        )
                    ),
                    median_signed_remaining_error=float(
                        np.median(
                            [
                                r["components"]["verdict"]["signed_remaining_error_projection"]
                                for r in rs
                            ]
                        )
                    ),
                    reset_increases_error_count=sum(
                        r["components"]["verdict"]["remaining_reset_error_norm"]
                        > r["components"]["verdict"]["original_error_norm"]
                        for r in rs
                    ),
                    immediate_source_failure_count=sum(
                        r["first_completed_block_over_05"]["source"] == k for r in rs
                    ),
                    immediate_verdict_failure_count=sum(
                        r["first_completed_block_over_05"]["verdict"] == k for r in rs
                    ),
                )
            )
    result = dict(
        scope=scope,
        qualified_measured_vector_account=True,
        maximum_identity_error=maximum,
        summary=summary,
        rows=rows,
        parent_audit_sha256=hashlib.sha256(audit_path.read_bytes()).hexdigest(),
        source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        definitions={
            "Eordinary": "native final delta minus ACTUALLY computed ordinary forecast",
            "Ereset": "native final delta minus ACTUALLY computed reset forecast",
            "reset_effect": "computed reset forecast minus computed ordinary forecast",
            "identity": "Eordinary = Ereset + reset_effect (signed vectors, not norms)",
            "projection": "dot(component,Eordinary)/norm(Eordinary), hidden units; medians need not add",
            "full": "full sequence represented by nonzero causal suffix with verifiedzero prefix",
        },
        limits="An algebraic account of a genuinely executed intervention. source_linear tail is the tested False-linear surrogate; union reset effect includes state-dependent changes to finite blocks. Not unique cause, additive L2fractions, direct J(error) qualification,196resolution, prospective prediction or solvedQuestionB.",
    )
    out.write_text(json.dumps(result, indent=2))
    print(json.dumps({k: v for k, v in result.items() if k != "rows"}, indent=2))


if __name__ == "__main__":
    main()
