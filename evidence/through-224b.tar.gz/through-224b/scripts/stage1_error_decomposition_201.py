"""Stage 1: Blockwise error decomposition for 201 (ZcP5D1)."""
import numpy as np, json
from pathlib import Path

F = np.load('runs/discovery-ranked-repair-201/forecasts/05eb1ec65ed02c71d8997ecd3c3a58f5d2c70ccbe004b28b7dd9f8b14e93502c.npz', allow_pickle=True)
O = np.load('runs/discovery-ranked-repair-201/observations/05eb1ec65ed02c71d8997ecd3c3a58f5d2c70ccbe004b28b7dd9f8b14e93502c.npz', allow_pickle=True)
false = F['false_rows']; true = O['true_rows']
e = true - false
results = []
for b in range(1, 28):
    e_b = e[b-1]
    e_next = e[b]
    false_step = false[b] - false[b-1]
    proj_scale = np.sum(e_b * false_step, axis=1, keepdims=True) / (np.sum(false_step**2, axis=1, keepdims=True)+1e-6)
    J_e_approx = proj_scale * false_step
    local_disc = e_next - J_e_approx
    results.append({
        "from_block": b, "to_block": b+1,
        "norm_e_b": float(np.mean(np.linalg.norm(e_b, axis=1))),
        "norm_e_next": float(np.mean(np.linalg.norm(e_next, axis=1))),
        "norm_J_e_approx": float(np.mean(np.linalg.norm(J_e_approx, axis=1))),
        "norm_local_disc": float(np.mean(np.linalg.norm(local_disc, axis=1))),
        "reconstruction_err": float(np.mean(np.linalg.norm(e_next - J_e_approx, axis=1))),
    })
print("=== STAGE 1: BLOCKWISE ERROR DECOMPOSITION (approx, 201 traces) ===")
for r in results[:6]:
    print(f"{r['from_block']:2d}->{r['to_block']:2d} | e_b={r['norm_e_b']:6.1f} e_next={r['norm_e_next']:6.1f} | J_e_approx={r['norm_J_e_approx']:6.1f} | local_disc={r['norm_local_disc']:6.1f} | recon={r['reconstruction_err']:6.1f}")
with open('.context/stage1_decomposition.json','w') as f:
    json.dump({"note":"Approximate J via false-step projection; provisional; not genuine model JVP.","results":results}, f, indent=2)
print("Saved .context/stage1_decomposition.json")
