"""Stage 2: Genuine oracle-state reset framework (ZcP5D1). Provisional — requires model forward pipeline."""
import numpy as np, json, torch, sys
from pathlib import Path
sys.path.insert(0,'src')

# Load 201 native/predicted arrays
F = np.load('runs/discovery-ranked-repair-201/forecasts/05eb1ec65ed02c71d8997ecd3c3a58f5d2c70ccbe004b28b7dd9f8b14e93502c.npz', allow_pickle=True)
O = np.load('runs/discovery-ranked-repair-201/observations/05eb1ec65ed02c71d8997ecd3c3a58f5d2c70ccbe004b28b7dd9f8b14e93502c.npz', allow_pickle=True)
false = F['false_rows']; true = O['true_rows']

# Reset depths per file
resets = [1,3,8,11,16,21,27]
status = {}

# Sanity-check framework (not executed without full model pipeline)
print("=== STAGE 2 FRAMEWORK ===")
print("Reset depths:", resets)
print("Required: load Qwen 1.5B MPS/eager, inject native state at k, resume hybrid predictors.")
print("Current workspace has .venv and src/; model checkpoint offline per manifest.")

# Try importing if available
try:
    from transformers import AutoModelForCausalLM, AutoTokenizer
    print("transformers import OK")
except Exception as e:
    print("transformers import failed:", e)

# Document what's missing for genuine reset
status = {
    "stage": 2,
    "provisional": True,
    "implemented": "framework + sanity-check specification only",
    "missing": [
        "Full causal-prefix embedding state at each block (only 1536-dim row arrays saved, not full hidden-state caches with RoPE/mask)",
        "Hybrid hook construction with native intermediate substitution (needs forward-AD backend + selected block replacements)",
        "Sanity checks: (a) error=0 at reset boundary, (b) predicted-reset reproduces ordinary forecast, (c) native-reset reproduces native final"
    ],
    "note": "Saved arrays alone insufficient; genuine continuation needs model execution. Previous proxy arithmetic invalidated per audit."
}
Path('.context/stage2_reset_framework.json').write_text(json.dumps(status, indent=2))
print("Saved .context/stage2_reset_framework.json")
