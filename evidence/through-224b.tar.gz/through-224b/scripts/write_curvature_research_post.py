"""Focused local post generated from qualified findings, with predictive boundaries intact."""

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def main():
    audits = {}
    for stage in (189, 190, 191, 193):
        a = json.loads((ROOT / f"docs/analysis/{stage}-independent-audit.json").read_text())
        n = json.loads((ROOT / f"docs/analysis/{stage}-numerical-recheck.json").read_text())
        assert a["numerical_qualified"] and all(a["controls"].values()) and n["passed"]
        audits[stage] = a
    b = audits[191]
    latest = json.loads((ROOT / "docs/analysis/194-independent-audit.json").read_text())
    ln = json.loads((ROOT / "docs/analysis/194-numerical-recheck.json").read_text())
    assert latest["numerical_qualified"] and all(latest["controls"].values()) and ln["passed"]
    native = audits[193]
    individual = max(abs(c["errors"]["C3"]) for c in b["cells"])
    balanced = max(abs(p["balanced_true_errors"]["C3"]) for p in b["panels"])
    native_lines = []
    for order in (1,):
        rows = [c for c in native["cells"] if (c["dose"], c["order"]) == (1.0, order)]
        accounts = native["accounts"]
        m = accounts[f"dose1.0_order{order}_individual_matching"]
        r = accounts[f"dose1.0_order{order}_residual_matching"]
        native_lines.append(
            f"Order {order} matches individual Boolean responses in **{m['compatible_panels']}/16 panels** (whole {'PASS' if m['whole_passed'] else 'FAIL'}), and residual displacements in **{r['compatible_panels']}/16** (whole {'PASS' if r['whole_passed'] else 'FAIL'}). Its maximum margin error is **{max(abs(c['margin_error']) for c in rows):.3f} nats**; maximum relative displacement error is **{max(c['last_relative_error'] for c in rows):.3f}**."
        )
    post = f"""# From an irrelevant Boolean to a counterfactual residual response

An explicitly irrelevant Boolean in an output prefix changes a later verdict's preference. The interesting question is whether we can predict the change from one observed computation, and explain which nonlinear operations generate and transmit the residual displacement.

This is a local research milestone. We have a controlled intervention account, a narrowly successful false-calibrated approximation, and a stricter native-response test. We have not identified a compact learned circuit or explained its training origin. General metadata influence is established; priority for this measurement/intervention package is not established.

## The setting

The model reads two facts about exhibit opening days and judges whether a proposed answer is supported by the passage. We request two Boolean fields. The first is explicitly arbitrary metadata; the second is the verdict. Generic field names (`first_value`, `second_value`) and descriptive names vary the schema while preserving the relation task.

We supply matched completion prefixes differing only in the first Boolean token, then score the later `true` versus `false` verdict. The earlier Boolean is forced for this comparison. “Native” below means the unmodified network on each supplied prefix; it does not mean the model spontaneously generated either metadata value. A score margin is logit(true)-logit(false), in nats. A preference change can occur while the decoded verdict stays unchanged.

Each experiment crosses four day/source blocks, two schemas, two sentence orders, both assignments and both questions: 64 paired contexts, grouped into 16 panels of four relation cells. A panel only passes when all its cells meet the stated bound. A whole account requires at least three of four sources in **every** schema/order stratum. These synthetic templates are dependent; this is not broad task prevalence.

## A common correction can change Boolean sensitivity

At each receiving MLP, write the paired natural SiLU inputs as `c-h` and `c+h`. The tangent at `c` omits the shared curvature remainder

`C = (phi(c-h)+phi(c+h))/2 - phi(c)`.

Adding this same C to both states nearly repairs the tangent's large shared preference error in earlier experiments. But C uses both native activation trajectories. It is a diagnostic finite difference, not a discovered endogenous signal and not a prediction from one state.

The gated MLP writes `D[gate * up]`. At a fixed gate input, adding C changes its residual write by `D[C * up]`. If up varies with the bit, this common offset changes the receiver's sensitivity. That architectural identity gives one transmission route; it does not prove that route is the whole mechanism.

Experiment189 exposed its boundary. Holding up fixed nearly removes the effect in many contexts. Holding both up and every RMS factor fixed instead produces a substantial **positive** response, against the **negative** response with these factors live. Fixing attention matrices as well gives the expected affine null. The same correction can therefore have different consequences in different receiver systems. W fixes attention weights, not all attention output or value vectors.

Every registered whole scientific account in189 failed. The positive response under NU was an unregistered observation there, so we tested it on new contexts rather than treating the plot as confirmation.

![Full operation factorial](../analysis/figures/189-norm-feedback-cuts.png)

Here kappa is C's change to the false-to-true verdict-margin response: `(M_true^even-M_false^even)-(M_true^paired-M_false^paired)`. Each comparison uses the **same cut's baseline**. N=all RMS factors, W=attention matrices, U=up outputs. The live/NW/NWU points in189 are validated parent references, not new executions.

## Final-readout geometry does not explain the whole effect

N includes 56 internal RMS factors and the final RMS factor. Experiment190 separated them with up fixed: U alone; FU with only the final factor fixed; IU with only internal factors fixed; NU with both fixed. Attention remained live.

The negative live versus positive NU reversal passes in **16/16 panels**, including all schema/order strata on four new blocks. But a final-only explanation matches **0/16**, and an internal-only explanation also matches **0/16**, under the frozen 0.10-nat rule. Up alone suppresses the effect precisely in only **7/16**. The simple universal up-bottleneck account fails.

FU and U have identical full residuals at block28; so do NU and IU. The final factor can alter the readout but cannot generate an earlier displacement. Changing internal normalization, however, changes the trajectory's magnitude and direction with exactly the same local sources held fixed.

The internal/final interaction contrast `kappa_NU-kappa_IU-kappa_FU+kappa_U` is positive in every measured cell: **0.427–1.141 nats** for generic schemas and **2.157–6.092** for descriptive schemas. This is descriptive interaction between altered systems, not a unique attribution to native pathways.

The conditional relationship matters. Fixing the final factor changes little while internal normalization is live. After the internal cut, final normalization has a much larger effect. The joint response needs both the changed upstream residual and its conversion into a verdict preference.

Projection/scale cancellation is ordinary geometry of one normalization operation. It is not evidence of two competing learned mechanisms. Saved-state arithmetic reconstructs the public scores and actual final-only counterfactuals within **7.21e-6 nats**. That checks the readout calculation; it does not explain generation of the upstream residual.

![Fresh final versus internal normalization split](../analysis/figures/190-norm-feedback-cuts.png)

## Where the displacement begins

With up fixed, the literal local correction write is `S_l = D_l(C_l * meanUP_l)`, common to both bits. Read-only traces cover every attention/MLP/block residual at all 28 receiving layers.

At block1, the correction-induced residual write agrees with that local source to **1.16e-5 per coordinate**; its bit difference is at most **1.53e-5**, consistent with subtraction/rounding. At block2 the final-position differential norm is already at least **0.00216 residual units** in every measured context. Later blocks amplify and reorient it. This is the point where a bit-common write becomes a state-dependent response.

In IU, internal RMS operations and the receiving MLP maps are affine. Attention-weight computation remains nonlinear. The two states can therefore transport the same write differently. We have measured that transport; we have not prospectively predicted it from a small set of components. Simultaneous source writes need not add linearly with live routing.

![Layerwise residual displacement](../analysis/figures/190-residual-generation-atlas.png)

## Curvature coefficients from one native state

Experiment191 removes the paired calibration at SiLU. At the native false input xF, fix analytic first, second and third derivatives of SiLU. Replace receiving SiLU by the corresponding Taylor polynomial, anchored exactly to the false output. All 448 false measurements/mapped forecasts were sealed before any native true measurement on four new blocks.

The first-order map precisely predicts the balanced evidence response in **3/16 panels**. The quadratic map reaches **14/16**, failing the whole criterion. The cubic map reaches **16/16**, with worst evidence error **{balanced:.6f} nats** against the predeclared 0.10 bound. Individual preference matching remains **0/16** for all three orders; cubic individual error reaches **{individual:.3f} nats**. Balancing cancels part of the common error—it does not make every preference correct.

This is useful but narrow. Coefficients come only from false; the counterfactual receiving inputs, up branch, attention and normalization remain live. It is not a forecast of the whole native displacement from one static observed trajectory. Higher polynomial order has no guaranteed global convergence.

![False-state SiLU curvature forecasts](../analysis/figures/191-false-state-curvature-errors.png)

## The strict test: predict the native Boolean flip

Our primary question is broader: can a transformer's native counterfactual behavioral response be predicted from one observed computation by identifying the nonlinear source and transport of its residual displacement?

Experiment193 supplies a baseline that meets the information constraint. The known change is the true-minus-false embedding at the single Boolean position. For the full native network F, compute the first directional derivative **only at the false input**. Forecast `F(0)+F'(0)`, including every residual layer and the public verdict logits. RMS, attention, SiLU, branch multiplication and their composition all participate. No true-state trajectory is used while predicting.

All 64 false readouts and 64 differentiated false invocations were saved before any target observation. The native target uses actual true input IDs. Smaller, predeclared embedding changes at 1/8, 1/4 and 1/2 are diagnostic: they distinguish local accuracy from finite-Boolean accuracy, but cannot rescue native failures.

{chr(10).join(native_lines)}

The residual criterion is at most 5% final-position displacement error and at least 0.99 cosine; the margin criterion is 0.10 nats. Both accuracy criteria must hold in every cell and enough sources in every stratum. Evidence balancing is secondary. All outcomes are retained, including small-dose results and layerwise prediction errors.

At one-eighth dose, the first-order score error meets the absolute 0.10-nat bound in16/16panels, but residual matching fails in0/16. This is small-dose diagnostic accuracy under an absolute bound, not success on the finite native Boolean flip.

![Strict single-state native predictions](../analysis/figures/193-single-state-native-forecast.png)

The saved trajectories locate an earlier boundary. At the changed Boolean token itself, first-block displacement error is70.2–71.5% across all64contexts. At the verdict position, first-block error is104.8–105.5%. Thus the failed native forecast is already wrong before deep-layer transport. The cubic receiving-SiLU experiment leaves the Boolean source encoder native, including its true-state nonlinear computation; it cannot establish that we predicted generation of this source displacement from false alone. This is a post-observation error-location diagnostic, not a causal attribution to one first-layer operation.

The attempted second-order version in192 failed numerical qualification: forward-AD and reverse-AD margin curvature contractions differed by up to **0.1402**. We preserved that failure and ran first-order-only193 on fresh prompts with the original derivative bounds. Its verified first-order forecasts are shown here; the second-order numbers are not scientific evidence.

This is a white-box directional-derivative baseline, not yet identification of a compact causal mechanism. The primary question remains open at the level of a general, mechanistically identified counterfactual predictor. A failure of a finite Taylor truncation would not prove the question impossible; a success on these templates would not settle it generally.

## Approximate the Boolean source as well as the receiver

Experiment194 keeps finite normalization,attention and multiplying branches, and builds an executable SiLU surrogate from the single false trajectory. We compare three cubic scopes: the Boolean source alone, later receiving positions alone, and both. First/quadratic approximations of both positions are also declared in advance. All704forecasts/False calls precede every nativeTrue observation on four new blocks.

This allows counterfactual component evaluation at predicted inputs. It is a larger computation budget than193's derivative-only forecast; it is not a compact mechanism or a predictor that avoids a mapped counterfactual forward pass.

The receiver-only cubic approximation preserves the secondary evidence response in14/16panels and passes the whole rule (at least3/4sources in every stratum). Source-only cubic reaches8/16—all descriptive—and source-plus-receiver cubic reaches7/16—all descriptive. Both whole accounts fail. Allfive arms fail both PRIMARY individual-preference and residual matching accounts:0/16panels each.

Thus a receiving approximation can preserve an evidence contrast while its counterpart at the Boolean source destroys generic-schema precision. That is a useful source/receiver boundary for this approximation. It does not identify a unique learned circuit or solve the native generator. The primary Question B remains open.

![Source and receiver curvature forecasts](../analysis/figures/194-source-receiver-curvature.png)

## Reproduction and limits

Experiments189–191 contain **3,584 main and 448 separate numerical ordinary forwards**. Experiment193 adds **320 ordinary and 64 differentiated main invocations**, plus **16 ordinary and 8 reverse-differentiated numerical invocations**. The preserved, numerically unqualified192attempt separately executed320ordinary+64differentiated main and16ordinary+8reverse-differentiated numerical invocations.192used two forward-AD levels;193uses one. Derivative invocations have different costs and are separately counted. Two engineering preflights add two ordinary false and two differentiated false invocations. A reporting-only source-hash error in the first preflight is preserved with its separate correction. Experiment194adds768main+96separate numerical ordinary forwards; everyselected score/full28state trajectory replays exactly and all11artifact controls pass. No thresholds were relaxed.

Selected189–191 numerical public scores and full residuals replay exactly.193 is checked separately by native readouts and reverse-AD contractions of the margin and two trajectory projections; those checks do not establish equality of every derivative coordinate.190 also contains 1,792 component down-projection evaluations and224 separate component matrix reconstructions, counted separately from model forwards. The saved-state atlas/readout analyses perform no additional model calls.

The [reproduction bundle](../../results/norm-curvature-189-194/README.md) includes immutable source/protocol dependencies, historical prerequisite provenance, audited endpoints, figures, environment versions, and clean-checkout commands. Raw multi-gigabyte activations and checkpoint weights are not in Git; reruns regenerate states locally. The default rerun190–194 uses an explicitly historical189 qualification seed; a longer mode reruns186–194 from the185 prerequisite. Neither seed is represented as fresh verification of its earlier experiments.

This continuation uses one pinned Qwen2.5-1.5B-Instruct checkpoint and dependent synthetic templates. Dense interventions change the baseline. Earlier competence and specificity failures remain: this is not a demonstration that a reliably grounded verifier can be disabled. There is no independent team, training-origin explanation, universal model claim or novelty-priority claim. Supplied literature claims were not independently verified in this continuation; no browser or literature search was used. Developed with an AI coding assistant.

The most useful progress is the separation of three questions: how a constructed shared correction acts, which local curvature approximations preserve an evidence contrast, and whether one native state predicts the whole counterfactual displacement. Those questions now have different tests and explicit failure boundaries.
"""
    (ROOT / "docs/drafts/lesswrong-shared-curvature-normalization.md").write_text(post)
    print("Wrote focused local LessWrong research draft from qualified results.")


if __name__ == "__main__":
    main()
