"""096: separate evidence sufficiency from sentiment, with a two-query control."""

import argparse
import json
import platform
import time
from datetime import datetime, timezone
from pathlib import Path

import torch
import transformers

from . import evidence_policy as score
from .source_binding import MODELS
from .target import load_target

ROOT = Path(__file__).resolve().parents[2]
STATES = ("empty", "fact", "irrelevant", "neutral", "positive", "negative")
ARMS = ("direct", "evidence", "polarity", "review")
RULE = (
    "Judge the author's expressed opinion about the target aspect using only the review. "
    "Praise gives 9.0, criticism gives 1.0, and an explicitly neutral opinion gives 5.0. "
    "A factual mention without an expressed opinion is insufficient evidence. "
    "An opinion about another aspect is also insufficient. "
    "Insufficient evidence must give null, never a neutral rating."
)
BLOCKS = {
    "development": [
        ("battery", "screen", "The battery appears in the component list."),
        ("keyboard", "trackpad", "The keyboard has its own section in the manual."),
        ("screen", "battery", "The screen is identified by a model number."),
        ("trackpad", "keyboard", "The trackpad is shown in the diagram."),
    ],
    "confirmation": [
        ("service", "food", "The receipt has a line labeled service."),
        ("food", "service", "The menu lists the food by category."),
        ("room", "location", "The room is identified by a number."),
        ("location", "room", "The booking confirmation includes the location."),
        ("breakfast", "staff", "Breakfast is mentioned in the information booklet."),
        ("staff", "breakfast", "The brochure includes a section about the staff."),
        ("delivery", "packaging", "The order page lists the delivery date."),
        ("packaging", "delivery", "The packaging carries a printed code."),
    ],
}


def code_hash():
    paths = [Path(__file__), ROOT / "src/latent_decisions/evidence_policy.py",
             ROOT / "src/latent_decisions/source_binding.py", ROOT / "src/latent_decisions/target.py",
             ROOT / "scripts/run_evidence_gate_096.py", ROOT / "docs/experiments/096-evidence-gate.md"]
    return score.digest({str(p.relative_to(ROOT)): p.read_text() for p in paths})


def dataset():
    rows = []
    for split, blocks in BLOCKS.items():
        for index, (aspect, other, fact) in enumerate(blocks):
            texts = {
                "empty": "[No review supplied]", "fact": fact,
                "irrelevant": f"I was delighted with the {other}. {fact}",
                "neutral": f"I found the {aspect} neither good nor bad.",
                "positive": f"I liked the {aspect} and thought it was excellent.",
                "negative": f"I disliked the {aspect} and thought it was awful.",
            }
            if split == "confirmation":
                texts.update(
                    neutral=f"My assessment of the {aspect} is neutral: neither positive nor negative.",
                    positive=f"I was pleased with the {aspect} and would happily choose it again.",
                    negative=f"I was disappointed with the {aspect} and would avoid it in the future.",
                    irrelevant=f"I was pleased with the {other}. {fact}",
                )
            for state in STATES:
                rows.append({"id": f"{split}-{index}-{state}", "block": f"{split}-{index}",
                             "split": split, "aspect": aspect, "state": state,
                             "review": texts[state],
                             "gold": {"neutral": 5., "positive": 9., "negative": 1.}.get(state)})
    return rows


def choices(arm):
    if arm == "evidence":
        return [('{"evidence": false}', False), ('{"evidence": true}', True)]
    values = [1., 5., 9.] + ([] if arm == "polarity" else [None])
    return [(json.dumps({"rating": v}), v) for v in values]


def messages(row, arm, draft=None):
    request = "Return exactly one JSON object with key rating and value 1.0, 5.0, 9.0, or null."
    if arm == "evidence":
        request = (
            "Does the review express any opinion about the target? An explicitly neutral opinion "
            "counts as an opinion; a mere fact or opinion of another aspect does not. "
            'Return exactly {"evidence": true} or {"evidence": false}.'
        )
    elif arm == "polarity":
        request = (
            "Conditional on an opinion being expressed, classify its polarity. Return exactly one "
            "JSON object with key rating and value 1.0, 5.0, or 9.0."
        )
    elif arm == "review":
        request = (
            f"A first-pass draft was {json.dumps({'rating': draft})}. Independently check and correct "
            "that draft against the review and the rubric, including whether evidence is sufficient. "
            + request
        )
    return [{"role": "system", "content": RULE},
            {"role": "user", "content": f"Target aspect: {row['aspect']}\nReview: {row['review']}\n{request}"}]


def prepare(run):
    if (run / "design.json").exists():
        return load_design(run)
    design = {"experiment": "096-evidence-gate", "created_utc": datetime.now(timezone.utc).isoformat(),
              "rows": dataset(), "models": MODELS, "code_hash": code_hash(),
              "bootstrap_samples": 5000, "bootstrap_seed": 9601,
              "pilot_lift": .50, "confirmation_lift": .25, "supported_accuracy": .90,
              "max_supported_drop": .05, "specificity_margin": .25,
              "primary": "Fact/irrelevant abstention accuracy: factorized minus direct"}
    bundle = {"design": design, "fingerprint": score.digest(design)}
    score.write_json(run / "design.json", bundle)
    return bundle


def load_design(run):
    bundle = json.loads((run / "design.json").read_text())
    if score.digest(bundle["design"]) != bundle["fingerprint"]:
        raise ValueError("Frozen design hash mismatch")
    if code_hash() != bundle["design"]["code_hash"]:
        raise ValueError("Code/protocol changed; use a new run")
    return bundle


def read_records(run, model, split, bundle):
    expected = {row["id"] for row in bundle["design"]["rows"] if row["split"] == split}
    records = {}
    for path in (run / model / split / "records").glob("*.json"):
        envelope = json.loads(path.read_text())
        rec = envelope["record"]
        if score.digest(rec) != envelope["sha256"] or rec["fingerprint"] != bundle["fingerprint"]:
            raise ValueError("Record integrity failure")
        if rec["id"] not in expected or rec["id"] in records:
            raise ValueError("Unexpected/duplicate record")
        records[rec["id"]] = rec
    if records:
        runtime = json.loads((run / model / "runtime.json").read_text())
        if any(r["runtime_hash"] != score.digest(runtime) for r in records.values()):
            raise ValueError("Runtime mismatch")
    return records, expected


def mean(values):
    return sum(values) / len(values)


def analyze(run, model, split):
    bundle = load_design(run)
    records, expected = read_records(run, model, split, bundle)
    result = {"model": model, "split": split, "complete": len(records) == len(expected),
              "completed": len(records), "expected": len(expected), "continue": False,
              "fingerprint": bundle["fingerprint"],
              "records_digest": score.digest({k: score.digest(v) for k, v in sorted(records.items())})}
    if result["complete"]:
        rows = [r for r in bundle["design"]["rows"] if r["split"] == split]
        predictions = {}
        for row in rows:
            outputs = records[row["id"]]["outputs"]
            predictions[row["id"]] = {a: outputs[a]["value"] for a in ("direct", "review")}
            predictions[row["id"]]["factorized"] = (
                outputs["polarity"]["value"] if outputs["evidence"]["value"] else None)
        by_state = {}
        for method in ("direct", "factorized", "review"):
            by_state[method] = {state: mean([predictions[r["id"]][method] == r["gold"]
                                            for r in rows if r["state"] == state]) for state in STATES}
        primary, control_gap = [], []
        for block in sorted({r["block"] for r in rows}):
            subset = [r for r in rows if r["block"] == block and r["state"] in ("fact", "irrelevant")]
            accuracies = {method: mean([predictions[r["id"]][method] is None for r in subset])
                          for method in ("direct", "factorized", "review")}
            primary.append(accuracies["factorized"] - accuracies["direct"])
            control_gap.append(accuracies["factorized"] - accuracies["review"])
        config = bundle["design"]
        primary_result = score.bootstrap(primary, config)
        control_result = score.bootstrap(control_gap, config)
        supported = {method: mean([v[state] for state in ("negative", "neutral", "positive")])
                     for method, v in by_state.items()}
        strength = primary_result["estimate"] if split == "development" else primary_result["ci95"][0]
        threshold = config["pilot_lift"] if split == "development" else config["confirmation_lift"]
        result.update(primary=primary_result, factorized_minus_review=control_result,
                      accuracy_by_state=by_state, supported_accuracy=supported,
                      factorization_specific_advantage=control_result["ci95"][0] >= config["specificity_margin"])
        result["continue"] = bool(strength >= threshold and
                                  supported["factorized"] >= config["supported_accuracy"] and
                                  supported["factorized"] >= supported["direct"] - config["max_supported_drop"])
        result["decision"] = (
            "Evidence-first repair passes this stage; specificity against self-review is separate"
            if result["continue"] else "Stop: frozen repair or supported-opinion competence gate failed"
        )
    score.write_json(run / model / split / "analysis.json", result)
    return result


def run_split(run, name, split, device, limit=None):
    bundle = load_design(run)
    if split == "confirmation":
        dev = analyze(run, name, "development")
        if not dev["complete"] or not dev["continue"]:
            raise ValueError("Development gate failed")
        path = run / name / "confirmation-lock.json"
        lock = {"fingerprint": bundle["fingerprint"], "development_digest": dev["records_digest"]}
        if path.exists() and json.loads(path.read_text()) != lock:
            raise ValueError("Confirmation lock mismatch")
        score.write_json(path, lock)
    with score.exclusive_lock(run / ".inference.lock"):
        records, _ = read_records(run, name, split, bundle)
        pending = [r for r in bundle["design"]["rows"] if r["split"] == split and r["id"] not in records]
        if limit is not None:
            pending = pending[:limit]
        if not pending:
            return analyze(run, name, split)
        model, tokenizer, actual = load_target(MODELS[name], device, offline=True)
        runtime = {"model": MODELS[name], "device": actual, "dtype": "float32",
                   "python": platform.python_version(), "torch": torch.__version__,
                   "transformers": transformers.__version__, "repetition_penalty": 1.,
                   "model_config_hash": score.digest(model.config.to_dict()),
                   "tokenizer_hash": score.digest(tokenizer.get_vocab()), "chat_template": tokenizer.chat_template}
        path = run / name / "runtime.json"
        if path.exists() and json.loads(path.read_text()) != runtime:
            raise ValueError("Runtime changed")
        score.write_json(path, runtime)
        audited = set()
        for index, row in enumerate(pending):
            started = time.monotonic()
            outputs = {}
            for arm in ARMS:
                candidates = choices(arm)
                sequences = score.token_sequences(tokenizer, candidates)
                msg = messages(row, arm, outputs.get("direct", {}).get("value"))
                prefix = tokenizer.apply_chat_template(msg, tokenize=True, add_generation_prompt=True)
                if len(prefix) > 1024:
                    raise ValueError("Prompt token budget exceeded")
                result = score.score_candidates(model, prefix, sequences, {"unit": 1.}, 4)["unit"]
                audit = None
                if arm not in audited:
                    refs = [score.reference_logprob(model, prefix, s, 1.) for s in sequences]
                    err = max(abs(a - b) for a, b in zip(refs, result["sequence_logprobs"]))
                    ids, _ = score.generate(model, tokenizer, prefix, 1., 25, sequences)
                    if err > .003 or ids != sequences[result["greedy_index"]]:
                        raise ValueError("Public-model audit failed")
                    audit = {"max_reference_error": err, "public_generate_matches": True}
                    audited.add(arm)
                outputs[arm] = {"value": candidates[result["map_index"]][1],
                                "greedy_value": candidates[result["greedy_index"]][1],
                                "scores": result, "messages": msg, "prompt_ids": prefix,
                                "choices": candidates, "candidate_ids": sequences, "audit": audit}
            record = {"id": row["id"], "fingerprint": bundle["fingerprint"],
                      "runtime_hash": score.digest(runtime), "outputs": outputs,
                      "seconds": time.monotonic() - started}
            score.write_json(run / name / split / "records" / f"{score.digest(row['id'])}.json",
                             {"record": record, "sha256": score.digest(record)})
            print(f"096 {name}/{split} {len(records)+index+1} "
                  f"{row['id']} ({record['seconds']:.2f}s)", flush=True)
        del model
    return analyze(run, name, split)


def pipeline(run, device):
    prepare(run)
    status = {"status": "running", "started_utc": datetime.now(timezone.utc).isoformat()}
    try:
        results = {}
        for name in MODELS:
            for split in BLOCKS:
                status.update(model=name, split=split)
                score.write_json(run / "pipeline-status.json", status)
                result = run_split(run, name, split, device)
                results[f"{name}/{split}"] = result
                if not result["continue"]:
                    status.update(status="stopped_at_scientific_gate", results=results)
                    score.write_json(run / "pipeline-status.json", status)
                    print(json.dumps(status, indent=2), flush=True)
                    return
        status.update(status="complete", results=results)
        score.write_json(run / "pipeline-status.json", status)
        print(json.dumps(status, indent=2), flush=True)
    except BaseException as exc:
        status.update(status="technical_failure", error=repr(exc))
        score.write_json(run / "pipeline-status.json", status)
        raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("prepare", "run", "analyze", "pipeline"))
    parser.add_argument("--run", type=Path, default=ROOT / "runs/evidence-gate-096")
    parser.add_argument("--model", choices=tuple(MODELS), default="granite2")
    parser.add_argument("--split", choices=tuple(BLOCKS), default="development")
    parser.add_argument("--device", choices=("mps", "cpu"), default="mps")
    parser.add_argument("--limit", type=int)
    args = parser.parse_args()
    if args.limit is not None and args.limit < 1:
        parser.error("--limit must be positive")
    if args.command == "prepare":
        print(prepare(args.run)["fingerprint"])
    elif args.command == "run":
        print(json.dumps(run_split(args.run, args.model, args.split, args.device, args.limit), indent=2))
    elif args.command == "analyze":
        print(json.dumps(analyze(args.run, args.model, args.split), indent=2))
    else:
        with score.exclusive_lock(args.run / ".pipeline.lock"):
            pipeline(args.run, args.device)


if __name__ == "__main__":
    main()
