"""Frozen, resumable evidence × serialization × inference-policy experiment.

Uses the PUBLIC causal-LM logits, including architecture-specific scaling.
Candidate probabilities include EOS and refer to canonical token sequences.
"""

import argparse
import contextlib
import hashlib
import itertools
import json
import math
import platform
import sys
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import torch
import transformers
from transformers import GenerationConfig, RepetitionPenaltyLogitsProcessor

from .target import load_target

ROOT = Path(__file__).resolve().parents[2]
EVIDENCE = ("relevant", "irrelevant", "none")
FORMATS = ("compact", "spaced")
POLICIES = ("unit", "checkpoint_penalty", "matched_penalty")
ASPECTS = ("battery", "screen", "keyboard")
STATES = ("negative", "neutral", "positive", "contradictory", "uninformative")
TEMPLATES = {
    "development": ("During my test, {statement}.",),
    "confirmation": (
        "My notes about this laptop: {statement}.",
        "After using this laptop for a week, I can report that {statement}.",
        "Here is my experience with the laptop: {statement}.",
    ),
}
RULE = (
    "Apply this fixed rating rubric to the author's opinion of the target aspect. "
    "Only criticism = 1.0; explicitly neither good nor bad = 5.0; only praise = 9.0. "
    "Both praise and criticism of the target count equally and give 5.0. "
    "A mention, specification, or opinion of a different aspect is not evidence. "
    "Do not infer an opinion from the target's name or from an unrelated opinion. "
)


def digest(value):
    return hashlib.sha256(
        json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()
    ).hexdigest()


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n")
    temporary.replace(path)


def code_hash():
    return digest({
        str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
        for p in (Path(__file__), ROOT / "src/latent_decisions/target.py",
                  ROOT / "scripts/run_evidence_policy_094.py")
    })


def dataset():
    """No random split of paraphrases; template families are separated prospectively."""
    rows = []
    for split, templates in TEMPLATES.items():
        for ti, template in enumerate(templates):
            for ai, aspect in enumerate(ASPECTS):
                other = ASPECTS[(ai + 1) % len(ASPECTS)]
                statements = {
                    "negative": f"the {aspect} was awful and I disliked it",
                    "neutral": f"the {aspect} was neither good nor bad",
                    "positive": f"the {aspect} was excellent and I liked it",
                    "contradictory": (
                        f"I liked the {aspect} in some ways and disliked it in other ways"
                    ),
                    "uninformative": f"the {aspect} is one of the laptop's components",
                }
                for state in STATES:
                    rows.append({
                        "id": f"{split}-{ti}-{aspect}-{state}",
                        "block": f"{split}-{ti}-{aspect}",
                        "split": split,
                        "template": ti,
                        "aspect": aspect,
                        "state": state,
                        "hidden_rating": {
                            "negative": 1.0, "neutral": 5.0, "positive": 9.0,
                            "contradictory": 5.0, "uninformative": None,
                        }[state],
                        "reviews": {
                            "relevant": template.format(statement=statements[state]),
                            # Identical within a block: cannot leak the paired hidden label.
                            "irrelevant": template.format(statement=(
                                f"the {other} was excellent and I liked it; "
                                f"the {aspect} is one of the laptop's components"
                            )),
                            "none": "[No review supplied]",
                        },
                    })
    return rows


def cells(rows, split):
    for row in rows:
        if row["split"] == split:
            for evidence, style, abstain in itertools.product(EVIDENCE, FORMATS, (False, True)):
                yield {
                    "id": f"{row['id']}:{evidence}:{style}:{int(abstain)}",
                    "item": row["id"], "evidence": evidence,
                    "format": style, "abstain": abstain,
                }


def render(value, style):
    return json.dumps({"rating": value}, separators=(",", ":") if style == "compact"
                      else (", ", ": "), allow_nan=False)


def candidates(style, abstain, step):
    values = [n / 10 for n in range(10, 91, step)] + ([None] if abstain else [])
    return [(render(v, style), v) for v in values]


def prompt(row, cell):
    missing = (
        "If the supplied text is insufficient, return null for rating. "
        if cell["abstain"] else
        "If the supplied text is insufficient, you must still estimate a numeric rating. "
    )
    spacing = (
        'Use compact JSON, for example {"rating":5.0}.' if cell["format"] == "compact"
        else 'Use a space after the colon, for example {"rating": 5.0}.'
    )
    return (
        RULE + missing + "Return exactly one JSON object with the single key rating. "
        "Numeric ratings must be from 1.0 to 9.0 with one decimal place. " + spacing
        + f"\nTarget aspect: {row['aspect']}\nReview: {row['reviews'][cell['evidence']]}"
    )


def parse_answer(text, abstain):
    """Semantic validity; formatting compliance is reported separately."""
    try:
        obj = json.loads(text.strip())
    except (ValueError, TypeError):
        return False, None
    if not isinstance(obj, dict) or set(obj) != {"rating"}:
        return False, None
    value = obj["rating"]
    if value is None:
        return abstain, None
    valid = type(value) in (int, float) and math.isfinite(value) and 1 <= value <= 9
    return bool(valid), float(value) if valid else None


def token_sequences(tokenizer, choices):
    eos = tokenizer.eos_token_id
    if eos is None:
        raise ValueError("Tokenizer needs an explicit EOS token")
    sequences = [tokenizer.encode(text, add_special_tokens=False) + [eos]
                 for text, _ in choices]
    if len({tuple(s) for s in sequences}) != len(sequences):
        raise ValueError("Candidate token sequences collide")
    if any(eos in seq[:-1] for seq in sequences):
        raise ValueError("A candidate contains EOS")
    return sequences


def trie(sequences):
    branches = {}
    for seq in sequences:
        for i, token in enumerate(seq):
            branches.setdefault(tuple(seq[:i]), set()).add(token)
    return {p: sorted(ts) for p, ts in branches.items()}


def public_logits(model, ids, keep):
    """Never call lm_head directly: Granite scales logits inside this API."""
    return model(
        input_ids=ids, attention_mask=torch.ones_like(ids), use_cache=False,
        logits_to_keep=keep,
    ).logits.float()


def process(logits, history, penalty):
    scores = logits.clone()
    if penalty != 1.0:
        processor = RepetitionPenaltyLogitsProcessor(penalty)
        scores = processor(history[None, :], scores[None, :])[0]
    return scores


@torch.inference_mode()
def score_candidates(model, prefix, sequences, penalties, batch_size=4):
    """Exact teacher forcing, grouped by length (no padded-position ambiguity).

    Score both unrestricted policy probabilities and locally grammar-masked
    probabilities. Reconstruct constrained greedy from the same prefix logits.
    Prefix consistency checks detect bad slicing, dropout, or batch dependence.
    """
    branches = trie(sequences)
    results = {name: {"sequence_logprobs": [None] * len(sequences),
                      "local_sequence_logprobs": [None] * len(sequences)}
               for name in penalties}
    nodes = {name: {} for name in penalties}
    device = next(model.parameters()).device
    for length in sorted({len(seq) for seq in sequences}):
        indices = [i for i, s in enumerate(sequences) if len(s) == length]
        for start in range(0, len(indices), batch_size):
            indices_batch = indices[start:start + batch_size]
            ids = torch.tensor([prefix + sequences[i] for i in indices_batch], device=device)
            # Positions: last prompt token through penultimate candidate token.
            logits = public_logits(model, ids, length + 1)[:, :-1, :]
            if logits.shape[1] != length:
                raise ValueError("Public model did not honor logits_to_keep")
            for bi, ci in enumerate(indices_batch):
                seq = sequences[ci]
                totals = {name: [0.0, 0.0] for name in penalties}
                for pos, token in enumerate(seq):
                    path = tuple(seq[:pos])
                    allowed = branches[path]
                    history = ids[bi, :len(prefix) + pos]
                    for name, penalty in penalties.items():
                        scores = process(logits[bi, pos], history, penalty)
                        lp = scores.log_softmax(-1)
                        allowed_scores = scores[allowed]
                        local_lp = allowed_scores.log_softmax(-1)
                        choice = allowed[int(allowed_scores.argmax())]
                        node = {"token": choice,
                                "raw_logprob": float(lp[choice]),
                                "allowed_token_mass": float(lp[allowed].exp().sum())}
                        old = nodes[name].get(path)
                        if old is not None and (
                            old["token"] != choice or
                            abs(old["raw_logprob"] - node["raw_logprob"]) > 0.003
                        ):
                            raise ValueError("Repeated prefix logits disagree; audit scoring")
                        nodes[name][path] = node
                        totals[name][0] += float(lp[token])
                        totals[name][1] += float(local_lp[allowed.index(token)])
                for name, (raw, local) in totals.items():
                    results[name]["sequence_logprobs"][ci] = raw
                    results[name]["local_sequence_logprobs"][ci] = local
    for name, result in results.items():
        path, trace = (), []
        while path in branches:
            node = nodes[name][path]
            trace.append(node)
            path += (node["token"],)
        result["greedy_index"] = sequences.index(list(path))
        result["greedy_trace"] = trace
        lp = np.array(result["sequence_logprobs"], dtype=np.float64)
        log_mass = float(np.logaddexp.reduce(lp))
        if log_mass > 0.003:
            raise ValueError("Candidate support mass exceeds one")
        local_sum = float(np.exp(result["local_sequence_logprobs"]).sum())
        if abs(local_sum - 1) > 0.003:
            raise ValueError("Finite locally masked distribution does not normalize")
        result["log_support_mass"] = log_mass
        result["conditional_probabilities"] = np.exp(lp - log_mass).tolist()
        result["map_index"] = int(lp.argmax())
    return results


def generation_config(tokenizer, penalty, max_tokens):
    """Fresh config: the checkpoint contributes ONLY its named penalty factor."""
    return GenerationConfig(
        do_sample=False, num_beams=1, repetition_penalty=penalty,
        max_new_tokens=max_tokens, eos_token_id=tokenizer.eos_token_id,
        pad_token_id=tokenizer.pad_token_id, bos_token_id=tokenizer.bos_token_id,
        use_cache=True,
    )


@torch.inference_mode()
def generate(model, tokenizer, prefix, penalty, max_tokens, sequences=None):
    kwargs = {}
    if sequences is not None:
        branches = trie(sequences)

        def allowed(batch_id, ids):
            return branches.get(tuple(ids.tolist()[len(prefix):]), [tokenizer.eos_token_id])

        kwargs["prefix_allowed_tokens_fn"] = allowed
    ids = torch.tensor([prefix], device=next(model.parameters()).device)
    output = model.generate(
        input_ids=ids, attention_mask=torch.ones_like(ids),
        generation_config=generation_config(tokenizer, penalty, max_tokens), **kwargs,
    )[0, len(prefix):].tolist()
    return output, tokenizer.decode(output, skip_special_tokens=True)


@torch.inference_mode()
def reference_logprob(model, prefix, sequence, penalty):
    """Independent full-output, one-candidate reference; no suffix slicing helper."""
    ids = torch.tensor([prefix + sequence], device=next(model.parameters()).device)
    logits = model(input_ids=ids, attention_mask=torch.ones_like(ids), use_cache=False).logits
    total = 0.0
    for offset, token in enumerate(sequence):
        position = len(prefix) - 1 + offset
        scores = process(logits[0, position].float(), ids[0, :position + 1], penalty)
        total += float(scores.log_softmax(-1)[token])
    return total


def distribution_summary(result, choices):
    probs = np.array(result["conditional_probabilities"])
    numeric = [i for i, (_, v) in enumerate(choices) if v is not None]
    numeric_mass = float(probs[numeric].sum())
    return {
        **result,
        "greedy_rating": choices[result["greedy_index"]][1],
        "map_rating": choices[result["map_index"]][1],
        "numeric_probability": numeric_mass,
        "null_probability": float(sum(probs[i] for i, (_, v) in enumerate(choices)
                                      if v is None)),
        "conditional_numeric_mean": (
            float(sum(probs[i] * choices[i][1] for i in numeric) / numeric_mass)
            if numeric_mass > 0 else None
        ),
    }


def first_divergence(left, right, tokenizer):
    for position, (a, b) in enumerate(itertools.zip_longest(left, right)):
        if a != b:
            return {"position": position, "unit_token": a, "comparison_token": b,
                    "unit_text": tokenizer.decode([a]) if a is not None else None,
                    "comparison_text": tokenizer.decode([b]) if b is not None else None}
    return None


def load_bundle(run):
    bundle = json.loads((run / "design.json").read_text())
    if bundle["fingerprint"] != digest(bundle["design"]):
        raise ValueError("Frozen design hash mismatch")
    if bundle["design"]["code_sha256"] != code_hash():
        raise ValueError("Code changed since prepare; use a fresh run directory")
    return bundle


def prepare(run, config_path):
    if (run / "design.json").exists():
        raise ValueError("Design already exists; use a new run directory")
    config = json.loads(config_path.read_text())
    if config["numeric_step_tenths"] not in (1, 10):
        raise ValueError("numeric_step_tenths must be 1 (primary) or 10 (debug)")
    if config["score_batch_size"] < 1 or config["bootstrap_samples"] < 100:
        raise ValueError("Invalid batch/bootstrap settings")
    design = {"config": config, "rows": dataset(), "code_sha256": code_hash(),
              "primary_endpoint": (
                  "matched_penalty minus unit in (abs_error_none - abs_error_relevant), "
                  "compact constrained greedy, forced numeric, negative/neutral/positive only"
              ),
              "analysis_unit": "template × aspect blocks; all labels and conditions paired",
              "created_utc": datetime.now(timezone.utc).isoformat()}
    bundle = {"design": design, "fingerprint": digest(design)}
    write_json(run / "design.json", bundle)
    print(json.dumps({"fingerprint": bundle["fingerprint"], "contexts_per_model": {
        s: len(list(cells(design["rows"], s))) for s in TEMPLATES
    }, "policies_per_context": 3, "note": "No model inference performed."}, indent=2))


@contextlib.contextmanager
def exclusive_lock(path):
    """Advisory process lock automatically released after crash (macOS/Linux)."""
    import fcntl

    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a") as handle:
        try:
            fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as exc:
            raise ValueError(f"Another process owns {path}") from exc
        try:
            yield
        finally:
            fcntl.flock(handle, fcntl.LOCK_UN)


def read_records(directory, expected, fingerprint):
    records = {}
    if not directory.exists():
        return records
    for path in sorted(directory.glob("*.json")):
        envelope = json.loads(path.read_text())
        record = envelope["record"]
        if envelope["sha256"] != digest(record):
            raise ValueError(f"Record checksum mismatch: {path}")
        if record["fingerprint"] != fingerprint or record["cell"]["id"] not in expected:
            raise ValueError(f"Foreign record: {path}")
        key = record["cell"]["id"]
        if record["cell"] != expected[key] or key in records:
            raise ValueError(f"Duplicate or modified condition: {path}")
        records[key] = record
    return records


def result_dir(run, model, split):
    return run / model / split


def run_model(args):
    run = args.run
    bundle = load_bundle(run)
    design, fingerprint = bundle["design"], bundle["fingerprint"]
    config = design["config"]
    if args.model not in config["models"]:
        raise ValueError("Unknown model alias")
    if args.split == "confirmation":
        lock = json.loads((run / args.model / "confirmation-lock.json").read_text())
        dev = analyze(run, args.model, "development", save=False)
        if (lock["fingerprint"] != fingerprint or lock["development_digest"] != dev["data_digest"]
                or not dev["complete"] or not dev["competence"]["passed"]):
            raise ValueError("Confirmation gate no longer matches complete competent development")
    directory = result_dir(run, args.model, args.split)
    expected = {c["id"]: c for c in cells(design["rows"], args.split)}
    with exclusive_lock(run / args.model / ".inference.lock"):
        existing = read_records(directory / "records", expected, fingerprint)
        pending = [c for key, c in expected.items() if key not in existing]
        if args.limit is not None:
            pending = pending[:args.limit]
        if not pending:
            print("No pending contexts.")
            return
        model, tokenizer, device = load_target(config["models"][args.model], args.device, args.offline)
        penalty = float(model.generation_config.repetition_penalty)
        penalties = {"unit": 1.0, "checkpoint_penalty": penalty,
                     "matched_penalty": config["matched_penalty"]}
        runtime = {
            "fingerprint": fingerprint, "model_alias": args.model,
            "model": config["models"][args.model], "device": device, "dtype": "float32",
            "python": platform.python_version(), "torch": torch.__version__,
            "transformers": transformers.__version__,
            "checkpoint_generation_config": model.generation_config.to_dict(),
            "model_config_sha256": digest(model.config.to_dict()),
            "tokenizer_sha256": digest(tokenizer.get_vocab()),
            "chat_template": tokenizer.chat_template,
            "resolved_policies": {name: generation_config(
                tokenizer, p, config["max_free_tokens"]).to_dict() for name, p in penalties.items()},
        }
        runtime_path = run / args.model / "runtime.json"
        if runtime_path.exists() and json.loads(runtime_path.read_text()) != runtime:
            raise ValueError("Runtime changed; refusing to mix runs")
        write_json(runtime_path, runtime)
        by_id = {r["id"]: r for r in design["rows"]}
        for ci, cell in enumerate(pending):
            row = by_id[cell["item"]]
            messages = [{"role": "user", "content": prompt(row, cell)}]
            prefix = tokenizer.apply_chat_template(messages, tokenize=True, add_generation_prompt=True)
            if len(prefix) > config["max_prompt_tokens"]:
                raise ValueError("Prompt too long; truncation is forbidden")
            choices = candidates(cell["format"], cell["abstain"], config["numeric_step_tenths"])
            sequences = token_sequences(tokenizer, choices)
            scores = score_candidates(model, prefix, sequences, penalties, config["score_batch_size"])
            audits = {}
            # Validate every format/abstention family in each invocation, including resumes.
            family = (cell["format"], cell["abstain"])
            if ci == 0:
                audited_families = set()
            if family not in audited_families:
                for name, p in penalties.items():
                    generated, _ = generate(model, tokenizer, prefix, p,
                                            max(map(len, sequences)) + 1, sequences)
                    if generated != sequences[scores[name]["greedy_index"]]:
                        raise ValueError("Public generate disagrees with reconstructed greedy")
                    errors = []
                    for index in sorted({0, len(sequences) // 2, len(sequences) - 1}):
                        ref = reference_logprob(model, prefix, sequences[index], p)
                        errors.append(abs(ref - scores[name]["sequence_logprobs"][index]))
                    if max(errors) > 0.003:
                        raise ValueError("Independent full-forward reference disagrees")
                    audits[name] = {"generate_matches": True, "max_reference_error": max(errors)}
                audited_families.add(family)
            outputs = {}
            for name, p in penalties.items():
                ids, text = generate(model, tokenizer, prefix, p, config["max_free_tokens"])
                valid, rating = parse_answer(text, cell["abstain"])
                outputs[name] = {
                    **distribution_summary(scores[name], choices),
                    "penalty": p, "free_text": text, "free_ids": ids,
                    "free_valid": valid, "free_rating": rating,
                    "free_canonical": text in {s for s, _ in choices},
                    "free_hit_token_limit": len(ids) == config["max_free_tokens"]
                    and (not ids or ids[-1] != tokenizer.eos_token_id),
                }
            record = {
                "fingerprint": fingerprint, "runtime_sha256": digest(runtime), "cell": cell,
                "prompt": messages, "prompt_ids": prefix, "choices": choices,
                "candidate_ids": sequences, "policies": outputs, "audits": audits,
                "policy_first_divergence": {
                    name: first_divergence(
                        sequences[outputs["unit"]["greedy_index"]],
                        sequences[outputs[name]["greedy_index"]], tokenizer,
                    ) for name in POLICIES if name != "unit"
                },
            }
            write_json(directory / "records" / f"{digest(cell['id'])}.json",
                       {"sha256": digest(record), "record": record})
            print(f"{args.model}/{args.split}: {len(existing) + ci + 1}/{len(expected)} "
                  f"{cell['id']}", flush=True)
    analyze(run, args.model, args.split)


def bootstrap(values, config):
    values = np.asarray(values, dtype=float)
    rng = np.random.default_rng(config["bootstrap_seed"])
    means = values[rng.integers(0, len(values), (config["bootstrap_samples"], len(values)))].mean(1)
    return {"estimate": float(values.mean()), "ci95": np.quantile(means, [.025, .975]).tolist(),
            "blocks": len(values)}


def analyze(run, model, split, save=True):
    bundle = load_bundle(run)
    design = bundle["design"]
    config = design["config"]
    expected = {c["id"]: c for c in cells(design["rows"], split)}
    directory = result_dir(run, model, split)
    records = read_records(directory / "records", expected, bundle["fingerprint"])
    runtime_path = run / model / "runtime.json"
    if records:
        runtime = json.loads(runtime_path.read_text())
        if any(r["runtime_sha256"] != digest(runtime) for r in records.values()):
            raise ValueError("Record/runtime mismatch")
    rows = {r["id"]: r for r in design["rows"]}
    complete = len(records) == len(expected)
    summary = {"model": model, "split": split, "fingerprint": bundle["fingerprint"],
               "complete": complete, "completed_contexts": len(records),
               "expected_contexts": len(expected),
               "data_digest": digest({k: digest(v) for k, v in sorted(records.items())}),
               "primary": None, "competence": {"passed": False}, "groups": []}
    groups = {}
    competence = []
    for rec in records.values():
        cell = rec["cell"]
        row = rows[cell["item"]]
        gold = row["hidden_rating"] if cell["evidence"] == "relevant" else None
        for name, output in rec["policies"].items():
            if (name == "unit" and cell["evidence"] == "relevant" and
                    cell["format"] == "spaced" and cell["abstain"] and
                    row["state"] in ("negative", "neutral", "positive")):
                competence.append(output["map_rating"] == gold)
            for endpoint in ("greedy", "map", "free", "mean"):
                valid = output["free_valid"] if endpoint == "free" else True
                prediction = (output["conditional_numeric_mean"] if endpoint == "mean"
                              else output[f"{endpoint}_rating"])
                key = (cell["evidence"], cell["format"], cell["abstain"], name, endpoint,
                       row["state"])
                group = groups.setdefault(key, [])
                group.append({
                    "valid": valid, "null": valid and prediction is None,
                    "supported_accuracy": float(valid and prediction == gold)
                    if cell["abstain"] and endpoint != "mean" else None,
                    "hidden_error": abs(prediction - row["hidden_rating"])
                    if valid and prediction is not None and row["hidden_rating"] is not None
                    else None,
                    "corner": float(valid and prediction == 1.0),
                    "support_mass": math.exp(output["log_support_mass"]),
                    "null_probability": output["null_probability"],
                })
    summary["competence"] = {
        "n": len(competence), "accuracy": float(np.mean(competence)) if competence else None,
        "threshold": config["competence_accuracy"],
        "passed": bool(complete and competence and np.mean(competence) >= config["competence_accuracy"]),
    }
    for key, values in sorted(groups.items()):
        entry = dict(zip(("evidence", "format", "abstain", "policy", "endpoint", "state"), key))
        entry["n"] = len(values)
        for metric in values[0]:
            observed = [v[metric] for v in values if v[metric] is not None]
            entry[metric] = {"mean": float(np.mean(observed)) if observed else None,
                             "n": len(observed)}
        summary["groups"].append(entry)
    if complete:
        primary_blocks = {}
        benefits = {}
        eligible = [r for r in rows.values() if r["split"] == split and
                    r["state"] in ("negative", "neutral", "positive")]
        for row in eligible:
            item_benefits = {}
            for style, name, endpoint in itertools.product(FORMATS, POLICIES, ("greedy", "map", "mean")):
                errors = {}
                for evidence in EVIDENCE:
                    rec = records[f"{row['id']}:{evidence}:{style}:0"]
                    out = rec["policies"][name]
                    value = (out["conditional_numeric_mean"] if endpoint == "mean"
                             else out[f"{endpoint}_rating"])
                    errors[evidence] = abs(value - row["hidden_rating"])
                for control in ("none", "irrelevant"):
                    key = f"{style}/{name}/{endpoint}/vs_{control}"
                    b = errors[control] - errors["relevant"]
                    benefits.setdefault(key, {}).setdefault(row["block"], []).append(b)
                    if style == "compact" and endpoint == "greedy" and control == "none":
                        item_benefits[name] = b
            primary_blocks.setdefault(row["block"], []).append(
                item_benefits["matched_penalty"] - item_benefits["unit"])
        summary["primary"] = bootstrap([np.mean(v) for v in primary_blocks.values()], config)
        summary["primary"]["definition"] = design["primary_endpoint"]
        summary["primary"]["threshold"] = config["practical_effect_rating_points"]
        lo, hi = summary["primary"]["ci95"]
        threshold = config["practical_effect_rating_points"]
        summary["primary"]["practically_resolved"] = lo > threshold or hi < -threshold
        summary["secondary_evidence_benefits"] = {
            key: bootstrap([np.mean(v) for v in blocks.values()], config)
            for key, blocks in benefits.items()
        }
        summary["policy_answer_change_rate"] = float(np.mean([
            r["policies"]["unit"]["greedy_index"] !=
            r["policies"]["matched_penalty"]["greedy_index"] for r in records.values()
        ]))
        summary["interpretation"] = (
            "Synthetic rubric task; template/aspect bootstrap is descriptive, with few dependent "
            "blocks. No natural-review or architecture-general claim follows automatically. "
            "Secondary contrasts are exploratory. Raw-policy candidate conditioning and local "
            "grammar normalization are different distributions."
        )
    if save:
        write_json(directory / "analysis.json", summary)
    return summary


def freeze_confirmation(run, model):
    bundle = load_bundle(run)
    summary = analyze(run, model, "development")
    if not summary["complete"] or not summary["competence"]["passed"]:
        raise ValueError("Complete development run must pass the frozen competence gate")
    path = run / model / "confirmation-lock.json"
    if path.exists():
        raise ValueError("Confirmation already frozen")
    write_json(path, {"fingerprint": bundle["fingerprint"],
                      "development_digest": summary["data_digest"],
                      "frozen_utc": datetime.now(timezone.utc).isoformat(),
                      "threshold": bundle["design"]["config"]["practical_effect_rating_points"]})
    print(f"Confirmation unlocked: {path}")


def compare_models(run):
    bundle = load_bundle(run)
    config = bundle["design"]["config"]
    names = (config["primary_model"], config["replication_model"])
    analyses = {name: analyze(run, name, "confirmation") for name in names}
    complete = all(a["complete"] for a in analyses.values())
    decision = "incomplete; no confirmatory conclusion"
    if complete:
        primary, replication = [analyses[name]["primary"] for name in names]
        passed = all(a["competence"]["passed"] for a in analyses.values())
        resolved = all(a["primary"]["practically_resolved"] for a in analyses.values())
        same_sign = primary["estimate"] * replication["estimate"] > 0
        decision = (
            "same-direction practical policy effect on both architectures; pursue one "
            "fresh-task prediction, without claiming natural-language generalization"
            if passed and resolved and same_sign else
            "primary continuation criterion failed; stop this hypothesis rather than "
            "promote an exploratory subgroup to confirmation"
        )
    report = {"fingerprint": bundle["fingerprint"], "complete": complete,
              "decision": decision, "models": analyses,
              "scope": "A penalty × evidence interaction, not a novelty or sign-reversal claim. "
              "Serialization and search contrasts remain secondary."}
    write_json(run / "comparison.json", report)
    print(json.dumps({k: v for k, v in report.items() if k != "models"}, indent=2))
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("prepare", "run", "analyze", "freeze", "compare"))
    parser.add_argument("--run", type=Path, default=ROOT / "runs/evidence-policy-094")
    parser.add_argument("--config", type=Path, default=ROOT / "configs/evidence-policy-094.json")
    parser.add_argument("--model", default="qwen15")
    parser.add_argument("--split", choices=tuple(TEMPLATES), default="development")
    parser.add_argument("--device", choices=("auto", "cpu", "mps"), default="auto")
    parser.add_argument("--offline", action="store_true")
    parser.add_argument("--limit", type=int, help="At most this many NEW contexts; never marks partial complete")
    args = parser.parse_args()
    if args.limit is not None and args.limit < 1:
        parser.error("--limit must be positive")
    try:
        if args.command == "prepare":
            prepare(args.run, args.config)
        elif args.command == "run":
            run_model(args)
        elif args.command == "freeze":
            freeze_confirmation(args.run, args.model)
        elif args.command == "compare":
            compare_models(args.run)
        else:
            result = analyze(args.run, args.model, args.split)
            print(json.dumps({k: v for k, v in result.items() if k != "groups"}, indent=2))
    except (ValueError, FileNotFoundError, KeyError) as exc:
        print(f"Experiment stopped: {exc}", file=sys.stderr)
        raise SystemExit(1) from exc


if __name__ == "__main__":
    main()
