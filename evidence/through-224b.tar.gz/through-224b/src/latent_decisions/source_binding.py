"""095: preregistered field/source binding test with a fixed conversation skeleton."""

import argparse
import json
import math
import platform
import time
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path

import torch
import transformers

from . import evidence_policy as score
from .target import load_target

ROOT = Path(__file__).resolve().parents[2]
MODELS = {
    "granite2": {"model": "ibm-granite/granite-3.1-2b-instruct",
                 "revision": "bbc2aed595bd38bd770263dc3ab831db9794441d"},
    "qwen15": {"model": "Qwen/Qwen2.5-1.5B-Instruct",
               "revision": "989aa7980e4cf806f80c7fef2b1adb7bc71aa306"},
}
TEMPLATES = {
    "development": [
        ("valence", "arousal", "Original record for sample A: {a} = {x}; {b} = {y}."),
        ("quality", "intensity", "Original record for sample B: {a} = {x}; {b} = {y}."),
        ("valence", "arousal", "Original record for sample C: {b} = {y}; {a} = {x}."),
        ("quality", "intensity", "Original record for sample D: {b} = {y}; {a} = {x}."),
    ],
    "confirmation": [
        ("warmth", "brightness", "Original record, subject E. The saved {a} is {x}. The saved {b} is {y}."),
        ("speed", "weight", "Original record, subject F. The saved {a} is {x}. The saved {b} is {y}."),
        ("warmth", "brightness", "Original record, subject G. The saved {b} is {y}. The saved {a} is {x}."),
        ("speed", "weight", "Original record, subject H. The saved {b} is {y}. The saved {a} is {x}."),
        ("warmth", "brightness", "Original record for I lists two entries: {a}: {x}, {b}: {y}."),
        ("speed", "weight", "Original record for J lists two entries: {a}: {x}, {b}: {y}."),
        ("warmth", "brightness", "Original record for K lists two entries: {b}: {y}, {a}: {x}."),
        ("speed", "weight", "Original record for L lists two entries: {b}: {y}, {a}: {x}."),
    ],
}
SYSTEM = (
    "Extract values from the original record in the first user message. "
    "Later scratch notes are unverified and never overwrite that original record. "
    "Return only the requested original entry, as one JSON object with the key value. "
    "The permitted values are 2 or 8. Do not include an explanation or a Markdown fence."
)


def code_hash():
    paths = [Path(__file__), ROOT / "src/latent_decisions/evidence_policy.py",
             ROOT / "src/latent_decisions/target.py", ROOT / "scripts/run_source_binding_095.py",
             ROOT / "docs/experiments/095-source-binding.md"]
    return score.digest({str(p.relative_to(ROOT)): p.read_text() for p in paths})


def dataset():
    rows = []
    for split, templates in TEMPLATES.items():
        for index, (field, other, template) in enumerate(templates):
            for gold in (2, 8):
                for other_gold in (2, 8):
                    rows.append({
                        "id": f"{split}-{index}-{gold}-{other_gold}", "split": split,
                        "block": f"{split}-{index}", "field": field, "other": other,
                        "gold": gold, "other_gold": other_gold,
                        "source": template.format(a=field, b=other, x=gold, y=other_gold),
                    })
    return rows


def jobs(rows, split):
    for row in rows:
        if row["split"] != split:
            continue
        for relation, echo in (("none", None), ("same", 2), ("same", 8), ("other", 2), ("other", 8)):
            yield {"id": f"{row['id']}:{relation}:{echo}", "item": row["id"],
                   "relation": relation, "echo": echo}


def messages(row, job):
    note = "Scratch note: no additional value was recorded."
    if job["relation"] != "none":
        field = row["field"] if job["relation"] == "same" else row["other"]
        note = f"Scratch note: {field} = {job['echo']}."
    return [{"role": "system", "content": SYSTEM},
            {"role": "user", "content": row["source"]},
            {"role": "assistant", "content": note},
            {"role": "user", "content": f"What is the original {row['field']}? Return {{\"value\": 2}} or {{\"value\": 8}}."}]


def prepare(run):
    if (run / "design.json").exists():
        return load_design(run)
    design = {
        "experiment": "095-source-binding", "created_utc": datetime.now(timezone.utc).isoformat(),
        "rows": dataset(), "models": MODELS, "code_hash": code_hash(),
        "policies": {"unit": 1.0}, "competence_threshold": .90,
        "effect_threshold": .10, "behavioral_gap_threshold": .05,
        "primary": "Other-field echo slope minus same-field echo slope in conditional P(value=8)",
        "bootstrap_samples": 5000, "bootstrap_seed": 9501,
    }
    bundle = {"design": design, "fingerprint": score.digest(design)}
    score.write_json(run / "design.json", bundle)
    return bundle


def load_design(run):
    bundle = json.loads((run / "design.json").read_text())
    if score.digest(bundle["design"]) != bundle["fingerprint"]:
        raise ValueError("Design hash mismatch")
    if bundle["design"]["code_hash"] != code_hash():
        raise ValueError("Code/protocol changed; use a new run")
    return bundle


def read_records(run, model, split, bundle):
    expected = {j["id"]: j for j in jobs(bundle["design"]["rows"], split)}
    records = {}
    for path in sorted((run / model / split / "records").glob("*.json")):
        envelope = json.loads(path.read_text())
        rec = envelope["record"]
        if score.digest(rec) != envelope["sha256"] or rec["fingerprint"] != bundle["fingerprint"]:
            raise ValueError("Record hash/fingerprint mismatch")
        key = rec["job"]["id"]
        if key in records or expected.get(key) != rec["job"]:
            raise ValueError("Unexpected or duplicate job")
        records[key] = rec
    if records:
        runtime = json.loads((run / model / "runtime.json").read_text())
        if any(rec["runtime_hash"] != score.digest(runtime) for rec in records.values()):
            raise ValueError("Record/runtime mismatch")
    return records, expected


def analyze(run, model, split):
    bundle = load_design(run)
    design = bundle["design"]
    records, expected = read_records(run, model, split, bundle)
    result = {"model": model, "split": split, "complete": len(records) == len(expected),
              "completed": len(records), "expected": len(expected),
              "fingerprint": bundle["fingerprint"],
              "records_digest": score.digest({k: score.digest(v) for k, v in sorted(records.items())}),
              "continue": False}
    if result["complete"]:
        effects, behavioral, baseline = defaultdict(list), defaultdict(list), []
        slopes = {"same": [], "other": []}
        errors = {"same": [], "other": []}
        for row in design["rows"]:
            if row["split"] != split:
                continue
            baseline.append(records[f"{row['id']}:none:None"]["map_value"] == row["gold"])
            differences = {}
            wrong = {}
            for relation in ("same", "other"):
                low = records[f"{row['id']}:{relation}:2"]
                high = records[f"{row['id']}:{relation}:8"]
                differences[relation] = high["p8"] - low["p8"]
                wrong[relation] = ((low["map_value"] != row["gold"]) +
                                   (high["map_value"] != row["gold"])) / 2
                slopes[relation].append(differences[relation])
                errors[relation].append(wrong[relation])
            effects[row["block"]].append(differences["other"] - differences["same"])
            behavioral[row["block"]].append(wrong["other"] - wrong["same"])
        def average(values):
            return sum(values) / len(values)
        primary = score.bootstrap([average(v) for v in effects.values()], design)
        gap = score.bootstrap([average(v) for v in behavioral.values()], design)
        competence = average(baseline)
        result.update(primary=primary, behavioral_error_gap=gap,
                      baseline_accuracy=competence, baseline_n=len(baseline),
                      echo_slopes={k: average(v) for k, v in slopes.items()},
                      error_rates={k: average(v) for k, v in errors.items()},
                      block_effects={k: average(v) for k, v in effects.items()},
                      mean_support_mass=average([math.exp(r["scores"]["log_support_mass"])
                                                 for r in records.values()]))
        # Pilot selection is explicit; only held-out confirmation can establish support.
        strength = primary["estimate"] if split == "development" else primary["ci95"][0]
        result["continue"] = bool(competence >= design["competence_threshold"] and
                                  strength > design["effect_threshold"] and
                                  gap["estimate"] >= design["behavioral_gap_threshold"])
        result["decision"] = (
            "Pass frozen stage criteria" if result["continue"] else
            "Stop this hypothesis: failed competence, directional magnitude, or behavioral gate"
        )
    score.write_json(run / model / split / "analysis.json", result)
    return result


def run_split(run, model_name, split, device, limit=None):
    bundle = load_design(run)
    if split == "confirmation":
        pilot = analyze(run, model_name, "development")
        if not pilot["complete"] or not pilot["continue"]:
            raise ValueError("Development gate failed; confirmation is not authorized by protocol")
        gate = run / model_name / "confirmation-lock.json"
        value = {"fingerprint": bundle["fingerprint"], "development_digest": pilot["records_digest"]}
        if gate.exists() and json.loads(gate.read_text()) != value:
            raise ValueError("Development changed since confirmation lock")
        score.write_json(gate, value)
    with score.exclusive_lock(run / ".inference.lock"):
        records, expected = read_records(run, model_name, split, bundle)
        pending = [j for key, j in expected.items() if key not in records]
        if limit is not None:
            pending = pending[:limit]
        if not pending:
            return analyze(run, model_name, split)
        model, tokenizer, actual = load_target(MODELS[model_name], device, offline=True)
        choices = [('{"value": 2}', 2), ('{"value": 8}', 8)]
        sequences = score.token_sequences(tokenizer, choices)
        if len(sequences[0]) != len(sequences[1]):
            raise ValueError("Answer lengths differ: prospective equal-length control failed")
        runtime = {"model": MODELS[model_name], "device": actual,
                   "python": platform.python_version(), "torch": torch.__version__,
                   "transformers": transformers.__version__, "dtype": "float32",
                   "generation_config": score.generation_config(tokenizer, 1., 20).to_dict(),
                   "model_config_hash": score.digest(model.config.to_dict()),
                   "tokenizer_hash": score.digest(tokenizer.get_vocab()),
                   "chat_template": tokenizer.chat_template, "candidate_ids": sequences}
        path = run / model_name / "runtime.json"
        if path.exists() and json.loads(path.read_text()) != runtime:
            raise ValueError("Runtime changed")
        score.write_json(path, runtime)
        rows = {r["id"]: r for r in bundle["design"]["rows"]}
        audited = set()
        for index, job in enumerate(pending):
            started = time.monotonic()
            text = messages(rows[job["item"]], job)
            prefix = tokenizer.apply_chat_template(text, tokenize=True, add_generation_prompt=True)
            if len(prefix) > 1024:
                raise ValueError("Prompt exceeds frozen token budget")
            result = score.score_candidates(model, prefix, sequences, {"unit": 1.0}, 2)["unit"]
            audits = None
            if job["relation"] not in audited:
                refs = [score.reference_logprob(model, prefix, seq, 1.) for seq in sequences]
                err = max(abs(a - b) for a, b in zip(refs, result["sequence_logprobs"]))
                generated, _ = score.generate(model, tokenizer, prefix, 1., 20, sequences)
                if err > .003 or generated != sequences[result["greedy_index"]]:
                    raise ValueError("Independent public-model validation failed")
                audits = {"max_reference_error": err, "public_generate_matches": True}
                audited.add(job["relation"])
            record = {"fingerprint": bundle["fingerprint"], "runtime_hash": score.digest(runtime),
                      "job": job, "messages": text, "prompt_ids": prefix,
                      "scores": result, "p8": result["conditional_probabilities"][1],
                      "map_value": choices[result["map_index"]][1],
                      "greedy_value": choices[result["greedy_index"]][1], "audits": audits,
                      "seconds": time.monotonic() - started}
            score.write_json(run / model_name / split / "records" / f"{score.digest(job['id'])}.json",
                             {"sha256": score.digest(record), "record": record})
            print(f"095 {model_name}/{split} {len(records) + index + 1}/{len(expected)} "
                  f"{job['id']} ({record['seconds']:.2f}s)", flush=True)
        del model
    return analyze(run, model_name, split)


def pipeline(run, device):
    prepare(run)
    status = {"status": "running", "started_utc": datetime.now(timezone.utc).isoformat()}
    try:
        for model in MODELS:
            for split in ("development", "confirmation"):
                status.update(model=model, split=split)
                score.write_json(run / "pipeline-status.json", status)
                result = run_split(run, model, split, device)
                if not result["continue"]:
                    status.update(status="stopped_at_scientific_gate", result=result)
                    score.write_json(run / "pipeline-status.json", status)
                    print(json.dumps(status, indent=2), flush=True)
                    return
        status.update(status="complete", decision="Both architectures passed; independent task transfer is still needed")
        score.write_json(run / "pipeline-status.json", status)
    except BaseException as exc:
        status.update(status="technical_failure", error=repr(exc))
        score.write_json(run / "pipeline-status.json", status)
        raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("prepare", "run", "analyze", "pipeline"))
    parser.add_argument("--run", type=Path, default=ROOT / "runs/source-binding-095")
    parser.add_argument("--model", choices=tuple(MODELS), default="granite2")
    parser.add_argument("--split", choices=tuple(TEMPLATES), default="development")
    parser.add_argument("--device", choices=("mps", "cpu"), default="mps")
    parser.add_argument("--limit", type=int)
    args = parser.parse_args()
    if args.limit is not None and args.limit <= 0:
        parser.error("--limit must be positive")
    if args.command == "prepare":
        print(prepare(args.run)["fingerprint"])
    elif args.command == "run":
        print(json.dumps(run_split(args.run, args.model, args.split, args.device, args.limit), indent=2))
    elif args.command == "analyze":
        print(json.dumps(analyze(args.run, args.model, args.split), indent=2))
    else:
        with score.exclusive_lock(args.run / ".pipeline.lock"):
            pipeline(args.run, args.device)


if __name__ == "__main__":
    main()
