"""An architectural null cannot rescue an effect erased by the other cuts."""

import itertools

import numpy as np
from audit_curvature_multiplication_188 import accounts, parent


def test_shared_translation_changes_gain_through_product():
    x = np.array([-1.0, 2.0])
    gate = 0.7 * x + 0.3
    up = 1.4 * x - 0.2
    correction = 0.6
    original = gate * up
    corrected = (gate + correction) * up
    assert abs(np.diff(corrected - original)[0]) > 1
    fixed_up = up.mean()
    assert abs(np.diff((gate + correction) * fixed_up - gate * fixed_up)[0]) < 1e-14


def test_null_and_survival_are_separate_accounts():
    cells = [
        {
            "block": block["id"],
            "schema": schema,
            "reverse": rev,
            "assignment": a,
            "target": t,
            "kappa": {"live": 1.0, "NW": 0.1, "NWU": 1e-6},
            "state_shift_interaction": {"live": 1, "NW": 0.1, "NWU": 1e-6},
        }
        for block, schema, rev, a, t in itertools.product(
            parent.parent.blocks(), ("generic", "descriptive"), range(2), range(2), range(2)
        )
    ]
    result = accounts(cells, True)
    assert result["architectural_null"]["passed"]
    assert result["survival_account"]["eligible_panels"] == 16
    assert not result["survival_account"]["whole_passed"]
    assert result["survival_account"]["compatible_panels"] == 0
    assert not accounts(cells, False)["architectural_null"]["passed"]
