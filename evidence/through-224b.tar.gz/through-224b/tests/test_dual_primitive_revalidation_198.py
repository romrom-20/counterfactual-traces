"""Independent public-layer dual-hook code path against the frozen forecast assembly."""

import torch
from check_dual_primitive_reconstruction_198 import reconstruct
from first_block_response_196 import ARMS, FACTORS, local_directions
from transformers import Qwen2Config, Qwen2ForCausalLM


def test_all_dual_hook_operation_scopes_match_assembly():
    torch.manual_seed(197)
    config = Qwen2Config(
        hidden_size=32,
        intermediate_size=64,
        num_hidden_layers=2,
        num_attention_heads=4,
        num_key_value_heads=2,
        vocab_size=900,
    )
    config._attn_implementation = "eager"
    model = Qwen2ForCausalLM(config).eval().requires_grad_(False)
    layer = model.model.layers[0]
    x = torch.randn(1, 7, 32) * 0.3
    dx = torch.zeros_like(x)
    dx[:, 3] = torch.randn(32) * 0.5
    mask = torch.full((1, 1, 7, 7), torch.finfo(x.dtype).min).triu(1)
    rope = model.model.rotary_emb(x, torch.arange(7)[None])
    directions, _ = local_directions(
        layer, {"x": x, "attention_mask": mask, "position_embeddings": rope}, dx, 3
    )
    expected = layer(x, attention_mask=mask, position_embeddings=rope)
    for arm in ARMS[:-1]:
        enabled = FACTORS if arm == "exact_block" else () if arm == "linear" else (arm,)
        primal, derivative = reconstruct(layer, x, dx, mask, rope, enabled)
        assert torch.equal(primal, expected)
        assert torch.max(abs(derivative - directions[arm])) <= 1e-5
        assert torch.count_nonzero(derivative[:, :3]) == 0
