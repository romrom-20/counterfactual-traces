"""Feedback can survive a fixed multiplying branch; accounts must not rescue failures."""

import itertools

import numpy as np
from audit_factorial_curvature_routes_189 import accounts, blocks


def test_normalization_restores_difference_with_fixed_up():
    states = np.array([[1.0, 2.0], [2.0, 1.0]])
    shift = np.array([0.7, 0.0])
    up = np.array([1.3, 0.5])
    readout = np.array([1.0, -0.4])
    output = states * up
    corrected = (states + shift) * up
    assert abs(np.diff((corrected - output) @ readout)[0]) < 1e-14

    def norm(x):
        return x / np.sqrt(np.mean(x * x, axis=1, keepdims=True) + 1e-6)

    assert abs(np.diff((norm(corrected) - norm(output)) @ readout)[0]) > 0.1


def test_intermediate_effect_and_ineligible_paths_are_not_successes():
    cells = [
        {
            "block": block["id"],
            "schema": schema,
            "reverse": rev,
            "assignment": a,
            "target": t,
            "kappa": {"live": 1.0, "U": 0.15, "NU": 0.15, "WU": 0.15, "NWU": 0.0},
        }
        for block, schema, rev, a, t in itertools.product(
            blocks(), ("generic", "descriptive"), range(2), range(2), range(2)
        )
    ]
    result = accounts(cells, True)
    assert not any(a["whole_passed"] for a in result["accounts"].values())
    assert result["accounts"]["norm_only_conditional"]["eligible_panels"] == 0
    assert result["accounts"]["attention_only_conditional"]["compatible_panels"] == 0
    for c in cells:
        c["kappa"]["U"] = 0.6
        c["kappa"]["WU"] = 0.6
        c["kappa"]["NU"] = 0.0
    result = accounts(cells, True)
    assert result["accounts"]["feedback_restoration"]["whole_passed"]
    assert result["accounts"]["norm_only_conditional"]["whole_passed"]
    assert not result["accounts"]["attention_only_conditional"]["whole_passed"]
    assert not any(a["whole_passed"] for a in accounts(cells, False)["accounts"].values())
