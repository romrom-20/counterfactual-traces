"""Meaningful architecture/causality checks before any frozen scientific execution."""

import torch
from first_block_response_195 import FACTORS, local_directions, source_forecast, tail
from recheck_first_block_primitive_repair_195 import assemble
from transformers import Qwen2Config, Qwen2ForCausalLM


def test_first_block_primitive_paths_and_causal_splice():
    torch.manual_seed(195)
    config = Qwen2Config(
        hidden_size=32,
        intermediate_size=64,
        num_hidden_layers=2,
        num_attention_heads=4,
        num_key_value_heads=2,
        vocab_size=900,
        rms_norm_eps=1e-6,
    )
    config._attn_implementation = "eager"
    model = Qwen2ForCausalLM(config).eval().requires_grad_(False)
    x = torch.randn(1, 7, 32) * 0.3
    dx = torch.zeros_like(x)
    dx[:, 3] = torch.randn(32) * 0.4
    mask = torch.full((1, 1, 7, 7), torch.finfo(x.dtype).min).triu(1)
    rope = model.model.rotary_emb(x, torch.arange(7)[None])
    context = {"x": x, "attention_mask": mask, "position_embeddings": rope}
    layer = model.model.layers[0]
    directions, _ = local_directions(layer, context, dx, 3)
    _, derivative = torch.func.jvp(
        lambda z: layer(z, attention_mask=mask, position_embeddings=rope), (x,), (dx,)
    )
    assert torch.max(abs(directions["linear"] - derivative)) < 1e-5
    direct_delta = layer(x + dx, attention_mask=mask, position_embeddings=rope) - layer(
        x, attention_mask=mask, position_embeddings=rope
    )
    assert torch.max(abs(directions["exact_block"] - direct_delta)) < 1e-5
    other = [0, 1, 2, 4, 5, 6]
    assert torch.equal(directions["exact_source"][:, other], directions["linear"][:, other])
    assert torch.equal(directions["exact_source"][:, 3], directions["exact_block"][:, 3])
    separate_context = {"x": x, "mask": mask, "rope": rope}
    for arm, value in directions.items():
        assert torch.count_nonzero(value[:, :3]) == 0
        if arm != "exact_source":
            enabled = FACTORS if arm == "exact_block" else () if arm == "linear" else (arm,)
            independently = assemble(layer, separate_context, dx, enabled)
            assert torch.max(abs(value - independently)) < 1e-5
    zero, _ = source_forecast(layer, context, torch.zeros_like(dx), FACTORS)
    assert torch.count_nonzero(zero) == 0


def test_tail_derivative_injection_equals_false_chain_rule():
    torch.manual_seed(196)
    config = Qwen2Config(
        hidden_size=32,
        intermediate_size=64,
        num_hidden_layers=2,
        num_attention_heads=4,
        num_key_value_heads=2,
        vocab_size=900,
    )
    config._attn_implementation = "eager"
    model = Qwen2ForCausalLM(config).eval().requires_grad_(False)
    ids = torch.tensor([[1, 2, 895, 3, 4]])
    first = []
    handle = model.model.layers[0].register_forward_hook(
        lambda m, args, out: first.append(out.detach().clone())
    )
    try:
        native = model(
            input_ids=ids, attention_mask=torch.ones_like(ids), use_cache=False, logits_to_keep=1
        )
    finally:
        handle.remove()
    direction = torch.randn_like(first[0]) * 0.05
    zero = torch.zeros(())
    primal, tangent = torch.func.jvp(
        lambda lam: tail(model, ids, first[0], direction, lam), (zero,), (torch.ones_like(zero),)
    )
    assert torch.equal(primal[1], native.logits[0, -1, [895, 830]])
    assert torch.equal(tangent[0][0], direction[0])
    # Compare a separate reverse derivative of the native public margin.
    lam = torch.zeros((), requires_grad=True)
    before = model.model.layers[1].register_forward_pre_hook(
        lambda m, args: (first[0] + lam * direction, *args[1:])
    )
    try:
        out = model(
            input_ids=ids, attention_mask=torch.ones_like(ids), use_cache=False, logits_to_keep=1
        )
        reverse = torch.autograd.grad(out.logits[0, -1, 830] - out.logits[0, -1, 895], lam)[0]
    finally:
        before.remove()
    assert abs(float(reverse) - float(tangent[1][1] - tangent[1][0])) < 1e-5
