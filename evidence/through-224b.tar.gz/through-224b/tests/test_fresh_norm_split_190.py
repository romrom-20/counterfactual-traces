"""Final scalar readout and internal causal paths must stay distinguishable."""

import itertools

import numpy as np
from audit_fresh_norm_split_190 import accounts, blocks, norm_targets


def test_final_and_internal_target_sets_are_disjoint_and_complete():
    means = {
        f"N_{site}_{kind}": np.ones((2, 1), np.float32)
        for site, kind in itertools.product(range(1, 29), ("pre", "post"))
    }
    means["N_final"] = np.ones((2, 1), np.float32)
    assert set(norm_targets(means, "FU")) == {"N_final"}
    assert len(norm_targets(means, "IU")) == 56
    assert set(norm_targets(means, "FU")) | set(norm_targets(means, "IU")) == set(
        norm_targets(means, "NU")
    )
    assert norm_targets(means, "U") == norm_targets(means, "live") == {}


def test_final_account_does_not_require_or_imply_internal_success():
    cells = [
        {
            "block": b["id"],
            "schema": s,
            "reverse": r,
            "assignment": a,
            "target": t,
            "kappa": {"live": -2.0, "U": 0.01, "FU": 1.0, "IU": 0.02, "NU": 1.0},
        }
        for b, s, r, a, t in itertools.product(
            blocks(), ("generic", "descriptive"), range(2), range(2), range(2)
        )
    ]
    result = accounts(cells, True)
    assert result["accounts"]["norm_conditioned_sign_reversal"]["whole_passed"]
    assert result["accounts"]["final_readout_explanation"]["whole_passed"]
    assert not result["accounts"]["internal_norm_explanation"]["whole_passed"]
    assert not any(v["whole_passed"] for v in accounts(cells, False)["accounts"].values())
