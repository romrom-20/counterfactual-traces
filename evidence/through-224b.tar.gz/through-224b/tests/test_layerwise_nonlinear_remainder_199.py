"""Sign, full-state telescoping, and the necessary nonlinear readout remainder."""

import torch


def test_remainder_budget_with_zero_oracle_start_and_nonlinear_readout():
    torch.manual_seed(199)
    weight = torch.randn(6, 6, dtype=torch.float64) / 3
    readout = torch.randn(6, dtype=torch.float64)
    functions = (
        lambda x: x + 0.2 * torch.sin(x),
        lambda x: x + 0.3 * torch.tanh(x @ weight),
        lambda x: x + 0.25 * torch.nn.functional.silu(x @ weight) * x,
    )
    head = lambda x: ((x[-1] / torch.sqrt(x[-1].square().mean() + 1e-6)) * readout).sum()
    x = torch.randn(2, 6, dtype=torch.float64, requires_grad=True)
    edited = x.detach().clone()
    edited[1] += torch.randn(6, dtype=torch.float64) * 0.8
    false, true = [], []
    a, b = x, edited
    for function in functions:
        a, b = function(a), function(b)
        false.append(a)
        true.append(b)
    delta = [b - a.detach() for a, b in zip(false, true)]
    prediction = [delta[0]]
    remainder = []
    for i in (1, 2):
        _, linear_pred = torch.func.jvp(functions[i], (false[i - 1].detach(),), (prediction[-1],))
        _, linear_actual = torch.func.jvp(functions[i], (false[i - 1].detach(),), (delta[i - 1],))
        prediction.append(linear_pred)
        remainder.append(delta[i] - linear_actual)
        error_previous = delta[i - 1] - prediction[i - 1]
        _, transported_error = torch.func.jvp(
            functions[i], (false[i - 1].detach(),), (error_previous,)
        )
        assert torch.max(abs(delta[i] - prediction[i] - transported_error - remainder[-1])) < 1e-10
    assert torch.count_nonzero(delta[0] - prediction[0]) == 0
    error = delta[-1][-1] - prediction[-1][-1]
    unit = error / torch.linalg.vector_norm(error)
    projection = (false[-1][-1] * unit).sum()
    margin = head(false[-1])
    for scalar in (projection, margin):
        adjoints = torch.autograd.grad(scalar, tuple(false), retain_graph=True)
        budget = sum((w * r).sum() for w, r in zip(adjoints[1:], remainder))
        if scalar is projection:
            assert abs(budget - torch.linalg.vector_norm(error)) < 1e-10
        else:
            actual_margin_delta = head(true[-1]) - margin.detach()
            predicted_margin_delta = (adjoints[-1] * prediction[-1]).sum()
            readout_remainder = actual_margin_delta - (adjoints[-1] * delta[-1]).sum()
            assert (
                abs(budget + readout_remainder - (actual_margin_delta - predicted_margin_delta))
                < 1e-10
            )
            assert abs(readout_remainder) > 1e-7
