"""Analytic curvature is local to false and strict prospective timing stays enforced."""

import numpy as np
import torch
from audit_one_sided_curvature_forecast_191 import coefficients as independent
from audit_one_sided_gain_forecast_186 import ordered
from run_one_sided_curvature_forecast_191 import coefficients


def test_false_only_derivatives_agree_with_autograd():
    x = torch.tensor([-4.0, -1.0, 0.0, 0.5, 2.0, 4.0], dtype=torch.float64, requires_grad=True)
    y = x * torch.sigmoid(x)
    derivs = []
    for _ in range(3):
        y = torch.autograd.grad(y.sum(), x, create_graph=True)[0]
        derivs.append(y.detach().numpy())
    xn = x.detach().numpy().astype(np.float32)
    yn = (xn / (1 + np.exp(-xn))).astype(np.float32)
    maps = coefficients(
        {
            f"{site}_{name}": v
            for site in range(1, 29)
            for name, v in [("input", xn), ("output", yn)]
        }
    )[1]
    other = independent(xn, yn)
    for name, d, factor in zip(("slope", "second", "third"), derivs, (1, 2, 6)):
        assert np.max(abs(maps[name] - d / factor)) < 1e-7
        assert np.max(abs(maps[name] - other[name])) < 1e-7
    assert np.array_equal(maps["center"], xn) and np.array_equal(maps["intercept"], yn)


def test_native_true_measurement_must_follow_global_manifest():
    assert ordered(
        ["2026-10-14T12:00:00+00:00"], "2026-10-14T12:01:00+00:00", ["2026-10-14T12:02:00+00:00"]
    )
    assert not ordered(
        ["2026-10-14T12:00:00+00:00"], "2026-10-14T12:01:00+00:00", ["2026-10-14T12:00:30+00:00"]
    )
