"""Midpoint updates may use forecasts, but must keep the measured false anchor."""

import itertools

import numpy as np
from audit_one_sided_gain_forecast_186 import ARMS, blocks, estimands, ordered
from run_one_sided_gain_forecast_186 import anchors_from_false, slope_at


def test_anchor_stays_false_after_gain_update():
    false = {
        f"{site}_{kind}": np.array([-0.5, 0.8], np.float32)
        if kind == "input"
        else np.array([-0.18877, 0.55198], np.float32)
        for site in range(1, 29)
        for kind in ("input", "output")
    }
    predicted = {f"{site}_input": np.array([1.0, 2.0], np.float32) for site in range(1, 29)}
    anchors = anchors_from_false(false, predicted)
    for site, a in anchors.items():
        assert np.array_equal(a["center"], false[f"{site}_input"])
        assert np.array_equal(a["intercept"], false[f"{site}_output"])
        assert np.array_equal(
            a["intercept"] + a["slope"] * (false[f"{site}_input"] - a["center"]),
            false[f"{site}_output"],
        )
        midpoint = (
            false[f"{site}_input"].astype(np.float64)
            + predicted[f"{site}_input"].astype(np.float64)
        ) / 2
        assert np.array_equal(a["slope"], slope_at(midpoint))


def test_oracle_success_is_not_prospective_and_cannot_rescue_prediction():
    records = []
    for block, schema, rev, a, t in itertools.product(
        blocks(), ("generic", "descriptive"), range(2), range(2), range(2)
    ):
        supported = a == t
        sign = 1 if supported else -1
        fm = 0.2 * sign
        tm = fm + 2 + 0.3 * sign

        def m(v):
            return {"false_score": 0.0, "true_score": v, "log_odds": v}

        patches = [
            {
                "arm": arm,
                "bit": bit,
                "margin": m(fm if bit == 0 else tm + (0 if arm == "oracle" else 0.3)),
            }
            for arm, bit in itertools.product(ARMS, range(2))
        ]
        records.append(
            {
                "block": block["id"],
                "schema": schema,
                "reverse": rev,
                "assignment": a,
                "target": t,
                "bases": [{"facts": {"supported": supported}}],
                "native_false": {"margin": m(fm)},
                "native_true": {"margin": m(tm)},
                "patches": patches,
            }
        )
    result = estimands(records, True)
    assert result["accounts"]["individual_matching"]["oracle"]["whole_passed"]
    assert not result["accounts"]["individual_matching"]["oracle"]["prospective"]
    assert not result["accounts"]["individual_matching"]["J2"]["whole_passed"]
    assert result["accounts"]["balanced_matching"]["J2"]["whole_passed"]


def test_ordering_rejects_early_native_true():
    before = ["2026-10-14T09:00:00+00:00", "2026-10-14T09:02:00+00:00"]
    assert ordered(before, "2026-10-14T09:03:00+00:00", ["2026-10-14T09:04:00+00:00"])
    assert not ordered(before, "2026-10-14T09:03:00+00:00", ["2026-10-14T09:01:00+00:00"])
