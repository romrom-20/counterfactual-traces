"""Finite-block budget, public-hook agreement, zero edit, and causal prefix checks."""

import torch
from public_ranked_block_response_200 import response
from ranked_block_response_200 import forecast, observe, source
from transformers import Qwen2Config, Qwen2ForCausalLM


def test_sparse_block_response_matches_independent_public_hooks():
    torch.manual_seed(200)
    config = Qwen2Config(
        hidden_size=32,
        intermediate_size=64,
        num_hidden_layers=4,
        num_attention_heads=4,
        num_key_value_heads=2,
        vocab_size=900,
    )
    config._attn_implementation = "eager"
    model = Qwen2ForCausalLM(config).eval().requires_grad_(False)
    ids = torch.tensor([[1, 2, 895, 3, 4]])
    edited = torch.tensor([[1, 2, 830, 3, 4]])
    states, context, scores = observe(model, ids)
    edit = model.model.embed_tokens(edited) - context["input"]
    initial = source(model, context, states, edit)
    for finite, finite_head in (
        (set(), False),
        (set(), True),
        ({3}, True),
        ({2, 4}, True),
        ({2, 3, 4}, True),
    ):
        predicted, ds, stats = forecast(model, context, states, initial, finite, finite_head)
        primal, independent = response(model, context["input"], edit, finite, finite_head)
        assert torch.max(abs(primal[0] - torch.stack(states)[:, 0])) < 1e-5
        assert torch.max(abs(primal[1] - scores)) < 1e-5
        assert torch.max(abs(predicted - independent[0])) < 1e-5
        assert torch.max(abs(ds - independent[1])) < 1e-5
        assert stats["local_finite_block_calls"] == len(finite)
        assert stats["local_block_ad_calls"] == 3 - len(finite)
        assert torch.count_nonzero(predicted[:, :2]) == 0
    true_states, _, true_scores = observe(model, edited)
    predicted, ds, _ = forecast(model, context, states, initial, {2, 3, 4}, True)
    assert (
        torch.max(abs(predicted + torch.stack(states)[:, 0] - torch.stack(true_states)[:, 0]))
        < 1e-5
    )
    assert torch.max(abs(ds + scores - true_scores)) < 1e-5
    zero_initial = source(model, context, states, torch.zeros_like(edit))
    for finite in (set(), {2, 3, 4}):
        predicted, ds, _ = forecast(model, context, states, zero_initial, finite, True)
        assert torch.count_nonzero(predicted) == 0
        assert torch.count_nonzero(ds) == 0
